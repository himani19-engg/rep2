package solRetailIHM.ScenarioMainClass;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import solRetailIHM.ProjSpecFunctions.*;
import solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41;
import solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarFinanceNonEc41;
import solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail;
import solRetailIHM.Utilities.BaseClass;
import solRetailIHM.Utilities.UniversalMethods;

import java.io.File;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


public class ScenarioMain_UK extends UniversalMethods {
	
	    final String URL;
		final String Brand;
		final String Country;
		final String Digital1;
		final String Digital1Flag;
		final String ScenarioName;
		final String PaymentMode;
		final String PaymentType;
		final String HomePageChecks;
		final String VehicleChoice;
		final String TrimPageCheck;
		final String BasketPageCheck;
		final String ConfigPageCheck;
		final String PersoV;
		final String PostalCode;
		final String City;
		final String NIF;
		final String Retailer;
		final String EmailId;
		final String Password;
		final String Name;
		final String Phone;
		final String Plate;
		final String Address;
		final String Fwidget;
		final String MopValidation;
		final String PXCheckoutPage;
		final String PXConfigPage;
        final String PXBO;
        final String Catalan;
        final String CarNumber;
		final String CarDate;
		final String CVC; 
        final String PromoCode;
	
		final String DealerPage;
		
		
		public static WebDriver driver;
		public static ExtentHtmlReporter htmlReporter;
		public static ExtentReports extent;
		public static ExtentTest logger;
		public static Object [] carPrices;
		public static String resultDirectory;
		
		
		public ScenarioMain_UK(String Brand, 
				            String Country, 
				            String Digital1,
				            String Digital1Flag,
				            String URL, 
				            String ScenarioName,
				            String PaymentMode,
				            String PaymentType,
				            String HomePageChecks,
				            String VehicleChoice,
				            String TrimPageCheck,
				            String BasketPageCheck,
				            String ConfigPageCheck,
				            String PersoV,
				            String PostalCode,
				            String City,
				            String NIF,
				            String Retailer,
				            String EmailId,
				            String Password,
				            String Name,
	                        String Phone,
	                        String Plate,
	                        String Address,
	                        String Fwidget,
	                        String MopValidation,
	                        String PXCheckoutPage,
	                        String PXConfigPage,
	                        String PXBO,
	                        String Catalan,
	                        String CarNumber,
		                    String CarDate,
		                    String CVC,
		                    String PromoCode,
							   String DealerPage) {
			super();
			this.Brand = Brand;
			this.Country = Country;
			this.Digital1 = Digital1;
			this.Digital1Flag = Digital1Flag; 
			this.URL = URL;
			this.ScenarioName = ScenarioName;
			this.PaymentMode = PaymentMode;
			this.PaymentType = PaymentType;
			this.HomePageChecks = HomePageChecks;
			this.VehicleChoice = VehicleChoice;
			this.TrimPageCheck = TrimPageCheck;
			this.BasketPageCheck = BasketPageCheck;
			this.ConfigPageCheck = ConfigPageCheck;
			this.PersoV = PersoV;
			this.PostalCode = PostalCode;
			this.City = City;
			this.NIF = NIF;
			this.EmailId = EmailId;
			this.Password = Password;
			this.Name = Name;
			this.Phone = Phone;
			this.Plate = Plate; 
			this.Address = Address;
			this.Fwidget = Fwidget;
			this.MopValidation = MopValidation;
			this.Retailer = Retailer;
			this.PXCheckoutPage=PXCheckoutPage;
			this.PXConfigPage = PXConfigPage ;
            this.PXBO = PXBO;
            this.Catalan = Catalan;
            this.CarNumber = CarNumber;
			this.CarDate = CarDate;
			this.CVC = CVC;
			this.PromoCode = PromoCode;
			this.DealerPage= DealerPage;
		}
		
		@BeforeTest
		public void SetUp() throws Exception
		{
		BaseClass bc = new BaseClass();
		bc.projectSetup();	
		
		String dateName = new SimpleDateFormat("EEE_dd_MMM_yyyy_HH_mm_ss").format(new Date());
		System.out.println(dateName);
		resultDirectory = Paths.get(System.getProperty("user.dir"),"test-output", "SolRetailIHM", "Results_"+ dateName+ "").toString();
		System.out.println(resultDirectory);
		
		 File file = new File(resultDirectory);
	       // true if the directory was created, false otherwise
	        if (file.mkdirs()) {
	            System.out.println("Directory is created!");
	        } else {
	            System.out.println("Failed to create directory!");
	        }
			
		
		
	        htmlReporter = new ExtentHtmlReporter(resultDirectory +"/NRTCampaignSolRetailIHM_"+ dateName +".html");
			// Create an object of Extent Reports
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			
			htmlReporter.config().setReportName("NRT QA auto Sol Retail IHM");
			htmlReporter.config().setCSS(".r-img { width: 100%; }");
			
			//String ExtentConfig = System.getProperty("user.dir") + "/src/test/javasolo2c/Utilities/extent-config.xml";
			
			htmlReporter.loadXMLConfig(new File(Paths.get(System.getProperty("user.dir"),"src", "test", "java", "soloRetailIHM", "Utilities","extent-config.xml").toString()), true);
							
		
		}
		

		@Test(priority = 1, description = "Scenario E2E", enabled = true)
		public void Sceanrio() throws Exception
		{
		  	
//			DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
//			desiredCapabilities.setCapability("screenResolution", "1920x1080");
//			desiredCapabilities.setBrowserName(BrowserType.CHROME);
//						
//			ChromeOptions options = new ChromeOptions();
//	    	options.setExperimentalOption("excludeSwitches", new String[] {"enable-automation"});
//			options.addArguments("--disable-web-security");
//			options.addArguments("--no-proxy-server");
//			options.addArguments("start-maximized");
//			options.addArguments("--no-sandbox");
//	        options.addArguments("--disable-dev-shm-usage");
//	        options.addArguments("--no-sandbox");
//	        options.addArguments("--disable-gpu");
//			Map<String, Object> prefs = new HashMap<String, Object>();
//			prefs.put("credentials_enable_service", false);
//			prefs.put("profile.password_manager_enabled", false);
//			options.setExperimentalOption("prefs", prefs);
//			desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);
//			driver= new RemoteWebDriver(new java.net.URL("http://localhost:4444/wd/hub"), desiredCapabilities);
			
			
			ChromeOptions options=new ChromeOptions();
			options.setExperimentalOption("excludeSwitches", new String[] {"enable-automation"});
			options.addArguments("--disable-web-security");
			options.addArguments("--no-proxy-server");
			//options.addArguments("start-maximized");
			options.addArguments("--no-sandbox");
			options.addArguments("chrome.switches", "--disable-extensions --disable-extensions-file-access-check --disable-extensions-http-throttling");
			//options.addArguments("--incognito");
			options.addArguments("force-device-scale-factor=0.75");
			options.addArguments("high-dpi-support=0.75");
			//options.addArguments("--incognito");
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", prefs);
			driver=new ChromeDriver(options);
			driver.manage().window().setSize(new Dimension(1920, 1080));
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			
		 
		  logger = extent.createTest(ScenarioName);
		  
		  System.out.println("ScenarioName : " + ScenarioName);
		  		 
          //Login to Sol RETAIL IHM
          LoginApplicationRetail.login(resultDirectory,driver, extent, logger, Digital1, Digital1Flag, URL, Brand, Country);
		 
		  //Check Home Page
          if (HomePageChecks.equals("yes")) {
        	//CheckHomePage.HomePageDetails(resultDirectory, driver, extent, logger, Country, EmailId, Name, Phone, Address, Password, Brand);
          }
		  //workflow cash non e-C41
	  
		  if ((PaymentMode.equals("Cash")) && (VehicleChoice.equals("non-ec41"))) {
		  //Choose vehicle
		   carPrices = ChooseCarCashNonEc41.chooseCarModel(resultDirectory, driver, extent, logger, Brand, Country,PaymentMode);
		   System.out.println(carPrices[0]);
		   System.out.println(carPrices[1]);
					  
		  //Check TrimPage
		   if(TrimPageCheck.equalsIgnoreCase("yes")) {
//		        CheckTrimPage.TrimPageCheck(resultDirectory,  driver, extent, logger, Brand, Country) ;
//					  
//					  
//		  carPrices = ChooseCarCashNonEc41.chooseCarModel(resultDirectory, driver, extent, logger, Country);
//		  System.out.println(carPrices[0]);
//		  System.out.println(carPrices[1]);
			}		  
					  
			   ChooseCarCashNonEc41.chooseCarType(resultDirectory, driver, extent, logger, Brand, Country, VehicleChoice, PaymentMode);
	/*			  
			 //Check ConfigPage
			 if(ConfigPageCheck.equalsIgnoreCase("yes")) {
			    CheckConfigPage.ConfigPageDetails(resultDirectory, driver, extent, logger, Brand, Country, VehicleChoice, PostalCode, EmailId, Password, Name, Phone, Address);
			 }
			  
	         //choose car options
			 if (PersoV.equals("yes")) {
				 ChooseCarOptions.CarOptions(resultDirectory, driver, extent, logger, Brand, Country);
			  }				  
			  
			 //part exchange config page
			  if (PXConfigPage.equals("yes")) {
				  ReprisePXconfig.FillReprise(resultDirectory, driver, extent, logger, Brand, Country, PostalCode, EmailId, Name,Phone, Plate);
			  
			  }
			 		  	  
     		 //Go to Basket	
			  GoToBasket.goToBasket(resultDirectory, driver, extent, logger, Country, PaymentMode, VehicleChoice); 
			  if(BasketPageCheck.equalsIgnoreCase("yes")) {
				  CheckBasketPage.BasketTrimPageCheck(resultDirectory, driver, extent, logger, Brand, Country, VehicleChoice, EmailId, Password);
				  GoToBasket.goToBasket(resultDirectory, driver, extent, logger, Country, PaymentMode, VehicleChoice); 
			  }
			  
			 //Validate Basket
			   ValidateBasket.basketVerification(resultDirectory,driver, extent, logger, Country, PaymentMode, VehicleChoice, PostalCode,PromoCode);
		
			   
			  //Login
     		  LoginUser.loginAccount(resultDirectory,driver, extent, logger, Country, PaymentMode, VehicleChoice,EmailId, Password);
     		  
     		  //Check Personnal Info
			  CheckPersonnalInfoCash.personalDetails(resultDirectory,driver, extent, logger,Country, VehicleChoice, PostalCode, City, NIF, EmailId, Address);
					  
			  
			  //Choose Dealer
			  ChooseDealerCash.searchAndSelectRetailer(resultDirectory, driver, extent, logger, Country, VehicleChoice, Retailer);
			  
			  
			  //Choose Reprise
			  RepriseCashPXcheckout.FillReprise(resultDirectory,driver, extent, logger, Country, PaymentMode, VehicleChoice, Brand, Plate, PXConfigPage, PXCheckoutPage);

			  
			  //Validate Order 
			  ValidateOrderCash.orderValidation(resultDirectory, driver, extent, logger, Country, Catalan);
			  
			  //PaymentCash
			  PaymentCash.Payment(resultDirectory, driver, extent, logger, MopValidation, CarNumber, CarDate, CVC);

		*/  
     } 
		  
		  //workflow finance non e-c41
		  if ((PaymentMode.equals("Finance")) && (VehicleChoice.equals("non-ec41"))) {
			  
			  //Choose vehicle
			  carPrices = ChooseCarFinanceNonEc41.validateBrandAndPrice_Finance_Model(resultDirectory, driver, extent, logger, Brand,Country, VehicleChoice);
			 
			  System.out.println(carPrices[0]);
			  System.out.println(carPrices[1]);
			  
			  ChooseCarFinanceNonEc41.validateBrandAndPrice_Finance_Type(resultDirectory, driver, extent, logger, Brand,Country, VehicleChoice);
			  Thread.sleep(6000);
			  
			  if (PersoV.equals("yes")) {
            	  				  
				 //ChooseCarOptions.CarOptions(resultDirectory, driver, extent, logger, Brand, Country);
				  
			  }
              
              //financial widget 
              if (Fwidget.equals("yes")) {
              financialWidget.ModifyFinancialInfo(driver, extent, logger, Country, PaymentMode, VehicleChoice, Brand);}
              
              //part exchange config page
			  if (PXConfigPage.equals("yes")) {
				  
				  ReprisePXconfig.FillReprise(resultDirectory, driver, extent, logger, Brand, Country,PaymentMode, PostalCode, EmailId, Name,Phone, Plate);
			  
			  }
		 
     		  //Go to Basket		  
			  GoToBasket.goToBasket(resultDirectory,driver, extent, logger, Country, PaymentMode, VehicleChoice,DealerPage,Brand,ScenarioName);
			  
			  //Validate Basket
			  ValidateBasket.navigateToDealerPage(resultDirectory,driver, extent, logger, Brand, Country, PaymentMode, VehicleChoice, PostalCode, DealerPage);

			  //Choose Dealer
			  ChooseDealerFinance.searchAndSelectRetailer(driver, extent, logger, Country, City);
			  
			  //Login
			  LoginUser.loginAccount(resultDirectory,driver, extent, logger, Brand, Country,PaymentMode,VehicleChoice, EmailId, Password);
			  
			  //Check Personnal Info
			  CheckPersonnalInfoFinance.personalDetails(resultDirectory, driver, extent, logger, Brand, Country, EmailId, Name, Phone, Address);
			  
			  //part exchange checkout page
			  if ((Country.equals("FR") && (PXCheckoutPage.equals("yes")))) {
				  
				  ReprisePXconfig.FillReprise(resultDirectory, driver, extent, logger, Brand, Country, PaymentMode, PostalCode, EmailId, Name,Phone, Plate);
			  
			  }
			 
			  //Mop checks
			  ValidateOrderFinance.orderValidation(resultDirectory, driver, extent, logger, Brand, Country, MopValidation,PaymentMode, ScenarioName, EmailId, PostalCode, City, Phone, Name);
			  
			  //Confirm order
			  if (MopValidation.equalsIgnoreCase("yes")) {
			  FinaliseOrderFinance.orderValidation(driver, extent, resultDirectory,logger, Brand, Country);
			  }
        
		  
		
		  }
		  
		  //Thread.sleep(3000);
		  //driver.quit();
		  //Thread.sleep(3000);
		  
	    }
		
				
		/*@AfterTest
		public static void closeBrowser() {
			extent.flush();
			
			
		}*/
		   
			
}
