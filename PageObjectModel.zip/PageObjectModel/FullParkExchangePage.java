package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.nio.file.Paths;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class FullParkExchangePage extends UniversalMethods {
	WebDriver driver = null;
	
	By GoToReprise = By.xpath("(//*[@class ='submit-title'])[1]");
	By GoToRepriseValidate = By.xpath("//*[@type ='submit']");
	
	By RepriseYesButton = By.xpath("//*[@class ='tradeIn-bloc-entry'] / Label [1]/ div/ div");
	By RepriseNoButton = By.xpath("//*[@class ='tradeIn-bloc-entry'] / Label [2]/ div/ div");
	By ConfirmRepriseButton = By.xpath("//*[@class ='btn btn-valider']");
	By ContinueRepriseButton = By.id("next-assurance");
	By ImmatriculationField = By.xpath("//*[@id= 'enter-vrm']");
	By ConfirmOfferConfirmationButton = By.id("button-init-immat");
	By ConfirmNextButton = By.xpath("//* [@class = 'form-nav'] /div/div[2]/div/button");
	By VersionRepriseList = By.id("version_chosen");
	By FirstVersionReprise = By.xpath("//* [@id = 'version_chosen'] / div / ul / li[2]");
	By ConfirmVersionRepriseButton = By.id("button-version");
	By OverAllMileageField = By.id("overallMileage");
	By AnnualMileageField = By.id("annualMileage");
	By MileageConfirmation = By.id("button-car-state");
	By CarOwnerConfirmationYes = By.xpath("//* [@id = 'registrationCertificateName1']/..");
	By CarOwnerValidation = By.id("button-car-state");
	By CarGageNo = By.xpath("//* [@id = 'pledged2']/..");
	By CarGageConfirmation = By.id("button-car-state");
	By CarCandriveYes =By.xpath("//* [@id = 'roll1']/..");
	By CarCanDriveConfirmation = By.id("button-car-state");
	By CarWreckedNo =By.xpath("//* [@id = 'state2']/..");
	By CarWreckedConfirmation = By.id("button-car-state");
	By ImportedCarNo = By.xpath("//* [@id = 'import2']/..");
	By ImportedCarConfirmation = By.id("button-car-state");
	By TechnicalControlYes = By.xpath("//* [@id = 'technicalControl1']/..");
	By TechnicalControlConfirmation = By.id("button-car-state");
	By ElectricStatusYes = By.xpath("//* [@id = 'electronicDamage1']/..");
	By MecanicalStatusYes = By.xpath("//* [@id = 'mechanicalDamage1']/..");
	By VehicleStatusConfirmation = By.id("button-car-state");
	By MaintenanceYes = By.xpath("//* [@data-value = '1']");
	By MaintenanceConfirmation = By.id("button-car-state");
	By CarInternalStatus = By.xpath("//* [@data-value = '1']");
	By CarInternalStatusConfirmation = By.id("button-car-state");
	By CarFrontTireStatus = By.xpath("//*[@data-scope='frontTiresCondition' and @data-value = '1']"); 
	By CarBackTireStatus = By.xpath("//*[@data-scope='rearTiresCondition' and @data-value = '1']");
	By CarTireStatusConfirmation = By.id("button-car-state");
	By NoDamageCheckbox = By.xpath("//* [@id = 'no-damage']/../..");
	By NoDamageConfirmationButton = By.id("button-car-state");
	By NoExternalDamages = By.id("no_default_row"); 
	By VehicleStatusSummaryCheckBox = By.xpath("//* [@class = 'legal-notice-check']");
	By NextStepStatusSummary = By.id("button-legal-notice");
	By InterstedInOffer = By.id("add_to_cart");
	By AttacheFiles = By.id("next-path");
	By CarteGrisePhot1 = By.id("fileToUpload1");
	By CarteGrisePhot2 = By.id("fileToUpload2");
	By CarPicture1 = By.id("fileToUpload3");
	By CarPicture2 = By.id("fileToUpload4");
	By CarPicture3 = By.id("fileToUpload5");
	By CarPicture4 = By.id("fileToUpload6");
	By CarPicture5 = By.id("fileToUpload7");
	By AuthorisationButton = By.xpath("//* [@id = 'accept_info']/..");
	By SendAttachedFilesButton = By.id("button-pj");
	By FinalisePaymentButton = By.id("button-assurance");
	By nextstepButton = By.xpath("//* [@class = 'btn btn-valider ng-star-inserted']");
	By UserConditionsCheckBox = By.xpath("//* [@for = 'optinTermsOfUse']");
	By OfferValidationDurationCheckbox = By.xpath("//* [@for = 'optionTermOfDeliveryDate']");
	By OrderWithPaymentObligationButton = By.xpath("//* [@class = 'row buttons mrg-px-t-4 ng-star-inserted'] /div/button");
	By CardNumber = By.xpath("//* [@name = 'cardnumber']");
	By ExpirationDate = By.xpath("//* [@id = 'root'] ");
	By ConfirmationMessage = By.xpath("//*[contains(text(),'commande ')]");
	
	//Specific Selectors AC
	By CooseBrandBox = By.xpath("//* [@id='brand_chosen']");
	By CooseBrandBoxPXCK = By.xpath("//* [@id='brand_chosen']/a/input");
	//By CooseBrandBox = By.linkText("---");
	By CooseBrand = By.xpath("//* [@data-option-array-index = '1']");
	By ChooseBrandButton = By.xpath("//* [@id = 'button-init-make']");
	By ChooseModelBox = By.id("model_chosen");
	By ChooseFirtIndex = By.xpath("//* [@data-option-array-index = '1']");
	By ChooseSecondIndex = By.xpath("//* [@data-option-array-index = '2']");
	By ChooseCirculationMonthBox = By.id("month_chosen");
	By ChooseFirtIndexCirculationmonth = By.xpath("//*[@id = 'month_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseCirculationYearBox = By.id("year_chosen");
	By ChooseFirtIndexCirculationYear = By.xpath("//*[@id = 'year_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseBodyBox = By.id("body_chosen");
	By ChooseBodyBoxPXCK = By.xpath("//* [@id='body_chosen']/a/input");
	By ChooseFirtIndexBody = By.xpath("//*[@id = 'body_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseNumberDoorBox = By.id("door_chosen");
	By ChooseNumberDoorBoxPXCK = By.xpath("//* [@id='door_chosen']/a/input");
	By ChooseFirtIndexNumberDoor = By.xpath("//*[@id = 'door_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseFuelBox = By.id("fuel_chosen");
	By ChooseFirtIndexFuel = By.xpath("//*[@id = 'fuel_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseGearBox = By.id("gear_chosen");
	By ChooseFirtIndexGear = By.xpath("//*[@id = 'gear_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseFiscalPowerBox = By.id("fiscalPower_chosen");
	By ChooseFirstIndexFiscalPower = By.xpath("//*[@id = 'fiscalPower_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseEnginePowerBox = By.id("enginePower_chosen");
	By ChooseFirstIndexEnginePower = By.xpath("//*[@id = 'enginePower_chosen'] /div/ul//* [@data-option-array-index = '1']");
	By ChooseOptionsConfirmationButton = By.id("button-car-detail");
    By ConfirmVersionChoice = By.id("button-version");
    By ChooseVersionChoicePXCG = By.xpath("//* [@id='version_chosen']/a/input");
    
    By ChooseNoReprise = By.xpath("//*[contains(@class, 'no-tradeIn')]");
    By ChooseNoRepriseYes = By.id("FO.POPIN.REPRISE.CONTINUE.CONFIRM.YES");
	
	//Specific Selectors AC et DS
	By ContinuetoattachedFielesButton = By.id("next-assurance");
	
	
	
	
	public FullParkExchangePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void GoToReprise() throws InterruptedException {
		System.out.println("Clicked on yes for Reprise");
		clickElement(driver, GoToReprise);
		Thread.sleep(500);
	}
	
	public void GoToRepriseValidate() throws InterruptedException {
		System.out.println("Clicked on yes for Reprise");
		clickElement(driver, GoToRepriseValidate);
		Thread.sleep(500);
	}
	
	public void ClickRepriseYes() throws InterruptedException {
		System.out.println("Clicked on yes for Reprise");
		clickElement(driver, RepriseYesButton);
		Thread.sleep(1000);
	}
	
	public void ClickRepriseNo() throws InterruptedException {
		System.out.println("Clicked on No for Reprise");
		clickElement(driver, RepriseNoButton);
		Thread.sleep(1000);
	}
	public void ClickConfirmRepriseButton() throws InterruptedException {
		System.out.println("Clicked on Confiorm Reprise");
		clickElement(driver, ConfirmRepriseButton);
		Thread.sleep(1000);
	}
	
	public void ClickOnContinueRepriseButton() throws InterruptedException {
		System.out.println("Clicked on Continue Reprise Button");
		clickElement(driver, ContinueRepriseButton);
		Thread.sleep(1000);
	}
	
	public void FillImmatriculation(String Plate) throws InterruptedException {
		System.out.println("Entered Immatriculation");
		enterData(driver, ImmatriculationField, Plate); 
		Thread.sleep(3000);

	}
	
	public void ClickOnContinueOfferRepriseButton() throws InterruptedException {
		System.out.println("Clicked on Offer Continue Reprise Button");
		clickElement(driver, ConfirmOfferConfirmationButton);
		Thread.sleep(1000);
	}	

	public void ClickOnNextConfirmButton() throws InterruptedException {
		System.out.println("Clicked on Next Confirm Button");
		clickElement(driver, ConfirmNextButton);
		Thread.sleep(1000);
	}	
	
	public void ChooseTheFirstVehicleFromRepriseList() throws InterruptedException {
		System.out.println("Vehicle Reprise Chosen");
		clickElement(driver, VersionRepriseList);
		clickElement(driver, FirstVersionReprise);
		clickElement(driver, ConfirmVersionRepriseButton);
		Thread.sleep(1000);
		

	}	
	
	public void EnterMileageInfo() throws InterruptedException {
		System.out.println("Mileage Info Entered");
		enterData(driver, OverAllMileageField,"100000");
		enterData(driver,AnnualMileageField,"50000");
		clickElement(driver, MileageConfirmation);
		Thread.sleep(1000);

	}
	
	public void CheckOwnerYes() throws InterruptedException {
		System.out.println("Owner Yes Checked");
		clickElement(driver, CarOwnerConfirmationYes);
		clickElement(driver, CarOwnerValidation);
		Thread.sleep(1000);
	}
	
	public void CheckCarGageNo() throws InterruptedException {
		System.out.println("Car Gage No Checked");
		clickElement(driver,CarGageNo );
		clickElement(driver, CarGageConfirmation);
		Thread.sleep(1000);
	}	
	
	public void CheckCarCanDriveYes() throws InterruptedException {
		System.out.println("Car Can Drive Checked");
		clickElement(driver, CarCandriveYes);
		clickElement(driver, CarCanDriveConfirmation);
		Thread.sleep(1000);
	}	
	
	public void CheckCarWreckedNo() throws InterruptedException {
		System.out.println("Car Not Wrecked Checked");
		clickElement(driver, CarWreckedNo);
		clickElement(driver, CarWreckedConfirmation);
		Thread.sleep(1000);
	}	
	
	public void ClickExternalDamages() throws InterruptedException {
		System.out.println("Clicked on No External Damages");
		clickElement(driver, NoExternalDamages);
		clickElement(driver, GoToRepriseValidate);
		Thread.sleep(1000);
	}	

	public void CheckCarImportedNo() throws InterruptedException {
		System.out.println("Car Not Imported Checked");
		clickElement(driver, ImportedCarNo);
		clickElement(driver, ImportedCarConfirmation);
		Thread.sleep(1000);
	}	
	
	public void CheckTechnicalControlYes() throws InterruptedException {
		System.out.println("Technical Control Checked");
		clickElement(driver, TechnicalControlYes);
		clickElement(driver, TechnicalControlConfirmation);
		Thread.sleep(1000);
	}	
	
	public void CheckVehicleStatus() throws InterruptedException {
		System.out.println("Check Vehicle Status Checked");
		clickElement(driver, MecanicalStatusYes);
		clickElement(driver, ElectricStatusYes);
		clickElement(driver, VehicleStatusConfirmation);
		Thread.sleep(1000);
	}
	
	public void CheckMaintenaceSatus() throws InterruptedException {
		System.out.println("Maintenance Checked");
		clickElement(driver, MaintenanceYes);
		clickElement(driver, MaintenanceConfirmation);
		Thread.sleep(1000);
	}
	
	public void CheckInternalStatus() throws InterruptedException {
		System.out.println("Maintenance Checked");
		clickElement(driver, CarInternalStatus);
		clickElement(driver, CarInternalStatusConfirmation);
		Thread.sleep(1000);
	}
	
	public void CheckTireStatus() throws InterruptedException {
		System.out.println("Tire Status Checked");
		clickElement(driver, CarFrontTireStatus);
		clickElement(driver, CarBackTireStatus);
		clickElement(driver, CarTireStatusConfirmation);
		Thread.sleep(1000);
	}
	
	public void CheckNodamage() throws InterruptedException {
		System.out.println("No Damage Checked");
		clickElement(driver, NoDamageCheckbox);
		clickElement(driver, NoDamageConfirmationButton);
		Thread.sleep(1000);
	}
	
	public void CheckStatusSummary() throws InterruptedException {
		System.out.println("Status Summary Checked");
		clickElement(driver, VehicleStatusSummaryCheckBox);
		clickElement(driver, NextStepStatusSummary);
		Thread.sleep(1000);
	}
	
	public void ConfirmOffer() throws InterruptedException {
		System.out.println("Offer Confirmed");
		clickElement(driver, InterstedInOffer);
		Thread.sleep(1000);
	}
	
	public void AttacheFiles() throws InterruptedException {
		System.out.println("Whent to attache File page");
		clickElement(driver, AttacheFiles);
		Thread.sleep(1000);
	}

	
	public void ProvideAttachedFiles() throws InterruptedException {
		System.out.println("Attached Files Added");
		//String PdfPath = System.getProperty("user.dir") +"\\src\\test\\java\\solRetailIHM\\Utilities\\pkimgoni.pdf";
		String PdfPath = Paths.get(System.getProperty("user.dir"),"src","test", "java", "solRetailIHM","Utilities", "pkimgoni.pdf").toString();
		WebElement EL = driver.findElement(CarteGrisePhot1);
		((RemoteWebElement) EL ).setFileDetector(new LocalFileDetector());
		EL.sendKeys(PdfPath);
		Thread.sleep(2000);
		EL = driver.findElement(CarteGrisePhot2);
		((RemoteWebElement) EL ).setFileDetector(new LocalFileDetector());
		EL.sendKeys(PdfPath);
		Thread.sleep(2000);
		EL = driver.findElement(CarPicture1);
		((RemoteWebElement) EL ).setFileDetector(new LocalFileDetector());
		EL.sendKeys(PdfPath);
		Thread.sleep(2000);
		EL = driver.findElement(CarPicture2);
		((RemoteWebElement) EL ).setFileDetector(new LocalFileDetector());
		EL.sendKeys(PdfPath);
		Thread.sleep(2000);
		EL = driver.findElement(CarPicture3);
		((RemoteWebElement) EL ).setFileDetector(new LocalFileDetector());
		EL.sendKeys(PdfPath);
		Thread.sleep(2000);
		EL = driver.findElement(CarPicture4);
		((RemoteWebElement) EL ).setFileDetector(new LocalFileDetector());
		EL.sendKeys(PdfPath);
		Thread.sleep(2000);
		EL = driver.findElement(CarPicture5);
		((RemoteWebElement) EL ).setFileDetector(new LocalFileDetector());
		EL.sendKeys(PdfPath);
		Thread.sleep(2000);
		
		clickElement(driver, AuthorisationButton);
		clickElement(driver, SendAttachedFilesButton);
		
		
		Thread.sleep(1000);
	}
	
	public void FinalisePayment() throws InterruptedException {
		System.out.println("Confim Finalise payment");
		clickElement(driver, FinalisePaymentButton);
		Thread.sleep(2000);
	}
	
	public void MovetoNextStep(String text, String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger) throws InterruptedException {
		System.out.println("Confim Next Step");
		
		Thread.sleep(1000);
        clickElement(driver, ChooseNoReprise);
		//clickUsingJS(driver, ChooseNoReprise);
		//WebElement reprise = driver.findElement(ChooseNoReprise);
		//reprise.sendKeys(Keys.RETURN);
		Thread.sleep(3000);
		System.out.println(ChooseNoReprise);
		//LogWithScreenshot("", resultDirectory, driver, extent, logger);
		clickElement(driver, ChooseNoRepriseYes);
		//clickUsingJS(driver, ChooseNoRepriseYes);
		Thread.sleep(3000);
		System.out.println(ChooseNoRepriseYes);
		//LogWithScreenshot("", resultDirectory, driver, extent, logger);
		driver.navigate().back();
		Thread.sleep(3000);
		System.out.println("Choose back");
		//LogWithScreenshot("", resultDirectory, driver, extent, logger);
		clickElement(driver, nextstepButton);
		//clickUsingJS(driver, ChooseNoRepriseYes);
		Thread.sleep(3000);
		System.out.println("next step");
		//LogWithScreenshot("", resultDirectory, driver, extent, logger);
		driver.get(driver.getCurrentUrl());
		Thread.sleep(6000);
		
		
	}
	
	public void CobfirmOfferWithPaymentObligation() throws InterruptedException {
		System.out.println("Confime Offer With Obligation of Payment");
		clickElement(driver, UserConditionsCheckBox);
		clickElement(driver, OfferValidationDurationCheckbox);
		clickElement(driver, OrderWithPaymentObligationButton);
		Thread.sleep(2000);
	}
	
	public void ContinueToAttacheFile() throws InterruptedException {
		System.out.println("Confime To Attached Files Done");
		clickElement(driver, ContinuetoattachedFielesButton);
		Thread.sleep(2000);
	}

	public void ChooseBrandAC(String PXCheckoutPage) throws InterruptedException, AWTException {
      	 System.out.println("Brand Have Been Choosen");
		 JavascriptExecutor js = (JavascriptExecutor) driver;
         js.executeScript("window.scrollBy(0,50)");
         Thread.sleep(500);
		 Thread.sleep(2000);
		 //driver.findElement(CooseBrandBox).sendKeys(Keys.DOWN);
		if (PXCheckoutPage.equals("yes")) {clickElement(driver, CooseBrandBoxPXCK);}
		else {clickElement(driver, CooseBrandBox);}
		Thread.sleep(2000);
        if (PXCheckoutPage.equals("yes")) {
			
			Robot r=new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(2000);
	     	
	    }
		
		else 
		{
			Robot r=new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(2000);
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(2000);
			r.keyPress(KeyEvent.VK_UP);
			r.keyRelease(KeyEvent.VK_UP);
			Thread.sleep(2000);
			r.keyPress(KeyEvent.VK_UP);
			r.keyRelease(KeyEvent.VK_UP);
		}

		Thread.sleep(2000);
		Robot or = new Robot();
		or.keyPress(KeyEvent.VK_ENTER);
		or.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		clickElement(driver, ChooseBrandButton);
		Thread.sleep(1000);
	}
	
	public void ChooseCarOptionsAC() throws InterruptedException, AWTException {
		System.out.println("Car Options Choosen");
		clickElement(driver, ChooseModelBox);
		Thread.sleep(2500);
		clickElement(driver, ChooseFirtIndex);
		Thread.sleep(2500);
		clickElement(driver, ChooseCirculationMonthBox);
		Thread.sleep(2500);
		clickElement(driver, ChooseFirtIndexCirculationmonth);
		Thread.sleep(2500);
		clickElement(driver, ChooseCirculationYearBox);
		Thread.sleep(2500);
		clickElement(driver, ChooseFirtIndexCirculationYear);
		Thread.sleep(2500);
		//if (PXCheckoutPage.equals("yes")) {
			clickElement(driver, ChooseBodyBoxPXCK);
			Thread.sleep(1000);
			Robot r=new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(1000);
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(1000);
			Robot or = new Robot();
			or.keyPress(KeyEvent.VK_ENTER);
			or.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
//			}
//		else {
//			clickElement(driver, ChooseBodyBox);
//			Thread.sleep(1000);
//			clickElement(driver, ChooseFirtIndexBody);}
			Thread.sleep(2500);
		//if (PXCheckoutPage.equals("yes")) {
			clickElement(driver, ChooseNumberDoorBoxPXCK);
			Thread.sleep(1000);
			Robot r2=new Robot();
			r2.keyPress(KeyEvent.VK_DOWN);
			r2.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(1000);
			r2.keyPress(KeyEvent.VK_DOWN);
			r2.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(1000);
			Robot or2 = new Robot();
			or2.keyPress(KeyEvent.VK_ENTER);
			or2.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			//}
	
//		else {
//			clickElement(driver, ChooseNumberDoorBox);
//			Thread.sleep(1000);
//		clickElement(driver, ChooseFirtIndexNumberDoor);}
//		
		
		Thread.sleep(2500);
		clickElement(driver, ChooseFuelBox);
		Thread.sleep(2500);
		clickElement(driver, ChooseFirtIndexFuel);
		Thread.sleep(2500);
		clickElement(driver, ChooseGearBox);
		Thread.sleep(2500);
		clickElement(driver, ChooseFirtIndexGear);
		Thread.sleep(2500);
		clickElement(driver, ChooseFiscalPowerBox);
		Thread.sleep(2500);
		clickElement(driver, ChooseFirstIndexFiscalPower);
		Thread.sleep(2500);
		clickElement(driver, ChooseEnginePowerBox);
		Thread.sleep(2500);
		clickElement(driver, ChooseFirstIndexEnginePower);
		Thread.sleep(2500);
		clickElement(driver, ChooseOptionsConfirmationButton);
		Thread.sleep(2500);

	}
	
	public void ChooseVersionAC(String PXConfigPage) throws InterruptedException, AWTException {
		System.out.println("Brand Have Been Choosen");
		Thread.sleep(2000);
		if (PXConfigPage.equals("yes")) {
			clickElement(driver, ChooseVersionChoicePXCG);
			Thread.sleep(1000);
			Robot r=new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(1000);
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(1000);
			Robot or = new Robot();
			or.keyPress(KeyEvent.VK_ENTER);
			or.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);;}
		else {
     	
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);}
		clickElement(driver, ConfirmVersionChoice);
		Thread.sleep(2000);
	}
	
	public boolean checkConfirmationMessage() throws InterruptedException {
		System.out.println("Checking Confirmation Message");
		Thread.sleep(1000); 
		return isElementPresentWithoutWait(driver, ConfirmationMessage);
	}
}