package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import solRetailIHM.Utilities.UniversalMethods;

import java.util.List;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class LoginUserPage extends UniversalMethods {
	
	private WebDriver driver;
	
	//By emailField = By.id("email");

	//By emailField= By.id("field_email");

	By emailField= By.xpath("//input[@id=\"field_email\"] | //input[@id=\"email\"] | (//input[@name='username'])[3]");
	By passwordField = By.xpath("((//div[@class='gigya-layout-cell responsive with-site-login']//div[@class='gigya-composite-control gigya-composite-control-password'])[2])//input[@type='password'] | //input[@id='password'] | (//*[@name='password'])[6]");
	By validateButton = By.xpath("(//input[@type='submit'])[17] |  //input[@value='VALIDAR'] | //input[@value='submit'] | (//input[@type='submit'])[17] | //input[@id='submit']");
	By link = By.xpath("//*[contains(@href,'authorize')]");
	By createAccountPageLocator = By.xpath("//h2[@class='main-title']");
	By logoutLink = By.xpath("//*[@data-testid='TESTING_LOGOUT_SIDEMENUITEM']");
	//By logoutLink = By.xpath("//*[text()='Log out'] | //*[text()='Desconexión'] | //*[@data-testid='TESTING_LOGOUT_SIDEMENUITEM']");
	//By logoutLink=By.linkText("Log out");
	By logoutLink_ES=By.partialLinkText("Desconexi");
	By textBoxForEnterEmail = By.xpath("//input[@type='text']");
	//By linkOnPersonalInfo = By.xpath("//a[@class='c-pointer']");
	By linkOnPersonalInfo = By.xpath("//button[contains(@class, 'login')]");
	By myAccountLink = By.xpath("//a[@href='/my-account']");
	By forgotPasswdLink = By.xpath("//a[contains(@href, 'forgot-password')] | //a[contains(@title,'Forgot password?')] | //*[contains(@title,'Vous avez oublié votre mot de passe')] | //a[@data-switch-screen='gigya-forgot-password-screen' and contains(@class,'gigya-forgotPassword') and @role='button']");
	By forgotPasswdMsg = By.xpath("//div[@id='page_description']/p | (//*[@class='gigya-layout-row']/label)[19]");
	
	public LoginUserPage(WebDriver driver) {
		this.driver = driver;
	}

	@Test(description="Entering Email")
	public void enterEmail(String emailId,String resultDirectory, ExtentTest NodeORSubNode) throws Exception {
		try {
			System.out.println("Enter Email");
			//Thread.sleep(5000);
			waitForPageToLoad(driver,30);
			waitForElementPresent(driver,emailField,120);
			Thread.sleep(5000);
			enterData(driver, emailField, emailId.toLowerCase(),60);
			//driver.findElement(By.xpath("//html")).click();
			clickElement(driver,By.xpath("//html"));
			NodeORSubNode.log(Status.INFO, "Entered Email");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to enter email",e);
		}
	}
	
	@Test(description="Entering Password")
	public void enterPassword(String password,String resultDirectory, ExtentTest NodeORSubNode) throws Exception {
		try {
			System.out.println("Entered Password " + password);
			waitForElementClickable(driver, passwordField, 30);
			waitForPageToLoad(driver,5);
			Thread.sleep(2000);
			enterData(driver, passwordField, password);
			driver.findElement(By.xpath("//html")).click();
			NodeORSubNode.log(Status.INFO, "Entered Password");
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to enter password", e);
		}
	}
	
	@Test(description="Clicking on Validate Login Button")
	public void validate(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException
	{
		try{
		System.out.println("validate Login");
		waitForElementClickable(driver,validateButton,10);
		waitForPageToLoad(driver,5);
		Thread.sleep(2000);
		/*List<WebElement> allEle=driver.findElements(By.xpath("(//input[@type='submit'])[17]"));
			for (WebElement ele:allEle
				 ) {
				System.out.println(ele.getText());
				if(ele.getText()!=null) {
					if (ele.getAttribute("value") != null && ele.getAttribute("value").contains("Submit")) {
						System.out.println(ele.getLocation());
						System.out.println(ele.getLocation().getX());
						System.out.println(ele.getLocation().getY());
						Actions ac = new Actions(driver);
						ac.moveToElement(ele,ele.getLocation().getX(),ele.getLocation().getY()).click().build().perform();
						//ele.click();
						break;
					}
				}
			}*/
			clickElement(driver, validateButton,6);
			//clickUsingJS(driver, validateButton);
			NodeORSubNode.log(Status.INFO, "Clicked on Validate Button");
		}catch (Exception e){
			e.printStackTrace();
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to click on Validate button",e);
		}
	}
	
	public boolean checkLogoutLink(String country) {
		/*if(country.equalsIgnoreCase("ES")) {
			waitForElementClickable(driver, logoutLink_ES, 40);
			return isElementPresent(driver, logoutLink_ES);
		}else{*/
			waitForElementClickable(driver, logoutLink, 40);
			return isElementPresent(driver, logoutLink);
		//}
	}
	
	@Test(description="Clicking on Logout Button")
	public void clickLogout(String resultDirectory, ExtentTest NodeORSubNode, String Country) throws InterruptedException {
		try {
			System.out.println("Logout");
			//if(Country.equalsIgnoreCase("FR")) {
			Thread.sleep(5000);
			clickElement(driver, logoutLink, 10);
			/*}else{
				clickElement(driver, logoutLink_ES, 10);
			}*/
			NodeORSubNode.log(Status.INFO, "Clicked on Logout Button");
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode, driver, "Image is not present on Home Page", e);
		}
	}
	
	@Test(description="Getting Create Account Page Locator")
	public String  CreateAccountPageLocator() throws InterruptedException {
		return getAnyText(driver, createAccountPageLocator);
	}
	
	@Test(description="Clicking on Link: Go to Login Page")
	public void clickLink() throws InterruptedException
	{
		System.out.println("go to login page");
		clickElement(driver, link);
	}
	
	@Test(description="Entering Email ID")
	public void enterEmailID(String emailId) throws Exception {
		//Thread.sleep(400);
		//waitForPageToLoad(driver,5);
		//clickElement(driver,textBoxForEnterEmail,10);
		waitForElementClickable(driver,textBoxForEnterEmail,5);
		enterData(driver, textBoxForEnterEmail, emailId,10);
		System.out.println("Entered Email ID");
		//Thread.sleep(400);
		waitForPageToLoad(driver,5);
	}
	
	@Test(description="Clicking on Link: Got to Login Page")
	public void clickOnLink() throws InterruptedException
	{
		System.out.println("go to login page");
		clickElement(driver, linkOnPersonalInfo);
	}
	
	@Test(description="Clicking on Link: go to account page")
	public void clickAccountkLink(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException
	{
		try {
			System.out.println("go to account page");
			String accountlink = driver.findElement(myAccountLink).getAttribute("href");
			System.out.println(accountlink);
			driver.get(accountlink);
			NodeORSubNode.log(Status.INFO, "Navigated to account Page");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Navigated to account Page",e);
		}
	}
	
	public void clickForgotPasswdLink() {
		waitForElementClickable(driver,forgotPasswdLink,10);
		clickElement(driver, forgotPasswdLink);
	}
	
	public String getForgotPasswdMsg() {
		return getAnyText(driver, forgotPasswdMsg);
	}
}