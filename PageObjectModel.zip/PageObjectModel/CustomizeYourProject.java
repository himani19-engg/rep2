package solRetailIHM.PageObjectModel;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CustomizeYourProject extends UniversalMethods {
	//public static int CashPriceFromHeader;
	//public static int FinancePriceFromHeader;
	WebDriver driver = null;
	By CustomizeYourProject_FR = By.xpath("//*[text()='PERSONNALISEZ VOTRE PROJET']");	
	By CustomizeYourProject_UK = By.xpath("//*[text()='PERSONALISE YOUR VEHICLE']");
	By CustomizeYourProject_UK_VX = By.xpath("//*[text()='PERSONALISE YOUR OFFER']");
	
	
			
	By headerCashPrice = By.className("cashContainer-cashPrice");
	By headerFinancePrice = By.className("financeContainer-price-monthlyPrice");
	By ConfigColour = By.xpath("//*[starts-with(@id,'TESTING_CONFIG_COLOR')]");
	By FinConPriceTitle = By.className("financeContainer__price-title");
	By CashConPriceTitle = By.className("cashContainer__price-title");
	By FinConPriceAmount = By.className("financeContainer__price-amount");
	By CashConPriceAmount = By.className("cashContainer__price-amount");
	By PrixTTCHorsOptionsPriceAmount = By.xpath("//*[@data-testid='TESTING_CASH_CONTAINER_PRICE_WITHOUT_OPTIONS']");
	By TotalOptionsPriceAmount = By.xpath("//*[@data-testid='TESTING_CASH_CONTAINER_OPTIONS_TOTAL']");
	By MontantTotalTTCPrice = By.xpath("//*[@data-testid='TESTING_CASH_CONTAINER_TOTAL_WITH_OPTIONS']");
	By TestingColour = By.xpath("//*[starts-with(@id,'TESTING_COLOR_')]");
	By TestingPrice = By.xpath("//*[@data-testid='TESTING_COLOR_PRICE']");
	By ConfigEngine = By.xpath("//*[starts-with(@id,'TESTING_CONFIG_MOTO')]");
	By MotorizationItem = By.xpath("//*[starts-with(@data-testid,'TESTING_MOTOR_ITEM_')]");
	By InteriorColour = By.xpath("//*[starts-with(@data-testid,'TESTING_INTERIORCOLOR_ITEM_')]");
	By InteriorColourPrice = By.xpath("//*[@data-testid='TESTING_INTERIORCOLOR_PRICE']");
	By InteriorColourPriceColExp = By.id("TESTING_CONFIG_INTER");
	By OptionColExp = By.xpath("//*[@data-testid='TESTING_OPTIONS_WRAPPER']");
	By TestOption = By.xpath("//*[starts-with(@data-testid,'TESTING_OPTION_CARDTITLE_')]");
	By OptionPrice = By.xpath("//*[@data-testid='TESTING_OPTIONS_PRICE']");
	
	By FinanceWidgetSelected = By.xpath("//*[@Class='financeContainer__price-title']/..");
	By CashWidgetSelected = By.xpath("//*[@Class='cashContainer__price']/..");
	By BasketContinue = By.id("TESTING_TO_BASKET_BOX");

	
	public String financeWidgetCheckBox() throws InterruptedException
	{
		return getClassValue (driver, FinanceWidgetSelected);
	}
	
	public String CashWidgetCheckBox() throws InterruptedException
	{
		return getClassValue (driver, CashWidgetSelected);
		
	}
	
	public void clickfinanceWidgetCheckBox() throws InterruptedException {
		System.out.println("Select Finance widget");
		clickElement(driver, FinanceWidgetSelected);
	}
	
	public void clickcashWidgetCheckBox() throws InterruptedException {
		System.out.println("Select Cash widget");
		clickElement(driver, CashWidgetSelected);
	}
	
	public void clickBasketcontinue() throws InterruptedException
	{
		System.out.println("Continue to basket");
		//waitForElementClickable(driver, BasketContinue);
		clickElement(driver, BasketContinue);
	}

	public CustomizeYourProject(WebDriver driver) throws InterruptedException {
		this.driver = driver;
		// getCashPriceFromHeader();
		// getFinancePriceFromHeader();
	}

	public String getCustomizeYourProjectText_FR() throws InterruptedException {
		System.out.println("Clicked on Personalize Button");
		return getAnyText(driver, CustomizeYourProject_FR);

	}
	
	
	
	
	public String getCustomizeYourProjectText_UK() throws InterruptedException {
		System.out.println("Clicked on Personalize Button");
		return getAnyText(driver, CustomizeYourProject_UK);}
		
		public String getCustomizeYourProjectText_UK_VX() throws InterruptedException {
			System.out.println("Clicked on Personalize Button");
			return getAnyText(driver, CustomizeYourProject_UK_VX);

	}

	public void clickConfigColour() throws InterruptedException {
		System.out.println("Clicked on Personalize Button");
		clickElement(driver, ConfigColour);
	}

	public void selectDefaultColour() throws InterruptedException {
		System.out.println("Clicked on first default colour for which colour price is present");
		int numVal;
		List<WebElement> allColours = driver.findElements(TestingColour);
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			for (int i = 0; i <= (allColours.size() - 1); i++) {
				//waitForElementClickable(driver, TestingPrice);
				if (i == 0) {
					Thread.sleep(6000);
				}
				allColours.get(i).click();
				Thread.sleep(6000);
				String price = getAnyText(driver, TestingPrice);
				while (price.equals("")) {
					Thread.sleep(2000);
					price = getAnyText(driver, TestingPrice);
					System.out.println("The price is: " + price);
				}
				if ((price != null) && (!price.contains("Inclus")) && (!price.contains("INCLUS"))) {
					System.out.println("Testing Price Text is: " + price);
					numVal = extractNumericFromString(price);
					System.out.println("Price in only Numeric is: " + numVal);
					if (numVal > 0) {
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickConfigEngine() throws InterruptedException {
		System.out.println("Clicked on Engine collapse/expand");
		clickElement(driver, ConfigEngine);
	}

	public void selectMotorItem() throws InterruptedException {
		clickConfigEngine();
		System.out.println("Clicked on first default Motor Item for which colour price and TTC/Mois is present");
		List<WebElement> allMotorItems = driver.findElements(MotorizationItem);
		String TTC_MOIS_Price = null;
		try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			for (int i = 0; i <= allMotorItems.size(); i++) {
				//waitForElementClickable(driver, MotorizationItem);
				Thread.sleep(4000);
				allMotorItems.get(i).click();
				//waitForElementClickable(driver, MotorizationItem);
				String Motorprice = allMotorItems.get(i).getText();
				String[] AllLineStrings = Motorprice.split("\\R");
				for (int j = 0; j <= AllLineStrings.length; j++) {
					if (AllLineStrings[j].contains("TTC")) {
						TTC_MOIS_Price = AllLineStrings[j];
						System.out.println("TTC/mois price is: " + TTC_MOIS_Price);
						break;
					}
				}
				int MotorNumprice = extractNumericFromString(TTC_MOIS_Price);
				if ((Motorprice != null) && (Motorprice.contains("TTC/mois")) && (MotorNumprice > 0)) {
					System.out.println("Motor Price is: " + MotorNumprice);

					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void InteriorColourPriceColExp() throws InterruptedException {
		System.out.println("Clicked on Interior Colour collapse/expand");
		clickElement(driver, InteriorColourPriceColExp);
	}

	public void selectInteriorColour() throws InterruptedException {
		System.out.println("Clicked on Interior colour for which price is present");
		int numVal;
		List<WebElement> allInteriorColours = driver.findElements(InteriorColour);
		try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			InteriorColourPriceColExp();
			for (int i = 0; i <= (allInteriorColours.size() - 1); i++) {
				//waitForElementClickable(driver, InteriorColourPrice);
				Thread.sleep(1000);
				allInteriorColours.get(i).click();
				//waitForElementClickable(driver, InteriorColourPrice);
				String price = getAnyText(driver, InteriorColourPrice);
				if ((price != null) && (!price.contains("Inclus"))) {
					System.out.println("Testing Interior Price Text is: " + price);
					numVal = extractNumericFromString(price);
					System.out.println("Interior Price in only Numeric is: " + numVal);
					if (numVal > 0) {
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOption() throws InterruptedException {
		System.out.println("Clicked on Option collapse/expand");
		clickElement(driver, OptionColExp);
	}

	public void selectOption() throws InterruptedException {
		System.out.println("Selecting first option for which price is present");
		int numVal;
		List<WebElement> allOptions = driver.findElements(TestOption);
		try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			clickOption();
			for (int i = 0; i <= (allOptions.size() - 1); i++) {
				//waitForElementClickable(driver, OptionPrice);
				Thread.sleep(6000);
				allOptions.get(i).click();
				//waitForElementClickable(driver, OptionPrice);
				String price = getAnyText(driver, OptionPrice);
				if ((price != null) && (!price.contains("Inclus"))) {
					System.out.println("Option Price Text is: " + price);
					numVal = extractNumericFromString(price);
					System.out.println("Option Price in only Numeric is: " + numVal);
					if (numVal > 0) {
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getCashPriceFromHeader() throws InterruptedException {
		System.out.println("Getting cash price from header");
		int CashPriceFromHeader = 0;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			CashPriceFromHeader = extractNumericFromString(getAnyText(driver, headerCashPrice));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CashPriceFromHeader;
	}

	public int getFinancePriceFromHeader() throws InterruptedException {
		System.out.println("Getting Finance price from header");
		int FinancePriceFromHeader = 0;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			FinancePriceFromHeader = extractNumericFromString(getAnyText(driver, headerFinancePrice));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FinancePriceFromHeader;
	}

	public String getFinanceContainerPriceTitle() throws InterruptedException {
		System.out.println("getting Finance Container Price Title");
		String label = null;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			label = getAnyText(driver, FinConPriceTitle);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return label;
	}
	
	public String getCashContainerPriceTitle() throws InterruptedException {
		System.out.println("getting cash Container Price Title");
		String label = null;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			label = getAnyText(driver, CashConPriceTitle);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return label;
	}

	public String getFinanceContainerPriceAmount() throws InterruptedException {
		System.out.println("getting Finance Container Price Amount");
		String price = null;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			price = getAnyText(driver, FinConPriceAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return price;
	}

	
	public String getCashContainerPriceAmount() throws InterruptedException {
		System.out.println("getting Cash Container Price Amount");
		String price = null;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			price = getAnyText(driver, CashConPriceAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return price;
	}
	
	public String getPrixTTCHorsOptions() throws InterruptedException {
		System.out.println("getting PRIX TTC HORS OPTIONS price");
		String price = null;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			price = getAnyText(driver, PrixTTCHorsOptionsPriceAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return price;
	}

	public String getTotalOptions() throws InterruptedException {
		System.out.println("getting Total OPTIONS price");
		String price = null;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			price = getAnyText(driver, TotalOptionsPriceAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return price;
	}
	
	public String getMontantTotalTTC() throws InterruptedException {
		System.out.println("getting Montant Total TTC price");
		String price = null;
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			price = getAnyText(driver, MontantTotalTTCPrice);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return price;
	}

}
