package solRetailIHM.PageObjectModel.Digital1;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solRetailIHM.Utilities.UniversalMethods;

public class Citroen_UK extends UniversalMethods {
	WebDriver driver = null;
	
			
	public Citroen_UK(WebDriver driver) {
		this.driver = driver;	
	}
	
	By ContAccepter=By.id("_psaihm_id_accept_all_btn");
	By Models = By.xpath("//span[text()='MODELS']");
	By GoToWebStore = By.xpath("//*[@data-gtm-event-label='GET STARTED NOW']");
	By SeeOffers = By.xpath("//*[@data-gtm-event-label='VIEW ALL OFFERS']");
	By Home = By.xpath("//*[@title='Home']");
	By GoToWebstoreLinks = By.xpath("(//*[@class='icon icon-shopping-cart'])");
	By buyMenu = By.xpath("//span[text()='BUY']");	
	
	By closeFormPopup = By.xpath("//*[@class='dy-quiz-init__content']/button[2]");	
	By OpenMenu = By.xpath("//*[@data-gtm-event-label='Menu']");	
	
	By GoToWebstoreMenu = By.xpath("//*[@data-gtm-event-label='Achetez en ligne']");
	
	
	By CommandOnLine = By.xpath("//*[@title='COMMANDEZ EN LIGNE']");
			
	public void clickContAccepter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			clickElement(driver, ContAccepter);
			System.out.println("Clicked on Accepter Btn");
			NodeORSubNode.log(Status.INFO, "Clicked on Accepter Btn");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with Clicking on Accepter Btn",e);
		}
	}
	
	public void ClickModels() throws InterruptedException {
		System.out.println("Models");
		waitForElementClickable(driver,Models,5);
		List<WebElement> allEle = driver.findElements(Models);
		allEle.get(allEle.size()-1).click();
	}
	
	public void GoToWebStore() throws InterruptedException {
		System.out.println("GoToWebStore");
		waitForElementClickable(driver,GoToWebStore,5);
		List<WebElement> allEle = driver.findElements(GoToWebStore);
		allEle.get(allEle.size()-1).click();
	}
	
	public void ClickHome() throws InterruptedException {
		System.out.println("Home Button");
		waitForElementClickable(driver,Home,5);
		List<WebElement> allEle = driver.findElements(Home);
		allEle.get(allEle.size()-2).click();
	}
	
	public void GoToWebstoreLink() throws InterruptedException {
		System.out.println("Web store Link");
		waitForElementClickable(driver,GoToWebstoreLinks,5);
		List<WebElement> allEle = driver.findElements(GoToWebstoreLinks);
		allEle.get(allEle.size()-1).click();
	}
	
	public void ClickBuyMenu() throws InterruptedException {
		System.out.println("Buy Menu");
		waitForElementClickable(driver,buyMenu,5);
		List<WebElement> allEle = driver.findElements(buyMenu);
		allEle.get(allEle.size()-1).click();
	}
	
	public void SeeOffers() throws InterruptedException {
		System.out.println("See offers");
		clickElement(driver, SeeOffers);
	}
	
	
	
	public void ClickGoToWebstoreMenu() throws InterruptedException {
		System.out.println("Open Menu web store");
		clickElement(driver, GoToWebstoreMenu);
	}
	
	
	
	public void ClickCommandOnline() throws InterruptedException {
		System.out.println("Command Online");
		clickElement(driver, CommandOnLine);
	}

}