package solRetailIHM.PageObjectModel.Digital1;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solRetailIHM.Utilities.UniversalMethods;

public class Vauxhall_UK extends UniversalMethods {
	WebDriver driver = null;
	
			
	public Vauxhall_UK(WebDriver driver) {
		this.driver = driver;	
	}
	
	By ContAccepter=By.id("_psaihm_id_accept_all_btn");
	By VauxhallStore = By.xpath("//*[@title='Vauxhall Store']");
	By OrderOnline = By.xpath("//*[@title='Order Online']");
	By VauxhallWebStore = By.xpath("//*[@title='GO TO VAUXHALL STORE']");
		
	public void clickContAccepter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			clickElement(driver, ContAccepter);
			System.out.println("Clicked Accepter Btn");
			NodeORSubNode.log(Status.INFO, "Clicked Accepter Btn");
		}catch(Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with Clicking on Accepter Btn",e);
		}
	}
	
	public void goToVauxhallStore() throws InterruptedException {
		System.out.println("go to vauxhall Store");
		clickElement(driver, VauxhallStore);
	}
	
	public void orderOnline() throws InterruptedException {
		System.out.println("order online");
		clickElement(driver, OrderOnline);
	}

	public void goToVauxhallWebStore() throws InterruptedException {
		System.out.println("go to vauxhall Store");
		clickElement(driver, VauxhallWebStore);
	}

}