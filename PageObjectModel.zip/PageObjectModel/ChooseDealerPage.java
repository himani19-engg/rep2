package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ChooseDealerPage extends UniversalMethods {

	private WebDriver driver;

	By Dealerpagelocator_UK_AC = By.xpath("//*[text()='Select retailer']/../div[3]");
	//By Dealerpagelocator_FR = By.xpath("//*[text()='Point de vente']/../div[3]");
	By Dealerpagelocator_FR = By.xpath("//div/p[contains(text(), 'Point de vente')]");
	By Dealerpagelocator_UK = By.xpath("//*[text()='Dealer']/../div[3]");

	By SearchRetailerField = By.xpath("//input[@data-testid='TESTING_DEALER_SEARCH_INPUT']");
	By SearchRetailer = By.xpath("//button[@data-testid='TESTING_DEALER_SEARCH']");
	By SelectRetailer = By.xpath("//button[contains(@data-testid,'TESTING_DEALER_ITEM_')]");

	By DealerChoiceAdress1 = By.xpath("(//div[@data-testid='TESTING_DEALER_ADDRESS']/p)[1]");
	By DealerChoiceAdress2 = By.xpath("(//div[@data-testid='TESTING_DEALER_ADDRESS']/p)[2]");
	By DealerChoiceAdress3 = By.xpath("(//div[@data-testid='TESTING_DEALER_ADDRESS']/p)[3]");
	By DealerChoiceAdress4 = By.xpath("(//div[@data-testid='TESTING_DEALER_ADDRESS']/p)[4]");


	By DealerDisplayAdress1 = By.xpath("(//div[@data-testid='TESTING_SELECTED_DEALER_INFO']/p)[1]");
	By DealerDisplayAdress2 = By.xpath("(//div[@data-testid='TESTING_SELECTED_DEALER_INFO']/p)[2]");
	By DealerDisplayAdress3 = By.xpath("(//div[@data-testid='TESTING_SELECTED_DEALER_INFO']/p)[3]");
	By DealerDisplayAdress4 = By.xpath("(//div[@data-testid='TESTING_SELECTED_DEALER_INFO']/p)[4]");

	By DealerContinue = By.xpath("//button[@data-testid='TESTING_HANDLE_DEALER']");

	By OpelSimulatorLocator = By.xpath("//*[@class='title centertitle']");

	//By CashIdentification = By.xpath("//*[@class='text-div-container ng-tns-c0-0 current-step ng-star-inserted']/p");
	By dealerHeader = By.xpath("//div[contains(@class, 'breadcrumb-pagination')]/div[1]/p");
	By dealerHeader_AC = By.xpath("//div[@id='breadcrumb-app']/div/div/div[2][contains(@class, 'current')]");
	By dealerHeader_OV = By.xpath("//div[@class='progressTitle']");
	By identificationHeader_OV = By.xpath("(//div[@class='progressTitle'])[1]");


	By CashRetailer = By.id("autocomplete");
	By CashRetailerStore = By.xpath("(//a[contains(@id,'PFDSearchPDVsaveSearchPDV')])[1]");
	By cashRetailerStore_OV = By.xpath("//button[@data-testid='TESTING_DEALER_ITEM_0']");
	By CashValidateRetailer = By.xpath("//*[(text()='Continuer') or (text()='Continuar')]");
	By CashValidateRetailer_DS = By.xpath("//*[(text()='CONTINUEZ') or (text()='Continuar')]");
	By cashRetailerContinue_OV = By.xpath("//button[@data-testid='TESTING_HANDLE_DEALER']");

	By OpelValidateFinance = By.id("ordinaora");
	By OpelRetailer = By.xpath("(//*[@class='checkbox-selection-map-show'])[1]");
	By OpelValidateRetailer = By.id("passosuccessivo");
	By OpelPageTitle = By.className("title-center");
	By OpelPageTitle2 = By.className("title");

	By EC41DealerPageTitle = By.xpath("//*[text()='Sélectionnez votre concessionnaire']");
	By delerSelectedText = By.xpath("//div[@class='dealers_sheet selected']//h3/span[2]");
	By checkDelerSelectedText = By.xpath("//span[contains(@class, 'name-selected')]");

	By firstFooterLink = By.xpath("(//*[@class='clicable ng-star-inserted']//a)[1]");
	By firstFooterLink_OV = By.id("TESTING_FOOTER_0");
	By secondFooterLink = By.xpath("(//*[@class='clicable ng-star-inserted']//a)[2]");
	By secondFooterLink_OV = By.id("TESTING_FOOTER_1");
	//By cashPrice = By.xpath("//div[contains(@class, 'price-total row')]/span[2]");
	By cashPrice = By.xpath("//div[contains(@class, 'price-total row')]//span[contains(@class, 'price-total-price')]");
	By financePrice = By.xpath("//p[@class='prix_mois']");

	public ChooseDealerPage(WebDriver driver) {
		this.driver = driver;
	}

	public boolean getEC41DealerTitle() throws InterruptedException {
		Boolean bool = false;
		try {
			System.out.println("Getting EC41 Dealer page title");
			bool = isElementPresentWithoutWait(driver, EC41DealerPageTitle);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bool;
	}

	public String DealerPage_UK() throws InterruptedException {
		return getClassValue(driver, Dealerpagelocator_UK);
	}

	public String DealerPage_FR() throws InterruptedException {
		return getClassValue(driver, Dealerpagelocator_FR);
	}

	public String DealerPage_UK_AC() throws InterruptedException {
		return getClassValue(driver, Dealerpagelocator_UK_AC);
	}

	public void ValidateCashRetailer() throws InterruptedException {
		System.out.println("Validate Retailer");
		//waitForElementClickable(driver, CashValidateRetailer);
		clickElement(driver, CashValidateRetailer);
	}

	public void ValidateOpelFinance() throws InterruptedException {
		System.out.println("Validate Finance conf");
		clickElement(driver, OpelValidateFinance);
	}


	public void ValidateCashRetailer_DS() throws InterruptedException {
		System.out.println("Validate Retailer");
		//waitForElementClickable(driver, CashValidateRetailer_DS);
		clickElement(driver, CashValidateRetailer_DS);
	}

	public void validateRetailerData(String brand) throws InterruptedException {
		//Validate if List has more that one retailer
		List<WebElement> allRetailers=driver.findElements(By.id("dealers_list"));

		//Validate if each grid's retailer's shop name is not null
		//Validate if each grid's address is not null
		//Validate if each grid has KM and the numeric value of KM
		//Validate zip code and city name is available
		//Validate if google map icon is available

	}
	
	public void CashRetailerStore(String brand) throws InterruptedException {
		System.out.println("Select Retailer");
		waitForPageToLoad(driver, 5);
		if (brand.equals("OV")) {
			waitForElementPresent(driver, cashRetailerStore_OV, 5);
			scrollToTop(driver);
			clickElement(driver, cashRetailerStore_OV);
		} else {
			//scrollToTop(driver);
			waitForPageToLoad(driver, 5);
			if (isElementPresent(driver, CashRetailerStore)) {
				scrollingJS(driver, CashRetailerStore);
			}
		}
		//clickElement(driver, CashRetailerStore);
	}	
	
	public void clickOpelRetailer() throws InterruptedException
	{
		System.out.println("Select Retailer");
		clickElement(driver, OpelRetailer);
	}	
	
	public void clickFirstFooter(String brand) throws InterruptedException
	{
		System.out.println("Click on first footer");
		if(brand.equals("OV"))
			clickElement(driver, firstFooterLink_OV);
		else
			clickElement(driver, firstFooterLink);
	}
	
	public void clickSecondFooter(String brand) throws InterruptedException
	{
		System.out.println("Click on second footer");
		if(brand.equals("OV"))
			clickElement(driver, secondFooterLink_OV,10);
		else
			clickElement(driver, secondFooterLink,10);
	}
	
	public void validateOpelRetailer() throws InterruptedException
	{
		System.out.println("Validate Retailer");
		clickElement(driver, OpelValidateRetailer);
	}
	
	public void clickCashRetailerContinueBtn() throws InterruptedException {
		System.out.println("Cash Retailer continue");
		clickElement(driver, cashRetailerContinue_OV);
	}
	
	public void enterCashRetailer(String Retailer) throws Exception {
		System.out.println("Enter Retailer");
		enterData(driver,  CashRetailer, Retailer);
		Thread.sleep(7000);
		Actions actionObject = new Actions(driver);
		actionObject = actionObject.sendKeys(Keys.ARROW_DOWN); //ASSIGN the return or you lose this event.
		actionObject.perform();
		Thread.sleep(2000);
		actionObject = actionObject.sendKeys(Keys.ENTER); //ASSIGN the return or you lose this event.
		actionObject.perform();
		Thread.sleep(2000);
	}
	
	public void enterCity(String City) throws Exception {
		System.out.println("Search City");
		enterData(driver,  SearchRetailerField, City);
	}
	

	public void searchRetailer() throws InterruptedException
	{
		System.out.println("SearchRetailer");
		clickElement(driver, SearchRetailer);
	}	
	
	public void SelectRetailer() throws InterruptedException
	{
		System.out.println("SelectRetailer");
		clickElement(driver, SelectRetailer);
	}
	
	public String  OpelSimulatorLocator() throws InterruptedException {
		return getAnyText(driver, OpelSimulatorLocator);

	}
	
	public String  OpelDealerLocator() throws InterruptedException {
		return getAnyText(driver, OpelPageTitle);

	}
	
	public String  OpelInfosLocator() throws InterruptedException {
		return getAnyText(driver, OpelPageTitle2);

	}
	
	public String  getCashPrice() throws InterruptedException {
		System.out.println("get cash price on checkout page");
		return getAnyText(driver, cashPrice);
	}
	
	public String  getFinancePrice() throws InterruptedException {
		String str=null;
		System.out.println("get finance price on checkout page");
		str=getAnyText(driver, financePrice);
		return str;
	}
	
	public String  DealerChoiceAdress() throws InterruptedException {
		String text = getAnyText(driver, DealerChoiceAdress1) + 
				      getAnyText(driver, DealerChoiceAdress2) + 
				      getAnyText(driver, DealerChoiceAdress4) + 
				      getAnyText(driver, DealerChoiceAdress3); 
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		System.out.println(text);
		return text;

	}
	
	public String  DealerDisplayAdress() throws InterruptedException {
		String text = getAnyText(driver, DealerDisplayAdress1) +
				      getAnyText(driver, DealerDisplayAdress2) +
				      getAnyText(driver, DealerDisplayAdress4) +
				      getAnyText(driver, DealerDisplayAdress3);
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		System.out.println(text);
		return text;

	}
	
	public void DealerContinue() throws InterruptedException {
		System.out.println("Dealer Continue");
		//waitForElementClickable(driver, DealerContinue);
		clickElement(driver, DealerContinue);
	}
	
   public String getDealerHeader() throws TimeoutException {
		System.out.println("check arrive on Dealer page");
		return getAnyText(driver, dealerHeader,15);
   }
   
   public String getDealerHeader_AC() {
		System.out.println("check arrive on Dealer page");
		return getAnyText(driver, dealerHeader_AC);
  }
   
   public String getDealerHeader_OV() {
		System.out.println("check arrive on dealer page");
		return getAnyText(driver, dealerHeader_OV);
   }
   
   public String getIdentificationHeader_OV() {
		System.out.println("check arrive on dealer page");
		return getAnyText(driver, identificationHeader_OV);
   }
   
   public String getDelerSelectedValue() {
		System.out.println("Text after deler selected ");
		return getAnyText(driver, delerSelectedText);
   }
   public String getTextAfterDelerSelected() {
		System.out.println("Text after deler selected ");
		return getAnyText(driver, checkDelerSelectedText);
   }
	
}