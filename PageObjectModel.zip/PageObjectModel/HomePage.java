package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class HomePage extends UniversalMethods {
    public By chatPopup = By.id("helpButtonSpan");
    WebDriver driver = null;

    int index;

    public static String getHomePageVahicleName;
    By homepageLogo = By.id("TESTING_LOGO");
    By HomepageLogo_Citroen = By.xpath("//*[@data-testid='TESTING_LOGO_BTN']");
    By Homepage_First_Brand = By.className("carTitleWrap--link");//cashPrice
    By Homepage_First_Price_ES = By.className("cashPrice");
    //By Homepage_First_Price_FR = By.className("cashPrice");
    By Homepage_First_Price_FR =By.xpath("//*[contains(@data-testid,'TESTING_CASH_PRICE')]");
    By Homepage_First_Price_UK = By.className("cashPrice");
    By Homepage_Monthly_Price_FR = By.className("monthlyPrice");
    By Homepage_Monthly_Price_UK = By.className("monthlyPrice");
    //By Homepage_Cash_Price = By.xpath("(//div[contains(@class,'cashPrice')]/span/span[@class='formatMoney'])[1]");
    By Homepage_Cash_Price=By.xpath("(//*[contains(@data-testid,'TESTING_CASH_PRICE')]/span/span)[1]");
    public static By monthly_Price = By.className("monthlyPrice");
    //By viewVehicleBtn = By.id("TESTING_DETAIL_0");
    By viewVehicleBtn=By.xpath("//*[@data-testid='TESTING_DETAIL_0']");
    //By ViewVehicleBtn_AC_noEC41 = By.id("TESTING_DETAIL_0");
    By ViewVehicleBtn_AC_noEC41 =By.xpath("//*[@data-testid='TESTING_DETAIL_0']");
            //By firstVehicleName = By.className("carTitleWrap--link");
    By firstVehicleName = By.xpath("//*[@data-testid='TESTING_CAR_TITLE_0']/a/h2");
    //By financeVehicleName = By.xpath("//div[@class='monthlyPrice']/ancestor::div[@class='priceBoxWrapper']/../preceding-sibling::div[@class='carTitleWrap']/a/h2");
    By financeVehicleName = By.xpath("//div[@class='monthlyPrice']/ancestor::div[contains(@class, 'priceBoxWrapper')]//ancestor::div[contains(@class, ' priceBoxContainer')]/preceding-sibling::div[@class='carTitleWrap']/a/h2");
    //By financeViewVehicleBtn = By.xpath("//div[@class='monthlyPrice']/ancestor::div[contains(@class, 'priceBoxWrapper')]/ancestor::div[contains(@class, ' priceBoxContainer')]/following-sibling::div[@class='buttonWrap']/button");
    By financeViewVehicleBtn = By.xpath("//*[contains(@data-testid,'TESTING_FINANCE_PRICE')]/parent::div/parent::div/parent::div/parent::div/parent::div/parent::div/following-sibling::div/button");
    By firstVehicleNotice = By.xpath("(//div[@class='priceNotice'])[1]");
    By ViewDefaultVehicleBtn = By.xpath("//button[starts-with(@id,'TESTING_DETAIL_')]");
    By TotalTestingOffers = By.xpath("//*[@data-testid='TESTING_OFFER_ENABLED']//div[contains(@class,'with-sticker')] | //*[@data-testid='TESTING_OFFER_ENABLED']//div//div//a//h2[contains(@class,'carTitleWrap')]");
    By BooTestDrive = By.className("dy-full-width-notifications-close");
    //Check Image On HP
    //By imageCheck = By.id("banner-top_level");
    //By imageCheck = By.xpath("//div[@id='banner-second_level']/div/div/div[@class='htmltext' and  text()='This is the test of banners']");
    //By imageCheck=By.xpath("//div[@id='banner-second_level']/div/div/div[@class='htmltext']");
    By imageCheck=By.xpath("//*[@data-testid='banner-top_level']");
    //NeedHelpLocators
    //By NeedHelpButton = By.xpath("//*[@data-id = 'TESTING_NEED-HELP']");
    //By NeedHelpButton = By.xpath("//a[@class='need-help-link ']");
    //By NeedHelpButton = By.cssSelector(".needHelp");
    By NeedHelpButton = By.xpath("//*[@data-testid='header-navigation-need-help'] | (//*[@class='help'])[2]");
    //header-navigation-need-help
    //By NeedHelpTitle = By.xpath("//div[@class='modalSidebar__wrap__header']/span[@class='modalSidebar__wrap__header__title']");
    By NeedHelpTitle = By.xpath("//*[@data-testid='header-navigation-contact-section']/span|//div[@class='modalSidebar__wrap__header']/span[@class='modalSidebar__wrap__header__title']");
    //By faqTitle_ES = By.xpath("//div[@class='faq']/div[@class='link']/a");
    By faqTitle_ES = By.xpath("//*[@data-testid='TESTING_MODAL_NEED_HELP_FAQ_LINK']");
    //By faqTitle_FR = By.xpath("//div[@class='faq']/div[@class='link']/a");
    By faqTitle_FR=By.xpath("//*[@data-testid='TESTING_MODAL_NEED_HELP_FAQ_LINK']");
    //By faqLink = By.xpath("//div[@class='faq']//div[@class='link']//a");
    By faqLink = By.xpath("//*[@data-testid='TESTING_MODAL_NEED_HELP_FAQ_LINK']");
    //***************************
    By FAQButton = By.xpath("//div[@class='need-help-section__faq']/a");
    /////Account Selectors
    //By AccountIcon = By.xpath("//a[@id='TESTING_MY_ACC']/span | (//div[@class='account'])[2]/a[@href='/login']/span[2]");
    By AccountIcon = By.xpath("//*[@data-testid='header-navigation-login-button']/span|(//*[@class='account']/a)[2]");
    By ConnexionButton = By.xpath("//*[@data-testid = 'TESTING_USER_LOGIN']");
    By CancleConnexionButton = By.id("cancel");
    By accountCreation = By.xpath("//a[@data-testid='TESTING_MY_ACC_STATEMENT']");
    By myOrderVehiclesLink = By.xpath("//li[@data-testid='TESTING_MYSAVES_SIDEMENUITEM']/a");
    By deleteOfferLink = By.xpath("//button[contains(@data-testid, 'TESTING_DELETE_OFFER')]");
    By deleteOrderConfirm = By.xpath("//*[@data-testid='TESTING_DELETE_CONFIRMATION']");
    By disConnexionButton = By.xpath("//* [@class = 'logoutButtonText']");
    By verifyDealMsg = By.xpath("//*[@class='nothing-found']");
    By logoutButton = By.xpath("//li[@data-testid='TESTING_LOGOUT_SIDEMENUITEM']/a");
    /////Cart Selectors
    By CartIcon = By.xpath("//*[@id='TESTING_BASKET']/span | //*[@id='TESTING_BASKET'] | //*[@id='TESTING_TO_BASKET_BOX_ORDERPANEL']|//*[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX']");

    //By CartIcon = By.id("TESTING_BASKET");
    //By CartIcon = By.id("TESTING_TO_BASKET_BOX_ORDERPANEL");

    By errorMessage= By.xpath("//div[@class='errorPage__content-wrapper']");
    By CartEmptyText = By.xpath("//* [@data-testid = 'TESTING_EMPTY_BASKET_TEXT']");
    By CartChooseCarButton = By.xpath("//* [@data-testid = 'TESTING_EMPTY_BASKET']");
    ///Filters Selectors
    ///New Energy
    //By energylist = By.xpath("//div[@id='fuel']/div[@class='energy']/div[contains(@class,'energyItem')]");
    By energylist = By.xpath("//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_FUEL_ITEM')]");
    By priceSelected=By.xpath("//button[contains(@class, 'prices selected')]");
    //By ResetButton = By.className("reset");
    By ResetButton=By.xpath("//*[@data-testid='TESTING_FILTER_RESET_BUTTON']");
    //GearBox
    //By GearBoxlist = By.xpath("//div[@class='gear']/div[contains(@class,'gearItem')]/div/input");
    By GearBoxlist = By.xpath("//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_GEARBOX_ITEM')]/input");
    //Footer Selectors
    //By footerBoxList = By.xpath("//*[@id = 'faqs']/div");
    By footerBoxList = By.xpath("//div[contains(@class, 'faqCategory')]/div/span/div");
    By footerCondition = By.xpath("//*[@class = 'footer']/ul/div");
    By footer = By.xpath("//*[@class = 'footer']/ul");
    By Cookies = By.xpath("//*[@class = 'cookiesPreferences']");
    By CookiesAcceptAll = By.xpath("//*[@id = '_psaihm_cta_container']/ a[1]");
    By CookiesAcceptAllFooters = By.id("_psaihm_button_param_accept");
    //store pro AC
    By StoreProButton = By.xpath("//*[@id = 'TESTING_B2B']/span");
    By StoreProPageTitle = By.xpath("//*[@class = 'main-section']/div/p/span");
    By StoreB2CButton = By.xpath("//*[@id = 'TESTING_B2C']/span");
    By PopUp = By.xpath("//*[@class = 'close']");
    By cookieFooter = By.xpath("//*[@class = 'footer']/ul/li");

    // Range Function
    By rangeStartPrice = By.xpath("//span[@data-testid='TESTING_START_RANGE']/span[@class='formatMoney']");
    By rangeEndPrice = By.xpath("//span[@data-testid='TESTING_END_RANGE']/span[@class='formatMoney']");

    By rangeCashPriceList = By.xpath("//*[contains(@data-testid, 'TESTING_OFFER')]//div//div[@class='carTitleWrap']");

    By rangeEnabledCashPriceList = By.xpath("//*[contains(@data-testid, 'TESTING_OFFER_ENABLED')]//div//div[@class='carTitleWrap']");

    By rangeDisabledCashPriceList = By.xpath("//*[contains(@data-testid, 'TESTING_OFFER_DISABLED')]//div//div[@class='carTitleWrap']");

    // Info
    //By infoIcon_FR = By.id("infoCircle");
    By infoIcon_FR = By.xpath("//*[contains(@aria-labelledby, 'svgImgSeeFinanceDetails')]");
    public static By infoIcon_ES = By.xpath("//button[(text()='Ejemplo TAE') or (text()='Ejemplo Renting') or (text()='Detalle de la simulación de financiacion')]");

    //public static //By infoMonthlyPrice = By.xpath("//span[contains(text(), 'CUOTA MENSUAL') or contains(text(), 'Cuota mensual')]/../following-sibling::div/span/span");
    public static By infoMonthlyPrice = By.xpath("//span[contains(text(), 'MENSUALIDAD')]/../following-sibling::div/span/span|//span[@data-testid='TESTING_FINANCE_PRICE_1_9']/span[@class='formatMoney']");

    public static By infoTotalPrice = By.xpath("//span[contains(text(), 'PVP (MODELO BASE)')]/../following-sibling::div/span/span | //span[contains(text(), 'PVP(MODELO BASE)')]/../following-sibling::div/span/span");
    By infoMonthlyPrice_FR = By.xpath("//span[(text()='48 loyer au titre de la location') or (text()='47 loyer au titre de la location')]/../following-sibling::div/span/span");

    By infoPopupMonthlyPrice = By.xpath("//span[@data-testid='TESTING_FINANCE_PRICE_1_9']/span[@class='formatMoney']|//span[@data-testid='TESTING_FINANCE_PRICE_1_7']/span[@class='formatMoney']");

    By infoPopupTotalPrice = By.xpath("//span[@data-testid='TESTING_FINANCE_PRICE_1_2']/span[@class='formatMoney']");
   public By closeButton = By.xpath("//button[@class='modalSidebar__wrap__header__closeBtn'] | //button[@data-testid='TESTING_CLOSE_MODAL']");

    By closeButton_InfoPupUp = By.xpath("//button[@data-testid='TESTING_CLOSE_MODAL' and @class='modalSidebar__wrap__header__closeBtn']");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

   /* @Test(description = "Closing Book Test Drive")
    public void CloseBookTestDrive(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            waitForElementPresent(driver,BooTestDrive,1);
            if (driver.findElements(BooTestDrive).size() != 0) {
                clickElement(driver, BooTestDrive);
                NodeORSubNode.log(Status.INFO, "Closed Book a Test Drive");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Close Book Test Drive", e);
        }
    }*/

    @Test(description = "Closing Book Test Drive")
    public void CloseBookTestDrive(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            if (driver.findElements(BooTestDrive).size() != 0) {
                highlightElement(driver, BooTestDrive);
                NodeORSubNode.log(Status.PASS, "Closed Book a Test Drive is available");
                clickElement(driver, BooTestDrive);
                NodeORSubNode.log(Status.INFO, "Closed Book a Test Drive");
                //Thread.sleep(500);
            } else {
                NodeORSubNode.log(Status.FAIL, "Unable to Close Book a Test Drive");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Close Book Test Drive", e);
        }
    }

    @Test(description = "clicking on HomePage Logo")
    public void clickHomePageLogo(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("Clicked on HomePage Logo");
        try {
            if (!config.getProperty("url").contains("citroen")) {
                clickElement(driver, homepageLogo);
                NodeORSubNode.log(Status.INFO, "Clicked on Home Page Logo");
                //waitForElementClickable(driver, HomepageLogo);
            } else {
                clickElement(driver, HomepageLogo_Citroen);
                NodeORSubNode.log(Status.INFO, "Clicked on Home Page Logo");
                //waitForElementClickable(driver, HomepageLogo_Citroen);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Home Page Logo", e);
        }
    }

    @Test(description = "Clicking on view vehicle button")
    public void clickViewVehicle(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, viewVehicleBtn);
            System.out.println("Clicked on view vehicle button on NON-EC41 ");
            NodeORSubNode.log(Status.INFO, "Clicked on View Vehicle Button on NON-EC41 ");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on view Vehicle button on NON-EC41 ", e);
        }
    }
    /*@Test(description = "Clicking on view vehicle button")
    public void clickViewVehicle() {
        try {
            clickElement(driver, viewVehicleBtn);
            System.out.println("Clicked on view vehicle button");
            //NodeORSubNode.log(Status.INFO, "Clicked on View Vehicle Button");
        }catch (Exception e){
            e.printStackTrace();
            //catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to click on view Vehicle button",e);
        }
    }*/

    public boolean checkHomePageIsDisplayed(String resultDirectory, ExtentTest NodeORSubNode) {
        Boolean bool = false;
        try {
            waitForElementClickable(driver, viewVehicleBtn, 40);
            bool = isElementPresent(driver, viewVehicleBtn);
            if (bool = true) {
                NodeORSubNode.log(Status.PASS, "View Vehicle Button is Displayed");
            } else {
                NodeORSubNode.log(Status.FAIL, "View Vehicle Button is Not Displayed");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with HomePage Display as View Vehicle Button is Not Displayed", e);
        }
        return bool;
    }

    @Test(description = "Clicking on view vehicle button ACnoEC41")
    public void clickViewVehicleACnoEC41(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            scrollingJS(driver, ViewVehicleBtn_AC_noEC41);
            System.out.println("Clicked on view vehicle button ACnoEC41");
            NodeORSubNode.log(Status.INFO, "Clicked on view vehicle button ACnoEC41");
            //waitForUrlContains("trim",driver,10);
            waitForPageToLoad(driver,10);
            // driver.findElement(ViewVehicleBtn_AC_noEC41).click();
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on view vehicle button ACnoEC41", e);
        }
    }

    @Test(description = "Clicking on Finance view vehicle button")
    public void clickViewVehicle(String resultDirectory, ExtentTest NodeORSubNode,String PaymentMode, String brand, String Country) {
        int k;
        try {
            List<Integer> relIndex=new ArrayList<>();
            List<WebElement> TotalVehicleList = new ArrayList<WebElement>();
            List<WebElement> infoList = new ArrayList<WebElement>();
           // TotalVehicleList= driver.findElements(By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']//div[contains(@class,'with-sticker')] | //*[@data-testid='TESTING_OFFER_ENABLED']//div//div//a//h2[contains(@class,'carTitleWrap')]"));
            TotalVehicleList= driver.findElements(By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']//div[contains(@class,'with-sticker')]"));
            int TotalVehicleListSize=TotalVehicleList.size();
            NodeORSubNode.log(Status.INFO, "Total number of Vehicles available: "+TotalVehicleListSize);
            if(PaymentMode.equalsIgnoreCase("Finance")) {
                infoList = driver.findElements(financeViewVehicleBtn);
                NodeORSubNode.log(Status.INFO, "Clicking on first CONFIGURA Y COMPRA button for Finance Payment");
                writeToProperties("currentCashPrice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("(//*[contains(@data-testid,'TESTING_FINANCE_PRICE_')])[1]/parent::div/parent::div/div[1]")).replace(",","."))));
                writeToProperties("currentFinanceprice", String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("(//*[contains(@data-testid,'TESTING_FINANCE_PRICE_')])[1]")).replace(",","."))));
                highlightElement(driver,infoList.get(0));
                infoList.get(0).click();
            }else{
                for (k=0;k<TotalVehicleListSize;k++) {
                    //waitForPageToLoad(driver, 10);
                    System.out.println(TotalVehicleList.get(k).getText());
                          if (((TotalVehicleList.get(k).getText().contains("/mes") == false)
                            && (TotalVehicleList.get(k).getText().contains("/mois") == false)
                            && (TotalVehicleList.get(k).getText().contains("/MES") == false)
                            && (TotalVehicleList.get(k).getText().contains("/MOIS") == false)
                            && (TotalVehicleList.get(k).getText().contains("Need a hand?") == false)
                            && (TotalVehicleList.get(k).getText().contains("NEED A HAND?") == false)
                            && (TotalVehicleList.get(k).getText() != null))) {
                        relIndex.add(k);
                    }
                }
                NodeORSubNode.log(Status.INFO, "Clicking on first CONFIGURA Y COMPRA button for cash Payment");
                By by;
                System.out.println("Relative index: "+ relIndex.size());
                if(relIndex.size()==0){
                    clickOnResetButton(resultDirectory,NodeORSubNode);
                    Thread.sleep(5000);
                    //by=By.xpath("(//div[@class=\"buttonWrap\"]/button/span[text()='CONFIGURA Y COMPRA' or text()='Voir les Offres' or text()='Voir les offres' or text()='Configurar' or text()='Voir les véhicules' or text()='Ver Ofertas'])[1]");
                    by=By.xpath("(//*[contains(@data-testid,'TESTING_DETAIL_')])[1]");
                    writeToProperties("currentCashPrice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("(//*[contains(@data-testid,'TESTING_CASH_PRICE_')])[1]")).replace(",","."))));
                } else{
                    System.out.println(k);
                    int index= k ;
                    List<WebElement> allChildern=driver.findElements(By.xpath("//div[@class=\"buttonWrap\"]/button/span[text()='CONFIGURA Y COMPRA' or text()='Voir les Offres' or text()='Voir les offres' or text()='Configurar' or text()='Voir les véhicules' or text()='Ver Ofertas']"));
                    if(index>allChildern.size()){
                        index-=1;
                    }
                    //by=By.xpath("(//div[@class=\"buttonWrap\"]/button/span[text()='CONFIGURA Y COMPRA' or text()='Voir les Offres' or text()='Voir les offres' or text()='Configurar' or text()='Voir les véhicules' or text()='Ver Ofertas'])["+index+"]");
                    by=By.xpath("(//*[contains(@data-testid,'TESTING_DETAIL_')])["+index+"]");
                    writeToProperties("currentCashPrice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("(//*[contains(@data-testid,'TESTING_CASH_PRICE_')])["+index+"]")).replace(",","."))));
                }

                 //getHomePageVahicleName = getAttributeValue(driver,By.xpath("(//*[@class='carTitleWrap--link'])["+index+"]"), "title");
                if(isElementDisplayed(driver,closeButton)){
                    clickElement(driver,closeButton);
                }
                Thread.sleep(3000);
                if(brand.equalsIgnoreCase("AC")&& Country.equalsIgnoreCase("FR")){
                    clickUsingJS(driver,by);
                } else {
                    clickElement(driver,by);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Finance view vehicle button", e);
        }
    }

    @Test(description = "Getting vehicle Model")
    public String getModelVehicle(String resultDirectory, ExtentTest NodeORSubNode,String PaymentMode, String brand) {
        String ModelName=null;
        int k;
        try {
            List<Integer> relIndex=new ArrayList<>();
            List<WebElement> TotalVehicleList = new ArrayList<WebElement>();
          //  List<WebElement> infoList = new ArrayList<WebElement>();
            if(brand.equalsIgnoreCase("DS") || brand.equalsIgnoreCase("OV") || brand.equalsIgnoreCase("AC"))
            {
                TotalVehicleList = driver.findElements(By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']"));

            }else {
                TotalVehicleList = driver.findElements(By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']"));
            }



            int TotalVehicleListSize=TotalVehicleList.size();
            NodeORSubNode.log(Status.INFO, "Total number of Vehicles available: "+TotalVehicleListSize);
            if(PaymentMode.equalsIgnoreCase("Finance")) {
                /*infoList = driver.findElements(financeViewVehicleBtn);
                highlightElement(driver,infoList.get(0));
                ModelName= infoList.get(0).getAttribute("data-testid");
                NodeORSubNode.log(Status.INFO, "Returned Finance 1st Model Name is: "+ModelName);*/
                for (k=0;k<TotalVehicleListSize;k++) {
                    System.out.println(TotalVehicleList.get(k).getText());
                    if (((TotalVehicleList.get(k).getText().contains("/mes") == true)
                            || (TotalVehicleList.get(k).getText().contains("/mois") == true)
                            || (TotalVehicleList.get(k).getText().contains("/MES") == true)
                            || (TotalVehicleList.get(k).getText().contains("/MOIS") == true))
                            || (TotalVehicleList.get(k).getText() != null)) {
                    }
                    relIndex.add(k+1);

                }
                By by;
                    if(k>=TotalVehicleListSize) {
                    by = By.xpath("(//div[@class='carTitleWrap']/a)["+(k-1)+"]");
                }else
                {
                    by = By.xpath("(//div[@class='carTitleWrap']/a)["+k+"]");

                }
                highlightElement(driver,by);
                ModelName= driver.findElement(by).getText();
                NodeORSubNode.log(Status.INFO, "Returned Cash 1st Model Name is: "+ModelName);
            }else{
                for (k=0;k<TotalVehicleListSize;k++) {
                    if (((TotalVehicleList.get(k).getText().contains("/mes") == false)
                            && (TotalVehicleList.get(k).getText().contains("/mois") == false)
                            && (TotalVehicleList.get(k).getText().contains("/MES") == false)
                            && (TotalVehicleList.get(k).getText().contains("/MOIS") == false))
                            && (TotalVehicleList.get(k).getText() != null)) {
                        relIndex.add(k+1);
                    }
                }
                System.out.println(k);
                By by;
              /*  if(relIndex.size()==0){
                    by=By.xpath("(//div[@class='carTitleWrap']/a)[1]");
                } else{
                    by=By.xpath("(//div[@class='carTitleWrap']/a)["+k+"]");
                }*/
                if(k>=TotalVehicleListSize) {
                    by = By.xpath("(//div[@class='carTitleWrap']/a)["+(k-1)+"]");
                }else
                {
                    by = By.xpath("(//div[@class='carTitleWrap']/a)["+k+"]");

                }
                highlightElement(driver,by);
                //clickElement(driver,by);
                ModelName= driver.findElement(by).getText();
                NodeORSubNode.log(Status.INFO, "Returned Cash 1st Model Name is: "+ModelName);
            }

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Finance view vehicle button", e);
        }
        return ModelName;
    }

    @Test(description = "Getting Finance vehicle name")
    public String getFinanceVehicleName(String resultDirectory, ExtentTest NodeORSubNode,String Brand) {

        String str = null;
        System.out.println("Getting finance vehicle name");
        try {
            if(Brand.equalsIgnoreCase("DS")){
                financeVehicleName=By.xpath("//*[@class='carTitleWrap--link']");
            }
            str = getAnyText(driver, financeVehicleName);
            NodeORSubNode.log(Status.INFO, "Finance Vehicle name is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting finance vehicle name", e);
        }

        return str;
    }

    @Test(description = "Getting first vehicle name")
    public String getFirstVehicleName(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting first vehicle name");
        String str = null;
        try {
            str = getAnyText(driver, firstVehicleName);
            NodeORSubNode.log(Status.INFO, "First Vehicle name is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting first vehicle name", e);
        }

        return str;
    }

    @Test(description = "Getting first Brand")
    public String getBrand_HomePage(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting First Brand");
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            str = getAnyText(driver, Homepage_First_Brand);
            NodeORSubNode.log(Status.INFO, "First Brand is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting first Brand", e);
        }

        return str;

    }

    /*
     * public String getBrand_DS4_Fin_HomePage() {
     * System.out.println("Getting First Brand"); return getAnyText(driver,
     * Homepage_First_Brand);
     *
     * }
     */
    @Test(description = "Getting First Brand's Price Homepage_First_Price_FR")
    public String getPrice_HomePage_FR(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting First Brand's Price Homepage_First_Price_FR");
        String str = null;
        try {
            waitForElementPresent(driver, Homepage_First_Price_FR, 5);
            str = getAnyText(driver, Homepage_First_Price_FR);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Getting First Brand's Price Homepage_First_Price_FR: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Unable to Get First Brand's Price Homepage_First_Price_FR: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting First Brand's Price Homepage_First_Price_FR", e);
        }

        return str;
    }

    @Test(description = "Getting First Brand's Price Homepage_First_Price_UK")
    public String getPrice_HomePage_UK(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting First Brand's Price Homepage_First_Price_UK");

        String str = null;
        try {
            waitForElementPresent(driver, Homepage_First_Price_UK, 5);
            str = getAnyText(driver, Homepage_First_Price_UK);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Getting First Brand's Price Homepage_First_Price_UK: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Unable to Get First Brand's Price Homepage_First_Price_UK: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting First Brand's Price Homepage_First_Price_UK", e);
        }

        return str;
    }

    @Test(description = "Getting Homepage First Price ES")
    public String getPrice_HomePage_ES(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting Homepage First Price ES");

        String str = null;
        try {
            str = getAnyText(driver, Homepage_First_Price_ES);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Getting Homepage First Price ES: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Unable to Get Homepage First Price ES: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting Homepage First Price ES", e);
        }

        return str;
    }

    /*@Test(description = "Getting Cash Price for Brand's Price Homepage_Cash_Price")
    public String getCashPrice_HomePage(String resultDirectory, ExtentTest NodeORSubNode) {
        String str=null;
        try{
            str=getAnyText(driver, Homepage_Cash_Price);
            System.out.println("Getting Cash Price for Brand's Price Homepage_Cash_Price");
            NodeORSubNode.log(Status.INFO, "Got Cash Price for Brand's Price Homepage_Cash_Price: "+str);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Cash Price for Brand's Price Homepage_Cash_Price",e);
        }
        return str;
    }*/

    @Test(description = "Getting Cash Price for Brand's Price Homepage_Cash_Price")
    public float getCashPrice_HomePage(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting Cash Price for Brand's Price Homepage_Cash_Price");
        float str = 0;
        try {
            str = Float.parseFloat(getAnyText(driver, Homepage_Cash_Price, 10).replace(" ","").substring(0,5));
            if (str != 0) {
                NodeORSubNode.log(Status.PASS, "Getting Cash Price for Brand's Price Homepage_Cash_Price: " + str);
            } else {
                //NodeORSubNode.log(Status.FAIL, "Unable to Get Cash Price for Brand's Price Homepage_Cash_Price: " + str);
                failWithScreenshot("Unable to Get Cash Price for Brand's Price Homepage_Cash_Price: " + str, resultDirectory, driver, NodeORSubNode);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting Cash Price for Brand's Price Homepage_Cash_Price:", e);
        }

        return str;
    }

    /*@Test(description = "Getting Brand's Cash Price Homepage_Cash_Price")
    public int getCashPriceNum_HomePage(String resultDirectory, ExtentTest NodeORSubNode) {
        int num=0;
        try{
            num=extractNumericFromString(getAnyText(driver, Homepage_Cash_Price,5));
            System.out.println("Getting Brand's Cash Price Homepage_Cash_Price: "+num);
            NodeORSubNode.log(Status.INFO, "Getting Brand's Cash Price Homepage_Cash_Price: "+num);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Brand's Cash Price Homepage_Cash_Price",e);
        }
        return num;
    }*/

    @Test(description = "Getting Brand's Cash Price Homepage_Cash_Price")
    public float getCashPriceNum_HomePage(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting Brand's Cash Price Homepage_Cash_Price");
        float cashPrice = 0;
        try {
            cashPrice = Float.parseFloat(getAnyText(driver, Homepage_Cash_Price,8).replace(" ","").substring(0,5));
            if (cashPrice != 0) {
                NodeORSubNode.log(Status.PASS, "Getting Brand's Cash Price Homepage_Cash_Price: " + cashPrice);
            } else {
                //NodeORSubNode.log(Status.FAIL, "Unable to Get Brand's Cash Price Homepage_Cash_Price: " + cashPrice);
                failWithScreenshot("Unable to Get Brand's Cash Price Homepage_Cash_Price: " + cashPrice, resultDirectory, driver, NodeORSubNode);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting Brand's Cash Price Homepage_Cash_Price: "+ cashPrice, e);
        }

        return cashPrice;
    }

    @Test(description = "Getting Monthly Price for Brand's Price")
    public String getMonthlyPriceFinance_HomePage_FR(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, Homepage_Monthly_Price_FR, 5);
            System.out.println("Getting Monthly Price for Brand's Price: " + str);
            NodeORSubNode.log(Status.INFO, "Getting Monthly Price for Brand's Price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Monthly Price for Brand's Price", e);
        }
        return str;
    }

    @Test(description = "Getting Monthly Price for Brand's Price")
    public String getMonthlyPriceFinance_HomePage_UK(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, Homepage_Monthly_Price_UK);
            System.out.println("Getting Monthly Price for Brand's Price: " + str);
            NodeORSubNode.log(Status.INFO, "Getting Monthly Price for Brand's Price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Monthly Price for Brand's Price", e);
        }
        return str;
    }

//	public int getPriceNum_HomePage() {
//		System.out.println("Getting First Brand's Price");
//		return extractNumericFromString(getAnyText(driver, Homepage_First_Price));
//	}

    @Test(description = "Getting Brand's Monthly Price Homepage_Monthly_Price_FR")
    public int getPriceMonthlyNum_HomePage_FR(String resultDirectory, ExtentTest NodeORSubNode) {
        int num = 0;
        try {
            num = extractNumericFromString(getAnyText(driver, Homepage_Monthly_Price_FR));
            System.out.println("Got Brand's Monthly Price Homepage_Monthly_Price_FR");
            NodeORSubNode.log(Status.INFO, "Got Brand's Monthly Price Homepage_Monthly_Price_FR: " + num);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Brand's Monthly Price Homepage_Monthly_Price_FR", e);
        }
        return num;
    }

    @Test(description = "Getting Brand's Monthly Price Homepage_Monthly_Price_UK")
    public int getPriceMonthlyNum_HomePage_UK(String resultDirectory, ExtentTest NodeORSubNode) {
        int num = 0;
        try {
            num = extractNumericFromString(getAnyText(driver, Homepage_Monthly_Price_UK, 5));
            System.out.println("Got Brand's Monthly Price Homepage_Monthly_Price_UK");
            NodeORSubNode.log(Status.INFO, "Got Brand's Monthly Price Homepage_Monthly_Price_UK: " + num);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Brand's Monthly Price Homepage_Monthly_Price_UK", e);
        }
        return num;
    }

    /*@Test(description = "Getting Number of Offers")
    public int numberOfOffers(String resultDirectory, ExtentTest NodeORSubNode) {
        int offerNo = 0;
        try {
            System.out.println("Getting Number of Offers");
            offerNo = numberOfElements(driver, TotalTestingOffers);
            highlightElement(driver, TotalTestingOffers);
            System.out.println("Number of Offers present: " + offerNo);
            NodeORSubNode.log(Status.INFO, "Number of Offers present: "+ + offerNo);
            if (offerNo > 0) {
                return offerNo;
            } else {
                NodeORSubNode.log(Status.INFO, "Screen seems to be hanged hence refreshing Screen once again");
                //System.err.println("Screen seems to be hanged hence refreshing Screen once again");
                driver.navigate().refresh();
                numberOfOffers(resultDirectory,NodeORSubNode);
            }
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with getting number of Offers",e);
        }
        return offerNo;
    }*/

    @Test(description = "Getting Number of Offers")
    public int numberOfOffers(String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting Number of Offers");
        int offerNo = 0;
        try {
            Thread.sleep(2000);
            offerNo = numberOfElements(driver, TotalTestingOffers);
            highlightElement(driver, TotalTestingOffers);
            System.out.println("Number of Offers present: " + offerNo);
            if (offerNo > 0) {
                NodeORSubNode.log(Status.PASS, "Number of offers present are more than 0");
                //return offerNo;
            } else {
                NodeORSubNode.log(Status.FAIL, "No offers are present");
                NodeORSubNode.log(Status.INFO, "Screen seems to be hanged hence refreshing Screen once again");
                System.err.println("Screen seems to be hanged hence refreshing Screen once again");
                driver.navigate().refresh();
                numberOfOffers(resultDirectory, NodeORSubNode);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting Number of Offers", e);
        }
        return offerNo;
    }

    // Check home page
    @Test(description = "image Check On HP")
    public void imageCheckOnHP(String resultDirectory, ExtentTest NodeOrSubNOde) {
        //Boolean bool=false;
        try {
            //WebElement bannerImageElement = new WebDriverWait(driver, 30)
                   // .until(ExpectedConditions.visibilityOfElementLocated(imageCheck));

            if (isElementPresent(driver, imageCheck, 5)) {
                NodeOrSubNOde.log(Status.PASS, "Image is Present");
            } else {
                failWithScreenshot("Image is not Present", resultDirectory, driver, NodeOrSubNOde);
                //NodeOrSubNOde.log(Status.FAIL, "Image is not Present");
            }
            //Assert.assertTrue(bannerImageElement.isDisplayed());
            //System.out.println("Is banner displayed: "+bannerImageElement.isDisplayed());
            //Assert.assertTrue(bannerImageElement.isDisplayed(), "Image is not present on Home Page");
        } catch (org.openqa.selenium.TimeoutException e) {
            catchFailDetails(resultDirectory, NodeOrSubNOde, driver, "Error with Display of the Image", e);
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeOrSubNOde, driver, "Error with Display of the Image", e);
        }
    }

    @Test(description = "Getting image URL")
    public String getImageURL(String resultDirectory, ExtentTest NodeORSubNode) {
        String url = null;
        String url2 = null;
        try {
            url = getAttributeValue(driver, imageCheck, "style");
            System.out.println("url to open in new tab is: "+url);
            if (url != null) {
                NodeORSubNode.log(Status.PASS, "url is available");
            } else {
                failWithScreenshot("url is not available", resultDirectory, driver, NodeORSubNode);
                //NodeORSubNode.log(Status.FAIL, "url is not available");
            }

            url2 = url.split("\"")[1];
            NodeORSubNode.log(Status.INFO, "Getting the url from the list :" + url2);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with URL as url is not available", e);
        }
        return url2;
    }

    // need helps fucntions
    @Test(description = "Clicking on Need Help text")
    public void clickonNeedHelp(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Clicking on Need Help text");
            scrollToTop(driver);
            clickElement(driver, NeedHelpButton, 30);
            //Thread.sleep(1000);
            NodeORSubNode.log(Status.INFO, "Clicked on Need Help text");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Need Help text", e);
        }
        //Thread.sleep(1000);
    }

    @Test(description = "Getting Need Help text")
    public String getNeedHelpText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("Get NeedHelpText");
        String str = null;
        try {
            str = getAnyText(driver, NeedHelpTitle,5);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Getting Need Help Text: " + str);
            } else {
                failWithScreenshot("Unable to Get Need Help Text: " + str, resultDirectory, driver, NodeORSubNode);
                //NodeORSubNode.log(Status.FAIL, "Unable to Get Need Help Text: " + str);
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Getting NeedHelp Text:", e);
        }
        return str;
    }

    @Test(description = "Getting FQA text/title")
    public String getFAQText(String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String text = null;
        System.out.println("Get FQA Text");
        try {
            if (country.equals("ES")) {
                waitForElementClickable(driver, faqTitle_ES, 2);
                text = getAnyText(driver, faqTitle_ES);
                NodeORSubNode.log(Status.INFO, "FQA text/title is: " + text);
            }
            if (country.equals("FR")) {
                waitForElementClickable(driver, faqTitle_FR, 2);
                text = getAnyText(driver, faqTitle_FR).trim();
                NodeORSubNode.log(Status.INFO, "FQA text/title is: " + text);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with FQA text/title", e);
        }
        return text;
    }

    @Test(description = "Clicking on FAQ Button")
    public void clickonFAQButton(String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //Thread.sleep(2000);
        try {
            clickElement(driver, faqLink);
            System.out.println("Click on FAQ Button");
            NodeORSubNode.log(Status.INFO, "Clicked on FAQ Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with FQA text/title", e);
        }
    }

    // Account Steps
    @Test(description = "clicking on Account Button")
    public void clickonAccountButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            //System.out.println("Scrolling to top");
            Thread.sleep(2000);
            scrollToTop(driver);
            waitForElementPresent(driver, AccountIcon, 10);
            clickElement(driver, AccountIcon);
            NodeORSubNode.log(Status.INFO, "Clicked on Account Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Account Button", e);
        }
    }

    @Test(description = "clicking on Account Creation logo")
    public void clickonAccountCreation(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Click on account Creation Logo");
            clickUsingJS(driver, accountCreation);
            NodeORSubNode.log(Status.INFO, "Clicked on account Creation Logo");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on account Creation Logo", e);
        }
    }

    @Test(description = "clicking on My Order Vehicles")
    public void clickonMyOrderVehicles(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Click on My Order Vehicles");
            clickElement(driver, myOrderVehiclesLink);
            NodeORSubNode.log(Status.INFO, "Clicked on My Order Vehicles");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on My Order Vehicles", e);
        }
    }

    @Test(description = "clicking on delete offer link")
    public void deleteOffer(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Click on delete offer link");
            // waitForElementClickable(driver, deleteOfferLink);
            clickUsingJS(driver, deleteOfferLink);
            NodeORSubNode.log(Status.INFO, "Clicked on delete offer link");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on delete offer link", e);
        }
    }

    @Test(description = "clicking on delete order confirm")
    public void deleteOrderConfirm(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Click on delete order confirm");
            waitForElementClickable(driver,deleteOrderConfirm,5);
            clickUsingJS(driver, deleteOrderConfirm);
            NodeORSubNode.log(Status.INFO, "Click on delete order confirm");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on delete order confirm", e);
        }
    }

    @Test(description = "clicking on connexion Button")
    public void clickonConnexionButton(String Country, String resultDirectory, ExtentTest NodeORSubNode, String PaymentMode, String Brand) throws InterruptedException {
        try {
            Thread.sleep(3000);
            waitForElementClickable(driver,ConnexionButton,10);
            clickElement(driver, ConnexionButton);
            System.out.println("Click on connexion Button");
            NodeORSubNode.log(Status.INFO, "Clicked on connexion Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on connexion Button", e);
        }
    }

    @Test(description = "clicking on cancel Button")
    public void clickonCancelButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, CancleConnexionButton);
            System.out.println("Clicked on cancel Button");
            NodeORSubNode.log(Status.INFO, "Clicked on cancel Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on cancel Button", e);
        }
    }

    @Test(description = "clicking on disconnection Button")
    public void clickonDisConnection(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, disConnexionButton);
            System.out.println("Click on disconnection Button");
            NodeORSubNode.log(Status.INFO, "Click on disconnection Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on disconnection Button", e);
        }
    }

    @Test(description = "clicking on logout Button")
    public void clickonLogout(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Click on logout Link");
            //Thread.sleep(1000);
            clickElement(driver, logoutButton, 6);
            NodeORSubNode.log(Status.INFO, "Clicked on logout Link");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on logout Link", e);
        }
    }

    @Test(description = "clicking on HomePage Logo")
    public void clickHomeLogo(String Brand, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Clicked on HomePage Logo");
            if (Brand.equals("AC")) {
                clickElement(driver, HomepageLogo_Citroen);
            } else {
                clickElement(driver, homepageLogo);
            }
            NodeORSubNode.log(Status.INFO, "Clicked on HomePage Logo");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Cart steps
    @Test(description = "clicking on cart Icon")
    public void clickonCartIcon(String Country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Click on cart Icon");
            Thread.sleep(2000);
            clickElement(driver, CartIcon,10);
            //NodeORSubNode.log(Status.INFO, "Clicked on cart Icon");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on cart Icon", e);
        }
    }

    @Test(description = "Getting Cart Empty Message")
    public String GetCartEmptyText(String Country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String text = null;
        try {
            if(isElementPresent(driver,errorMessage)!=true) {
                System.out.println("Get Cart Empty Message");
                text = getAnyText(driver, CartEmptyText);
                NodeORSubNode.log(Status.PASS, "Got Car Empty Text: "+text);
            }else{
                NodeORSubNode.log(Status.FAIL, "Error Page appeared");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on cart Icon", e);
        }
        return text;
    }

    @Test(description = "Clicking on choose my car button")
    public void clickonChooseMycar(String Country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            System.out.println("Click on choose my car button");
            //Thread.sleep(3000);
            clickElement(driver, CartChooseCarButton);
            NodeORSubNode.log(Status.INFO, "Clicked on choose my car button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on choose my car button", e);
        }
    }

    ////////////////////////////////////////////////////////////////////////
    @Test(description = "Clicking on Select Finance Offer")
    public void clickSelectFinanceOffer(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
            int monthlyPr = 0;
            System.out.println("Getting Number of Offers");
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            waitForElementClickable(driver, TotalTestingOffers, 5);
            List<WebElement> allEle = driver.findElements(TotalTestingOffers);

            for (int i = 0; i <= allEle.size(); i++) {

                // if ((VehicleChoice.equals("non-ec41")) && (Brand.equals("AC")) && (i <1)) {}
                // else {
                System.out.println("The whole text of the brand is: " + allEle.get(i).getText());
                NodeORSubNode.log(Status.INFO, "The whole text of the brand is: " + allEle.get(i).getText());
                Boolean clickBrand = false;
                if (Country.equalsIgnoreCase("FR")) {
                    clickBrand = (allEle.get(i).getText().contains("TTC"))
                            && ((allEle.get(i).getText().contains("TTC/MOIS"))
                            || (allEle.get(i).getText().contains("TTC/mois")));
                }
                if (Country.equalsIgnoreCase("UK")) {
                    clickBrand = (allEle.get(i).getText().contains("OTR"))
                            && ((allEle.get(i).getText().contains("pm")) || (allEle.get(i).getText().contains("PM")));
                }

                if (clickBrand) {
                    // System.out.println(allEle.get(i).getText());
                    // System.out.println("========================================================");
                    if (Country.equalsIgnoreCase("FR")) {
                        System.out.println(driver.findElement(Homepage_Monthly_Price_FR).getText());
                        monthlyPr = extractNumericFromString(driver.findElement(Homepage_Monthly_Price_FR).getText());
                        NodeORSubNode.log(Status.INFO, "Monthly Price: " + monthlyPr);
                    }

                    if (Country.equalsIgnoreCase("UK")) {
                        System.out.println(driver.findElement(Homepage_Monthly_Price_UK).getText());
                        monthlyPr = extractNumericFromString(driver.findElement(Homepage_Monthly_Price_UK).getText());
                        NodeORSubNode.log(Status.INFO, "Monthly Price: " + monthlyPr);
                    }

                    System.out.println("TTC/Monthly price is: " + monthlyPr);
                    if ((monthlyPr != 0)) {
                        // waitForElementClickable(driver, By.id("TESTING_DETAIL_" + i));
                        clickElement(driver, By.id("TESTING_DETAIL_" + i));
                        NodeORSubNode.log(Status.INFO, "TESTING_DETAIL_" + i);
                        break;
                    }
                }
            }
            // }

        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Choose An Energy", e);
        }
    }

    // Get energy list NEW
    @Test(description = "getting the list of energies")
    public List<WebElement> getEnergyList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("get the list of energies");
        List<WebElement> allEnergies = null;
        try {
            waitForElementClickable(driver, energylist, 10);
            allEnergies = driver.findElements(energylist);
            /*for (WebElement ele:allEnergies
                 ) {
                System.out.println("Energy is: " + ele.getText());
                NodeORSubNode.log(Status.INFO, "Energy is: " + ele.getText());
            }*/
            System.out.println("Total Energy Items Present are: "+allEnergies.size());
            NodeORSubNode.log(Status.INFO, "Got Energy List: " + allEnergies.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Choose An Energy", e);
        }
        //return the liste of energies
        return allEnergies;
    }

    @Test(description = "Choose An Energy")
    public void chooseAnEnergy(int i, String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            //clickElement(driver,By.xpath("//*[@data-testid = 'TESTING_FILTER_fuel']/button[" + i + "]"),5);
            //waitForElementClickable(driver,By.xpath("(//div[@class='energy']/div[contains(@class,'energyItem')]/div[@class='container']/inpu
            // t[@type='checkbox'])["+i+"]"),5);
            waitForElementClickable(driver,By.xpath("(//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_FUEL_ITEM')]/input[@type='checkbox'])["+i+"]"),5);
            waitForPageToLoad(driver,10);
            Thread.sleep(2000);
            clickUsingJS(driver,By.xpath("(//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_FUEL_ITEM')]/input[@type='checkbox'])["+i+"]"));
            waitForPageToLoad(driver,10);
            Thread.sleep(2000);
            //clickElement(driver,By.xpath("(//div[@class='energy']/div[contains(@class,'energyItem')]/div[@class='container']/input[@type='checkbox'])["+i+"]"),5);
            NodeORSubNode.log(Status.INFO, "Choosing energy");
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Choose An Energy", e);
        }
    }

    @Test(description = "getting the list of Gearbox")
    public List<WebElement> getGearBoxList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> allGearBox = null;
        try {
            //clickElement(driver,By.xpath("//div[@class='desktop']/button[contains(@class,'gearbox')]"),5);
            clickElement(driver,By.xpath("//*[@data-testid='TESTING_FILTER_GEARBOX']"),5);
            waitForElementPresent(driver, GearBoxlist, 5);
            allGearBox = driver.findElements(GearBoxlist);
            System.out.println("Got the list of Gearbox which are: " + allGearBox.size());
            NodeORSubNode.log(Status.INFO, "Got the list of Gearbox which are: " + allGearBox.size());
            //waitForElementClickable(driver, GearBoxlist, 2);
            // System.out.println(driver.findElements(energy1).get(0).getText());
            // return the liste of energies
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the list of Gearbox", e);
        }
        return allGearBox;

    }

    @Test(description = "Choosing GearBox")
    public void chooseAGearBox(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {

            i = i + 1;
            Thread.sleep(5000);
            //System.out.println("(//div[@class='gear']/div[contains(@class,'gearItem')]/div[@class='container']/input[@type='checkbox'])["+i+"]");
            System.out.println("(//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_GEARBOX_ITEM')]/input)["+i+"]");
            //waitForElementClickable(driver, By.xpath("//*[@data-testid = 'TESTING_FILTER_gearbox']/button[" + i + "]"), 5);
            //clickElement(driver, By.xpath("(//div[@class='gear']/div[contains(@class,'gearItem')]/div[@class='container']/input[@type='checkbox'])["+i+"]"),10);
            //waitForElementPresent(driver,By.xpath("(//div[@class='gear']/div[contains(@class,'gearItem')]/div[@class='container']/input[@type='checkbox'])["+i+"]"),5);
            //clickUsingJS(driver,By.xpath("(//div[@class='gear']/div[contains(@class,'gearItem')]/div[@class='container']/input[@type='checkbox'])["+i+"]"));
            clickUsingJS(driver,By.xpath("(//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_GEARBOX_ITEM')]/input)["+i+"]"));
            Thread.sleep(5000);
            NodeORSubNode.log(Status.INFO, "Chosen GearBox");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Choose GearBox", e);
        }
    }

    @Test(description = "getting the list of footers")
    public List<WebElement> getFooterList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> allFooters = new ArrayList<WebElement>();
        try {
            //waitForElementClickable(driver, footerBoxList, 5);
            if(isElementPresent(driver,footerBoxList,5)){
                allFooters = driver.findElements(footerBoxList);
                highlightElement(driver, footerBoxList);
                // System.out.println(driver.findElements(energy1).get(0).getText());
                System.out.println("Got the list of footers which are: " + allFooters.size());
                NodeORSubNode.log(Status.PASS, "Got the list of footers which are: " + allFooters.size());
            }else{
                System.out.println("Footer Box is not present");
                NodeORSubNode.log(Status.INFO, "Footers Box is not present");
            }
            // return the liste of energies
        } catch (Exception e) {
            //catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the list of footers", e);
        }
        return allFooters;
    }

    @Test(description = "clicking on open footers")
    public void openFooter(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            //i = i + 1;
            //System.out.println("//*[@id = 'faqs']/div["+i+"]");
            //System.out.println("(//div[contains(@class, 'faqCategory')]/div/span/div)[" + i + "]");
            //scrollIntoView(driver, By.xpath("(//div[contains(@class, 'faqCategory')]/div/span/div)["+i+"]"));
            //Thread.sleep(1000);
            //clickElement(driver, By.xpath("//*[@id = 'faqs']/div["+i+"]"));
            //clickElement(driver, By.xpath("(//div[contains(@class, 'faqCategory')]/div/span/div)["+i+"]"));
            //By by = By.xpath("(//div[contains(@class, 'faqCategory')]/div/span/div)[" + i + "]");
            By by = By.xpath("//div[@data-testid='TESTING_FAQS_TITLE_" + i + "']");
            waitForElementClickable(driver, by, 8);
            clickElement(driver,by,5);
            NodeORSubNode.log(Status.INFO, "clicking on open footer");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on open footers", e);
        }
    }

    @Test(description = "Getting Sub Footer List")
    public List<WebElement> getSubFooterList(int i, String resultDirectory, ExtentTest NodeORSubNode) {
        List<WebElement> allSubFooters = new ArrayList<WebElement>();
        try {
            //allSubFooters = driver.findElements(By.xpath("//*[@id = 'faqs']/div["+i+"]/div/div/div/div"));
            By by = By.xpath("(//div[contains(@class, 'faqCategory')]/div/span/div)[" + i + "]/../following-sibling::div//div[contains(@class, 'faqGroup')]/div/span/div");
            //waitForElementClickable(driver, by, 8);
            if(isElementPresent(driver,by,2)) {
                allSubFooters = driver.findElements(by);
                NodeORSubNode.log(Status.INFO, "Got Sub Footer List which are: " + allSubFooters.size());
            }else{
                allSubFooters=driver.findElements(by);
                NodeORSubNode.log(Status.INFO, "No Sub Footer Found ");
            }
        } catch (Exception e) {
            System.out.println("No sub footers present");
        }
        return allSubFooters;
    }

    @Test(description = "Clicking on Open SubFooter")
    public void openSubFooter(int i, int j, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        i = i + 1;
        j = j + 1;
        System.out.println("//*[@id = 'faqs']/div[" + i + "]/div/div/div/div[" + j + "]");
        Thread.sleep(500);
        try {
            clickElement(driver, By.xpath("//*[@id = 'faqs']/div[" + i + "]/div/div/div/div[" + j + "]"));
            NodeORSubNode.log(Status.INFO, "Clicked on Open SubFooter");
            Thread.sleep(500);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Open SubFooter", e);
        }
    }

    public void openSubFooters(int i, int j, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        i = i + 1;
        //j = j+1;
        //System.out.println("//*[@id = 'faqs']/div["+i+"]/div/div/div/div["+j+"]");
        System.out.println("((//div[contains(@class, 'faqCategory')]/div/span/div)[" + i + "]/../following-sibling::div//div[contains(@class, 'faqGroup')]/div/span/div)[" + j + "]");
        //Thread.sleep(500);
        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            clickElement(driver, By.xpath("((//div[contains(@class, 'faqCategory')]/div/span/div)[" + i + "]/../following-sibling::div//div[contains(@class, 'faqGroup')]/div/span/div)[" + j + "]"), 5);
            NodeORSubNode.log(Status.INFO, "Clicked on Open SubFooter");
            //Thread.sleep(500);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Open SubFooter", e);
        }
    }

    @Test(description = "Getting Footer")
    public int getFooter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //Integer size = null;
        int size = 0;
        try {
            size = driver.findElements(footer).size();
            highlightElement(driver, footer);
            NodeORSubNode.log(Status.INFO, "Getting size of the footer");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get size of the footer", e);
        }
        return size;

    }

    @Test(description = "Getting Footer Condition List")
    public List<WebElement> getFooterConditionList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("get the list of footers");
        List<WebElement> allFootersCondition = null;
        try {
            waitForElementClickable(driver, footerCondition, 5);
            allFootersCondition = driver.findElements(footerCondition);
            highlightElement(driver, footerCondition);
            NodeORSubNode.log(Status.INFO, "Got the list of footers which are: " + allFootersCondition.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get the list of footers", e);
        }
        return allFootersCondition;
    }

    @Test(description = "Accepting All Cookies")
    public void acceptAllCookies(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            Thread.sleep(500);
            // clickElement(driver, Cookies);
            clickUsingJS(driver, CookiesAcceptAll);
            NodeORSubNode.log(Status.INFO, "Accepted All Cookies");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Accepting All Cookies", e);
        }
    }

    @Test(description = "Accepting All Cookies Footers")
    public void acceptAllCookiesFooters(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            waitForElementClickable(driver, CookiesAcceptAllFooters, 2);
            // clickElement(driver, Cookies);

            if (driver.findElements(CookiesAcceptAllFooters).size() != 0) {
                clickUsingJS(driver, CookiesAcceptAllFooters);
                highlightElement(driver, CookiesAcceptAllFooters);
                NodeORSubNode.log(Status.INFO, "Accepted All Cookies Footers");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Accepting All Cookies Footers", e);
        }
    }

    @Test(description = "Clicking on Open Footer Condition")
    public void openFooterCondition(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            i = i + 1;
            System.out.println("//*[@class = 'footer']/ul/div[" + i + "]");
            clickElement(driver, By.xpath("//*[@class = 'footer']/ul/div[" + i + "]"), 5);
            NodeORSubNode.log(Status.INFO, "Clicked on Open Footer Condition");
            //Thread.sleep(500);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Open Footer Condition", e);
        }
    }

    @Test(description = "Clicking on Open Store Pro")
    public void openStorePro(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            //System.out.println(StoreProButton);
            clickElement(driver, StoreProButton);
            NodeORSubNode.log(Status.INFO, "Clicked on Open Store Pro");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Open Store Pro", e);
        }
    }

    @Test(description = "Clicking on Store B2C Button")
    public void openB2CStore(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println(StoreB2CButton);
            clickElement(driver, StoreB2CButton);
            NodeORSubNode.log(Status.INFO, "Clicked on Store B2C Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Store B2C Button", e);
        }
    }

    @Test(description = "Clicking on Reset Button")
    public void clickOnResetButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println(ResetButton);
                scroling(driver, ResetButton);
                NodeORSubNode.log(Status.INFO, "Clicked on Reset Button");

        } catch (Exception e) {
           // catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Reset Button", e);
        }
    }

    @Test(description = "Getting Store Pro Page Title")
    public String getStoreProPageTitle(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String Title = null;
        try {
            waitForElementClickable(driver, StoreProPageTitle);
            Title = driver.findElement(StoreProPageTitle).getText();
            System.out.println("Store Pro Page title is :   " + Title);
            //Thread.sleep(500);
            NodeORSubNode.log(Status.INFO, "Store Pro Page title is :   " + Title);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Store Pro Page title", e);
        }
        return Title;
    }

    @Test(description = "Closing Pop-up")
    public void closePoUp(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println(PopUp);
            clickElement(driver, PopUp);
            NodeORSubNode.log(Status.INFO, "Closed Pop-up");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Closed Pop-up", e);
        }
    }

    @Test(description = "Checking If Footer  Icon Present")
    public boolean footerIconPresent(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        Boolean bool = false;
        try {
            //bool = isElementPresent(driver, By.xpath("//* [@class = 'itemsWrapper']/div[" + i + "]"));
            bool = isElementPresent(driver, By.xpath("(//*[contains(@data-testid,'TESTING_FOOTER_ITEM')])["+i+"]"));
            if (bool = true) {
                NodeORSubNode.log(Status.PASS, "Footer  Icon Present");
            } else {
                NodeORSubNode.log(Status.FAIL, "Footer  Icon is not Present");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Footer Icon", e);
        }
        return bool;
    }

    @Test(description = "Getting Footer Icon Text")
    public String getFooterIconText(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            //str = getAnyText(driver, By.xpath("//* [@class = 'itemsWrapper']/div[" + i + "]/div[2]"), 5);
            str = getAnyText(driver, By.xpath("(//*[contains(@data-testid,'TESTING_FOOTER_ITEM')]/div/following-sibling::div)["+i+"]"), 5);
            //highlightElement(driver,By.xpath("//* [@class = 'itemsWrapper']/div[" + i + "]/div[2]"));
            highlightElement(driver,By.xpath("(//*[contains(@data-testid,'TESTING_FOOTER_ITEM')]/div/following-sibling::div)["+i+"]"));
            NodeORSubNode.log(Status.INFO, "Got Footer Icon Text");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Footer Icon Text", e);
        }
        return str;
    }

    @Test(description = "waiting for Chat Popup")
    public void waitforChatPopup() throws InterruptedException {
        waitForElementPresent(driver, chatPopup, 60);
    }

    @Test(description = "clicking on Cookie Footer")
    public void clickCookieFooter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, cookieFooter);
            NodeORSubNode.log(Status.INFO, "Clicked on Cookie Footer");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error clicking on Cookie Footer", e);
        }
    }

    @Test(description = "Adjusting Range")
    public void adjustRange(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
            //WebElement e = driver.findElement(By.xpath("//div[@class='rc-slider']/div[4][@tabindex='0']"));
            WebElement e = driver.findElement(By.xpath("(//*[@data-testid='TESTING_FILTER_CATEGORY_PRICE_RANGE']/div/div/div/following-sibling::div[3])[1]"));
            //WebElement e= driver.findElement(By.xpath("//button[contains(@class,'prices')]"));
            //clickElement(driver,By.xpath("//button[contains(@class,'prices')]"));
            clickElement(driver,By.xpath("//*[@data-testid='TESTING_FILTER_PRICES']"));
            //WebElement e = driver.findElement(By.xpath("//div[@class='rc-slider']/div[4]"));
            //waitForElementPresent(driver,By.xpath("//div[@class='rc-slider']/div[4][@tabindex='0']"),10);
            waitForElementPresent(driver,By.xpath("(//*[@data-testid='TESTING_FILTER_CATEGORY_PRICE_RANGE']/div/div/div/following-sibling::div[3])[1]"),10);
            Actions move = new Actions(driver);
            move.moveToElement(e).clickAndHold().moveByOffset(100, 0).release().perform();
            NodeORSubNode.log(Status.INFO, "Adjusted Range");
            waitForPageToLoad(driver,10);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Adjusting Range", e);
        }
    }

    @Test(description = "Clicking on Select Button of the Filter")
    public void clickSelectBtn(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
            clickElement(driver,By.className("validate"));
            NodeORSubNode.log(Status.INFO, "Clicked on Select button of the Filter");
            waitForPageToLoad(driver,10);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Select button of the Filter", e);
        }
    }

    @Test(description = "getting Range Price")
    public Float getRangeEndPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String price = null;
        try {
            price = getAnyText(driver, rangeEndPrice).replaceAll(" ","").replace(",",".");
            price =price.substring(0, price.length()-1);
            NodeORSubNode.log(Status.INFO, "Got Price Range");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Price Range", e);
        }
        return Float.parseFloat(price);
    }

    @Test(description = "getting Range Start Price")
    public Float getRangeStartPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String price = null;
        try {
            price = getAnyText(driver, rangeStartPrice).replaceAll(" ","").replace(",",".");
            price =price.substring(0, price.length()-1);
            NodeORSubNode.log(Status.INFO, "Got Range Start Price");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Start Price Range", e);
        }
        return Float.parseFloat(price);
    }

    @Test(description = "get the list of cars in between range price")
    public List<WebElement> getRangeCashPriceCarList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> priceCarList = null;
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            waitForElementClickable(driver, rangeCashPriceList, 10);
            Thread.sleep(2000);
            priceCarList = driver.findElements(rangeCashPriceList);
            for (WebElement ele:priceCarList
                 ) {
                highlightElement(driver, ele);
            }
            System.out.println("Got the list of cars in between range price which are: " + priceCarList.size());
            NodeORSubNode.log(Status.INFO, "Got the list of cars in between range price which are: " + priceCarList.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of cars in between range price", e);
        }
        return priceCarList;
    }

    @Test(description = "get the list of enabled cars in between range price")
    public List<WebElement> getRangeCashPriceEnabledCarList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> priceCarList = null;
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            waitForElementClickable(driver, rangeEnabledCashPriceList, 10);
            Thread.sleep(2000);
            priceCarList = driver.findElements(rangeEnabledCashPriceList);
            for (WebElement ele:priceCarList
            ) {
                highlightElement(driver, ele);
            }
            System.out.println("Got the list of Enabled cars in between range price which are: " + priceCarList.size());
            NodeORSubNode.log(Status.INFO, "Got the list of Enabled cars in between range price which are: " + priceCarList.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of Enabled cars in between range price", e);
        }
        return priceCarList;
    }

    @Test(description = "get the list of enabled cars in between range price")
    public List<WebElement> getRangeCashPriceDisabledCarList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> priceCarList = null;
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            //waitForElementClickable(driver, rangeDisabledCashPriceList);
            //Thread.sleep(2000);
            if(isElementPresent(driver,rangeDisabledCashPriceList,10)) {
                priceCarList = driver.findElements(rangeDisabledCashPriceList);
                for (WebElement ele:priceCarList
                ) {
                    highlightElement(driver, ele);
                }
                System.out.println("Got the list of Disabled cars in between range price which are: " + priceCarList.size());
                NodeORSubNode.log(Status.INFO, "Got the list of Disabled cars in between range price which are: " + priceCarList.size());
            }else{
                NodeORSubNode.log(Status.INFO, "No Disabled cars are present in between selected price range");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of Disabled cars in between range price", e);
        }
        return priceCarList;
    }

    @Test(description = "get the list of cash price")
    public List<WebElement> getCashPriceList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> priceCarList = null;
        try {
            waitForElementPresent(driver, Homepage_Cash_Price, 2);
            priceCarList = driver.findElements(Homepage_Cash_Price);
            highlightElement(driver, Homepage_Cash_Price);
            System.out.println("Got the list of cash price which are: " + priceCarList.size());
            NodeORSubNode.log(Status.INFO, "Got the list of cash price which are: " + priceCarList.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of cash price", e);
        }
        return priceCarList;
    }

    @Test(description = "get the list of monthly price")
    public List<WebElement> getMonthlyPriceList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> priceCarList = null;
        try {
            waitForElementPresent(driver, monthly_Price, 2);
            priceCarList = driver.findElements(monthly_Price);
            highlightElement(driver, monthly_Price);
            System.out.println("get the list of monthly price which is: " + priceCarList.size());
            NodeORSubNode.log(Status.INFO, "Got the list of monthly price which is: " + priceCarList.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of monthly price", e);
        }
        return priceCarList;
    }

    @Test(description = "geting Cash Price")
    public Float getCashPrice(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String cashPrice = null;
        //String xpath = "//*[contains(@data-testid, 'TESTING_OFFER')][" + i + "]//div[@class='cashPrice']//span[@class='formatMoney']";
        String xpath = "(//div[@class='price ']//div[contains(@class,'cashPrice')]//span//span[contains(@class,'formatMoney')])["+i+"]";
        try {
            //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
            //Thread.sleep(5000);
            waitForPageToLoad(driver,10);
            cashPrice = getAnyText(driver, By.xpath(xpath), 5).replaceAll(" ","").replace(",",".");
            StringBuffer sb= new StringBuffer(cashPrice);
            cashPrice= String.valueOf(sb.deleteCharAt(sb.length()-1));
            NodeORSubNode.log(Status.INFO, "Got cash price which is: " + cashPrice);

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Cash Price", e);
        }
        return Float.parseFloat(cashPrice);
    }

    @Test(description = "getting Data Test Id")
    public String getCarOfferDataTestIdAttribute(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String dataTestId = null;
        String xpath = "//*[contains(@data-testid, 'TESTING_OFFER_ENABLED')][" + i + "]";
        try {
            dataTestId = getAttributeValue(driver, By.xpath(xpath), "data-testid", 5);
            NodeORSubNode.log(Status.INFO, "Got Data Test Id: " + dataTestId);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Data Test Id", e);
        }
        return dataTestId;
    }

    @Test(description = "getting Data Test Id for Disabled")
    public String getCarOfferDataTestIdAttributeDisabled(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String dataTestIdDisabled = null;
        String xpath = "//*[contains(@data-testid, 'TESTING_OFFER_DISABLED')][" + i + "]";
        try {
            dataTestIdDisabled = getAttributeValue(driver, By.xpath(xpath), "data-testid", 5);
            NodeORSubNode.log(Status.INFO, "Got Data Test Id: " + dataTestIdDisabled);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Data Test Id", e);
        }
        return dataTestIdDisabled;
    }

    @Test(description = "Clicking on reset Button")
    public void clickReset(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
            clickElement(driver,priceSelected);
            waitForUrlContains("success&prices",driver,10);
            NodeORSubNode.log(Status.INFO, "Clicked on Price Selected Visible Range");
            clickElement(driver, ResetButton);
            waitForUrlContains("success",driver,10);
            NodeORSubNode.log(Status.INFO, "Clicked on Reset");
            clickElement(driver,closeButton);
            NodeORSubNode.log(Status.INFO, "Clicked on close Model Popup icon");
            //Thread.sleep(3500);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Data Test Id", e);
        }
    }

    @Test(description = "getting the list of info for cars")
    public List<WebElement> getInfoList(String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> infoList = null;
        try {
            infoList = new ArrayList<WebElement>();
            if (country.equals("ES")) {
                waitForElementClickable(driver,infoIcon_ES,10);
                infoList = driver.findElements(infoIcon_ES);
                for (WebElement ele :
                        infoList) {
                    highlightElement(driver, ele);
                }
            }
            if (country.equals("FR")) {
                waitForElementClickable(driver,infoIcon_FR,5);
                infoList = driver.findElements(infoIcon_FR);
                for (WebElement ele :
                        infoList) {
                    highlightElement(driver, ele);
                }
            }
            System.out.println("Got the list of info for cars which is: " + infoList.size());
            NodeORSubNode.log(Status.INFO, "Got the list of info for cars which is: " + infoList.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of info for cars", e);
        }
        return infoList;
    }

    @Test(description = "getting the list of cash cars")
    public int validateCashCarList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> infoList = null;
        int count = 0;
        String bothPrice;
        try {
            waitForElementClickable(driver, By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']/div/div[3]/div/div/div/div[2][contains(@class,'price')]"), 10);
            infoList = driver.findElements(By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']/div/div[3]/div/div/div/div[2][contains(@class,'price')]"));
            for (WebElement ele :
                    infoList) {
                bothPrice = ele.getText();
                System.out.println(ele.getText());
                if ((bothPrice.contains("/MES"))) {
                    System.out.println("Monthly Price is available for the current grid");
                } else {
                    System.out.println("Monthly Price is not available for the current grid");
                    String[] eachLine=bothPrice.split("\\R");
                    System.out.println(eachLine[0]);
                    String value=eachLine[0].substring(0,eachLine[0].length()-13).replaceAll(" ","");
                    Float totalCashPrice=Float.parseFloat(value.replace(",","."));
                    //Float totalCashPrice=totalCashPrice.replace(",",".");
                    if((eachLine[0]!=null)&&(totalCashPrice!=0.00)){
                        System.out.println("Total Cash Price for Cash Car is: "+totalCashPrice+" €");
                        NodeORSubNode.log(Status.PASS, "Total Cash Price for Cash Car is: "+totalCashPrice+" €");
                    }
                    count++;
                    highlightElement(driver, ele);
                }
            }
            System.out.println("Got the list of cash cars which is: " + count);
            NodeORSubNode.log(Status.INFO, "Got the list of cash cars which is: " + count);
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of cash cars", e);
        }
        return count;
    }

    @Test(description = "Clicking on Info")
    public void clickInfo(int i, String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //String xpath = "(//div [@class = 'monthlyPrice'])["+ i +"]/div";
        String xpath = null;
        try {
            if (country.equals("ES")) {
                //xpath = "(//button[contains(text(), 'Ejemplo TAE') or contains(text(), 'Ejemplo Renting') or contains(text(), 'Detalle de la simulación de financiacion')])[" + i + "]";
                xpath ="(//*[contains(@data-testid,'TESTING_FINANCE_PRICE_')])["+i+"]/parent::div/parent::div/parent::div/parent::div/div/button";
            }
            if (country.equals("FR")) {
                xpath = "(//div[contains(@data-testid, 'TESTING_INFOICON')]/div[@class = 'vertical'])[" + i + "]";
            }
            clickElement(driver, By.xpath(xpath), 5);
            NodeORSubNode.log(Status.INFO, "Clicked on Financial Info");
            //Thread.sleep(1000);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Financial Info", e);
        }
    }

    @Test(description = "getting Monthly Price")
    public Float getMonthlyPrice(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, By.xpath("(//div[@class='monthlyPrice']/span[1]/span[@class='formatMoney'])[" + i +"]"), 10);
            if(str!=null) {
                System.out.println("Get monthly price: " + str);
                NodeORSubNode.log(Status.INFO, "got Monthly Price: " + str);
            }else{
                NodeORSubNode.log(Status.FAIL, "Monthly Price could not be found");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Monthly Price", e);
        }
        String MonthlyPrice=str.replaceAll(" ","").replace(",",".");
        //StringBuffer sb= new StringBuffer(MonthlyPrice);
        str= MonthlyPrice.substring(0,MonthlyPrice.length()-1);
        //return String.valueOf(sb.delete(0,sb.length()-1));
        return Float.parseFloat(str);
    }

    @Test(description = "getting Monthly Price")
    public Float getTotalPrice(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            //str = getAnyText(driver, By.xpath("(//div[@class='price ']/div[@class='cashPrice ']/span/span[@class='formatMoney'])["+i+"]"), 10);
            str = getAnyText(driver, By.xpath("(//*[contains(@data-testid, 'TESTING_FINANCE_PRICE')]/parent::div/parent::div/div[1]/span[1]/span)["+i+"]"),10);
            if(str!=null) {
                System.out.println("Get Total price: " + str);
                NodeORSubNode.log(Status.INFO, "got Total Price: " + str);
            }else{
                NodeORSubNode.log(Status.FAIL, "Total Price could not be found");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting Total Price", e);
        }
        String TotalPrice=str.replaceAll(" ","").replace(",",".");
        //StringBuffer sb= new StringBuffer(MonthlyPrice);
        str= TotalPrice.substring(0,TotalPrice.length()-1);
        //return String.valueOf(sb.delete(0,sb.length()-1));
        return Float.parseFloat(str);
    }

    @Test(description = "getting info Monthly Price")
    public Float getInfoPopupMonthlyPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, infoMonthlyPrice, 5);
            System.out.println("Get info monthly price: " + str);
            NodeORSubNode.log(Status.INFO, "got info Monthly Price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting info Monthly Price or the Popup itself did not appear or the popup is an error popup", e);
        }
        str=str.replaceAll(" ","").replaceAll(",",".");
        str=str.substring(0,str.length()-1);
        return Float.parseFloat(str);
    }

    @Test(description = "getting info Total Price")
    public Float getInfoPopupTotalPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, infoTotalPrice, 5);
            System.out.println("Get info total price: " + str);
            NodeORSubNode.log(Status.INFO, "got info total Price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting info total Price or the Popup itself did not appear or the popup is an error popup", e);
        }
        str=str.replaceAll(" ","").replaceAll(",",".");
        str=str.substring(0,str.length()-1);
        return Float.parseFloat(str);
    }

    @Test(description = "getting info Monthly Price FR")
    public Float getInfoPopupMonthlyPrice_FR(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, infoMonthlyPrice_FR,3);
            System.out.println("Got info monthly price FR: " + str);
            NodeORSubNode.log(Status.INFO, "Got info Monthly Price FR: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting info Monthly Price FR", e);
        }
        return Float.parseFloat(str);
    }

    @Test(description = "closing info Popup")
    public void closeInfoPopup(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Close popup");
            clickElement(driver, closeButton_InfoPupUp,2);
            NodeORSubNode.log(Status.INFO, "Closed Info Popup");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Closed Info Popup", e);
        }
    }

    @Test(description = "closing Filter Popup")
    public void closeFilterPopup(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            System.out.println("Close popup");
            clickElement(driver, closeButton,2);
            NodeORSubNode.log(Status.INFO, "Closed Filter Popup");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Close Filter Popup", e);
        }
    }

    @Test(description = "info Popup Monthly Price get By")
    public By getInfoPopupMonthlyPriceBy() throws InterruptedException {
        return infoPopupMonthlyPrice;
    }

    @Test(description = "info Popup Total Price get By")
    public By getInfoPopupTotalPriceBy() throws InterruptedException {
        return infoPopupTotalPrice;
    }

    @Test(description = "getting the list of info for cars")
    public List<WebElement> getVehiclesList(String resultDirectory, ExtentTest NodeORSubNode,String Brand, String PaymentMode) {
        List<WebElement> infoList = new ArrayList<WebElement>();
        List<WebElement> TotalVehicleList = new ArrayList<WebElement>();
        List<WebElement> TotalFinVehicleList = new ArrayList<WebElement>();
        int finCountVeh=0;
        HomePage hp=new HomePage(driver);
        try {
            if(driver!=null) {
            /*if(Brand.equalsIgnoreCase("DS")){
                financeViewVehicleBtn=By.xpath("//*[@class='carImageWrap']/following-sibling::div/following-sibling::div/button");
            }*/
                waitForElementPresent(driver, By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']"), 10);
                TotalVehicleList = driver.findElements(By.xpath("//div[@data-testid='TESTING_OFFER_ENABLED']"));

                int TotalVehicleListSize = TotalVehicleList.size();
                NodeORSubNode.log(Status.INFO, "Total number of Vehicles available: " + TotalVehicleListSize);
                for (int k = 0; k < TotalVehicleListSize; k++) {
                    if (PaymentMode.equalsIgnoreCase("Finance")) {
                        if ((TotalVehicleList.get(k).getText().contains("/mes")
                                || TotalVehicleList.get(k).getText().contains("/mois")
                                || TotalVehicleList.get(k).getText().contains("/MES")
                                || TotalVehicleList.get(k).getText().contains("/MOIS")
                                || TotalVehicleList.get(k).getText().contains("/MONTH")
                                || TotalVehicleList.get(k).getText().contains("/Month")
                                || TotalVehicleList.get(k).getText().contains("/month"))
                                && (TotalVehicleList.get(k).getText().contains("Need a hand?") != true)
                        ) {
                            finCountVeh = finCountVeh + 1;
                        }
                    } else {
                        if ((TotalVehicleList.get(k).getText().contains("/mes") == false)
                                && (TotalVehicleList.get(k).getText().contains("/mois") == false)
                                && (TotalVehicleList.get(k).getText().contains("/MES") == false)
                                && (TotalVehicleList.get(k).getText().contains("/MOIS") == false)
                                && (TotalVehicleList.get(k).getText().contains("/MONTH") == false)
                                && (TotalVehicleList.get(k).getText().contains("/Month") == false)
                                && (TotalVehicleList.get(k).getText().contains("/month") == false)) {
                            finCountVeh = finCountVeh + 1;
                        }
                    }
                }

                System.out.println("Total " + PaymentMode + " Vehicles are: " + finCountVeh);
                NodeORSubNode.log(Status.INFO, "Total " + PaymentMode + " Vehicles are: " + finCountVeh);
                if (finCountVeh == 0 && PaymentMode.equalsIgnoreCase("cash")) {
                    NodeORSubNode.log(Status.WARNING, "Total " + PaymentMode + " Vehicles are: " + finCountVeh + " .Hence not testing further");
                    driver.close();
                }
                if (PaymentMode.equalsIgnoreCase("Finance") && driver != null) {
                    infoList = driver.findElements(financeViewVehicleBtn);
                    NodeORSubNode.log(Status.INFO, "Total number of Finance Vehicles available: " + infoList.size());
                } else {
                    for (int k = 0; k < TotalVehicleListSize; k++) {
                        if (((TotalVehicleList.get(k).getText().contains("/mes") == false)
                                && (TotalVehicleList.get(k).getText().contains("/mois") == false)
                                && (TotalVehicleList.get(k).getText().contains("/MES") == false)
                                && (TotalVehicleList.get(k).getText().contains("/MOIS") == false)
                                && (TotalVehicleList.get(k).getText().contains("/MONTH") == false)
                                && (TotalVehicleList.get(k).getText().contains("/Month") == false)
                                && (TotalVehicleList.get(k).getText().contains("Need a hand?") == false)
                                && (TotalVehicleList.get(k).getText().contains("/month") == false))
                                && (TotalVehicleList.get(k).getText() != null)) {
                            System.out.println(TotalVehicleList.get(k).getText());
                            String dateParsed[] = TotalVehicleList.get(k).getText().split("\\r?\\n|\\r");
                            for (int l = 0; l < dateParsed.length; l++) {
                                if (dateParsed[l].contains("CONFIGURA Y COMPRA")
                                        || dateParsed[l].contains("Voir les Offres")
                                        || dateParsed[l].contains("VOIR LES OFFRES")
                                        || dateParsed[l].contains("Voir les offres")
                                        || dateParsed[l].contains("Voir Les offres")
                                        || dateParsed[l].contains("Voir Les Offres")
                                        || dateParsed[l].contains("Voir les véhicules")
                                        || dateParsed[l].contains("Ver Ofertas")
                                        || dateParsed[l].contains("See Offers")
                                ) {
                                    highlightElement(driver, TotalVehicleList.get(k));
                                    infoList.add(TotalVehicleList.get(k));
                                }
                            }
                        }
                    }
                    System.out.println("Total cash buttons are: " + infoList.size());
                }

                if (infoList.size() != 0) {
                    //highlightElement(driver, financeViewVehicleBtn);
                    System.out.println("Got the list of info for cars which is :" + infoList.size());
                    NodeORSubNode.log(Status.PASS, "Got the list of finance vehicles which is :" + infoList.size());
                } else {
                    hp.adjustRange(resultDirectory, NodeORSubNode);
                    hp.clickSelectBtn(resultDirectory,NodeORSubNode);
                    infoList = driver.findElements(financeViewVehicleBtn);
                    if (infoList.size() != 0) {
                        highlightElement(driver, financeViewVehicleBtn);
                        System.out.println("Got the list of info for cars which is :" + infoList.size());
                        NodeORSubNode.log(Status.PASS, "Got the list of finance vehicles which is :" + infoList.size());
                    } else {
                        if (PaymentMode.equalsIgnoreCase("Finance")) {
                            System.out.println("None of the finance vehicles are present");
                            NodeORSubNode.log(Status.FAIL, "None of the finance vehicles are present. Hence No Further Testing Required");
                            driver.close();
                        } else {
                            System.out.println("None of the finance vehicles are present");
                            NodeORSubNode.log(Status.INFO, "None of the finance vehicles are present");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get list of finance vehicles", e);
        }
        return infoList;
    }

    @Test(description = "getting info monthly price FR")
    public String getFirstvehiclenoticeText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, firstVehicleNotice);
            System.out.println("Got info monthly price FR: " + str);
            NodeORSubNode.log(Status.INFO, "Unable to get Get info monthly price FR: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get info monthly price FR", e);
        }
        return str;
    }

    @Test(description = "Getting Number of Offers")
    public void clickSelectEC41Offer(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest NodeORSubNode)
            throws InterruptedException {
        try {
            int monthlyPr = 0;
            System.out.println("Getting Number of Offers");
            driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
            waitForElementPresent(driver, TotalTestingOffers, 5);
            List<WebElement> allEle = driver.findElements(TotalTestingOffers);
            NodeORSubNode.log(Status.INFO, "The Number of Offers are: " + allEle.size());
            Boolean clickBrand = false;
            for (int i = 0; i <= (allEle.size() - 1); i++) {
                System.out.println("The whole text of the brand is: " + allEle.get(i).getText());
                highlightElement(driver, TotalTestingOffers);
                NodeORSubNode.log(Status.INFO, "The whole text of the brand is: " + allEle.get(i).getText());

                clickBrand = (allEle.get(i).getText().contains("Ë-C4"));

                if (clickBrand) {
                    // System.out.println(allEle.get(i).getText());
                    // System.out.println("========================================================");
                    waitForElementPresent(driver, Homepage_Monthly_Price_FR, 2);
                    System.out.println(driver.findElement(Homepage_Monthly_Price_FR).getText());
                    NodeORSubNode.log(Status.INFO, driver.findElement(Homepage_Monthly_Price_FR).getText());
                    monthlyPr = extractNumericFromString(driver.findElement(Homepage_Monthly_Price_FR).getText());
                    waitForElementPresent(driver, Homepage_Monthly_Price_UK, 2);
                    System.out.println(driver.findElement(Homepage_Monthly_Price_UK).getText());
                    NodeORSubNode.log(Status.INFO, driver.findElement(Homepage_Monthly_Price_UK).getText());
                    monthlyPr = extractNumericFromString(driver.findElement(Homepage_Monthly_Price_UK).getText());
                }/*else{
                    NodeORSubNode.log(Status.FAIL, "EC41 car is not present " + monthlyPr);
                }*/

                System.out.println("TTC/Monthly price is: " + monthlyPr);
                NodeORSubNode.log(Status.INFO, "TTC/Monthly price is: " + monthlyPr);
                if ((monthlyPr != 0)) {
                    // waitForElementClickable(driver, By.id("TESTING_DETAIL_" + i));
                    scrollingJS(driver, By.id("TESTING_DETAIL_" + i));
                    break;
                }

                NodeORSubNode.log(Status.PASS, "EC41 car is present " + monthlyPr);

            }

            if (!clickBrand) {
                NodeORSubNode.log(Status.FAIL, "EC41 car is not present " + monthlyPr);
                //catchFailDetails(resultDirectory, NodeORSubNode, driver, "EC41 car is not present", e);
                failWithScreenshot("EC41 car is not present", resultDirectory, driver, extent, NodeORSubNode);
                driver.close();
            }

        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "EC41 car is not present", e);
        }

    }

}