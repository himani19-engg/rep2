package solRetailIHM.PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeoutException;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ReprisePage extends UniversalMethods {
	
	private WebDriver driver;
		
	By Dealerpagelocator_UK_AC = By.xpath("//*[text()='Select retailer']/../div[3]");
	By Dealerpagelocator_FR = By.xpath("//*[text()='Point de vente']/../div[3]"); 
	By Dealerpagelocator_UK = By.xpath("//*[text()='Dealer']/../div[3]");
	
	By SearchRetailerField = By.xpath("//input[@data-testid='TESTING_DEALER_SEARCH_INPUT']");
	By SearchRetailer = By.xpath("//button[@data-testid='TESTING_DEALER_SEARCH']");
	By SelectRetailer = By.xpath("//button[contains(@data-testid,'TESTING_DEALER_ITEM_')]");
	By DealerChoiceAdress = By.xpath("//div[@data-testid='TESTING_DEALER_ADDRESS']");
	By DealerDisplayAdress = By.xpath("//div[@data-testid='TESTING_SELECTED_DEALER_INFO']"); 
	By DealerContinue = By.xpath("//button[@data-testid='TESTING_HANDLE_DEALER']");
	
	By OpelSimulatorLocator = By.xpath("//*[@class='title centertitle']");
	
	By CashIdentification = By.xpath("//*[@class='text-div-container ng-tns-c0-0 current-step ng-star-inserted']/.");

	By RepriseCashPrice=By.xpath("//span[contains(@class,'price-total-price')]");
	By noRadioBtn = By.xpath("//div[contains(text(), 'Non')]");
	By goToNextStepBtn = By.xpath("(//span[@class='submit-title'])[2]");
	//By noTradeInOffer = By.xpath("//button[@class='btn-valider no-tradeIn']/span");
	By noTradeInOffer = By.xpath("//*[@class='steps ng-star-inserted'][2]");
	//By confirmNoTradeIn = By.xpath("//span[contains(@id, 'CONFIRM.YES')]");

	By confirmNoTradeIn = By.xpath("//*[@class='btn btn-valider focus_button']");
	public By submitBtn = By.xpath("//button[contains(@class, 'valid')]/span | //button[contains(text(),'Suivant')] | //button[contains(text(),'SUIVANT')]");
	By validateButton=By.xpath("(//*[contains(@class,'btn-valider')])[2]");
	By validateButton_AC_FR=By.xpath("(//*[contains(@class,'btn-valider')])[1]");
	By yesButton=By.xpath("//*[contains(text(),'Oui')]");

	//By threeIcons=By.xpath("//footer[contains(@class,'assurance assurance')]/ul");
	By threeIcons = By.xpath("//*[contains(@class,'box-img')] | //footer[contains(@class,'assurance assurance')]");

	By RepriseYesbutton = By.xpath("(//*[contains(@class,'btn-to-custom-focus')])[1]");

	By RepriseNoButton = By.xpath("(//*[contains(@class,'btn-to-custom-focus')])[2]");

	public ReprisePage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickRepriseYesButton()
	{
		clickElement(driver,RepriseYesbutton);
		System.out.println("Click on yes button");
	}

	public void clickRepriseNoButton()
	{
		clickElement(driver,RepriseNoButton);
		System.out.println("Click on No button");
	}
	
	public String DealerPage_UK() throws InterruptedException
	{
		return getClassValue (driver, Dealerpagelocator_UK);
	}
	
	public String DealerPage_FR() throws InterruptedException
	{
		return getClassValue (driver, Dealerpagelocator_FR);
	}
	
	public String DealerPage_UK_AC() throws InterruptedException
	{
		return getClassValue (driver, Dealerpagelocator_UK_AC);
	}
	
	public void enterCity(String City) throws Exception {
		System.out.println("Search City");
		enterData(driver,  SearchRetailerField, City);
	}
	

	public void searchRetailer() throws InterruptedException
	{
		System.out.println("SearchRetailer");
		clickElement(driver, SearchRetailer);
	}	
	
	public void SelectRetailer() throws InterruptedException
	{
		System.out.println("SelectRetailer");
		clickElement(driver, SelectRetailer);
	}
	
	public String OpelSimulatorLocator() throws InterruptedException {
		return getAnyText(driver, OpelSimulatorLocator);
	}
	
	public String DealerChoiceAdress() throws InterruptedException {
		return getAnyText(driver, DealerChoiceAdress);
	}
	
	public String DealerDisplayAdress() throws InterruptedException {
		return getAnyText(driver, DealerDisplayAdress);
	}
	
	public void DealerContinue() {
		System.out.println("Dealer Continue");
		clickElement(driver, DealerContinue);
	}

	public String getCashIdentification() {
		System.out.println("check arrive on personnal info page cash");
		return getAnyText(driver, CashIdentification);
	}

	public String getRepriseCashPrice() throws TimeoutException {
		String Str=null;
		Str=getAnyText(driver, RepriseCashPrice,10);
		return Str;
	}

	public void selectNoOption() {
		clickElement(driver, noRadioBtn);
		System.out.println("Select No option for reprise");
	}
	
	public void clickSubmit() {
		clickElement(driver, submitBtn);
		System.out.println("Click Submit button");
	}
	
	public void clickGoToNextStep() {
		clickElement(driver, goToNextStepBtn);
		System.out.println("Click Go to next step button");
	}
	
	public void clickToConfirmNoTradeInOffer() {
		clickElement(driver, noTradeInOffer,10);
		clickElement(driver, confirmNoTradeIn,10);
		System.out.println("Click no trade-in offer");
	}

	public void clickValidateButton(WebDriver driver, String Country, String Brand) {
		/*if(Country.equalsIgnoreCase("FR")&&Brand.equalsIgnoreCase("AC")){
			clickElement(driver, validateButton_AC_FR, 5);
		} else{*/
			clickElement(driver, validateButton, 5);
		//}
	}

	public void clickYesButton(WebDriver driver) {
		clickElement(driver, yesButton, 5);
	}

	public Boolean checkThreeIconsPresent(WebDriver driver) {
		Boolean bool=false;
		if(isElementPresent(driver,threeIcons,10)){
			bool=true;
		}else{
			bool=false;
		}
		return bool;
	}

	public String threeIconContext(WebDriver driver) {
		return getAnyText(driver,threeIcons);
	}
}