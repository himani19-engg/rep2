package solRetailIHM.PageObjectModel;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class BasketPage extends UniversalMethods {
	WebDriver driver = null;
	
	By Basket_FR_DS = By.xpath("//*[text()='RÉCAPITULATIF DE VOTRE PROJET']");
	By Basket_FR_AC_AP =  By.xpath("(//*[text()[contains(.,'Récapitulatif de mon projet')]])[1]");

	By PaymentLoaChoice = By.xpath("//*[@data-testid='TESTING_JOURNEY_TYPE']/div/span[1]");
	By paymentHeader = By.xpath("//span[contains(text(), 'PAIEMENT')] | //span[contains(text(), 'Paiement')]");


	By Basket_UK = By.xpath("//*[text()='ORDER SUMMARY']");
	By Basket_UK_VX = By.xpath("//*[text()='YOUR CAR SUMMARY']");
	By Basket_UK_AC = By.xpath("(//*[text()[contains(.,'Order summary')]])[1]");
	By Basket_FR_AC =  By.xpath("(//*[text()[contains(.,'Récapitulatif de mon projet')]])[1]");
	By basket_ES = By.xpath("//*[text()='RESUMEN DE LA COMPRA']");
	By CarteGrise = By.className("dealerFee_title_postalCodeButton");
	//By codePostal = By.xpath("//input[@placeholder='Code Postal' or @placeholder='Code postal']");
	By codePostal = By.xpath("//*[@data-testid='TESTING_POSTAL_CODE_INPUT']");
	//By yesRepriseradioBtn = By.xpath("//*[@class='description' and text()=\"Je souhaite que vous réalisiez les démarches d'immatriculation pour moi\"]");
	By yesRepriseradioBtn = By.xpath("//*[@data-testid='TESTING_SELECTION_HAS_REGISTRATION_FEE']/div/span[2]");
	//By carteGrisePrice=By.xpath("//*[@class='item noBorderTop']/span[2]");
	By carteGrisePrice=By.xpath("//*[@data-testid='TESTING_POSTAL_CODE_PRICE']");
	//By carteGrisePriceInPriceSection=By.xpath("(//*[text()='Carte grise'])[4]/following-sibling::span | (//*[contains(text(),'carte grise')])[5]/following-sibling::span");
	By carteGrisePriceInPriceSection=By.xpath("//*[@data-testid='TESTING_SUMMARY_CARTE_GRISE_PRICE']");
	By demarchesFees=By.xpath("//*[text()='Démarches  d´immatriculation']/following-sibling::span | //*[text()=\"Demarches immatriculation\"]/following-sibling::span");
	By demarchesFees_DS=By.xpath("(//*[text()=\"Démarches d'immatriculation\"])[2]/following-sibling::span");
	//By demarchesFeesInPriceSection=By.xpath("(//*[text()='Démarches  d´immatriculation'])[2]/following-sibling::span | (//*[text()=\"Demarches immatriculation\"])[2]/following-sibling::span");
	By demarchesFeesInPriceSection=By.xpath("//*[@data-testid='TESTING_SUMMARY_REGISTRATION_FEE_PRICE']");
	By demarchesFeesInPriceSection_DS=By.xpath("(//*[text()=\"Démarches d'immatriculation\"])[3]/following-sibling::span");
	By CarteGrise1 = By.xpath("//*[@class = 'dealerFee_title_postalCodeButton']");
//	By ValidatePostalCode = By.xpath("//button[@data-testid='TESTING_DELETE_CONFIRMATION']");
	//By validatePostalCode = By.xpath("//div[@class='postalCode_input']/button");
	By validatePostalCode = By.xpath("//*[@data-testid='TESTING_POSTAL_CODE_BUTTON']");
	//By carteGriseTick = By.xpath("//span[(text()='Carte Grise' or text()='Carte grise')]/preceding-sibling::span");
	By carteGriseTick = By.xpath("//*[@data-testid='TESTING_BASKET_STEP_CARTE_GRISE']/span[1]");
	By validateBasket = By.id("TESTING_TO_BASKET_BOX");
	//By CGPriceCalculationErorPopup = By.className("modalWindow__wrap");
	By CGPriceCalculationErorPopup = By.xpath("//button[@data-testid='TESTING_CLOSE_MODAL']");
	By CGPriceCalculationErorPopupClosing = By.className("modalWindow__wrap__header__closeBtn");

	By OfferCommercialPopup = By.xpath("//*[starts-with(@class, 'ModalOfferSharingConfirmation__Container')]");
	By promoCodeText = By.xpath("//button[contains(@class, 'promoCodeSection_title')]/span");
	//By textBoxForPromoCode = By.xpath("//input[@class='promoCode__input ']");
	By textBoxForPromoCode=By.xpath("//*[@data-testid='TESTING_PROMO_CODE_INPUT']");
	//By applyButton = By.xpath("//button[@class='promoCode__button ']");
	By applyButton = By.xpath("//*[@data-testid='TESTING_PROMO_CODE_BUTTON']");
	//By promoSuccessMsg = By.xpath("//span[@class='promoCode__input_label_success']/span[2");
	By promoSuccessMsg = By.xpath("//*[@data-testid='TESTING_PROMO_CODE_SUCCESS_MESSAGE']/span[2]");
	//By promoCodeContent = By.xpath("//div[@class='promoCode__content']/span[1]");
	By promoCodeContent = By.xpath("//*[@data-testid='TESTING_PROMO_CODE_CODE']");
	//By promoDiscountPrice = By.xpath("//div[@class='promoCode__content']//span[@class='formatMoney']");
	By promoDiscountPrice = By.xpath("//*[@data-testid='TESTING_PROMO_CODE_PRICE']/span");
	By carteGriseErrorPopin = By.xpath("//*[@class='tooltip tooltip--opened']");
	//By monthlyPaymentOption = By.xpath("//button[contains(@class, 'rightSection')]/div");
	By monthlyPaymentOption=By.xpath("//*[@data-testid='TESTING_SELECTION_FINANCE']/div/span/span");
	//By cashPaymentOption = By.xpath("//button[contains(@class, 'leftSection')]/div/span/span");
	By cashPaymentOption = By.xpath("//*[@data-testid='TESTING_SELECTION_CASH']/div/span/span");
	//By monthlyPaymentSuffixLabel = By.className("currencyLabel__suffix--TTC-monthly");
	//By paymentTick = By.xpath("//span[(text()='Paiement') or (text()='Payment') or (text()='Pago')]/preceding-sibling::span");
	By monthlyPaymentSuffixLabel=By.xpath("//*[@data-testid='TESTING_VEHICLE_SUMMARY_TOTAL_MONTHLY_PRICE']/div/span[2]/span/span/span");
	By paymentTick = By.xpath("//*[@data-testid='TESTING_BASKET_STEP_PAYMENT']/span[1]");
	By textBoxForEmail = By.xpath("(//input[@type='text'])[2]");
	By submitButtonforEmail = By.xpath("//button[@type='submit']");
	//By emailconfirmationMsg = By.xpath("//div[contains(@class, 'ModalShareConfiguration__Text')]");
	By emailconfirmationMsg = By.xpath("//span[@class='textTitle']");
	By closeMailNotificationPopup = By.xpath("//button[@data-testid='TESTING_CLOSE_MODAL']");
	By shareEmailSuccessMsg = By.className("success");
//	By cashPrice = By.xpath("//span[@class='totalPrice_price']/span");
	By cashPrice = By.xpath("//div[@class='storePrice_value']/span[2]");
	By vatIncludedPrice = By.xpath("//div[@class='totalPrice_cashPrice ']/span[1]");
	By additionalCostSection = By.id("mandatoryFees");
	//By additionalCosts = By.xpath("//span[@class='dealerFee_title_price']/span");
	By additionalCosts = By.xpath("//div[@class='fees']/descendant::span[@class='price']/span[1]");
	//By additionalCosts = By.xpath("//*[contains(@data-testid,'TESTING_OPTIONAL_FEE')]/parent::div/parent::div/span");
	//	By totalAdditionalCost = By.xpath("//span[@class='mandatoryFeesTotalPrice_price']/span[@class='formatMoney']");
	By totalAdditionalCost = By.xpath("//div[@class='totalPrice_cashPrice ']/span");
	By stickyBarCosts = By.xpath("//div[@class='storePrice']/following-sibling::div[1]//descendant::span[@class='formatMoney']");
	//By stickyBarCosts = By.xpath("//*[@data-testid='TESTING_TOTAL_CASH_PRICE']/span[1]");
	//Price
	By payment_CashPrice = By.xpath("(//div[@class='cashSummary']//span[@class='price']/span)[3]");
	By payment_TotalCashPrice = By.xpath("//div[@class='totalPrice_cashPrice isCash']/span");
	By payment_FinancePrice = By.xpath("//div[@class='financeSummary']//span[@class='price']/span");
	By payment_TotalFinancePrice = By.xpath("//span[@class='totalPrice_monthlyPrice_price']/span");
	
	By vehicleName = By.xpath("//*[@class = 'car-info-title']");
	//By clickOncontinueBasket = By.xpath("//button[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX']");
	By clickOncontinueBasket = By.xpath("//*[@data-testid='TESTING_TO_BASKET_BOX_INTERESTEDBOX']");
	By notificationForm = By.xpath("//*[text()='Contact an advisor']");
	//By shareEmailLink = By.xpath("//*[text()='Recibir la oferta por email']");
	By shareEmailLink = By.xpath("(//div[@class='elements'])[1]/div[2]//button");

	//New notification Form
	//By notificationButton = By.xpath("(//div[@class='elements'])[2]/div[2]/button");
	By notificationButton = By.xpath("(//div[@class='elements'])[2]/div[2]/div/button");
	By civilityBox = By.xpath("//*[@data-key = 'civility']/div/div/label[1]");
	By firstNameField = By.xpath("//* [@name = 'firstName']");
	By lastNameField = By.xpath("//* [@name = 'lastName']");
	By phoneNumberField = By.xpath("//* [@name = 'phone']");
	By emailField = By.xpath("//* [@name = 'emailCust']");
	By emailFieldCheckBox =By.xpath("//input[contains(@name, 'legal1')]");
	By postalCodeField = By.xpath("//* [@name = 'postCode']");
	By postalCodeFieldUK = By.xpath("//* [@name = 'customerpostcode']");
	By submitButton = By.xpath("//* [@class = 'submit-button button btn btn-primary']");
	By closeFormButton = By.xpath("//*[@data-testid = 'TESTING_CLOSE_MODAL']");
	By adressField = By.xpath("//*[@name = 'address1']");
	By townField = By.xpath("//*[@name = 'townAddress']");
	By emailFieldCheckBox_UK = By.xpath("//input[contains(@name, 'emailPreference')]");
	By emailFieldCheckBox_UKVX = By.xpath("//input[contains(@name, 'newsChannel')]");

	//Calculator
    By clickOnPersonalizeFinanceButton = By.xpath("//*[@class='personalizeButton']");
    By calculatorPrice = By.xpath("//div[contains(@class,'price-container')]");
    By closeCalculatorPopup = By.xpath("//div[contains(@class,'fipsa-header-close-button')]");
    By financeDurationButton = By.xpath("//div[contains(@class,'repaymentPeriod-month')]");
//    By entradaRateRange_ES = By.xpath("//div[contains(@class, 'firstRentAmount')]/div[contains(@class, 'slider')]//div/span[@class='rc-slider-mark-text'][2]/span");
    By entradaRateRange_ES = By.xpath("//div[contains(@class, 'firstRentAmount')]/div[contains(@class, 'slider')]//div/span[@class='rc-slider-mark-text'][2]");
    By entradaRateRange_FR = By.xpath("//div[contains(@class, 'firstRentAmount')]/div[contains(@class, 'slider')]//div");
    By annualMileageRange = By.xpath("//div[contains(@class, 'annualMileage')]/div[contains(@class, 'slider')]//div/span[@class='rc-slider-mark-text'][2]/span");
    By continueButton = By.xpath("//div[@id='wid00bpf-fipsa-button-action']/button");
    By finConPriceAmount = By.xpath("//div[@id='financing-details']/div[2]/div/div[2]/div/div[3]/div/div/div/span[2]");
    By assuranceCheckbox = By.xpath("(//div[contains(@class, 'assurance-line__select')])[4]");
    By assuranceConfirmCheckbox = By.xpath("//div[contains(@class, 'assurance-confirmation')]/label/div");

    // Additional services
    By additionalServices = By.xpath("//button[@class='nav-item']//span[contains(text(), 'services')]");
    //By additionalServicesTick = By.xpath("//span[(text()='Additional services') or (text()='Compléments') or (text()='Complementos')]/preceding-sibling::span");
	By additionalServicesTick = By.xpath("//*[@data-testid='TESTING_BASKET_STEP_OPTIONAL_DEALER_FEES']/span[1]");
	//By additionalServicesCheckbox = By.xpath("//*[@id='id-SOL_5-part-checkbox' and @name='SOL_5-part-checkbox'] | //*[@name='SOL_100-part-checkbox']");
	//By additionalServicesCheckbox =By.xpath("(//*[contains(@class,'checkbox')])[1]/div/input");
	By additionalServicesCheckbox =By.xpath("(//*[contains(@data-testid,'TESTING_OPTIONAL_FEE_')]/input)[1]");
	By additionalServicesCheckbox_ES = By.xpath("(//*[@class='container'])[2]/input");
    //By additionalServicesCheckbox = By.xpath("//div[contains(@class, '__name')]/descendant::input[contains(@id, '-checkbox')]");
   // By additionalServicesName = By.xpath("//div[@class='fee__priceWrapper']/preceding-sibling::span");
    //By additionalServicesName = By.xpath("(//div[contains(@class, '__priceWrapper')]/preceding-sibling::span)[1]");
	By additionalServicesName = By.xpath("(//*[contains(@data-testid,'TESTING_OPTIONAL_FEE_')]/parent::div/following-sibling::span)[1]");
	//By additionalServices_priceSectionName_ES = By.xpath("//div[@class='priceSection'][3]//div[@class='priceSection_value']/span[1]");
	By additionalServices_priceSectionName_ES = By.xpath("//*[contains(text(),'Offert : Moulins Sel Poivre Peugeot')] | (//*[@class='priceSection_title'])[6]");
	By additionalServices_priceSectionName_AC_ES=By.xpath("(//*[@class='priceSection_title'])[7]");
	By additionalServices_priceSectionName_DS_ES=By.xpath("(//*[@class='priceSection_title'])[7]");
    //By additionalServices_priceSectionName_FR = By.xpath("//div[contains(@class, 'part selected')]//div//div[@class='part__priceWrapper']");
	By additionalServices_priceSectionName=By.xpath("(//*[contains(@data-testid,'TESTING_SUMMARY_OPTIONAL_FEE_')]/parent::div/span)[1]");
	By additionalServices_priceSectionName_FR =By.xpath("(//*[@class='priceSection_title'])[3]");
	By additionalServices_priceSectionName_FR_DS =By.xpath("(//*[@class='priceSection_title'])[6]");

	//By priceInComplementsSection=By.xpath("//*[@class='part__priceWrapper_price']");
	By priceInComplementsSection=By.xpath("//*[contains(@data-tesstid,'TESTING_OPTIONAL_FEE_')]");
	//By priceInPriceSection=By.xpath("(//*[@class='priceSection_title'])[3]/following-sibling::span/span");
	By priceInPriceSection=By.xpath("(//*[contains(@data-testid,'TESTING_SUMMARY_OPTIONAL_FEE_')]/span)[1]");
	By priceInPriceSection_DS=By.xpath("(//*[@class='priceSection_title'])[6]/following-sibling::span/span");
	By priceInPriceSection_AP_ES=By.xpath("(//*[@class='priceSection_title'])[6]/parent::div/span[2]/span");
	By priceInPriceSection_AC_ES=By.xpath("(//*[@class='priceSection_title'])[5]/following-sibling::span/span");
	By priceInPriceSection_DS_ES=By.xpath("(//*[@class='priceSection_title'])[7]/following-sibling::span/span");
	// Assisted Sales Popin
    //By vendorModuleLink = By.className("dealerShareFeature");
    By vendorModuleLink = By.xpath("//*[text()='Vendor module']");

	By vendorModuleForm = By.xpath("//*[(@class='title') and contains(text(),'Send this offer by email')]");

    By sectionHeader = By.className("section-header");
    //By searchButton = By.className("searchSection");

	By identificationDropDown=By.xpath("(//*[contains(text(),'What is your function?')] | //*[contains(text(),'Etes-vous un point de vente ?')])[1]");
    //By dealerSelectBtn = By.xpath("//button[@data-testid='TESTING_DEALER_ITEM_0']");

	By salesman=By.xpath("//div/input[@placeholder='My Salesman ID'] | //div/input[@placeholder='Mon identifiant vendeur']");

	By dealer2=By.id("react-select-2-input");
    By civilityRdoBtn = By.xpath("//div[@class='civility']/div");
    By emailTextbox = By.xpath("//input[@placeholder='Email du client']");
    By prenomTextbox = By.xpath("//input[@placeholder='Prénom']");
    By nomTextbox = By.xpath("//input[@placeholder='Nom']");
    By phoneTextbox = By.xpath("//input[@placeholder='Numéro de téléphone']");
    By copyLink = By.xpath("//button[@data-testid='modal-share-configuration-dealer-code-copyLink'] | //*[text()='Copiez le lien']");
	//By financePrice = By.xpath("//span[contains(@class,'totalPrice_monthlyPrice_price')]");
	By financePrice = By.xpath("//*[@data-testid='TESTING_TOTAL_MONTHLY_PRICE']");
	By financePrice_DS=By.xpath("//*[contains(@class,'totalPrice_cashPrice')]/span");
	By financePrice_AP_ES=By.xpath("//*[contains(@class,'totalPrice_cashPrice ')]");
	By openFeatureSwitch = By.xpath("//*[@data-testid='TESTING_OPEN_FEATURE_SWITCHES_BUTTON']");
	//By openFeatureSwitch = By.linkText("Open feature switches");
	By pxEnabledSwitch=By.xpath("//*[text()='pxEnabled: ']");
	By pxEnabledValue=By.xpath("//*[text()='pxEnabled: ']/following-sibling::button");
	public By closeButton=By.xpath("//*[@data-testid='TESTING_CLOSE_MODAL']");
	public By noButton=By.xpath("//*[@data-testid='TESTING_SELECTION_NO_REGISTRATION_FEE']");
	By estimationDeReprisetxt = By.xpath("//*[contains(text(),\"estimation de reprise\")]");
	//By estimationDeRepriseYesButton = By.xpath("//*[contains(text(),\"estimation de reprise\")]//..//button[@data-testid=\"TESTING_TRADE_IN_SELECTION_YES\"]");
	By estimationDeRepriseYesButton = By.xpath("//*[@data-testid='TESTING_TRADE_IN_SELECTION_YES']");
	By estimezVotreVehicletxt = By.xpath("//div[contains(text(),\"Estimez votre véhicule\")]");

By CarPlateenterData = By.xpath("//*[contains(@class,\"validate-car-plate\")]");

By validateInteger = By.xpath("//*[contains(@class,\"validate-integer\")]");

By ÉVALUERMAVOITUREBtn = By.xpath("(//button[contains(text(),\"Évaluer\")])[1] | (//button[contains(text(),\"ÉVALUER\")])[1]");

By SelectDropDown = By.xpath("//*[contains(@class,\"custom-select\")]");

By DropDownValue = By.xpath("//option[contains(text(),\"3.0 TDI\")]");

By obtenirMonEstimationBtn = By.xpath("//button[contains(text(),'Obtenez')] | //button[contains(text(),'OBTENIR')]");

By estimationDeVotreVehicleTxt = By.xpath("//*[contains(text(),\"Estimation de votre véhicule\")]");

By continuerEstimationBtn = By.xpath("//button[contains(text(),\"Continuez\")] | //button[contains(text(),\"CONTINUER\")]");
    private String resultDirectory;
    private ExtentTest nodeORSubNode;
    private String paymentMode;

    public BasketPage(WebDriver driver) {
		this.driver = driver;
	}
	public String  getFinancePrice(String Brand,String country) throws InterruptedException {
		System.out.println("get finance price on checkout page");
		if(Brand.equalsIgnoreCase("DS")){
			return getAnyText(driver, financePrice_DS).replaceAll("€","");
		}
		/*if(Brand.equalsIgnoreCase("AP")&&country.equalsIgnoreCase("ES")){
			return getAnyText(driver,financePrice_AP_ES).replaceAll("€","");
		}*/
		return getAnyText(driver, financePrice).replaceAll("€","");
	}
	public void clickPaymentLoaChoice(String resultDirectory,ExtentTest NodeORSubNode) throws InterruptedException{
		try {
			clickElement(driver, PaymentLoaChoice);
			System.out.println("Loa choice has been choosen");
			NodeORSubNode.log(Status.INFO, "Loa choice has been choosen");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to choose Loa choice",e);
		}
	}

    public String classPaymentLoaChoice(String resultDirectory,ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getClassValue(driver, PaymentLoaChoice);
			NodeORSubNode.log(Status.INFO, "Got class PaymentLoaChoice: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get class PaymentLoaChoice",e);
		}
		return str;
	}

	public boolean CommercialOfferPopup(String resultDirectory,ExtentTest NodeORSubNode)  throws InterruptedException {
		Boolean bool= null;
		try {
			System.out.println("Getting CommercialOfferPopup");
			bool=isElementPresentWithoutWait(driver, OfferCommercialPopup);
			NodeORSubNode.log(Status.INFO, "Got Commercial Offer Popup");
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Commercial Offer Popup", e);
		}
		return bool;
	}

	public void closeCGPriceCalculationErorPopup(String resultDirectory,ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			if (isElementPresent(driver, CGPriceCalculationErorPopup,6)) {
				//logger.log(Status.INFO, MarkupHelper.createLabel("Price calculation error popup for Carte Grise", ExtentColor.ORANGE));
				clickElement(driver, CGPriceCalculationErorPopupClosing);
				NodeORSubNode.log(Status.INFO, "Closed CG Price Calculation Eror Popup Closing");
			}
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with Closing CG Price Calculation Eror Popup Closing",e);
		}

	}

	public void priceCarteGriseErorPopin(String resultDirectory,ExtentTest NodeORSubNode, String PostalCode) throws InterruptedException {
		try {
			if (isElementPresentWithoutWait(driver, carteGriseErrorPopin)) {
				fillCarteGrise(PostalCode,resultDirectory,NodeORSubNode);
				closeCGPriceCalculationErorPopup(resultDirectory, NodeORSubNode);
				NodeORSubNode.log(Status.INFO, "Clicked on close CG Price Calculation Error Popup");
			}
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with price Carte Grise Error Popin",e);
		}

	}

	public String getBasketText_FR_DS(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String str=null;
		try{
			str=getAnyText(driver, Basket_FR_DS);
			System.out.println("Got Basket Text_FR_DS: "+str);
			NodeORSubNode.log(Status.INFO, "Got Basket Text_FR_DS: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Basket Text_FR_DS: "+str,e);
		}
		return str;
	}
//	public void validateBasketPageandDelaerpagePrices(String resultDirectory, ExtentTest NodeORSubNode, String PaymentMode) {
//        this.resultDirectory = resultDirectory;
//        nodeORSubNode = NodeORSubNode;
//        paymentMode = PaymentMode;
//		Float dealerPageCashPrice = null;
//		writeToProperties("currentCashPrice", String.valueOf(dealerPageCashPrice));
//		try {
//			Float dealerpageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
//			Float basketPageCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//div[@data-testid='TESTING_TOTAL_CASH_PRICE']")));
//			if (dealerpageCashPrice - basketPageCashPrice < 1) {
//				NodeORSubNode.log(Status.PASS, "dealer page Cash price " + dealerpageCashPrice + "is same as basket page cash price");
//			} else {
//				NodeORSubNode.log(Status.FAIL, "dealer Page Cash Price" + dealerpageCashPrice + "is not same as basket page cash price");
//			}
//
//			if (PaymentMode.equalsIgnoreCase("Finance")) {
//				Float dealerPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
//				Float basketPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@data-testid='TESTING_TOTAL_MONTHLY_PRICE']")));
//				if (dealerPageFinancePrice - basketPageFinancePrice < 1) {
//					NodeORSubNode.log(Status.PASS, "dealer page Finance price " + dealerPageFinancePrice + "is same as basket page finance price");
//				} else {
//					NodeORSubNode.log(Status.FAIL, "dealer Page Finance Price" + dealerPageFinancePrice + "is not same as basket page finance price");
//				}
//			}
//		} catch (Exception e) {
//			catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate prices of delaer and basket", e);
//		}
//	}

	public String getBasketText_FR_AC_AP(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String str=null;
		try{
			str=getInnerHML(driver, Basket_FR_AC_AP);
			System.out.println("Got BasketText FR_AC_AP: "+str);
			NodeORSubNode.log(Status.INFO, "Got BasketText FR_AC_AP: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get BasketText FR_AC_AP: "+str,e);
		}
		return str;

	}
	public String getBasketText_UK(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String str=null;
		try{
			str=getAnyText(driver, Basket_UK);
			System.out.println("Got Basket Text: "+str);
			NodeORSubNode.log(Status.INFO, "Got Basket Text: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Got Basket Text: "+str,e);
		}
		return str;

	}

	public String getBasketText_UK_AC(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String str=null;
		try{
			str=getInnerHML(driver, Basket_UK_AC);
			System.out.println("Got Basket Text: "+str);
			NodeORSubNode.log(Status.INFO, "Got Basket Text: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Basket Text: "+str,e);
		}
		return str;
	}

	public String getBasketText_UK_VX(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String str=null;
		try{
			str=getAnyText(driver, Basket_UK_VX);
			System.out.println("Got Basket Text UK_VX: "+str);
			NodeORSubNode.log(Status.INFO, "Got Basket Text UK_VX: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Basket Text UK_VX: "+str,e);
		}
		return str;
	}

	public String getBasketText_ES(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String str=null;
		try{
			str=getAnyText(driver, basket_ES);
			System.out.println("Got Basket Text_ES: "+str);
			NodeORSubNode.log(Status.INFO, "Got Basket Text_ES: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Basket Text_ES: "+str,e);
		}
		return str;
	}

	public void fillCarteGrise(String PostalCode,String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			System.out.println("Click on carte grise");
			enterData(driver, codePostal, PostalCode,10);
			NodeORSubNode.log(Status.INFO, "Carte grise Postal code has been entered");
			clickElement(driver, validatePostalCode,6);
			NodeORSubNode.log(Status.INFO, "Carte grise Postal code validate button is clicked");
		} catch (Exception e) {
			/*logger.log(Status.FAIL, "Unable to enter Carte grise Postal Code");
			logger.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to enter Carte grise Postal Code",e);
		}
	}
	public String getCarteGrisePrice(String resultDirectory, ExtentTest NodeORSubNode){
		String price=null;
		try {
			price = getAnyText(driver, carteGrisePrice);
			System.out.println("Got carte grise Price: "+price);
			NodeORSubNode.log(Status.INFO, "Got carte grise Price: "+price);
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get carte grise Price: "+price,e);
		}
		return price;
	}
	public String getCarteGrisePriceInPriceSection(String resultDirectory, ExtentTest NodeORSubNode){
		String price=null;
		try {
			price = getAnyText(driver, carteGrisePriceInPriceSection);
			System.out.println("Got carte grise Price displayed in Price section : "+price);
			NodeORSubNode.log(Status.INFO, "Got carte grise Price displayed in Price section: "+price);
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get carte grise Price in Price section : "+price,e);
		}
		return price;
	}
	public void selectYesReprise(String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			Thread.sleep(3000);
			waitForElementClickable(driver,yesRepriseradioBtn,6);
			clickElement(driver, yesRepriseradioBtn,6);
			NodeORSubNode.log(Status.INFO, "Yes Estimation Price Radio button is clicked");
		} catch (Exception e) {
			/*logger.log(Status.FAIL, "Unable to enter Carte grise Postal Code");
			logger.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to click Estimation Price Radio button",e);
		}
	}
     public String getDemarchesFees(String resultDirectory, ExtentTest NodeORSubNode, String Brand){
		 String price=null;
		 try {
			 if(Brand.equalsIgnoreCase("DS")){
				 price = getAnyText(driver, demarchesFees_DS);
			 } else{
				 price = getAnyText(driver, demarchesFees);
			 }
			 System.out.println("Got demarches fees : "+price);
			 NodeORSubNode.log(Status.INFO, "Got demarches fees : "+price);
		 } catch (Exception e) {
			 catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get demarches fees : "+price,e);
		 }
		 return price;
     }
	public String getDemarchesFeesInPriceSection(String resultDirectory, ExtentTest NodeORSubNode, String Brand){
		String price=null;
		try {
			/*if(Brand.equalsIgnoreCase("DS")){
				price = getAnyText(driver, demarchesFeesInPriceSection_DS);
			} else{*/
				price = getAnyText(driver, demarchesFeesInPriceSection);
			//}
			System.out.println("Got demarches fees in Price section : "+price);
			NodeORSubNode.log(Status.INFO, "Got demarches fees in Price section : "+price);
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get demarches fees in Price section : "+price,e);
		}
		return price;
	}
	public void clickOnprompcodeText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		try {
			clickElement(driver, promoCodeText);
			System.out.println("Clicked on promocode text");
			NodeORSubNode.log(Status.INFO, "Clicked on promocode text");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on promocode text",e);
		}
	}

	public void enterPromoCode(String PromoCode,String resultDirectory, ExtentTest NodeORSubNode) throws Exception {
		try {
			enterData(driver, textBoxForPromoCode, PromoCode);
			System.out.println("Entered PromoCode");
			NodeORSubNode.log(Status.INFO, "Entered PromoCode");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Enter PromoCode",e);
		}
	}

	public void clickOnApplyButton(String resultDirectory, ExtentTest NodeORSubNode, String Brand, String Country) throws InterruptedException{
		try {
			waitForElementClickable(driver,applyButton,10);
			if(Brand.equalsIgnoreCase("OV")|| Country.equalsIgnoreCase("ES")){
			clickUsingJS(driver,applyButton);
			} else{
			clickElement(driver, applyButton);
			}
			System.out.println("Apply button click after entering PromoCode");
			NodeORSubNode.log(Status.INFO, "Apply button click after entering PromoCode");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click Apply button after entering PromoCode",e);
		}
	}

	public String getPromoSuccessText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			if(isElementPresent(driver,promoSuccessMsg)){
				str=getAnyText(driver, promoSuccessMsg);
				NodeORSubNode.log(Status.INFO, "Got promo success text: "+str);
			}
			else{
				str="";
			}
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get promo success text: "+str,e);
		}
		return str;
	}

	public String getPromoContentText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAnyText(driver, promoCodeContent);
			NodeORSubNode.log(Status.INFO, "Got value of promo Code Content: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get value of promo Code Content: "+str,e);
		}
		return str;
	}

	public String getPromoDiscountPrice (String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAnyText(driver, promoDiscountPrice);
			NodeORSubNode.log(Status.INFO, "Got promo discount price: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get promo discount price: "+str,e);
		}
		return str;
	}

	public Float getFinancePrice(WebDriver driver,String resultDirectory, ExtentTest NodeORSubNode,String PaymentMode) throws InterruptedException{
		String str=null;
		Float financePriceOnBasketPage= 0.0F;
		try{
			if(PaymentMode.equalsIgnoreCase("Finance")) {
				str = getAnyText(driver, By.xpath("//span[@class='totalPrice_monthlyPrice_price']//span[@class='formatted']//span[@class='formatMoney']")).replace(" ", "").replace(",", ".").replace("€","");
				if (str != null) {
					financePriceOnBasketPage = Float.parseFloat(str);
					System.out.println("Finance Price on Basket Page is: "+financePriceOnBasketPage);
					NodeORSubNode.log(Status.INFO, "Finance Price on Basket Page is: "+financePriceOnBasketPage);
				}
			}
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get get Finance Price On Basket Page: "+financePriceOnBasketPage,e);
		}
		return financePriceOnBasketPage;
	}

	public void clickBasketContinue(String Country,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException
	{
		System.out.println("Validate Basket");
		//waitForElementClickable(driver, ValidateBasket);

		if ((Country.equals("ES"))||(Country.equals("FR"))) {
	/*	WebElement we = driver.findElement(By.xpath("//*[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX']"));
		Actions clickTriangle= new Actions(driver);
		clickTriangle.moveToElement(we).moveByOffset(-15, 0).click().perform();}

		else {scrolingJS(driver, ValidateBasket);}
	*/
		Thread.sleep(1000);

			try {

				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
				wait.until(ExpectedConditions.elementToBeClickable(clickOncontinueBasket)).click();
				//clickUsingJS(driver,clickOncontinueBasket);
				//clickElement(driver, clickOncontinueBasket,15);
				System.out.println("Clicked Basket Continue");
				NodeORSubNode.log(Status.INFO, "Clicked Basket Continue");
			}
			catch (Exception e){
				catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Basket COntinue",e);
			}

		//Thread.sleep(1000);
		}
	}

	public void clickOnNotificationEmailButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		try {
			clickElement(driver, notificationForm);
			System.out.println("Click link of notification button");
			NodeORSubNode.log(Status.INFO, "Click link of notification button");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on link of notification button",e);
		}
	}
	public void clickOnMonthlyPaymentButton(String resultDirectory, ExtentTest NodeORSubNode, String brand, String country) throws InterruptedException{
		try {
			Thread.sleep(3000);
			if((brand.equalsIgnoreCase("OV")&&country.equalsIgnoreCase("FR"))||(brand.equalsIgnoreCase("AP")&&country.equalsIgnoreCase("FR"))||(brand.equalsIgnoreCase("DS")&&country.equalsIgnoreCase("FR"))||(brand.equalsIgnoreCase("AC")&&country.equalsIgnoreCase("FR"))){
				clickUsingJS(driver, monthlyPaymentOption);
			} else{
				clickElement(driver,monthlyPaymentOption);
			}
			System.out.println("Monthly payment button clicked");
			Thread.sleep(1000);
			NodeORSubNode.log(Status.INFO, "Monthly payment button clicked");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Monthly payment button",e);
		}
	}

	public void clickOnCashPaymentButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		try {
			//scrollIntoView(driver,cashPaymentOption);
			scrollIntoViewWithActionClass(driver,cashPaymentOption);
			clickElement(driver, cashPaymentOption,10);
			System.out.println("Cash payment button click");
			//Thread.sleep(1000);
			waitForPageToLoad(driver,5);
			NodeORSubNode.log(Status.INFO, "Cash payment button click");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Cash payment button",e);
		}
	}

	public void clickOnEstimationDeRprise(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		try {
			//scrollIntoView(driver,cashPaymentOption);
			scrollIntoViewWithActionClass(driver,cashPaymentOption);
			clickElement(driver, cashPaymentOption,10);
			System.out.println("Cash payment button click");
			//Thread.sleep(1000);
			waitForPageToLoad(driver,5);
			NodeORSubNode.log(Status.INFO, "Cash payment button click");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Cash payment button",e);
		}
	}

	public String getCashPaymentAttribute(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAttributeValue(driver, cashPaymentOption, "class");
			NodeORSubNode.log(Status.INFO, "Got cash payment attribute value: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get cash payment attribute value: "+str,e);
		}
		return str;
	}
	
	public String getPaymentTickAttribute(String name,String resultDirectory, ExtentTest NodeORSubNode) {
		String attribute = null;
		try {
			attribute = getAttributeValue(driver, paymentTick, name);
			NodeORSubNode.log(Status.INFO, "Got payment Tick attribute value: "+attribute);
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get cash payment attribute value: "+attribute,e);
		}
		return attribute;
	}

	public String getMonthlyPaymentSuffixLabel(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAnyText(driver, monthlyPaymentSuffixLabel);
			NodeORSubNode.log(Status.INFO, "Got Monthly Payment Suffix Label: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Monthly Payment Suffix Label: "+str,e);
		}
		return str;
	}

	public void clickOnShareEmailLink(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			clickElement(driver, shareEmailLink,10);
			System.out.println("Click on share email link");
			NodeORSubNode.log(Status.INFO, "Clicked on share email link");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on share email link",e);
		}
		//clickUsingJS(driver, shareEmailLink);
	}
	public void emailInTextBox(String EmailId,String resultDirectory, ExtentTest NodeORSubNode) throws Exception {
		System.out.println("Entered email id");
		try{
			enterData(driver, textBoxForEmail, EmailId);
			System.out.println("Entered email id");
			NodeORSubNode.log(Status.INFO, "Entered email id");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Enter email id",e);
		}
	}

	public void clickOnSubmitButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			clickElement(driver,submitButtonforEmail);
			System.out.println("Clicked on submit button");
			NodeORSubNode.log(Status.INFO, "Clicked on submit button");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on submit button",e);
		}
	}

	public void closeMailPopup(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			//waitForElementPresent(driver, emailconfirmationMsg, 20);
			waitForElementClickable(driver,closeMailNotificationPopup,10);
			Actions action = new Actions(driver);
			action.sendKeys(Keys. ESCAPE);
			//driver.switchTo().defaultContent();
			//clickElement(driver, closeMailNotificationPopup);
			System.out.println("Closed email notification popup");
			NodeORSubNode.log(Status.INFO, "Closed email notification popup");
		}catch (Exception e){
			e.printStackTrace();
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Close email notification popup",e);
		}
	}

	public String getShareEmailSuccessMsgText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAnyText(driver, shareEmailSuccessMsg);
			NodeORSubNode.log(Status.INFO, "Got share email success message text: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get share email success message text: "+str,e);
		}
		return str;
	}

	public String getCashPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAnyText(driver, cashPrice);
			NodeORSubNode.log(Status.INFO, "Got cash Price: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get cash price: "+str,e);
		}
		return str;
	}

	public String getVATIncludedPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAnyText(driver, vatIncludedPrice);
			NodeORSubNode.log(Status.INFO, "Got VAT Include Price: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get VAT Include price: "+str,e);
		}
		return str;
	}

	public String getTotalAdditionalCost(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		String str=null;
		try{
			str=getAnyText(driver, totalAdditionalCost);
			NodeORSubNode.log(Status.INFO, "Got Total Additional Cost: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Total Additional Cost: "+str,e);
		}
		return str;
	}

	public List<WebElement> getAdditionalCostsList(String resultDirectory, ExtentTest NodeORSubNode) {
		List<WebElement> list = new ArrayList<WebElement>();
		try {
			waitForElementClickable(driver,additionalCosts,10);
			list = driver.findElements(additionalCosts);
			NodeORSubNode.log(Status.INFO, "Got Additional Cost List size: "+list.size());
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Additional Cost List size: "+list.size(),e);
		}
		return list;
	}

	public List<WebElement> getStickyBarCostsList(String resultDirectory, ExtentTest NodeORSubNode) {
		List<WebElement> list = new ArrayList<WebElement>();
		try {
			list = driver.findElements(stickyBarCosts);
			highlightElement(driver,stickyBarCosts);
			NodeORSubNode.log(Status.INFO, "Got Sticky Bar Cost List size: "+list.size());
		}catch(Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Sticky Bar Cost List size: "+list.size(),e);
		}
		return list;
	}
	
	public void clickAdditionalCostSection(String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			clickElement(driver, additionalCostSection);
			System.out.println("Clicked on Additional Cost Section");
			NodeORSubNode.log(Status.INFO, "Clicked on Additional Cost Section");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Additional Cost Section",e);
		}
	}

	public String getVehicleNameOnBasket(String resultDirectory, ExtentTest NodeORSubNode){

		String str=null;
		try{
			str=getAnyText(driver, vehicleName);
			NodeORSubNode.log(Status.INFO, "Got vehicle name on Basket: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get vehicle name on Basket: "+str,e);
		}
		return str;
	}

	public void fillNotificationForm(String brand, String country, String postalCode, String email, String name,
			String phone, String address,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			if ((country.equals("FR"))) {
			} else {
				System.out.println("Fill Notification Form");
				clickElement(driver, notificationButton,5);
				NodeORSubNode.log(Status.INFO, "Fill Notification Form");
				Thread.sleep(5000);

				if (!country.equalsIgnoreCase("UK")) {
					/*clickUsingJS(driver, civilityBox);
					Thread.sleep(2000);*/
					clickUsingJS(driver, civilityBox);
					NodeORSubNode.log(Status.INFO, "Clicked on civility Box");
					//Thread.sleep(1000);
					enterText(driver, postalCodeField, postalCode);
					System.out.println("PostalCodeField");
					NodeORSubNode.log(Status.INFO, "Entered in Postal Code Field");
					//Thread.sleep(1000);
					clickElement(driver, emailFieldCheckBox);
					NodeORSubNode.log(Status.INFO, "Clicked on email Field CheckBox");
					//Thread.sleep(1000);
				}
				//Thread.sleep(1000);
				enterData(driver, firstNameField, name);
				System.out.println("Entered First Name Field");
				NodeORSubNode.log(Status.INFO, "Entered First Name");
				//Thread.sleep(1000);
				enterData(driver, lastNameField, name);
				System.out.println("Entered Last Name Field");
				NodeORSubNode.log(Status.INFO, "Entered Last Name");
				//Thread.sleep(1000);
				enterData(driver, phoneNumberField, phone);
				System.out.println("Entered Phone Number Field");
				NodeORSubNode.log(Status.INFO, "Entered Phone number");
				//Thread.sleep(1000);
				enterData(driver, emailField, email);
				System.out.println("Entered Email Field");
				NodeORSubNode.log(Status.INFO, "Entered Email");
				//Thread.sleep(1000);

				if (country.equalsIgnoreCase("UK") && !brand.equalsIgnoreCase("VX")) {
					enterData(driver, postalCodeField, postalCode);
					NodeORSubNode.log(Status.INFO, "Entered Postal Code");
					//Thread.sleep(1000);
					enterData(driver, adressField, address);
					NodeORSubNode.log(Status.INFO, "Entered Address");
					//Thread.sleep(1000);
					enterData(driver, townField, postalCode);
					NodeORSubNode.log(Status.INFO, "Entered Town ");
					//Thread.sleep(1000);
					clickElement(driver, emailFieldCheckBox_UK);
					NodeORSubNode.log(Status.INFO, "Entered Email");
					//Thread.sleep(1000);
				} else if (country.equalsIgnoreCase("UK") && brand.equalsIgnoreCase("VX")) {
					enterData(driver, postalCodeFieldUK, postalCode);
					NodeORSubNode.log(Status.INFO, "Entered Postal Code ");
					//Thread.sleep(1000);
					clickElement(driver, emailFieldCheckBox_UKVX);
					NodeORSubNode.log(Status.INFO, "Entered Email Field");
					//Thread.sleep(1000);
				}

				clickElement(driver, submitButton);
				System.out.println("Clicked on submit button");
				NodeORSubNode.log(Status.INFO, "Clicked on submit button");

				//Write code if the form was submitted successfully or not
				//Thread.sleep(2000);
				clickElement(driver, closeFormButton);
				System.out.println("close button");
				NodeORSubNode.log(Status.INFO, "Clicked on close Form button");
				//Thread.sleep(2000);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnPersonalizeFinanceButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			clickElement(driver, clickOnPersonalizeFinanceButton);
			System.out.println("Clicked on Personalize Finance Button");
			NodeORSubNode.log(Status.INFO, "Clicked on Personalize Finance Button");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Personalize Finance Button",e);
		}
	 }

	public void clickFinanceDurationButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			clickElement(driver, financeDurationButton);
			System.out.println("Click on finance duration button ");
			NodeORSubNode.log(Status.INFO, "Clicked on finance duration Button");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on finance duration Button",e);
		}
	 }

	public void selectEntradaRateRange(String country,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			if (country.equals("ES")) {
				clickElement(driver, entradaRateRange_ES);
			}
			if (country.equals("FR")) {
				clickElement(driver, entradaRateRange_FR);
			}
			System.out.println("Selected rate range");
			NodeORSubNode.log(Status.INFO, "Selected rate range");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select rate range",e);
		}
	    //Thread.sleep(2000);
	 }

	public void selectAnnualMileageRange(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			clickElement(driver, annualMileageRange);
			System.out.println("Select annual mileage range");
			NodeORSubNode.log(Status.INFO, "Select annual mileage range");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select annual mileage range",e);
		}
	 }

	public String getFinanceDurationPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String price = null;
		try {
			price = getAnyText(driver, calculatorPrice);
			System.out.println("Got finance duration Price: "+price);
			NodeORSubNode.log(Status.INFO, "Got finance duration Price: "+price);
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get finance duration Price: "+price,e);
		}
		return price;
	}

	public void clickClosePopup(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			if(isElementPresent(driver,closeCalculatorPopup)) {
				clickElement(driver, closeCalculatorPopup);
				System.out.println("Calculator popup closed");
				NodeORSubNode.log(Status.INFO, "Calculator popup closed");
			}
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to close Calculator popup",e);
		}
	}

	public void clickOnContinueButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		//scrollIntoView(driver, continueButton);
		try {
			clickElement(driver, continueButton);
			System.out.println("Continue button clicked");
			NodeORSubNode.log(Status.INFO, "Continue button clicked");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to click Continue button",e);
		}
	}

	public String getFinanceContainerPriceAmount(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		String price = null;
		try {
			price = getAnyText(driver, finConPriceAmount);
			System.out.println("Got Finance Container Price Amount: "+price);
			NodeORSubNode.log(Status.INFO, "Got Finance Container Price Amount: "+price);
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Finance Container Price Amount: "+price,e);
		}
		return price;
	}

	public void selectFirstAdditionalService(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			waitForUrlContains("/basket",driver,5);
			//scrollIntoView(driver,additionalServicesCheckbox);
			String url=driver.getCurrentUrl();
			/*if(url.contains("-es-")){
				clickUsingJS(driver, additionalServicesCheckbox_ES);
			}else {*/
				clickUsingJS(driver, additionalServicesCheckbox);
			//}
			//clickElement(driver,additionalServicesCheckbox);
			//clickElement(driver,additionalServicesCheckbox);
			System.out.println("Selected first additional service");
			NodeORSubNode.log(Status.INFO, "Selected first additional service");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select first additional service",e);
		}
	}

	public String getFirstAdditionalServiceText(String resultDirectory, ExtentTest NodeORSubNode) {
		String str=null;
		try{
			scrollToTop(driver);
			str=getAnyText(driver, additionalServicesName);
			NodeORSubNode.log(Status.INFO, "Got First Additional Service Text: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get First Additional Service Text: "+str,e);
		}
		return str;
	}

	public String getFirstAdditionalServiceTextFromPriceSection(String country,String resultDirectory, ExtentTest NodeORSubNode, String Brand) {
		String text = null;
		try {
			/*if (country.equals("ES") && Brand.equalsIgnoreCase("AP")) {
				waitForElementPresent(driver, additionalServices_priceSectionName_ES, 80);
				text = getAnyText(driver, additionalServices_priceSectionName_ES);
				NodeORSubNode.log(Status.INFO, "Got First Additional Service Text From Price Section for "+Brand+" brand: "+text);
			} else if(country.equals("ES") && Brand.equalsIgnoreCase("AC")){
				waitForElementPresent(driver, additionalServices_priceSectionName_AC_ES, 80);
				text = getAnyText(driver, additionalServices_priceSectionName_AC_ES);
				NodeORSubNode.log(Status.INFO, "Got First Additional Service Text From Price Section for "+Brand+" brand: "+text);
			} else if(country.equals("ES") && Brand.equalsIgnoreCase("DS")){
				waitForElementPresent(driver, additionalServices_priceSectionName_DS_ES, 80);
				text = getAnyText(driver, additionalServices_priceSectionName_DS_ES);
				NodeORSubNode.log(Status.INFO, "Got First Additional Service Text From Price Section for "+Brand+" brand: "+text);
			}
			if (country.equals("FR")) {
				if(Brand.equalsIgnoreCase("DS")|| Brand.equalsIgnoreCase("OV")){
					waitForElementPresent(driver, additionalServices_priceSectionName_FR_DS, 80);
					text = getAnyText(driver, additionalServices_priceSectionName_FR_DS);
					NodeORSubNode.log(Status.INFO, "Got First Additional Service Text From Price Section for "+Brand+" brand: "+text);
				} else{*/
					waitForElementPresent(driver, additionalServices_priceSectionName, 80);
					text = getAnyText(driver, additionalServices_priceSectionName);
					NodeORSubNode.log(Status.INFO, "Got First Additional Service Text From Price Section: for "+Brand+" brand: "+text);
				//}
				//}
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get First Additional Service Text FromPriceSection: "+text,e);
		}
		return text;
	}
	public  String getPriceInComplementsSectionText(String resultDirectory, ExtentTest NodeORSubNode){
		String price=null;
		try{
			waitForElementPresent(driver, priceInComplementsSection, 10);
			price = getAnyText(driver, priceInComplementsSection);
			NodeORSubNode.log(Status.INFO,"Got price displayed in complements section");
			if(price.equalsIgnoreCase("Incluido")){
				return "0,00 €";
			}
		} catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get price displayed in complements section :"+price,e);
		}
		return  price;
	}
	public String getPriceInPriceSection(String resultDirectory, ExtentTest NodeORSubNode, String Brand, String Country){
	String price=null;
	try{
		/*if(Brand.equalsIgnoreCase("DS") && Country.equalsIgnoreCase("FR")||(Brand.equalsIgnoreCase("OV"))){
			waitForElementPresent(driver, priceInPriceSection_DS, 10);
			price = getAnyText(driver, priceInPriceSection_DS);
			NodeORSubNode.log(Status.INFO,"Got price displayed in price section");
		} else if(Brand.equalsIgnoreCase("AP") && Country.equalsIgnoreCase("ES")){
			waitForElementPresent(driver, priceInPriceSection_AP_ES, 10);
			price = getAnyText(driver, priceInPriceSection_AP_ES);
			NodeORSubNode.log(Status.INFO,"Got price displayed in price section");
		} else if(Brand.equalsIgnoreCase("AC") && Country.equalsIgnoreCase("ES")){
			waitForElementPresent(driver, priceInPriceSection_AC_ES, 10);
			price = getAnyText(driver, priceInPriceSection_AC_ES);
			NodeORSubNode.log(Status.INFO,"Got price displayed in price section");
		} else if(Brand.equalsIgnoreCase("DS") && Country.equalsIgnoreCase("ES")){
			waitForElementPresent(driver, priceInPriceSection_DS_ES, 10);
			price = getAnyText(driver, priceInPriceSection_DS_ES);
			NodeORSubNode.log(Status.INFO,"Got price displayed in price section");
		}
		else{*/
			waitForElementPresent(driver, priceInPriceSection, 10);
			price = getAnyText(driver, priceInPriceSection);
			NodeORSubNode.log(Status.INFO,"Got price displayed in price section");
		//}

	}catch (Exception e){
		catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get price displayed in price section :"+price,e);
	}
	return price;
	}
	public String getAdditionalServicesTickAttribute(String name,String resultDirectory, ExtentTest NodeORSubNode) {
		String attribute = null;
		try {
			attribute = getAttributeValue(driver, additionalServicesTick, name);
			NodeORSubNode.log(Status.INFO, "Got Additional Services Tick Attribute: "+attribute);
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Additional Services Tick Attribute: "+attribute,e);
		}
		return attribute;
	}

	public boolean checkAdditionalServices() {
		boolean check = isElementPresentShort(driver, additionalServices);
		return check;
	}

	/**
	 * To get Payment section header
	 * @return
	 */
	public String getPaymentHeaderText(String resultDirectory, ExtentTest NodeORSubNode) {
		String str = null;
		try {
			str = getAnyText(driver, paymentHeader,5);
			NodeORSubNode.log(Status.INFO, "Got Payment Header Text: "+str);
		}catch(Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Payment Header Text: "+str,e);
		}
		return str;
	}

	/**
	 * To select assurance checkbox on Calculator popup
	 * @return
	 */
	public void selectAssuranceCheckbox(String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			clickElement(driver, assuranceCheckbox);
			System.out.println("assurance checkbox selected");
			NodeORSubNode.log(Status.INFO, "assurance checkbox selected");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to select assurance checkbox",e);
		}
	}

	/**
	 * To select assurance confirmation checkbox on Calculator popup
	 * @return
	 */
	public void selectAssuranceConfirmCheckbox(String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			clickElement(driver, assuranceConfirmCheckbox);
			System.out.println("assurance confirm checkbox selected");
			NodeORSubNode.log(Status.INFO, "assurance confirm checkbox selected");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to select assurance confirm checkbox",e);
		}
	}
	
	public int getPaymentCashPrice(String resultDirectory, ExtentTest NodeORSubNode) {
		int price = 0;
		try {
			price = extractNumericFromString(getAnyText(driver, payment_CashPrice));
			NodeORSubNode.log(Status.INFO, "Got Payment Cash Price: "+price);
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Payment Cash Price: "+price,e);
		}
		return price;
	}
	
	public int getStickyBarCashPrice(String resultDirectory, ExtentTest NodeORSubNode) {
		int price = 0;
		try {
			price = extractNumericFromString(getAnyText(driver, payment_TotalCashPrice));
			NodeORSubNode.log(Status.INFO, "Got Sticky Bar Cash Price: "+price);
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Sticky Bar Cash Price: "+price,e);
		}
		return price;
	}
	
	public int getPaymentFinancePrice(String resultDirectory, ExtentTest NodeORSubNode) {
		int price = 0;
		try {
			price = extractNumericFromString(getAnyText(driver, payment_FinancePrice));
			NodeORSubNode.log(Status.INFO, "Got Payment Finance Cash Price: "+price);
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Payment Finance Bar Cash Price: "+price,e);
		}
		return price;
	}
	
	public int getStickyBarFinancePrice(String resultDirectory, ExtentTest NodeORSubNode) {
		int price = 0;
		try {
			price = extractNumericFromString(getAnyText(driver, payment_TotalFinancePrice));
			NodeORSubNode.log(Status.INFO, "Got Sticky Bar Finance Price: "+price);
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Sticky Bar Finance Price: "+price,e);
		}
		return price;
	}
	
	public String getCarteGriseTickAttribute(String name, String resultDirectory, ExtentTest NodeORSubNode) {
		String attribute = null;
		try {
			attribute = getAttributeValue(driver, carteGriseTick, name,10);
			NodeORSubNode.log(Status.INFO, "Got Carte Grise Tick Attribute: "+attribute);
		}catch(Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Carte Grise Tick Attribute: "+attribute,e);
		}
		return attribute;
	}
	
	public void clickVendorModuleLink(String resultDirectory, ExtentTest subNode) {
		try {
			clickElement(driver, vendorModuleLink);
			subNode.log(Status.INFO, "Clicked Vendor module link");
			/*if(isElementPresent(driver,vendorModuleForm)){
				subNode.log(Status.PASS, "Wizard-Send this offer by email is opened");
				clickElement(driver,closeMailNotificationPopup);
			}else{
				subNode.log(Status.FAIL, "Wizard-Send this offer by email is not opened");
			}*/
		}catch (Exception e){
			catchFailDetails(resultDirectory, subNode, driver, "Unable to click vendor module link", e);
		}
	}
	
	public void selectDealer(String resultDirectory, ExtentTest subNode) {
		try {
			Thread.sleep(2000);
			//driver.switchTo().defaultContent();
			clickElement(driver, identificationDropDown,10);
			Thread.sleep(5000);
			subNode.log(Status.INFO, "Clicked search button");
			Robot r=new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(5000);
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			//clickElement(driver, dealerSelectBtn);
			subNode.log(Status.INFO, "Selected dealer");
			enterData(driver,salesman,"abc");
			subNode.log(Status.INFO, "Entered salesman id");
		}catch (Exception e){
			catchFailDetails(resultDirectory, subNode, driver, "Unable to select dealer", e);
		}
	}
	
	public void fillOfferSection(String resultDirectory, ExtentTest subNode, String email, String phone) {
		try {
			clickElement(driver, civilityRdoBtn);
			subNode.log(Status.INFO, "Selected first civility option");
			enterData(driver, emailTextbox, email, 2);
			subNode.log(Status.INFO, "Entered email");
			enterData(driver, prenomTextbox, "Telly", 2);
			subNode.log(Status.INFO, "Entered first name");
			enterData(driver, nomTextbox, "Talker", 2);
			subNode.log(Status.INFO, "Entered name");
			enterData(driver, phoneTextbox, phone, 2);
			subNode.log(Status.INFO, "Entered phone");
		}catch (Exception e){
			catchFailDetails(resultDirectory, subNode, driver, "Unable to fill offer section", e);
		}
	}
	
	public void clickCopyLink(String resultDirectory, ExtentTest subNode) {
		try {
			Thread.sleep(2000);
			clickElement(driver, copyLink,6);
			subNode.log(Status.INFO, "Clicked copy link");
			Thread.sleep(12000);
			allowClipBoardPopup(resultDirectory, subNode);
		} catch (Exception e) {
			catchFailDetails(resultDirectory, subNode, driver, "Unable to click copy link", e);
		}
	}
	
	public void acceptCookieUsingRobot(String resultDirectory, ExtentTest subNode) {
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
		}catch (Exception e){
			catchFailDetails(resultDirectory, subNode, driver, "Unable to click copy link", e);
		}
	}
	
	/**
	 * To click paste using Robot class
	 */
	public void clickPasteUsingRobot(String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			Robot robot = new Robot();
			Thread.sleep(8000);
			/*System.out.println("Clicking on Tab");
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			Thread.sleep(5000);*/
			/*System.out.println("Clicking on Tab");
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			System.out.println("Clicking on Tab");
			Thread.sleep(5000);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);*/
			System.out.println("Deleting existing URL");
			Thread.sleep(5000);
			robot.keyPress(KeyEvent.VK_DELETE);
			robot.keyRelease(KeyEvent.VK_DELETE);
			Thread.sleep(5000);
			System.out.println("Pasting URL");
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_V);
			System.out.println("Hitting on ENTER keyboard button");
			Thread.sleep(5000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			NodeORSubNode.log(Status.INFO, "Done paste with key from Keyboard");
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with paste key from Keyboard", e);
		}
	}
	public void clickOpenSwitches(String resultDirectory, ExtentTest NodeORSubNode){
		try{
			clickElement(driver,openFeatureSwitch,10);
			NodeORSubNode.log(Status.PASS,"Clicked open feature switches");
		} catch (Exception e){
			catchFailDetails(resultDirectory,NodeORSubNode,driver,"Unable to click open feature switches button",e);
		}
	}
	public boolean checkPxEnabled(String resultDirectory, ExtentTest NodeORSubNode){
		try{
			if(isElementPresent(driver,pxEnabledSwitch,10)){
				String pxEnabledSwitchValue=getAnyText(driver,pxEnabledValue);
				if(pxEnabledSwitchValue.contains("true")
					|| pxEnabledSwitchValue.contains("TRUE")
				){
					return true;
				} else{
					Thread.sleep(3000);
					clickElement(driver,pxEnabledValue);
					return checkPxEnabled(resultDirectory,NodeORSubNode);
				}

			}
		} catch (Exception e){
			catchFailDetails(resultDirectory,NodeORSubNode,driver,"Unable to get pxEnabled switch value",e);
		}
		return false;
	}
	public void clickCloseButton(String resultDirectory, ExtentTest NodeORSubNode){
		try{
			clickElement(driver,closeFormButton,10);
			NodeORSubNode.log(Status.PASS,"Clicked close button");
		} catch (Exception e){
			catchFailDetails(resultDirectory,NodeORSubNode,driver,"Unable to click on close button",e);
		}
	}

	public void tradeInEstimationReprise(String resultDirectory, ExtentTest NodeORSubNode)
	{
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			if(isElementPresent(driver, estimationDeReprisetxt)==true) {
				clickElement(driver, estimationDeRepriseYesButton);
				NodeORSubNode.log(Status.PASS,"Clicked estimation de reprise yes button");
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				isElementPresent(driver, estimezVotreVehicletxt);
				enterData(driver, CarPlateenterData, "DE965TK");
				NodeORSubNode.log(Status.PASS,"Enter car plate number");
				enterData(driver, validateInteger, "125");
				NodeORSubNode.log(Status.PASS,"Enter Mileage");
				clickElement(driver, ÉVALUERMAVOITUREBtn);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				//selectDropdownValueByValue(driver, SelectDropDown, "3.0 TDI 245 PLATINUM EDITION TIPTRONIC-S BVA");
				clickElement(driver, SelectDropDown);
				clickElement(driver,DropDownValue);
				clickElement(driver, obtenirMonEstimationBtn);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				isElementPresent(driver, estimationDeVotreVehicleTxt);
				clickElement(driver, continuerEstimationBtn);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			}
		}catch (Exception e)
		{
			catchFailDetails(resultDirectory,NodeORSubNode,driver,"Unable to click on estimation reprise yes button",e);

		}


	}

}