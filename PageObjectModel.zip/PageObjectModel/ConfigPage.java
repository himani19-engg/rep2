package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.ScenarioMainClass.ScenarioMain_ES;
import solRetailIHM.ScenarioMainClass.ScenarioMain_FR;
import solRetailIHM.Utilities.UniversalMethods;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ConfigPage extends UniversalMethods {


    WebDriver driver = null;

    //Color
    //By TestingColour = By.xpath("//div[@class='colors  ']/div/ul/li");
    By TestingColour = By.xpath("//*[@data-testid=\"TESTING_CONFIG_COLOR_SELECT_TITLE\"]/..//div/ul/li/button");
   // By colourName = By.xpath("//span[@class='name']");
    By colourName = By.xpath("//span[@data-testid='TESTING_COLOR_NAME']");

    By TestingPrice = By.xpath("//*[@data-testid='TESTING_COLOR_PRICE']");
    By ConfigColour = By.xpath("//*[starts-with(@id,'TESTING_CONFIG_COLOR')]/div/span");
    By color_goToNext = By.xpath("//div[@class='colors  ']/div/button[@aria-label='Go to next slide']");
    //By color_goToNext = By.xpath("//*[@id=\"__next\"]/div[1]/div/div[4]/div/div[2]/div[3]/div/div/button']");

    //Engine
    By ConfigEngine = By.xpath("//*[starts-with(@id,'TESTING_CONFIG_MOTO')]/div/span");
    //By MotorizationItem = By.xpath("//*[starts-with(@id,'TESTING_MOTOR')]");
    //By MotorizationItem = By.xpath("//div[@class='engines ']/div");
    By MotorizationItem = By.xpath("//button[contains(@data-testid,'TESTING_ENGINE_')]");
    //By motorSection = By.xpath("(//span[@class='sectionTitle'])[1]");
    By motorSection = By.xpath("//*[@data-testid='TESTING_CONFIG_ENGINE_SELECT_TITLE']");
    By MotorizationPrice = By.xpath("//*[starts-with(@id,'TESTING_MOTOR')]//div[@class='motorization-price']");

    //Interior
    By interiorOptions = By.xpath("//div[@class='interiors ']/div");
    //By interiorOptions = By.xpath("//*[@data-testid='TESTING_CONFIG_INTERIOR_SELECT_TITLE']/..//div/div");
    By InteriorColour = By.xpath("//*[starts-with(@data-testid,'TESTING_INTERIORCOLOR_ITEM_TITLE')]");
    By InteriorColourPrice = By.xpath("//*[@data-testid='TESTING_INTERIORCOLOR_PRICE']");
    By InteriorColourPriceColExp = By.xpath("//*[@id='TESTING_CONFIG_INTER']/div/span");
    By InteriorscrollBar = By.xpath("//*[@class ='simplebar-track simplebar-horizontal']/div");

    // old Option
   // public static By optionLabel = By.xpath("(//*[@class='sectionTitle'])[4]");
    public static By optionLabel = By.xpath("//*[@data-testid='TESTING_CONFIG_OPTION_SELECT_TITLE']");
    By OptionColExp = By.xpath("//*[@data-testid='TESTING_OPTIONS_WRAPPER']");
    By TestOption = By.xpath("//*[starts-with(@id,'TESTING_OPTION')]");
    By TestOptiionText = By.xpath("//*[starts-with(@data-testid,'TESTING_OPTION')]/span");
    By OptionPrice = By.xpath("//*[@data-testid='TESTING_OPTIONS_PRICE']");
    By OptionAdd = By.xpath("(//*[@data-testid='TESTING_OPTIONS_ADD'])[2]");

    // Options
    //By noOfOptions = By.xpath("//span[(text()='Opciones') or (text()='Opción')]/following-sibling::div/div");
    By noOfOptions = By.xpath("//div[@class='option-list ']/div");
    //By collpaseExpandFirstOptions = By.xpath("//div[@class='option-list ']/div[1]/span");
    By collpaseExpandFirstOptions = By.xpath("//*[@data-testid='TESTING_CONFIG_OPTION_SELECT_TITLE']//..//div/span");
    //By firstOptionItem = By.xpath("//div[@class='option-list ']/div[1]/div/div/div/descendant::input[@type='checkbox']");
    By firstOptionItem = By.xpath("//div[@data-testid='TESTING_CONFIRM_CHECKBOX']");
   // By firstOptionItemText = By.xpath("//div[@class='option-list ']/div[1]/div/div/div/descendant::input[@type='checkbox']/../../following-sibling::span");

    //By firstOptionItemText = By.xpath("//*[@data-testid='TESTING_OPTION_NAME_J6EJ']//*[contains(@class,'checkbox')]");
    By firstOptionItemText =By.xpath("(//*[@data-testid='TESTING_OPTION_NAME']/span[2])[1]");
    By optionDetailLink = By.className("option-card__detailLink");
    By optionDetailLink_AC = By.xpath("//div[@class='option-card__wrap']/div/div/button");
    By optionIcon = By.xpath("//*[@aria-labelledby='optionIcon']");
    By optionDetailTitle = By.className("option-detail__title");
    By selectedOptionsText = By.className("selectedOptions");

    By CustomizeYourProject_FR = By.xpath("//*[text()='PERSONNALISEZ VOTRE PROJET']");
    By CustomizeYourProject_UK = By.xpath("//*[text()='PERSONALISE YOUR VEHICLE']");
    By CustomizeYourProject_UK_VX = By.xpath("//*[text()='PERSONNALISEZ VOTRE PROJET']");
    By CustomizeYourProject_ES = By.xpath("//*[text()='PERSONALIZA TU COMPRA']");
    By CustomizeYourProject_ES_DS = By.xpath("//*[text()='PERSONALIZA TU COMPRA']");

    By headerCashPrice = By.className("cashContainer-cashPrice");
    By headerFinancePrice = By.className("financeContainer-price-monthlyPrice");

    By FinConPriceTitle = By.className("financeContainer__price-title");
    By CashConPriceTitle = By.className("cashContainer__price-title");
    //By FinConPriceAmount = By.className("financeContainer__price-amount");
    //By FinConPriceAmount = By.xpath("//span[@class='price']/span");
    By FinConPriceAmount = By.xpath("(//span[@class='price']/span)[3]");
    By CashConPriceAmount = By.className("cashContainer__price-amount");
    By PrixTTCHorsOptionsPriceAmount = By.xpath("//*[@data-testid='TESTING_CASH_CONTAINER_PRICE_WITHOUT_OPTIONS']");
    By TotalOptionsPriceAmount = By.xpath("//*[@data-testid='TESTING_CASH_CONTAINER_OPTIONS_TOTAL']");
    By MontantTotalTTCPrice = By.xpath("//*[@data-testid='TESTING_CASH_CONTAINER_TOTAL_WITH_OPTIONS']");

    By FinanceWidgetSelected = By.xpath("(//*[starts-with(@class, 'financeContainer__price')]/..)[1]");
    By CashWidgetSelected = By.xpath("//*[@Class='cashContainer__price']/..");
    //By BasketContinue = By.id("TESTING_TO_BASKET_BOX_INTERESTEDBOX");
    //By BasketContinue =By.id("TESTING_TO_BASKET_BOX_ORDERPANEL");
	By BasketContinue =By.xpath("//*[@id='TESTING_TO_BASKET_BOX_ORDERPANEL' or @id='TESTING_TO_BASKET_BOX_INTERESTEDBOX']/span|(//*[@class='button'])[2]");
	By DealerBeforeBasketContinue = By.id("TESTING_TO_BASKET_BOX_INTERESTEDBOX");
    By OfferCommercialeContinue = By.id("TESTING_OPEN_FORM_MODAL");
    By vehicleSummeryPageContinue = By.id("TESTING_TO_BASKET_BOX_BUTTONANDLINKS-configRightSection");

    //New Energy
    By energylist = By.xpath("//*[@data-testid = 'TESTING_FILTER_fuel']/button");

    //Color

    //New notification Form

    By notificationButton = By.id("TESTING_OPEN_FORM_MODAL");
    By notificationButton_AC = By.xpath("//button[@data-testid='TESTING_OPEN_FORM_MODAL']");
    By CivilityBox = By.xpath("//* [@data-key = 'civility']/div/div/label[1]");
    By FirstNameField = By.xpath("//* [@name = 'firstName']");
    By LastNameField = By.xpath("//* [@name = 'lastName']");
    By PhoneNumberField = By.xpath("//* [@name = 'phone']");
    By EmailField = By.xpath("//* [@name = 'emailCust']");
    By EmailFieldCheckBox = By.xpath("//input[contains(@name, 'legal1')]");
    By PostalCodeField = By.xpath("//* [@name = 'postCode']");
    By PostalCodeFieldUK = By.xpath("//* [@name = 'customerpostcode']");
    By submitButton = By.xpath("//* [@class = 'submit-button button btn btn-primary']");
    By closeFormButton = By.xpath("//*[@data-testid = 'TESTING_CLOSE_MODAL']");
    By AdressField = By.xpath("//*[@name = 'address1']");
    By TownField = By.xpath("//*[@name = 'townAddress']");
    By EmailFieldCheckBox_UK = By.xpath("//input[contains(@name, 'emailPreference')]");
    By EmailFieldCheckBox_UKVX = By.xpath("//input[contains(@name, 'newsChannel')]");

    //Save Button
    By CarSaveButton = By.xpath("//*[@class = 'save-button']");
    By CarSaveButtonAfterClick = By.xpath("//*[@data-testid='TESTING_TOP_BAR_SAVE_BUTTON']");
    By LogingButton = By.xpath("//*[@data-testid = 'TESTING_LOGIN']");
    By CarName = By.xpath("//*[@class = 'carName']/span");
    By BackButton = By.xpath("//* [@data-testid = 'TESTING_BACK']");

    //Characteristics Link
    //By characteristicLink = By.xpath("//*[@data-testid='TESTING_SHOW_CHARACTERISTICS_BUTTON']");
    //By characteristicLink = By.className("show-characteristics-button");
    //By characteristicLink = By.xpath("//*[contains(@class,'show-characteristics-button')]");
    By characteristicLink = By.xpath("//*[contains(@data-testid,'TESTING_SHOW_CHARACTERISTICS_BUTTON')]");
    //By textEnergy = By.xpath("//div[@class ='techLabel']");
    By textEnergy = By.xpath("//*[@data-testid='TESTING_TECH_LABEL_FUEL']");
    //By textGearbox = By.xpath("(//div[@class ='techLabel'])[2]");

    By textGearbox = By.xpath("//div[@data-testid='TESTING_TECH_LABEL_GEARBOX']");
    By textPower = By.xpath("(//div[@class='environmentalItem']/span)[1]");
    By textMixedconsumption = By.xpath("(//div[@class='environmentalItem']/span)[2]");
    By textTotalCO2Emissions = By.xpath("(//div[@class='environmentalItem']/span)[3]");
    By textConsumoMixto_ES_DS = By.xpath("(//div[@class='environmentalItem']/span)[3]");
    By textTotalCO2Emissions_ES_DS = By.xpath("(//div[@class='environmentalItem']/span)[4]");
    //By CharacteristicsLink = By.xpath("(//div[@class='environmentalItem']/span)");
    By CharacteristicsLink = By.xpath("//span[contains(@data-testid,'TESTING_TECH_LABEL')]");
    // Check Config Page image View
    //By exteriorImageLink = By.xpath("//span/*[contains(@data-name, 'Adas')]/..");
   // By exteriorImageLink = By.xpath("//span/*[contains(@aria-labelledby, 'ExteriorSwitcher')]/..");
    By exteriorImageLink = By.xpath("//span[@data-testid='TESTING_IMAGE_SECTION_EXTERIOR_SWITCHER']//span");
   // By interiorImageLink = By.xpath("//span/*[contains(@data-name, 'SteeringCircuit')]/..");
    By interiorImageLink = By.xpath("//span[contains(@data-testid,'TESTING_IMAGE_SECTION_INTERIOR_SWITCHER')]//span");
    By imageList = By.xpath("//li[contains(@class, 'react-multi-carousel-dot')]");
    //By slideArrowButton = By.xpath("//button[@aria-label='Go to next slide']");
    By slideArrowButton = By.xpath("//button[@data-testid='TESTING_IMAGE_CAROUSEL_ARROW_RIGHT']");
    By vehicleName = By.xpath("(//*[@class = 'carName'])[2]");

    //Calculator
    // By clickOnPersonalizeFinanceButton = By.xpath("//button[@class='calculator']/span");
    public static By clickOnPersonalizeFinanceButton = By.xpath("//*[@aria-labelledby='personalizeFinanceDetailsLink']/..");
    By calculatorPrice = By.xpath("(//div[contains(@class,'price-container')])[2]");
    By calculatorPrice_OV=By.xpath("(//div[contains(@class,'price-container')])[3]");
    public static By technicalProblemError = By.xpath("(//*[@id='__next']");
    By closeCalculatorPopup = By.xpath("//div[contains(@class,'fipsa-header-close-button')]");

    By closeErrorTAEPopup = By.xpath("//*[@xmlns=\"http://www.w3.org/2000/svg\"][1]");
    By financeDurationButton = By.xpath("//div[contains(@class,'repaymentPeriod-month')]");
    By continueButton = By.xpath("(//button[@type='button'])[1]");
    By assuranceCheckbox = By.xpath("(//div[contains(@class, 'assurance-line__select')])[4]");
    By assuranceConfirmCheckbox = By.xpath("//div[contains(@class, 'assurance-confirmation')]/label/div");

    // All price on TAE popupLink
    public By clickOnTAELink_ES = By.xpath("//*[@data-testid ='TESTING_PANEL_INFOICON']");
    public By clickOnTAELink_FR = By.xpath("(//div[contains(@class, 'infoIcon')]/div/span)[1]");
    By cashPriceOnConfigPage = By.xpath("(//span[@class='price']/span)[1]");
    By financePriceOnConfigPage = By.xpath("(//span[@class='price']/span)[3]");
    By entradaPriceOnConfigPage = By.xpath("(//div[@class='promotionalTextWrapper']/div/span)[2]");
    By cashPriceOnTAEPopup = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_1_2']");
    By financePriceOnTAEPopup_ES = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_1_1']");
    By financePriceOnTAEPopup_FR = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_3_1']");
    //By financePriceOnTAEPopup = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_1_1']");
    By entradaPriceOnTAEPopup = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_1_3']");
    By closeTAELink = By.xpath("//*[@data-testid ='TESTING_CLOSE_MODAL']");
    By deliveryMessage = By.xpath("//span[@class='delivery']");

    //Telephone number link
    // By telephoneNumberLink = By.xpath("//*[@class='contactPhone']");
    By telephoneNumberLink = By.xpath("//a[contains(@class, 'contactPhone')]");
    //By legalText = By.xpath("//div[@class='descriptionContainer']//p");
    //By legalText=By.xpath("//*[@class='legal-text'] | //div[@class='descriptionContainer']//p");
    By legalText=By.xpath("//*[@data-testid='TESTING_LEGAL_TEXT']");
    // Stickybar
    By continueButtonOnStickybar = By.xpath("//button[@id='TESTING_TO_BASKET_BOX_ORDERPANEL']");
    //By notificationFormOnStickyBar = By.xpath("//div[@class='section section-end']//span");
    By notificationFormOnStickyBar = By.xpath("//*[@data-testid='TESTING_CONFIG_CONTACT_SALESMAN_LINK']");
    //By notificationFormHeader = By.className(" //*[@class='modalWindow__wrap__header__title' or @class='modalSidebar__wrap__header__title' or @id='modal_header']");
    //By makeRequestOnStickybar=By.xpath("//*[text()='Make the request']");
    By makeRequestOnStickybar=By.xpath("//*[@data-testid='TESTING_MODAL_NEED_HELP_LEAD_FORM_LINK']");
    //By notificationFormHeader = By.id("modal_header");
    By notificationFormHeader = By.xpath("//*[@data-testid='TESTING_CLOSE_MODAL']/..");


    @Test(description = "getting the list of Characteristics")
    public List<WebElement> CharacteristicsLink(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> characteristics = null;
        System.out.println("get the list of Characteristics");
        try {
            waitForElementClickable(driver, CharacteristicsLink, 10);
            characteristics = driver.findElements(CharacteristicsLink);
            highlightElement(driver, CharacteristicsLink);
            NodeORSubNode.log(Status.INFO, "Got the list of Characteristics");
            //System.out.println(driver.findElements(energy1).get(0).getText());
            //return the liste of energies
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get the list of Characteristics", e);
        }
        return characteristics;
    }

    @Test(description = "getting Characteristics text")
    public String CharacteristicsLinkCheck(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        i = i + 1;
        //By by = By.xpath("(//div[@class='environmentalItem']/span)[" + i + "]");
        By by = By.xpath("(//span[contains(@data-testid,'TESTING_TECH_LABEL')])[" + i + "]");
        //Thread.sleep(500);
        try {
            str = getAnyText(driver, by);
            NodeORSubNode.log(Status.INFO, "Got the Characteristics Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get the Characteristics Text", e);
        }

        return str;
    }

    @Test(description = "clicking On TAE Popup Link")
    public void clickOnTAEPopupLink(String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            if (country.equals("ES")) {
                clickElement(driver, clickOnTAELink_ES,8);
            }
            if (country.equals("FR")) {
                clickElement(driver, clickOnTAELink_FR,8);
            }
            System.out.println("Click on TAE price link");
            NodeORSubNode.log(Status.INFO, "Clicked on TAE price link");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on TAE price link", e);
        }
    }

    @Test(description = "getting Cash Price On Config page")
    public String getCashPriceOnConfigpage(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String text = null;
        try {
            System.out.println("get cash price on config page");
            text = getAnyText(driver, cashPriceOnConfigPage).replace(" ","").substring(0,5).trim();
            NodeORSubNode.log(Status.INFO, "Got cash price on config page: " + text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get cash price on config page", e);
        }
        return text;
    }

    @Test(description = "getting Cash Price On Config TAE PopUp")
    public String getCashPriceOnConfigTAEPopUp(String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            System.out.println("get cash price on config TAE page");
            text = getAnyText(driver, cashPriceOnTAEPopup).replace(" ","").replace(",",".").substring(0,8).trim();
            NodeORSubNode.log(Status.INFO, "Got cash price on config TAE page: " + text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get cash price on config TAE page", e);
        }
        return text;
    }

    @Test(description = "getting Finance Price On Config page")
    public String getFinancePriceOnConfigpage(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            waitForElementPresent(driver, financePriceOnConfigPage, 5);
            str = getAnyText(driver, financePriceOnConfigPage,8).substring(0,3).trim();
            System.out.println("get finance price on config page");
            NodeORSubNode.log(Status.INFO, "Got finance price on config page: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get finance price on config page", e);
        }
        return str;
    }

    @Test(description = "getting Finance Price On Config TAE PopUp")
    public String getFinancePriceOnConfigTAEPopUp(String country, String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            if (country.equals("ES")) {
                text = getAnyText(driver, financePriceOnTAEPopup_ES).trim();
            }
            if (country.equals("FR")) {
                text = getAnyText(driver, financePriceOnTAEPopup_FR).replace(",",".").substring(0,6).trim();
            }
            System.out.println("get finance price on config TAE popup");
            NodeORSubNode.log(Status.INFO, "Got finance price on config TAE Popup: " + text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get finance price on config TAE Popup", e);
        }
        return text;
    }

    @Test(description = "getting Entrada Price On Config page")
    public String getEntradaPriceOnConfigpage(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            System.out.println("get entrada price on config page");
            waitForElementClickable(driver, entradaPriceOnConfigPage, 5);
            str = getAnyText(driver, entradaPriceOnConfigPage).trim();
            NodeORSubNode.log(Status.INFO, "Got Entrada Price On Config page: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Got Entrada Price On Config page", e);
        }
        return str;
    }

    @Test(description = "getting Entrada Price On Config TAE PopUp")
    public String getEntradaPriceOnConfigTAEPopUp(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            System.out.println("get entrada price on config page");
            waitForElementClickable(driver, entradaPriceOnConfigPage, 5);
            str = getAnyText(driver, entradaPriceOnTAEPopup).trim();
            System.out.println("Got entrada price on TAE popup: " + str);
            NodeORSubNode.log(Status.INFO, "Got entrada price on TAE popup: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Got Entrada Price On TAE popup", e);
        }
        return str;
    }

    @Test(description = "clicking Continue Button On Sticky Bar")
    public void clickContinueButtonOnStickyBar(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, continueButtonOnStickybar, 5);
            //Thread.sleep(5000);
            System.out.println("Continue button on Config stick bar is clicked");
            NodeORSubNode.log(Status.INFO, "Continue button on Config stick bar is clicked");

        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Continue button on Config stick bar", e);
        }
    }

    @Test(description = "clicking On Telephone Number Link")
    public void clickOnTelephoneNumberLink(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, telephoneNumberLink,8);
            //Thread.sleep(3000);
            NodeORSubNode.log(Status.INFO, "Clicked On Telephone Number Link");
            System.out.println("Telephone number link is clicked");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking On Telephone Number Link", e);
        }
        //Thread.sleep(1000);
    }

    @Test(description = "clicking On TClose TAE Popup Link")
    public void clickOnTCloseTAEPopupLink(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, closeTAELink);
            //Thread.sleep(500);
            System.out.println("Close TAE popup link");
            //Thread.sleep(500);
            NodeORSubNode.log(Status.INFO, "Clicked on Close TAE popup link");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Close TAE popup link", e);
        }
    }

    @Test(description = "clicking Config Colour")
    public void clickConfigColour() throws InterruptedException {
        System.out.println("Clicked on Personalize Button");
        Thread.sleep(1000);
        clickElement(driver, ConfigColour);
        Thread.sleep(500);
    }

    @Test(description = "selecting Default Colour")
    public void selectDefaultColour() throws InterruptedException {
        System.out.println("Clicked on first default colour for which colour price is present");
        int numVal;
        List<WebElement> allColours = driver.findElements(TestingColour);
        try {
            driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
            for (int i = 0; i <= (allColours.size() - 1); i++) {

                if (i == 0) {
                    for (int k = 0; k < 10; k++) {
                        try {
                            allColours.get(k).click();
                            break;
                        } catch (ElementClickInterceptedException e) {

                            Thread.sleep(500);
                        }
                    }
                } else {
                    allColours.get(i).click();
                }

                //Thread.sleep(3000);
                String price = getAnyText(driver, TestingPrice);

                System.out.println("The price is: " + price);

                if ((price != null) && (!price.contains("Inclus")) && (!price.contains("INCLUS")) &&
                        (!price.contains("No-cost")) && (!price.contains("Incluido")) && (!price.contains("INCLUIDO"))) {
                    break;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getting the list of Colours")
    public List<WebElement> getColoursList() throws InterruptedException {
        scrollIntoView(driver,TestingColour);
        List<WebElement> allColours = driver.findElements(TestingColour);
        return allColours;
    }

    @Test(description = "selecting Color from the list")
    public void selectColor(int i) throws InterruptedException, AWTException {
        Robot r=new Robot();
        String xpath;
        System.out.println("Current URL is: "+driver.getCurrentUrl());
        String currentURL=driver.getCurrentUrl();
       // scrollIntoView(driver,By.xpath("//span[@class='sectionTitle' and text()=\"Couleur(s)\"] |//span[@class='sectionTitle' and text()=\"Couleur\"] | //span[@class='sectionTitle' and text()=\"Teinte\"] | //span[@class='sectionTitle' and text()=\"Color\"]"));
        scrollIntoView(driver,By.xpath("//span[@data-testid=\"TESTING_CONFIG_COLOR_SELECT_TITLE\"]"));
        for(int j=0;j<2;j++){
            r.keyPress(KeyEvent.VK_UP);
            r.keyRelease(KeyEvent.VK_UP);
        }
        if(currentURL.contains("-es-")) {
             xpath = "//div[contains(@class, 'colors')]/div/ul/li["+i+"]/button";
             clickUsingJS(driver,By.xpath(xpath));
        }else {
            // xpath = "//div[contains(@class, 'colors')]/div/ul/li[" + i + "]";
            xpath = "//*[@data-testid=\"TESTING_CONFIG_COLOR_SELECT_TITLE\"]/..//div/ul/li[" + i + "]/button";
            scrollIntoView(driver , By.xpath(xpath));
            waitForElementClickable(driver, By.xpath(xpath),20);
             //clickElement(driver, By.xpath(xpath), 10);
            clickUsingJS(driver,By.xpath(xpath));
        }
        //waitForElementClickable(driver,By.xpath(xpath));
        //Thread.sleep(1000);
        //scrollIntoView(driver,By.xpath(xpath));
        //scrollUp();


    }

    @Test(description = "Hovering on Color from the list")
    public void hoverColor(int i) throws InterruptedException {
        //Instantiate Action Class
        Actions actions = new Actions(driver);
        //Retrieve WebElement 'Music' to perform mouse hover
        WebElement menuOption = driver.findElement(By.xpath("//div[contains(@class, 'colors')]/div/ul/li[" + i + "]/*"));
        highlightElement(driver,By.xpath("//div[contains(@class, 'colors')]/div/ul/li[" + i + "]/*"));
        //Mouse hover menuOption 'Music'
        actions.moveToElement(menuOption).perform();
        System.out.println("Done Mouse hover on colour: "+i);
    }

    @Test(description = "selecting Color based on choice")
    public String getSelectedColorAttribute(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //String xpath = "//div[contains(@class, 'colors')]/div/ul/li[" + i + "]/button";
        //String xpath = "//div[contains(@class, 'colors')]/div/ul/li[" + i + "]/*";
        //String xpath = "//*[@data-testid=\"TESTING_CONFIG_COLOR_SELECT_TITLE\"]//../div/ul/li[" + i + "]/*";
        String xpath ="//*[@data-testid='TESTING_COLOR_"+(i-1)+"']";
        String str = null;
        try {
            System.out.println("selecting Color based on choice");
            //scrollIntoView(driver,By.xpath(xpath));
            str = getAttributeValue(driver, By.xpath(xpath), "class");
            //str = getAttributeValue(driver, By.xpath(xpath), "area-label");
            System.out.println("selecting Color based on choice: " + str);
            NodeORSubNode.log(Status.INFO, "selecting Color based on choice: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to selecting Color based on choice", e);
        }
        return str;
    }

    public String getColourName(String resultDirectory, ExtentTest NodeORSubNode) {
        String name = null;
        try {
            name = getAnyText(driver, colourName);
            NodeORSubNode.log(Status.INFO, "Got Colour Name: " + name);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Image is not present on Home Page", e);
        }
        return name;
    }

    /**
     * To get text for disabled color with given configuration
     *
     * @param i
     * @return
     * @throws InterruptedException
     */
    public String getTextForDisabledColorConfiguration(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //String xpath = "//div[contains(@class, 'colors')]/div/ul/li[" + i + "]/button";
        String str = null;
        //String xpath = "//div[contains(@class, 'colors')]/div/ul/li[" + i + "]/*/div[2]";
        String xpath = "//div[contains(@class, 'colors')]/div/ul/li[" + i + "]/*";
        //*[@id="__next"]/div[1]/div/div[4]/div/div[2]/div[3]/div/div/ul/li[3]/button
        try {
            str= driver.findElement(By.xpath(xpath)).getAttribute("class");
            System.out.println("Attribute of the colour is: "+str);
            //str = getAnyText(driver, By.xpath(xpath));
            NodeORSubNode.log(Status.INFO, "Got Text For Disabled Color Configuration: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Text For Disabled Color Configuration", e);
        }
        return str;
    }

    @Test(description = "clicking on Color GoToNext Slide")
    public void clickColorGoToNextSlide(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            mouseHover(color_goToNext);
            scrollIntoView(driver,color_goToNext);
            clickElement(driver, color_goToNext);
            NodeORSubNode.log(Status.INFO, "Clicked Colour Go To Next Slide");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click Colour Go To Next Slide", e);
        }
    }

    // Engine
    @Test(description = "clicking Config Engine")
    public void clickConfigEngine(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, ConfigEngine);
            System.out.println("Clicked on Engine collapse/expand");
            NodeORSubNode.log(Status.INFO, "Clicked on Engine collapse/expand");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Engine collapse/expand", e);
        }
    }

    @Test(description = "getting Motor List")
    public List<WebElement> getMotorList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> allMotorList = null;
        try {
            waitForElementClickable(driver, MotorizationItem, 15);
            allMotorList = driver.findElements(MotorizationItem);
            NodeORSubNode.log(Status.INFO, "Getting Motor List: " + allMotorList.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Motor List", e);
        }
        return allMotorList;
    }

    @Test(description = "Selecting Motor from List")
    public void selectMotor(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String xpath=null;
        String xpathEngineTitle=null;
        try {
            String url=driver.getCurrentUrl();
            if(url.contains("-es-")){
                //xpath = "(//button[starts-with(@class,'engine ')])["+i+"]";
                xpath ="//*[contains(@data-testid,'TESTING_ENGINE_"+(i-1)+"')]";
            }else {
                //xpath = "(//div[@class='engines ']/div)[" + i + "]";
                xpath ="//*[contains(@data-testid,'TESTING_ENGINE_"+(i-1)+"')]";
                xpathEngineTitle = "(//div[@class='engines ']/div/button[@class='engine ']/div[@class='inner']/span[@class='engineTitle'])["+i+"]";
            }
            //scrollByPixel(10,By.className("engine "));

            clickElement(driver, By.xpath(xpath), 100);
            NodeORSubNode.log(Status.INFO, "Selecting Motor from List");
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Select Motor from List", e);
        }
    }

    @Test(description = "getting Motor's Attribute as per the selection")
    public String getSelectedMotorAttribute(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            // String xpath = "//span[@class='engineTitle']/span["+i+"]/span";
            //String xpath = "(//div[@class='engines ']/div/button)[" + i + "]";
            String xpath ="//*[contains(@data-testid,'TESTING_ENGINE_"+(i-1)+"')]";
            str = getAttributeValue(driver, By.xpath(xpath), "class");
            NodeORSubNode.log(Status.INFO, "Got Motor's Attribute as per the selection: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Motor's Attribute as per the selection", e);
        }
        return str;
    }

    @Test(description = "getting No. Of Options List")
    public List<WebElement> getNoOfOptionsList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> optionList = new ArrayList<WebElement>();
        try {
            waitForElementClickable(driver,noOfOptions,5);
            optionList = driver.findElements(noOfOptions);
            NodeORSubNode.log(Status.INFO, "Got No. Of Options List: " + optionList.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Engine collapse/expand", e);
        }
        return optionList;
    }

    @Test(description = "clicking on Option Icon")
    public void clickOptionIcon(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            String xpath = "//div[@class='option-list ']/div[" + i + "]/span";
            clickElement(driver, By.xpath(xpath),5);
            NodeORSubNode.log(Status.INFO, "Clicked on Option Icon");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Option Icon", e);
        }
    }

    public void clickToCollapseExpandFirstOptions(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, collpaseExpandFirstOptions,2);
            System.out.println("Clicked To Collapse Expand First Options");
            NodeORSubNode.log(Status.INFO, "Clicked To Collapse Expand First Options");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click To Collapse Expand First Options", e);
        }
    }

    public void selectFirstOptionItem(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            //clickElement(driver, firstOptionItem,2);
            clickUsingJS(driver, firstOptionItem);
            System.out.println("Selected First Option Item");
            NodeORSubNode.log(Status.INFO, "Selected First Option Item");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click To Select First Option Item", e);
        }
    }

    public String getFirstOptionItemText(String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            text = getAnyText(driver, firstOptionItemText,5);
            NodeORSubNode.log(Status.INFO, "Selected First Option Item: " + text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click To Select First Option Item", e);
        }
        return text;
    }

    public void clickOptionDetailLink(String brand,String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            if (brand.equals("AC")) {
                clickElement(driver, optionDetailLink_AC,2);
            } else {
                //scrollIntoView(driver,optionDetailLink);
                clickElement(driver, optionDetailLink,2);
            }
            System.out.println("Clicked option detail link");
            NodeORSubNode.log(Status.INFO, "Clicked option detail link");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click option detail link",e);
        }

    }

    public boolean clickOptionIcon(String resultDirectory, ExtentTest NodeORSubNode) {
        boolean bool=false;
        try {
            if(isElementPresent(driver,optionIcon)) {
                bool=true;
                NodeORSubNode.log(Status.PASS, "Option Icon is present");
                clickElement(driver, optionIcon, 2);
                System.out.println("Clicked Option Icon");
                NodeORSubNode.log(Status.INFO, "Clicked on Option Icon");
            }else{
                bool=false;
                NodeORSubNode.log(Status.FAIL, "Option Icon is not present");
            }
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Clicked Option Icon",e);
        }
        return bool;
    }

    public String getOptionDetailTitle(String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            text = getAnyText(driver, optionDetailTitle,3);
            NodeORSubNode.log(Status.INFO, "Got option Detail Title: "+text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Get option Detail Title",e);
        }
        return text;
    }

    public void clickCloseFormPopup(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, closeFormButton,2);
            System.out.println("Clicked on Close Form Popup");
            NodeORSubNode.log(Status.INFO, "Clicked on Close Form Popup");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Close Form Popup",e);
        }
    }

    public String getSelectedOptions(String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            text = getAnyText(driver, selectedOptionsText);
            NodeORSubNode.log(Status.INFO, "Selected Option: "+text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select Option",e);
        }
        return text;
    }

    @Test(description = "selecting Option Item")
    public void selectOptionItem(int i,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
//		String xpath = "//div[@class='option-list ']/div["+i+"]/div/div/div";
        try {
            String xpath = "//div[@class='option-list ']/div[" + i + "]/div/div/div/descendant::input[@type='checkbox']";
            waitForElementClickable(driver,By.xpath(xpath),2);
            clickUsingJS(driver, By.xpath(xpath));
            NodeORSubNode.log(Status.INFO, "Selected Option Item");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select Option Item",e);
        }
    }

    @Test(description = "getting selected Option Item Attribute")
    public String getSelectedOptionItemAttribute(int i,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str=null;
        String xpath = "//div[@class='option-list ']/div[" + i + "]/div/div/div";
        try{
            str=getAttributeValue(driver, By.xpath(xpath), "class",5);
            NodeORSubNode.log(Status.INFO, "Got selected Option Item Attribute: "+str);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get selected Option Item Attribute",e);
        }
        return str;
    }

    @Test(description = "selecting Motor Item")
    public void selectMotorItem() throws InterruptedException {

        System.out.println("Clicked on first default Motor Item for which colour price and TTC/Mois is present");
        waitForElementClickable(driver,MotorizationItem,5);
        List<WebElement> allMotorItems = driver.findElements(MotorizationItem);
        highlightElement(driver,MotorizationItem);
        waitForElementClickable(driver,MotorizationPrice,5);
        List<WebElement> allMotorPrices = driver.findElements(MotorizationPrice);
        highlightElement(driver,MotorizationPrice);

        String TTC_MOIS_Price = null;
        try {
            driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
            for (int i = 0; i <= (allMotorItems.size() - 1); i++) {

                if (i == 0) {
                    for (int k = 0; k < 10; k++) {
                        try {
                            allMotorItems.get(i).click();
                            break;
                        } catch (ElementClickInterceptedException e) {

                            e.printStackTrace();
                        }
                    }
                } else {
                    allMotorItems.get(i).click();
                }

                //Thread.sleep(6000);

                String Motorprice = allMotorPrices.get(i).getText();
                System.out.println(Motorprice);
                String[] AllLineStrings = Motorprice.split("\\r");
                System.out.println(Motorprice);
                for (int j = 0; j < AllLineStrings.length; j++) {
                    System.out.println(AllLineStrings[j]);
                    if ((AllLineStrings[j].contains("TTC")) || (AllLineStrings[j].contains("pm"))
                            || (AllLineStrings[j].contains("OTR")) || (AllLineStrings[j].contains("mes"))
                            || (AllLineStrings[j].contains("MES")) || (AllLineStrings[j].contains("IVA"))) {
                        TTC_MOIS_Price = AllLineStrings[j];
                        System.out.println("TTC/mois price is: " + TTC_MOIS_Price);
                        break;
                    }
                }
                //int MotorNumprice = extractNumericFromString(TTC_MOIS_Price);
                if ((Motorprice != null) && ((Motorprice.contains("TTC/mois")) ||

                        (Motorprice.contains("pm")) || (Motorprice.contains("TTC"))
                        || (Motorprice.contains("MES")) || (Motorprice.contains("mes")) || (Motorprice.contains("IVA")))) {


                    //System.out.println("Motor Price is: " + MotorNumprice);

                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Interior
    @Test(description = "Interior Colour Price Col Exp")
    public void InteriorColourPriceColExp(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, InteriorColourPriceColExp);
            System.out.println("Clicked on Interior Colour collapse/expand");
            NodeORSubNode.log(Status.INFO, "Clicked on Interior Colour collapse/expand");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Interior Colour collapse/expand", e);
        }
    }

    @Test(description = "Clicking on Interior colour for which price is present")
    public void selectInteriorColour(String country,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("Clicked on Interior colour for which price is present");
        int numVal;
        waitForElementClickable(driver,InteriorColour,5);
        List<WebElement> allInteriorColours = driver.findElements(InteriorColour);
        highlightElement(driver,InteriorColour);
        try {
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            int forloop = 0;
            if (allInteriorColours.size() > 3) {
                forloop = 3;
            } else {
                forloop = allInteriorColours.size();
            }
            for (int i = 0; i < forloop; i++) {
                if (i == 0) {
                    for (int k = 0; k < 30; k++) {
                        try {
                            waitForElementClickable(driver,InteriorColour,1);
                            allInteriorColours.get(i).click();
                            break;
                        } catch (ElementClickInterceptedException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    waitForElementClickable(driver,InteriorColour,1);
                    allInteriorColours.get(i).click();
                }

                String price = getAnyText(driver, InteriorColourPrice,6);
                if (price.contains("OR")) {
                    String[] price2 = price.split("OR");
                    price = price2[1];
                }
                if (price.contains("OU")) {
                    String[] price2 = price.split("OU");
                    price = price2[1];
                }
                if ((price.contains("O")) && (country.equalsIgnoreCase("ES"))) {
                    String[] price2 = price.split("O");
                    price = price2[1];
                }

                if ((price != null) && (!price.contains("Inclus")) && (!price.contains("INCLUS"))
                        && (!price.contains("Included")) && (!price.equals("")) && (!price.contains("Incluido"))
                        && (!price.contains("INCLUIDO")) && (!price.contains("No-cost"))) {
                    numVal = extractNumericFromString(price);
                    System.out.println("Interior Price in only Numeric is: " + numVal);
                    NodeORSubNode.log(Status.INFO, "Interior Price in only Numeric is: " + numVal);
                    if (numVal > 0) {
                        break;
                    }

                }
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error while Clicking on Interior colour for which price is present",e);
        }
    }

    // Option
    @Test(description = "Clicking on Option collapse/expand")
    public void clickOption(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickUsingJS(driver, OptionColExp);
            System.out.println("Clicked on Option collapse/expand");
            NodeORSubNode.log(Status.INFO, "Clicked on Option collapse/expand");
            //Thread.sleep(500);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Option collapse/expand",e);
        }
    }

    @Test(description = "Getting Options Numbers")
    public int getOptionsNumbers(String resultDirectory, ExtentTest NodeORSubNode) {
        String text=null;
        int nbrOptions=0;
        try {
            text = getAnyText(driver, TestOptiionText);
            System.out.println(text);
            NodeORSubNode.log(Status.INFO, "Getting Options: "+text);
            String[] text2 = text.split("\\(");
            nbrOptions = Integer.parseInt(text2[1].replaceAll("\\)", ""));
            System.out.println(nbrOptions);
            NodeORSubNode.log(Status.INFO, "Got Options Numbers: "+nbrOptions);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Get Options Numbers",e);
        }
        return nbrOptions;

    }

    @Test(description = "Getting Interior List")
    public List<WebElement> getInteriorList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> allInteriorOptions = null;
        try {
            allInteriorOptions = driver.findElements(interiorOptions);
            NodeORSubNode.log(Status.INFO, "Got Interior List: "+allInteriorOptions);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Interior List",e);
        }
        return allInteriorOptions;
    }

    @Test(description = "selecting Interior Option")
    public void selectInteriorOption(int i,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String xpath = "(//*[@data-testid='TESTING_CONFIG_INTERIOR_SELECT_TITLE']//..//div/button)[" + (i) + "]";
        try {
            //scrollIntoView(driver,By.xpath(xpath));
            if(isElementPresent(driver,By.xpath("//span[@class='name' and text()=\"Gris Platinium (M)\"]"))) {
                scrollIntoView(driver, By.xpath("//span[@class='name' and text()=\"Gris Platinium (M)\"]"));
            }else{
               // scrollIntoView(driver,By.xpath("//span[@class='sectionTitle' and text()=\"Intérieur\"]|//span[@class='sectionTitle' and text()=\"Interior\"]"));

                scrollIntoView(driver,By.xpath("//span[@data-testid=\"TESTING_CONFIG_INTERIOR_SELECT_TITLE\"]"));

            }
            clickElement(driver, By.xpath(xpath), 10);
            System.out.println("Selected Interior Option");
            NodeORSubNode.log(Status.INFO, "Selected Interior Option");
            Thread.sleep(3000);
            for(int k=0;k<=7;k++) {
                Robot r = new Robot();
                r.keyPress(KeyEvent.VK_UP);
                r.keyRelease(KeyEvent.VK_UP);
                Thread.sleep(200);
            }
        }catch (Exception e){
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select Interior Option",e);
        }
    }

    @Test(description = "getting Selected Interior Option Attribute")
    public String getSelectedInteriorOptionAttribute(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            String xpath = "(//*[@data-testid=\"TESTING_CONFIG_INTERIOR_SELECT_TITLE\"]/..//div//button)[" + i + "]";
            waitForElementClickable(driver, By.xpath(xpath), 5);
            clickElement(driver,By.xpath(xpath));
            str = getAttributeValue(driver, By.xpath(xpath), "class");
            NodeORSubNode.log(Status.INFO, "Got Selected Interior Option Attribute: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Selected Interior Option Attribute", e);
        }
        return str;
    }

    @Test(description = "Selecting first option for which price is present")
    public void selectOption(String Country, String Brand, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("Selecting first option for which price is present");
        int numVal;
        HomePage hmpg = new HomePage(driver);
        if (getOptionsNumbers(resultDirectory, NodeORSubNode) > 0) {
            waitForElementClickable(driver,TestOption,5);
            List<WebElement> allOptions = driver.findElements(TestOption);
            highlightElement(driver,TestOption);
            System.out.println("##############" + allOptions.size());
            if (allOptions.size() > 0) {
                try {
                    driver.manage().timeouts().implicitlyWait(240, TimeUnit.SECONDS);
                    for (int i = 0; i < allOptions.size(); i++) {
                        System.out.println("##############" + i);
                        if (i == 0) {
                            for (int k = 0; k < 10; k++) {
                                try {
                                    waitForElementClickable(driver,TestOption);
                                    allOptions.get(i).click();
                                    break;
                                } catch (ElementClickInterceptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        } else {
                            waitForElementClickable(driver,TestOption);
                            allOptions.get(i).click();
                        }

                        //Thread.sleep(6000);

                        String price = getAnyText(driver, OptionPrice,6);
                        if ((price != null) && (!price.contains("Inclus")) && (!price.contains("No-cost"))
                                && (!price.contains("Incluido")) && (!price.contains("INCLUIDO"))) {
                            //// waitForElementClickable( driver, OptionAdd);
                            scroling(driver, OptionAdd);
                            Thread.sleep(2000);
                            driver.navigate().to(driver.getCurrentUrl());
                            //Thread.sleep(3000);
                            if ((Country.equalsIgnoreCase("UK")) && (Brand.equalsIgnoreCase("DS"))) {
                                hmpg.CloseBookTestDrive(resultDirectory,NodeORSubNode);
                            }
                            // scroll to the top
                            JavascriptExecutor js = (JavascriptExecutor) driver;
                            js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
                            //Thread.sleep(500);
                            clickOption(resultDirectory,NodeORSubNode);

                            break;
                        }

                    }
                } catch (Exception e) {
                    catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select first option for which price is present",e);
                }
            }
        }
    }

    @Test(description = "Getting value of finance Widget CheckBox")
    public String financeWidgetCheckBox(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str=null;
        try{
            str=getClassValue(driver, FinanceWidgetSelected);
            NodeORSubNode.log(Status.INFO, "Got value of finance Widget CheckBox: "+str);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get value of finance Widget CheckBox",e);
        }
        return str;
    }

    @Test(description = "Getting value of Cash Widget CheckBox")
    public String CashWidgetCheckBox(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str=null;
        try{
            str=getClassValue(driver, CashWidgetSelected);
            NodeORSubNode.log(Status.INFO, "Got value of Cash Widget CheckBox: "+str);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get value of Cash Widget CheckBox",e);
        }
        return str;
    }

    @Test(description = "Clicking on finance Widget CheckBox")
    public void clickfinanceWidgetCheckBox(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, FinanceWidgetSelected);
            System.out.println("Clicked on finance Widget CheckBox");
            NodeORSubNode.log(Status.INFO, "Clicked on finance Widget CheckBox");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on finance Widget CheckBox",e);
        }
    }

    @Test(description = "Clicking on Cash Widget CheckBox")
    public void clickcashWidgetCheckBox(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, CashWidgetSelected);
            System.out.println("Clicked on Cash Widget CheckBox");
            NodeORSubNode.log(Status.INFO, "Clicked on Cash Widget CheckBox");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Cash Widget CheckBox",e);
        }
    }

    @Test(description = "Clicking on Config Continue")
    public void clickConfigcontinue(String resultDirectory, ExtentTest NodeORSubNode,String Country, String Brand) throws InterruptedException {
        try {
            waitForElementClickable(driver, BasketContinue,10);
            Thread.sleep(2000);
            if((Country.equalsIgnoreCase("FR") && (Brand.equalsIgnoreCase("DS"))|| Brand.equalsIgnoreCase("OV"))
                    || (Country.equalsIgnoreCase("ES")&&Brand.equalsIgnoreCase("DS"))){
                clickUsingJS(driver,BasketContinue);
            } else{
                clickElement(driver, BasketContinue, 15);
            }
            /*if(driver.findElements(BasketContinue).size()==1) {
                clickElement(driver, BasketContinue, 15);
            }
            if(driver.findElements(BasketContinue).size()==2){
                String url=driver.getCurrentUrl();*/
                /*if( Country.equalsIgnoreCase("FR")&& Brand.equalsIgnoreCase("DS")&& !url.contains("/summary")){
                    clickElement(driver, By.xpath("(//*[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX'])[2]"), 15);
                } else{*/

                    //clickElement(driver, By.xpath("(//*[@id='TESTING_TO_BASKET_BOX_ORDERPANEL' or @id='TESTING_TO_BASKET_BOX_INTERESTEDBOX'])[2]"), 15);
                //}

            System.out.println("Clicked on Config Continue");
            NodeORSubNode.log(Status.INFO, "Clicked on Config Continue");
            Thread.sleep(3000);
        }catch (Exception e){
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Config Continue",e);
        }
    }

    @Test(description = "Clicking on Continue to order summary page")
    public void clickOnVehicleSummaryContinue(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, vehicleSummeryPageContinue);
            System.out.println("Clicked on Continue to order summary page");
            NodeORSubNode.log(Status.INFO, "Clicked on Continue to order summary page");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Continue to order summary page",e);
        }
    }

    @Test(description = "Clicking on Commercial Offer")
    public void clickCommercialOffer(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, OfferCommercialeContinue);
            System.out.println("Continued to commercial offer");
            NodeORSubNode.log(Status.INFO, "Continued to commercial offer");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Continue to commercial offer",e);
        }
    }

    public ConfigPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        // getCashPriceFromHeader();
        // getFinancePriceFromHeader();
    }

    @Test(description = "getCustomizeYourProjectText_FR")
    public String getCustomizeYourProjectText_FR(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str=null;
        try{
            str=getAnyText(driver, CustomizeYourProject_FR);
            System.out.println("Clicked on Personalize Button");
            NodeORSubNode.log(Status.INFO, "Clicked on Personalize Button: "+str);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Personalize Button",e);
        }
        return str;
    }

    public String getMotorLabelText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            Thread.sleep(4000);
            str = getAnyText(driver, motorSection,15);
            System.out.println("Got Motor Label Text: " + str);
            NodeORSubNode.log(Status.INFO, "Got Motor Label Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Motor Label Text", e);
        }
        return str;
    }

    @Test(description = "getting information form text")
    public String getInformationFormText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, notificationButton,5);
            System.out.println("information form text : " + str);
            NodeORSubNode.log(Status.INFO, "information form text : " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get information form text", e);
        }
        return str;

    }

    @Test(description = "getCustomizeYourProjectText_UK")
    public String getCustomizeYourProjectText_UK(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, CustomizeYourProject_UK);
            System.out.println("Got Customize Your Project Text: " + str);
            NodeORSubNode.log(Status.INFO, "Got Customize Your Project Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get customize Your Project Text", e);
        }
        return str;
    }

    @Test(description = "getCustomizeYourProjectText_UK_VX")
    public String getCustomizeYourProjectText_UK_VX(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, CustomizeYourProject_UK_VX);
            System.out.println("Got Customize Your Project Text: " + str);
            NodeORSubNode.log(Status.INFO, "Got Customize Your Project Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Customize Your Project Text", e);
        }
        return str;
    }

    @Test(description = "getting text getCustomizeYourProjectText_ES")
    public String getCustomizeYourProjectText_ES(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str=null;
        try {
            str = getAnyText(driver, CustomizeYourProject_ES);
            System.out.println("Got text getCustomizeYourProjectText_ES: "+str);
            NodeORSubNode.log(Status.INFO, "Got text getCustomizeYourProjectText_ES");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get text getCustomizeYourProjectText_ES: "+str,e);
        }
        return str;
    }

    @Test(description = "getting text CustomizeYourProject_ES_DS")
    public String getCustomizeYourProjectText_ES_DS(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str=null;
        try {
            str = getAnyText(driver, CustomizeYourProject_ES_DS);
            System.out.println("Got text CustomizeYourProject_ES_DS: "+str);
            NodeORSubNode.log(Status.INFO, "Got text CustomizeYourProject_ES_DS: "+str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get text CustomizeYourProject_ES_DS",e);
        }
        return str;
    }

    @Test(description = "Getting cash price from header")
    public int getCashPriceFromHeader(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        int CashPriceFromHeader = 0;
        try {
            CashPriceFromHeader = extractNumericFromString(getAnyText(driver, headerCashPrice,20));
            System.out.println("Got cash price from header: "+CashPriceFromHeader);
            NodeORSubNode.log(Status.INFO, "Got text cash price from header: "+CashPriceFromHeader);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get text cash price from header",e);
        }
        return CashPriceFromHeader;
    }

    @Test(description = "Getting Finance price from header")
    public int getFinancePriceFromHeader(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("Getting Finance price from header");
        int FinancePriceFromHeader = 0;
        try {
            FinancePriceFromHeader = extractNumericFromString(getAnyText(driver, headerFinancePrice,20));
            NodeORSubNode.log(Status.INFO, "Got Finance price from header: "+FinancePriceFromHeader);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Finance price from header",e);
        }
        return FinancePriceFromHeader;
    }

    @Test(description = "getting Finance Container Price Title")
    public String getFinanceContainerPriceTitle(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String label = null;
        try {
            label = getAnyText(driver, FinConPriceTitle,100);
            System.out.println("Got Finance Container Price Title: "+label);
            NodeORSubNode.log(Status.INFO, "Got Finance Container Price Title: "+label);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Finance Container Price Title",e);
        }
        return label;
    }

    @Test(description = "getting cash Container Price Title")
    public String getCashContainerPriceTitle(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("getting cash Container Price Title");
        String label = null;
        try {
            label = getAnyText(driver, CashConPriceTitle,100);
            NodeORSubNode.log(Status.INFO, "Got cash Container Price Title: "+label);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get cash Container Price Title",e);
        }
        return label;
    }

    @Test(description = "getting Finance Container Price Amount")
    public String getFinanceContainerPriceAmount(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("getting Finance Container Price Amount");
        String price = null;
        try {
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            price = getAnyText(driver, FinConPriceAmount,100).substring(0,3);
            System.out.println("Price as is: "+price);
            NodeORSubNode.log(Status.INFO, "Got Finance Container Price Amount: " + price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Finance Container Price Amount", e);
        }
        return price;
    }

    @Test(description = "getting Cash Container Price Amount")
    public String getCashContainerPriceAmount(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String price = null;
        try {
            price = getAnyText(driver, CashConPriceAmount,100);
            System.out.println("Got Cash Container Price Amount");
            NodeORSubNode.log(Status.INFO, "Got Cash Container Price Amount: " + price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Cash Container Price Amount", e);
        }
        return price;
    }

    @Test(description = "getting PRIX TTC HORS OPTIONS price")
    public String getPrixTTCHorsOptions(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String price = null;
        try {
            price = getAnyText(driver, PrixTTCHorsOptionsPriceAmount,100);
            System.out.println("getting PRIX TTC HORS OPTIONS price: "+price);
            NodeORSubNode.log(Status.INFO, "getting PRIX TTC HORS OPTIONS price: " + price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get PRIX TTC HORS OPTIONS price", e);
        }
        return price;
    }

    @Test(description = "getting Total OPTIONS price")
    public String getTotalOptions(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String price = null;
        try {
            price = getAnyText(driver, TotalOptionsPriceAmount,100);
            System.out.println("Got Total OPTIONS price: "+price);
            NodeORSubNode.log(Status.INFO, "Got Total OPTIONS price: "+price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Total OPTIONS price", e);
        }
        return price;
    }

    @Test(description = "getting Montant Total TTC price")
    public String getMontantTotalTTC(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String price = null;
        try {
            price = getAnyText(driver, MontantTotalTTCPrice);
            System.out.println("Got Montant Total TTC price: "+price);
            NodeORSubNode.log(Status.INFO, "Got Montant Total TTC price: "+price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Montant Total TTC price", e);
        }
        return price;
    }

    //Notification Form
    @Test(description = "Filling Notification Form")
    public void fillNotificationForm(String Brand, String Country, String PostalCode, String Email, String Name,
                                     String Phone, String Adress, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

            System.out.println("Fill Notification Form");
            //Assert.assertEquals(isElementPresent(driver, notificationButton, 10), true, "Notification Button Not Present");
            if (Brand.equals("AC")) {
                waitForElementClickable(driver, notificationButton_AC, 5);
                //Thread.sleep(1000);
                clickElement(driver, notificationButton_AC,5);
                NodeORSubNode.log(Status.INFO, "Clicked on Notification Button");
            } else {
                waitForElementClickable(driver, notificationButton, 5);
                clickElement(driver, notificationButton);
                NodeORSubNode.log(Status.INFO, "Clicked on Notification Button");
            }
            Thread.sleep(3000);
            if (!Country.equalsIgnoreCase("UK")) {
                clickUsingJS(driver, CivilityBox);
                Thread.sleep(500);
                clickUsingJS(driver, CivilityBox);
                NodeORSubNode.log(Status.INFO, "Clicked on Civility Box");
                Thread.sleep(500);
                enterText(driver, PostalCodeField, PostalCode);
                System.out.println("PostalCodeField");
                NodeORSubNode.log(Status.INFO, "Entered Postal Code Field");
                // Thread.sleep(1000);
                clickElement(driver, EmailFieldCheckBox);
                NodeORSubNode.log(Status.INFO, "Entered Email field Checkbox");
                // Thread.sleep(1000);
            }
            // Thread.sleep(1000);
            enterData(driver, FirstNameField, Name);
            System.out.println("FirstNameField");
            NodeORSubNode.log(Status.INFO, "Entered First Name");
            // Thread.sleep(1000);
            enterData(driver, LastNameField, Name);
            System.out.println("LastNameField");
            NodeORSubNode.log(Status.INFO, "Entered Last Name");
            // Thread.sleep(1000);
            enterData(driver, PhoneNumberField, Phone);
            System.out.println("PhoneNumberField");
            NodeORSubNode.log(Status.INFO, "Entered Phone Number");
            // Thread.sleep(1000);
            enterData(driver, EmailField, Email);
            System.out.println("EmailField");
            NodeORSubNode.log(Status.INFO, "Entered Email Field");
            // Thread.sleep(1000);

            if (Country.equalsIgnoreCase("UK") && !Brand.equalsIgnoreCase("VX")) {
                enterData(driver, PostalCodeField, PostalCode);
                NodeORSubNode.log(Status.INFO, "Entered Postal Code");
                // Thread.sleep(1000);
                enterData(driver, AdressField, Adress);
                NodeORSubNode.log(Status.INFO, "Entered Address");
                // Thread.sleep(1000);
                enterData(driver, TownField, PostalCode);
                NodeORSubNode.log(Status.INFO, "Entered Town");
                // Thread.sleep(1000);
                clickElement(driver, EmailFieldCheckBox_UK);
                NodeORSubNode.log(Status.INFO, "Clicked on Email Field");
                // Thread.sleep(1000);
            } else if (Country.equalsIgnoreCase("UK") && Brand.equalsIgnoreCase("VX")) {
                enterData(driver, PostalCodeFieldUK, PostalCode);
                NodeORSubNode.log(Status.INFO, "Entered Postal Code");
                // Thread.sleep(1000);
                clickElement(driver, EmailFieldCheckBox_UKVX);
                NodeORSubNode.log(Status.INFO, "Clicked on Email Field");
                // Thread.sleep(1000);
            }

            clickElement(driver, submitButton,10);
            System.out.println("submit button");
            NodeORSubNode.log(Status.INFO, "Clicked on Submit Button");
            // Thread.sleep(2000);
            clickElement(driver, closeFormButton);
            System.out.println("close button");
            NodeORSubNode.log(Status.INFO, "Clicked on Close Button");
            // Thread.sleep(2000);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Filling of Notification Field", e);
        }
    }

    // Get energy liste
    @Test(description = "get the list of energies")
    public List<WebElement> getEnergyList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> allEnergies = null;
        int numEnr;
        try {
            waitForElementClickable(driver,energylist,5);
            allEnergies = driver.findElements(energylist);
            System.out.println("Got the list of energies: "+allEnergies.size());
            NodeORSubNode.log(Status.INFO, "Got the list of energies: "+allEnergies.size());
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with getting the list of energies", e);
        }

        //return the liste of energies
        return allEnergies;
		/*try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			for (int i = 0; i <= (allColours.size() - 1); i++) {
				
				if (i==0) {
					for (int k = 0; k < 10; i++) {
			            try {
			            	allColours.get(k).click();
			            	break;
			            	}
			             catch (ElementClickInterceptedException e) {
			                
			                Thread.sleep(500);
			            }
					}
				}
				else {allColours.get(i).click();}
					
				Thread.sleep(3000);
				String price = getAnyText(driver, TestingPrice);
				
					System.out.println("The price is: " + price);
				
				if ((price != null) && (!price.contains("Inclus")) && (!price.contains("INCLUS"))&& (!price.contains("No-cost")))  {
						break;
					}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}*/


    }

    // Save Button
    @Test(description = "getting Save Button Text")
    public String getSaveButtonText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("getting Save Button Text");
        String price = null;
        try {
            price = getAnyText(driver, CarSaveButton,100);
            NodeORSubNode.log(Status.INFO, "Got save button Text: " + price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get save button text", e);
        }
        return price;
    }

    @Test(description = "getting Save Button Text After Clicking")
    public String getSaveButtonTextAfterClicking(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String price = null;
        try {
            price = getAnyText(driver, CarSaveButtonAfterClick,100);
            System.out.println("Got Save Button Text After Clicking: " + price);
            NodeORSubNode.log(Status.INFO, "Got Save Button Text After Clicking: " + price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click Save Button Text After Clicking", e);
        }
        return price;
    }

    @Test(description = "Save car Button clicked")
    public void clickOnSaveButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            // waitForElementClickable(driver, CarSaveButton);
            clickElement(driver, CarSaveButton, 5);
            System.out.println("Save car Button clicked");
            NodeORSubNode.log(Status.INFO, "Save car Button clicked");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click Save car Button", e);
        }
    }

    @Test(description = "Login Button clicked")
    public void clickOnLoginButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            // waitForElementClickable(driver, LogingButton);
            clickElement(driver, LogingButton);
            System.out.println("Login Button clicked");
            NodeORSubNode.log(Status.INFO, "Login Button clicked");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Login Button", e);
        }
    }

    @Test(description = "Back Button clicked")
    public void clickOnBackButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, BackButton,5);
            System.out.println("Back Button clicked");
            NodeORSubNode.log(Status.INFO, "Back Button clicked");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with clicking on Back Button",e);
        }
    }

    @Test(description = "getting The Car Name: ")
    public String getTheCarText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String carName = null;
        try {
            carName = getAnyText(driver, CarName,100);
            System.out.println("Got The Car Name: "+carName);
            NodeORSubNode.log(Status.INFO, "Got The Car Name: "+carName);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with getting the car Name",e);

        }
        return carName;
    }

    @Test(description = "Charactristics link Clicked")
    public void clickOnCharateristics(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            scrollToTop(driver);
            NodeORSubNode.log(Status.INFO, "Scrolled to TOP");
            System.out.println("Characteristics link Clicked");
            //scrollIntoView(driver,characteristicLink);
            clickElement(driver, characteristicLink,10);
            NodeORSubNode.log(Status.INFO, "Clicked on Characteristics Link");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Clicking on Characteristics Link", e);
        }
    }

    @Test(description = "Getting Energy Text")
    public String getEnergyText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, textEnergy);
            NodeORSubNode.log(Status.INFO, "Got Energy Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Energy Text", e);
        }
        return str;
    }

    @Test(description = "Getting Power Text")
    public String getPowerText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, textPower);
            NodeORSubNode.log(Status.INFO, "Got Power Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Power Text", e);
        }
        return str;
    }

    @Test(description = "Getting GearBox Text")
    public String getGearboxText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, textGearbox);
            NodeORSubNode.log(Status.INFO, "Got Gear Box Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get gearbox text", e);
        }
        return str;
    }

    @Test(description = "Getting Mixed consumption Text")
    public String getMixedconsumptionText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, textMixedconsumption);
            NodeORSubNode.log(Status.INFO, "Got Mixed consumption Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Mixed consumption Text", e);
        }
        return str;
    }

    @Test(description = "Getting Total CO2 Emissions Text")
    public String getTotalCO2EmissionsText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, textTotalCO2Emissions);
            NodeORSubNode.log(Status.INFO, "Got Total CO2 Emissions Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Total CO2 Emissions Text", e);
        }
        return str;
    }

    @Test(description = "Getting ConsumoMixto Text")
    public String getConsumoMixtoText_ES_DS(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, textConsumoMixto_ES_DS);
            NodeORSubNode.log(Status.INFO, "Got ConsumoMixto Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get ConsumoMixto Text", e);
        }
        return str;
    }

    @Test(description = "Getting Total CO2 Emissions Text for ES_DS")
    public String getTotalCO2EmissionsText_ES_DS(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, textTotalCO2Emissions_ES_DS);
            NodeORSubNode.log(Status.INFO, "Got Total CO2 Emissions Text for ES_DS: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Total CO2 Emissions Text for ES_DS", e);
        }
        return str;
    }

    @Test(description = "Clicking on Exterior image")
    public void clickExteriorImage(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, exteriorImageLink);
            System.out.println("Exterior image clicked");
            NodeORSubNode.log(Status.INFO, "Clicked on Exterior Image");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Exterior Image", e);
        }
    }

    @Test(description = "Clicking on Interior image")
    public void clickInteriorImage(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, interiorImageLink);
            System.out.println("Interior image clicked");
            NodeORSubNode.log(Status.INFO, "Clicked on Interior Image");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Interior Image", e);
        }
    }

    @Test(description = "Clicking on Next Slide Arrow")
    public void clickonNextSlideArrow(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, slideArrowButton, 5);
            System.out.println("next slide arrow clicked");
            NodeORSubNode.log(Status.INFO, "Clicked on Next Slide Arrow");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Next Slide Arrow", e);
        }
    }

    public List<WebElement> getImageList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> images=null;
        try {
            images = driver.findElements(imageList);
            System.out.println("Got the list of images: "+images.size());
            NodeORSubNode.log(Status.INFO, "Got the list of images: "+images.size());
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the list of images", e);
        }
        return images;
    }

    @Test(description = "Clicking on Image Link")
    public void clickImageLink(int i,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String xpath="//li[contains(@class, 'react-multi-carousel-dot')][" + i + "]";
        try {
            clickElement(driver, By.xpath(xpath),5);
            System.out.println("Clicked on image Link: "+xpath);
            NodeORSubNode.log(Status.INFO, "Clicked on image Link");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on image Link",e);
        }
    }

    @Test(description = "Getting Value of Image Attribute")
    public String getImageAttributeValue(int i,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String xpath="//li[contains(@class, 'react-multi-carousel-dot')][" + i + "]";
        String classValue=null;
        try {
            classValue = getClassValue(driver,By.xpath(xpath));
            System.out.println("Got the Value of Image Attribute: "+classValue);
            NodeORSubNode.log(Status.INFO, "Got the Value of Image Attribute: "+classValue);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get the Value of Image Attribute",e);
        }
        return classValue;
    }

    @Test(description = "Getting Vehicle Name")
    public String getVehicleName(String resultDirectory, ExtentTest NodeORSubNode) {
        String str=null;
        try{
            str=getAnyText(driver, vehicleName,5);
            NodeORSubNode.log(Status.INFO, "Got vehicle Name: "+str);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get vehicle Name",e);
        }
        return str;
    }

    @Test(description = "Clicking on calculator button")
    public void clickOnPersonalizeFinanceButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, clickOnPersonalizeFinanceButton,25);
            System.out.println("Click on Personalize Finance Button");
            NodeORSubNode.log(Status.INFO, "Click on Personalize Finance Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Personalize Finance Button", e);
        }
    }

    @Test(description = "Clicking on finance duration button")
    public void clickFinanceDurationButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            Thread.sleep(2000);
            clickElement(driver, financeDurationButton, 20);
            System.out.println("Clicked on finance duration button");
            NodeORSubNode.log(Status.INFO, "Clicked on finance duration button");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on finance duration button",e);
        }
    }

    @Test(description = "getting finance duration Price")
    public String getFinanceDurationPrice(String resultDirectory, ExtentTest NodeORSubNode,String country, String brand,String PaymentMode) throws InterruptedException {
        System.out.println("getting finance duration Price");
        String price = null;
        try {
            //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            if(Country.equalsIgnoreCase("ES") && brand.equalsIgnoreCase("AP") && PaymentMode.equalsIgnoreCase("Finance")){
                price = getAnyText(driver, calculatorPrice, 100).substring(0, 8).replace(".", "").replace(",", ".");
            } else if(Country.equalsIgnoreCase("FR") && brand.equalsIgnoreCase("OV") && PaymentMode.equalsIgnoreCase("Finance")){
                price=getAnyText(driver,calculatorPrice_OV,100).substring(0,7);
            }
            else {
                price = getAnyText(driver, calculatorPrice, 100).substring(0, 7).replace(",", ".");
            }
            System.out.println("Price as is: "+price);
            NodeORSubNode.log(Status.INFO, "Got Finance Duration Price: " + price);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Finance Duration Price", e);
        }
        return price;
    }

    @Test(description = "getting technical problem error text if available")
    public String techProblemError(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        System.out.println("getting technical problem error text if available");
        String techProbText = null;
        try {
            //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            if(isElementPresent(driver,technicalProblemError,20)) {
                techProbText = getAnyText(driver, technicalProblemError);
                if ((techProbText != null) && (techProbText.contains("SE HA PRODUCIDO UN ERROR…"))) {
                    NodeORSubNode.log(Status.INFO, "Got Technical Error Text " + techProbText);
                } else {
                    NodeORSubNode.log(Status.INFO, "Technical Error Text is not found");
                }
            }else{
                NodeORSubNode.log(Status.INFO, "Technical Error Text is not found");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get technical problem text", e);
        }
        return techProbText;
    }

    @Test(description = "Clicking on close popup")
    public void clickClosePopup(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            if (isElementPresent(driver, closeCalculatorPopup)) {
                clickElement(driver, closeCalculatorPopup);
                System.out.println("Closed Calculator popup");
                NodeORSubNode.log(Status.INFO, "Closed Calculator popup");
            }
            if (isElementPresent(driver, closeErrorTAEPopup)) {
                clickElement(driver, closeErrorTAEPopup);
                System.out.println("Closed Calculator popup");
                NodeORSubNode.log(Status.INFO, "Closed Calculator popup");
            }

        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Close Calculator popup", e);
        }
    }

    @Test(description = "Clicking on Continue button")
    public void clickOnCalculatorContinueButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            Thread.sleep(2000);
            clickElement(driver, continueButton,60);
            System.out.println("Continue button clicked");
            NodeORSubNode.log(Status.INFO, "Continue button clicked");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Continue button",e);
        }

    }

    @Test(description = "getting delivery message")
    public String getDeliveryText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str=null;
        try{
            str=getAnyText(driver, deliveryMessage,5);
            NodeORSubNode.log(Status.INFO, "Got delivery message: "+str);
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get delivery message",e);
        }
        return str;
    }

    /**
     * To select assurance checkbox on Calculator popup
     *
     * @return
     */
    public void selectAssuranceCheckbox(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, assuranceCheckbox, 8);
            System.out.println("assurance checkbox selected");
            NodeORSubNode.log(Status.INFO, "assurance checkbox selected");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to select assurance checkbox",e);
        }
    }

    /**
     * To select assurance confirmation checkbox on Calculator popup
     *
     * @return
     */
    public void selectAssuranceConfirmCheckbox(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, assuranceConfirmCheckbox, 10);
            System.out.println("assurance confirm checkbox selected");
            NodeORSubNode.log(Status.INFO, "assurance confirm checkbox selected");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Select assurance confirm checkbox",e);
        }
    }

    public void clickNotificationFormOnStickyBar(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, notificationFormOnStickyBar, 5);
            System.out.println("Clicked on notification form on StickyBar");
            NodeORSubNode.log(Status.INFO, "Clicked on notification form on StickyBar");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on notification form on StickyBar",e);
        }
    }
    public void clickOnMakeRequest(String resultDirectory, ExtentTest NodeORSubNode){
        try {
            clickElement(driver, makeRequestOnStickybar, 5);
            System.out.println("Clicked on Make a request on StickyBar");
            NodeORSubNode.log(Status.INFO, "Clicked on Make a request on StickyBar");
        }catch (Exception e){
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Make a request on StickyBar",e);
        }
    }

    public String getNotificationFormHeader(String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            text = getAnyText(driver, notificationFormHeader);
            NodeORSubNode.log(Status.INFO, "Clicked on notification form on Header: "+text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on notification form on Header",e);
        }
        return text;
    }

    public String getLegalText(String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            text = getAnyText(driver, legalText,10);
            NodeORSubNode.log(Status.INFO, "Got legal Text: " + text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get legal text", e);
        }
        return text;
    }

}
