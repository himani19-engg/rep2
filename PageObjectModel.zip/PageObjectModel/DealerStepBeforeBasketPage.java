package solRetailIHM.PageObjectModel;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import junit.framework.Assert;
import solRetailIHM.Utilities.UniversalMethods;

public class DealerStepBeforeBasketPage extends UniversalMethods {
    WebDriver driver = null;

    By basketContinue = By.xpath("//*[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX']/span");// Redirection to basket page
    // from dealer before basket
    // //*[@id="TESTING_TO_BASKET_BOX_INTERESTEDBOX"]/span
    //By searchboxforpostalcode = By.xpath("//*[@id='search']/div/div/div/div");// Click on search Input box with postal
    By searchboxforpostalcode = By.xpath("//*[@data-testid=\"TESTING_LOCATION_INPUT\"]");// Click on search Input box with postal

    By goToBasketBtn=By.id("TESTING_TO_BASKET_BOX_INTERESTEDBOX");
    // code-
    // //*[@id="search"]/div/div/div/div/input
    //By enterPostalCode = By.xpath("//*[@id='search']/div/div/div/div/input");// enter postal code in search inputbox
    By enterPostalCode = By.xpath("//*[@data-testid=\"TESTING_LOCATION_INPUT\"]");// enter postal code in search inputbox

    //By searchButton = By.xpath("//*[@id='search']/button/span[2] | //*[@class=\"dropDown\"]/ul/li[1]");// Click on Search button //*[@id="search"]/button // //*[@id="search"]
    By searchButton = By.xpath("//*[@data-testid='TESTING_LOCATION_PREDICTED_PLACE_0']");// Click on Search button //*[@id="search"]/button // //*[@id="search"]

    //By dealerList = By.xpath("//*[@id='dealerList']/button[]"); //dealer list //*[@id="dealerList"]
    //By dealerList = By.xpath("//*[@id='dealerList']//button[contains(@class, 'visible')]");
    By dealerList = By.xpath("//*[contains(@data-testid,'dealer-')]//button[contains(@class, 'visible')]");
    // //*[@id="dealerList"]/button[6]
    //By defaultDealer = By.xpath("//*[@id='dealerList']/button[1]");
    By defaultDealer = By.xpath("(//button[contains(@data-testid,'dealer-')])[1]");
//    By linkButton = By.className("linkButton");
    By linkButton=By.xpath("//*[@class='links-section']/div/child::div");
    By loginScreen = By.xpath("//*[@id='__next']/div[1]/p");

//    By phoneLink = By.linkText("PAR TELEPHONE AU : 09 69 39 10 08");
    //By phoneLink = By.xpath("(//*[@class='links-section']/div/following-sibling::div/child::div/div)[1]");
    By phoneLink = By.xpath("//*[@data-testid='TESTING_NEED_A_HAND_SECTION_PHONE_LINK']");
    //    By ContactAdvisorLink = By.xpath("//*[text() = 'Contacter votre conseiller']");
//    By ContactAdvisorLink =  By.xpath("(//*[@class='links-section']/div/following-sibling::div/child::div/div)[2]");
    By ContactAdvisorLink;
    //By ModelWindow = By.className("modalWindow__wrap__header");

    By ModelWindow = By.className("modalSidebar__wrap__header__title");

    By SuccessBoxContent = By.className("box-content");

    By modelPopupCloseBtn = By.xpath("//button[@data-testid='TESTING_CLOSE_MODAL']");

    By namePrefix = By.xpath("//*[@name='civility' and @value = 'M.']");

    By firstName = By.name("firstName");

    By lastName = By.name("lastName");

    By phoneNumber = By.name("phone");

    By CustomerEmail = By.name("emailCust");

    By PostalCode = By.name("postCode");

    By submitBtn= By.xpath("//*[@class='submit-button button btn btn-primary']");

    //By dealerCityDistance = By.className("name");
    By dealerCityDistance = By.xpath("//*[contains(@data-testid,'TESTING_LOCATION_DEALER_NAME')]/parent::div");
    By address = By.className("address");

    By dealerToolTip = By.className("dealerToolTip");

    By openingHours = By.className("openingHours");
    //By distanceUnit = By.className("distanceUnit");
    By distanceUnit = By.xpath("//*[contains(@data-testid,'TESTING_LOCATION_DEALER_DISTANCE')]/span[2]");
   // By viewMore = By.xpath("//*[@id=\"__next\"]/div[1]/div/div[3]/div[1]/div[1]/div[1]/button");
    By viewMore = By.xpath("//*[@data-testid='TESTING_DEALERS_SHOW_MORE']");


    By priceSection = By.className("titleWrapper");

//    By storePrice_link=By.className("storePrice_link");
    //By storePrice_link=By.xpath("//*[text()='Détail du prix du véhicule']");
    //By storePrice_link=By.xpath("//*[contains(@class,'titleWrapper')]");
    By storePrice_link=By.xpath("//*[@data-testid='TESTING_VEHICLE_SUMMARY_TITLE_TEXT']");
    //By cashPriceTotalLeft = By.xpath("//div[@class='cashPrice']//span[@class='formatMoney'] | (//span[@class='formatMoney'])[3]");
    //By cashPriceTotalLeft = By.xpath("//div[@class='cashPrice']//span[@class='formatMoney'] | (//span[@class='formatMoney'])[5]");
    By cashPriceTotalLeft = By.xpath("//*[@data-testid='TESTING_VEHICLE_SUMMARY_TOTAL_CASH_PRICE']/span[1]");
    By cashPriceTotalRight = By.xpath("//div[@class='totalPrice_cashPrice ']//span[@class='formatMoney']");

    By totalMonthlyPrice= By.xpath("//div[@class=\"totalPrice_monthlyPrice_price\" or @class=\"totalPrice_cashPrice \"]");

    //   By fundingDetails= By.className("aprDescription");
 //   By fundingDetails= By.xpath("//*[@class='IconStyled-sc-1eor1xf-0 cmximg icon-wrapper']");
 By fundingDetails= By.xpath("(//*[@class='suffix']/following-sibling::button)[2]/div/div/span");
    By financeYourVehicleHeader= By.className("modalSidebar__wrap__header__title");

    By financeYourVehicleRental=By.xpath("//*[@data-testid='TESTING_FINANCE_PRICE_3_1']");
    By dealerChoice = By.xpath("//*[@id=\"dealerList\"]/button[2]");
    By clickOnDealerStepbbContinue = By.xpath("//*[@id=\"__next\"]/div[1]/div/div[3]/div[1]/div[1]/div[2]/div[1]/div");// Clicking on dealer

    public static By getDealerPgVehicleName = By.xpath("//*[@class='label']");



    public DealerStepBeforeBasketPage(WebDriver driver) {
        this.driver = driver;
    }

    public static String getDealerPgVehicleName(WebDriver driver) {
        String vehicleName = null;

        vehicleName = getAnyText(driver,getDealerPgVehicleName);

        return vehicleName;
    }

    @Test(description = "Clicking on Config Continue")
    public void clickDealerbeforeBasketcontinue(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        try {
            // waitForElementClickable(driver, BasketContinue);
            Thread.sleep(2000);
            clickElement(driver, basketContinue, 10);
            System.out.println("Clicked on Dealer Step Before basket Continue");
            NodeORSubNode.log(Status.INFO, "Clicked on Dealer Step Before basket Continue");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver,
                    "Unable to Click on Dealer Step Before basket Continue", e);
        }
    }

    @Test(description = "Navigating into Dealer step before basket Page")
    public void clickSearchPostalCode(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            waitForElementClickable(driver, searchboxforpostalcode, 5);
            waitForPageToLoad(driver,5);
            Thread.sleep(2000);
            if(isElementPresent(driver,goToBasketBtn,2)!=true) {
                NodeORSubNode.log(Status.PASS, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is not present");
            }else{
                NodeORSubNode.log(Status.FAIL, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is present");
                //clickElement(driver, By.id("TESTING_TO_BASKET_BOX_INTERESTEDBOX"), 10);
            }
            waitForPageToLoad(driver,5);
            //Thread.sleep(1000);
            clickElement(driver, searchboxforpostalcode, 2);
            System.out.println("Clicked on Search PostalCode Text Box");
            NodeORSubNode.log(Status.INFO, "Clicked on postalcode search text");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Search Postal Code", e);
        }
    }

    @Test(description = "Clicking on  Search PostalCode Text box")
    public void enterpostalCode(String resultDirectory, String PostalCode, ExtentTest NodeORSubNode) throws Exception {

        try {
            waitForPageToLoad(driver,5);
            Thread.sleep(1000);
            enterData(driver, enterPostalCode, PostalCode, 2);
            System.out.println("Entered PostalCode");
            NodeORSubNode.log(Status.INFO, "Entered PostalCode");
            waitForPageToLoad(driver,10);
            Thread.sleep(1500);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Enter postal code on Search Box ", e);
        }
    }

    @Test(description = "Entered Search PostalCode Text box")
    public void clickOnSearchButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            waitForElementClickable(driver, searchButton, 20);
            //clickElement(driver,searchButton,20);
            //Thread.sleep(2000);
            waitForPageToLoad(driver,5);
            waitForElementClickable(driver,searchButton,10);
            clickUsingJS(driver, searchButton);
            System.out.println("Clicked link of Search button");
            NodeORSubNode.log(Status.INFO, "Click linked of Search button");
            //Thread.sleep(5000);
            waitForPageToLoad(driver,10);
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on link of Search button", e);
        }
    }

    @Test(description = "deleting postal code and verifying absence of default List and go to basket button")
    public void deletePostalCode(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
           // clickElement(driver,By.xpath("//*[@id='search']/div/div/div/div/span"),10);
            clickElement(driver,By.xpath("//*[@data-testid=\"TESTING_LOCATION_CLEAR_ICON\"]"),10);

            NodeORSubNode.log(Status.INFO, "Clicked on cross icon available adjacent to search field");
            Thread.sleep(3000);
            if(isElementPresent(driver,defaultDealer)){
                NodeORSubNode.log(Status.FAIL, "Default Dealer is present");
            }else{
                NodeORSubNode.log(Status.PASS, "Default Dealer is not present");
            }
            if(isElementPresent(driver,goToBasketBtn)){
                NodeORSubNode.log(Status.FAIL, "Go to Basket button is present");
            }else{
                NodeORSubNode.log(Status.PASS, "Go to Basket button is not present");
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "deleting postal code and verifying absence of default List and go to basket button is failed", e);
        }
    }
    public void validateDealer(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            List<String> str = stringSplit(driver.findElement(dealerCityDistance).getText(), "\\R", resultDirectory, NodeORSubNode);
            if (str.get(0) != null) {
                System.out.println("Dealer is available: " + str.get(0));
                NodeORSubNode.log(Status.PASS, "Dealer is available: " + str.get(0));
            } else {
                NodeORSubNode.log(Status.FAIL, "Dealer is not available: " + str.get(0));
            }
            if (str.get(1) != null) {
                System.out.println("City is available: " + str.get(1));
                NodeORSubNode.log(Status.PASS, "City is available: " + str.get(1));
            } else {
                NodeORSubNode.log(Status.FAIL, "City is not available: " + str.get(1));
            }
            if (str.get(2) != null) {
                System.out.println("Distance is available: " + str.get(2));
                NodeORSubNode.log(Status.PASS, "Distance is available: " + str.get(2));
            } else {
                NodeORSubNode.log(Status.FAIL, "Distance is not available: " + str.get(2));
            }

            if (driver.findElement(distanceUnit).getText() != null) {
                System.out.println("distance Unit is available");
                NodeORSubNode.log(Status.PASS, "distance Unit is available");
            } else {
                NodeORSubNode.log(Status.FAIL, "Distance is not available: " + str.get(2));
            }
            if (driver.findElement(address).getText() != null) {
                System.out.println("Address is available");
                NodeORSubNode.log(Status.PASS, "Address is available");
            } else {
                NodeORSubNode.log(Status.FAIL, "Address is not available");
            }
            if (isElementPresent(driver, dealerToolTip)) {
                System.out.println("Dealer Tool Tip is available");
                NodeORSubNode.log(Status.PASS, "Dealer Tool Tip is available");
            } else {
                NodeORSubNode.log(Status.FAIL, "Dealer Tool Tip is not available");
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate Dealer's Details", e);
        }
    }

    public void validateOpeningClosingHours(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, dealerToolTip);
            List<String> str2 = stringSplit(driver.findElement(dealerToolTip).getAttribute("data-tip"), "<br /> ", resultDirectory, NodeORSubNode);
            if (str2.size() == 7) {
                System.out.println("Opening and closing Hours are available for all 7 days");
                NodeORSubNode.log(Status.PASS, "Opening and closing Hours are available for all 7 days");
            } else {
                System.out.println("All Opening and closing Hours are not available for all 7 days");
                NodeORSubNode.log(Status.FAIL, "All Opening and closing Hours are not available for all 7 days");
            }
            for (int k = 0; k < str2.size(); k++) {
                if (str2.get(k).contains("<div style=\"text-align: left\">") && str2.get(k) != null) {
                    str2.get(k).replace("<div style=\"text-align: left\">", "");
                    System.out.println("Opening hour is available: " + str2.get(k).replace("<div style=\"text-align: left\">", ""));
                    NodeORSubNode.log(Status.PASS, "Opening hour is available: " + str2.get(k).replace("<div style=\"text-align: left\">", ""));
                } else if (str2.get(k).contains("<br /></div>") && str2.get(k) != null) {
                    str2.get(k).replace("<br /></div>", "");
                    System.out.println("Opening hour is available: " + str2.get(k).replace("<br /></div>", ""));
                    NodeORSubNode.log(Status.PASS, "Opening hour is available: " + str2.get(k).replace("<br /></div>", ""));
                } else if (str2.get(k) != null) {
                    System.out.println("Opening hour is available: " + str2.get(k));
                    NodeORSubNode.log(Status.PASS, "Opening hour is available: " + str2.get(k));
                } else {
                    System.err.println("Opening hour is not available: " + str2.get(k));
                    NodeORSubNode.log(Status.FAIL, "Opening hour is not available: " + str2.get(k));
                }
            }

            if (isElementPresent(driver, openingHours)) {
                System.out.println("Opening Hour Label is available");
                NodeORSubNode.log(Status.PASS, "Opening Hour Label is available");
            }else{
				NodeORSubNode.log(Status.FAIL, "Opening Hour Label is not available");
			}
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate Dealer's Opening and Closing Hours", e);
        }
    }

    @Test(description = "Checking Default Postal Code option ")
    public void verifyDefaultSelectedDealer(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        try {
            //clickElement(driver,searchButton,20);
            waitForElementClickable(driver, searchButton, 5);
            waitForElementClickable(driver, defaultDealer, 25);
            if(isElementPresent(driver,goToBasketBtn)) {
                NodeORSubNode.log(Status.PASS, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is present");
                //clickElement(driver, By.id("TESTING_TO_BASKET_BOX_INTERESTEDBOX"), 10);
            }else{
                NodeORSubNode.log(Status.FAIL, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is not present");
            }
            if (isElementPresent(driver, defaultDealer, 40)) {
                NodeORSubNode.log(Status.PASS, "Default Dealer is available");
                Assert.assertTrue(isElementPresent(driver, defaultDealer, 40));
                System.out.println("dealer list is clicked and selected by default");
                NodeORSubNode.log(Status.INFO, "dealer list is clicked and selected by default");
                validateDealer(resultDirectory, NodeORSubNode);
                validateOpeningClosingHours(resultDirectory, NodeORSubNode);
            } else {
                NodeORSubNode.log(Status.FAIL, "Default Dealer is not available");
            }

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Default postal code is not selected ", e);
        }
    }

    @Test(description = "Validating Sauvegardez Cette Voiture Link ")
    public void validateLink1(String resultDirectory, ExtentTest NodeORSubNode,String Brand)
            throws InterruptedException {
        try {
            if(Brand.equalsIgnoreCase("AP")||Brand.equalsIgnoreCase("DS")||Brand.equalsIgnoreCase("OV")||Brand.equalsIgnoreCase("AC")){
                linkButton=By.className("linkButton");
            } else{
                linkButton=By.className("linkText");
            }

            if (isElementPresent(driver, linkButton)) {
                System.out.println("Sauvegardez Cette Voiture Link is available");
                NodeORSubNode.log(Status.PASS, "Sauvegardez Cette Voiture Link is available");
                clickElement(driver, linkButton);
                NodeORSubNode.log(Status.INFO, "Clicked on Sauvegardez Cette Voiture Link");
                waitForUrlContains("/login", driver, 10);
                if (driver.getCurrentUrl().contains("/login")) {
                    System.out.println("Navigation to login Page is successful as per the current URL");
                    NodeORSubNode.log(Status.PASS, "Navigation to login Page is successful as per the current URL");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Navigation to login Page is Failed as per the current URL");
                }
                if (getAnyText(driver, loginScreen).contains("Votre voiture sera enregistrée après votre connexion")) {
                    System.out.println("Navigation to login Page is successful as per the Page Title");
                    NodeORSubNode.log(Status.PASS, "Navigation to login Page is successful as per the Page Title");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Navigation to login Page is Failed as per the Page Title");
                }
                driver.navigate().back();
                NodeORSubNode.log(Status.INFO, "Navigated Back");
                waitForUrlContains("/dealers", driver, 10);
            } else {
                NodeORSubNode.log(Status.INFO, "Sauvegardez Cette Voiture Link is not available");
            }

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Sauvegardez Cette Voiture Link could not be validated ", e);
        }
    }

    @Test(description = "Validating PAR TELEPHONE AU : 09 69 39 10 08 Link ")
    public void validateLink2(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        try {
            if (isElementPresent(driver, phoneLink)) {
                System.out.println("Link Text PAR TELEPHONE AU : 09 69 39 10 08 is available");
                NodeORSubNode.log(Status.PASS, "Link Text PAR TELEPHONE AU : 09 69 39 10 08 is available");
                clickElement(driver, phoneLink);
                NodeORSubNode.log(Status.INFO, "Clicked on Contact Phone Link");
                Thread.sleep(5000);
                /*driver.switchTo().alert().dismiss();
                ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(0));*/

                clickEnterUsingRobot(resultDirectory, NodeORSubNode);
                //driver.switchTo().alert().dismiss();
                waitForUrlContains("/dealers", driver, 10);
                Thread.sleep(1000);
            } else {
                NodeORSubNode.log(Status.INFO, "Link Text PAR TELEPHONE AU : 09 69 39 10 08 is not available");
            }

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "PAR TELEPHONE AU : 09 69 39 10 08 Link could not be validated ", e);
        }
    }

    @Test(description = "Validating Contacter votre conseiller Link ")
    public void validateLink3(String postalCode, String email, String name,
                              String phone, String resultDirectory, ExtentTest NodeORSubNode, String Brand)
            throws InterruptedException {
        try {
            if(Brand.equalsIgnoreCase("AP")|| Brand.equalsIgnoreCase("OV") ){
                ContactAdvisorLink=By.xpath("//*[text() = 'Contacter votre conseiller']");
            }else{
                ContactAdvisorLink=By.xpath("(//*[@class='linkText'])[3]");
            }
            if (isElementPresent(driver, ContactAdvisorLink)) {
                if (getAnyText(driver, ContactAdvisorLink).contains("Contacter votre conseiller")||getAnyText(driver, ContactAdvisorLink).contains("ENVOYEZ VOTRE DEMANDE")) {
                    System.out.println("Link Text Contacter votre conseiller is available");
                    NodeORSubNode.log(Status.PASS, "Link Text Contacter votre conseiller is available");
                    clickElement(driver, ContactAdvisorLink, 5);
                    NodeORSubNode.log(Status.INFO, "Clicked on Contact Advisor Link");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Link Text Contacter votre conseiller is not available");
                }
                if (getAnyText(driver, ModelWindow, 15).contains("Vous avez besoin de plus d'informations avant d'acheter ?")) {
                    System.out.println("Model Window Popup is opened");
                    NodeORSubNode.log(Status.PASS, "Model Window Popup is opened");
                    fillNeedMoreInfoForm(postalCode, email, name,
                            phone, resultDirectory, NodeORSubNode);
                    Thread.sleep(1000);
                    System.out.println(getAnyText(driver, SuccessBoxContent, 15));
                    if (getAnyText(driver, SuccessBoxContent, 15).contains("Merci ! Votre demande est bien prise en compte.")
                            ||getAnyText(driver, SuccessBoxContent, 15).contains("Merci ! votre demande est bien prise en compte.")) {
                        System.out.println("Form is submitted successfully");
                        NodeORSubNode.log(Status.PASS, "Form is submitted successfully");
                    } else {
                        NodeORSubNode.log(Status.FAIL, "Form is not submitted successfully");
                    }
                    clickElement(driver, modelPopupCloseBtn,10);
                    NodeORSubNode.log(Status.INFO, "Closed Model Poup up");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Contacter votre conseiller Link could not be validated ", e);
        }
    }

    @Test(description = "Validating Cash Total Price")
    public void validateCashTotalPrice(String resultDirectory, ExtentTest NodeORSubNode, String Brand, String Country)
            throws InterruptedException {
        try {
            Thread.sleep(1000);
            //clickElement(driver, storePrice_link, 10);
            clickUsingJS(driver,storePrice_link);
            NodeORSubNode.log(Status.INFO, "Clicked on Store Price Link");
            Thread.sleep(3000);
            /*if(Brand.equalsIgnoreCase("AP") && Country.equalsIgnoreCase("FR")){
                cashPriceTotalLeft=By.xpath("(//div[@class='cashPrice']//span[@class='formatMoney'] | (//span[@class='formatMoney'])[3])[2]");
            }*/

            waitForElementClickable(driver, cashPriceTotalLeft, 10);
            String cashLeft = getAnyText(driver, cashPriceTotalLeft).substring(0, 6);
            NodeORSubNode.log(Status.INFO, "Vehicle Price Monthly Total in left hand side: " + cashLeft);
            waitForElementClickable(driver, cashPriceTotalLeft, 10);
//            Float summaryPageCashPrice=Float.parseFloat(readFromProperties("currentCashPrice"));
//            Float dealerPageCashPrice=extractFloatFromString(getAnyText(driver, cashPriceTotalLeft).replace(",","."));
//            if(dealerPageCashPrice-summaryPageCashPrice<1){
//                NodeORSubNode.log(Status.PASS,"Config/Summary page cash price "+summaryPageCashPrice+" is same as dealer page cash price");
//            } else{
//                NodeORSubNode.log(Status.FAIL,"Config/Summary page cash price "+summaryPageCashPrice+" is not same as dealer page cash price "+dealerPageCashPrice);
//            }
            //ap &&fr
            Float summaryPageCashPrice=Float.parseFloat(readFromProperties("currentCashPrice"));
            Float dealerPageCashPrice=extractFloatFromString(getAnyText(driver, cashPriceTotalLeft).replace(",","."));
            if(dealerPageCashPrice-summaryPageCashPrice<1){
                NodeORSubNode.log(Status.PASS,"Config/Summary page cash price "+summaryPageCashPrice+" is same as dealer page cash price");
            } else{
                NodeORSubNode.log(Status.FAIL,"Config/Summary page cash price "+summaryPageCashPrice+" is not same as dealer page cash price "+dealerPageCashPrice);
            }
//            if(PaymentMode.equalsIgnoreCase("Finance")){
//                Float summaryPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
//                clickElement(driver,By.xpath("//span[@data-testid='TESTING_VEHICLE_SUMMARY_TITLE_ICON']"));
//
//                Float dealerPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//div[@data-testid='TESTING_VEHICLE_SUMMARY_TOTAL_MONTHLY_PRICE']")));
//                if(summaryPageFinancePrice - dealerPageFinancePrice<1){
//                    NodeORSubNode.log(Status.PASS,"Dealer Page Finance Price" + dealerPageFinancePrice + "is same as Summary page finance price");
//                }else{
//                   NodeORSubNode.log(Status.FAIL,"Dealer Page Finance Price" + dealerPageFinancePrice + "is not same as Summary page finance price");
//                }
            /*String cashRight = getAnyText(driver, cashPriceTotalRight).substring(0, 6);
            NodeORSubNode.log(Status.INFO, "Total amount in right hand side: " + cashRight);
            if (cashLeft.equalsIgnoreCase(cashRight)) {
                NodeORSubNode.log(Status.PASS, "Both cash Prices are same");
            } else {
                NodeORSubNode.log(Status.FAIL, "Both cash Prices are not same");
            }*/
            //Link is changed with save your car, which is a different functionality. New Script has to be written here
            /*String TotalMonthlyPrice = getAnyText(driver, totalMonthlyPrice).replace(",",".").replace(" ","").substring(0, 8);
            if(isElementPresent(driver,fundingDetails)) {
                clickElement(driver, fundingDetails);
                Thread.sleep(3000);
                String FinanceYourVehicle = getAnyText(driver, financeYourVehicleHeader);
                if (FinanceYourVehicle.equalsIgnoreCase("Financez votre vehicule")) {
                    NodeORSubNode.log(Status.PASS, "Finance your vehicle header is validated");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Finance your vehicle header could not be validated");
                }
                String FinanceYourVehicleRentalPayment = getAnyText(driver, financeYourVehicleRental).substring(0, 5).replace(",", "");
                if (Float.parseFloat(TotalMonthlyPrice) - Float.parseFloat(FinanceYourVehicleRentalPayment) < 1) {
                    NodeORSubNode.log(Status.PASS, "Finance Your Vehicle Rental Payment and Total Monthly Price are same");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Finance Your Vehicle Rental Payment and Total Monthly Price are not same");
                }
                clickElement(driver, modelPopupCloseBtn);
                NodeORSubNode.log(Status.INFO, "Closed Model Window");
            }else{
                NodeORSubNode.log(Status.FAIL, "Funding details is not available");
            }*/
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Contacter votre conseiller Link could not be validated ", e);
        }
    }

    public boolean validateDealerChoiceInFeatureSwitch(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        boolean bool=false;
        try {
            Thread.sleep(2000);
            clickElement(driver,By.xpath("//*[@data-testid=\"TESTING_OPEN_FEATURE_SWITCHES_BUTTON\"]"),10);
           // clickElement(driver, By.linkText("Open feature switches"),10);
            NodeORSubNode.log(Status.INFO, "Opened Feature Switches");
            //waitForElementClickable(driver, By.xpath("//*[@id=\"__next\"]/div[1]/div/div[6]/div/div/div[2]/div[1]/div"), 10);
            waitForElementClickable(driver, By.xpath("//*[@class=\"modalWindow__wrap__modalBody\"]//div[contains(@class,\"FeatureSwitcherStyled\")]"), 10);
            Thread.sleep(1000);
            String window= driver.getWindowHandle();
            driver.switchTo().window(window);
            List<WebElement> allswitches = driver.findElements(By.xpath("//*[@class=\"modalWindow__wrap__modalBody\"]//div[contains(@class,\"FeatureSwitcherStyled\")]"));
            for (WebElement ele : allswitches
            ) {
               // waitForElementClickable(driver, By.xpath("//*[@id=\"__next\"]/div[1]/div/div[6]/div/div/div[2]/div[1]/div"), 2);
                waitForElementClickable(driver, By.xpath("//*[@class=\"modalWindow__wrap__modalBody\"]//div[contains(@class,\"FeatureSwitcherStyled\")]"), 2);

                System.out.println("Current Text: " + ele.getText());
                if (ele.getText().contains("is dealer choice enabled")) {
                    System.out.println("is dealer choice enabled");
                    NodeORSubNode.log(Status.PASS, "is dealer choice enabled label is present");
                    if (ele.getText().contains("TRUE")|| ele.getText().contains("true")) {
                        bool=true;
                        System.out.println("is dealer choice enabled: "+bool);
                        NodeORSubNode.log(Status.PASS, "is dealer choice enabled: "+bool);
                        break;
                    } else {
                        System.err.println("is dealer choice enabled: False");
                        NodeORSubNode.log(Status.FAIL, "is dealer choice enabled: False");
                    }
                }
            }

            clickElement(driver, By.xpath("//button[@data-testid='TESTING_CLOSE_MODAL']"));
            NodeORSubNode.log(Status.INFO, "Closed Model Wizard");
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Contacter votre conseiller Link could not be validated ", e);
        }
        NodeORSubNode.log(Status.INFO, "is dealer choice enabled: "+bool);
        return bool;
    }

    @Test(description = "Filling Need More Info Form")
    public void fillNeedMoreInfoForm(String postalCode, String email, String name,
                                     String phone, String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        try {
            Thread.sleep(3000);
            driver.switchTo().defaultContent();
            clickElement(driver, namePrefix, 10);
            enterData(driver, firstName, name);
            NodeORSubNode.log(Status.INFO, "Entered First Name: "+name);
            enterData(driver, lastName, name);
            NodeORSubNode.log(Status.INFO, "Entered Last Name: "+name);
            enterData(driver, phoneNumber, phone);
            NodeORSubNode.log(Status.INFO, "Entered Phone Number: "+phone);
            enterData(driver, CustomerEmail, email);
            NodeORSubNode.log(Status.INFO, "Entered Email Id: "+email);
            enterData(driver, PostalCode, postalCode);
            NodeORSubNode.log(Status.INFO, "Entered Postal Code: "+postalCode);
            clickElement(driver,submitBtn);
            NodeORSubNode.log(Status.INFO, "Clicked on Submit Button");
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Default postal code is not selected ", e);
        }
    }

    @Test(description = "Clicking in Search Postal code Button ")

    public void verifyNumberofDefaultVisibleList(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {

            //(driver,viewMore, 2);
            //System.out.println("Clicked on Search Button");

//            dateCalendar = (List) driver.findElements(obj.Select_Future_Date());
//            int total = dateCalendar.size();
//            for (int index = 0; index < total; index++) {
//                if (dateCalendar.get(index).getAttribute("checked").equals("true")) {
//                    if (!dateCalendar.get(index + 1).isEnabled()) {
//                        System.out.println(dateCalendar.get(index + 1).getText());
//                        System.out.println("The future date is disabled");
//                    }
//                }
//            }
            List<WebElement> defaultDealerlist = driver.findElements(dealerList);
            int total_Dealers= defaultDealerlist.size();
            int count =0;
            for(int index=0; index<total_Dealers; index++){
                System.out.println(getAnyText(driver, By.xpath(String.valueOf(dealerList))));
                count= count+1;
            }
            Assert.assertTrue(isElementPresent(driver,dealerList, 20));
//            int count = 0;
//            int k = 1;
//            //By by= By.xpath("//*[@id=\"dealerList\"]/button["+k+"]");
//
//            //for (int k=1;k<=10;k++) {
//            while ((getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button[" + k + "]"), 15) != null) &&
//                    (getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button[" + k + "]"), 15) != "")) {
//                System.out.println("Current XPath is: " + By.xpath("//*[@id=\"dealerList\"]/button[" + k + "]"));
//                System.out.println(getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button[" + k + "]"), 5));
//                count = count + 1;
//                k = k + 1;
//            }/*
//             * else { break; }
//             */
//            //}

            System.out.print("Number of Visible default search results are: " + count);
			if(count==3){
				NodeORSubNode.log(Status.PASS, "Only 3 Dealers are available by default");
			}else{
				NodeORSubNode.log(Status.FAIL, "3 Dealers are not available by default");
			}
            Assert.assertEquals(3, count);
            /*
             * int k =1; // waitUntilElementIsInvisible(driver,dealerList);
             *
             * for(int i=1; i<=3*k; i++) {
             *
             * for(int j=1;j<=k;j++) {
             *
             * String Visible = defaultDealerlist.get(i).getAttribute("class"); //
             * System.out.println(Visible);
             *
             *
             * if(Visible.equalsIgnoreCase(defaultDealerlist.get(i).getAttribute("class")))
             * { System.out.println(defaultDealerlist.get(i).getText()); } else { count=0;
             * defaultDealerlist.get(0).click();
             * System.out.println(defaultDealerlist.get(i).getText()); } } count++;
             * System.out.println("list of deafault dealers:" + count); }
             *
             * NodeORSubNode.log(Status.INFO, "Clicked on Search Button");
             */
        }
	       /* try {
	        //	String Str = getAnyText(driver,dealerChoice,2);
	        //	System.out.println(Str);
	            List<WebElement> defaultDealerlist = driver.findElements(dealerList);
			//  int size = numberOfElements(driver,dealerList);
			   //System.out.println(size);
	              System.out.println("list of dealers"+ defaultDealerlist.size());
				  for(WebElement l : defaultDealerlist) {
					 boolean bval =false ;
					 if(bval=l.isSelected())
					 {
						 System.out.println("Defalut delaer list postal code is selected" +l.getAttribute("class"));
						 System.out.println(l.getText());
				     }
						 * else { defaultDealerlist.get(0).click();
						 *
						 * }
	          int size = defaultDealerlist.size();

	          System.out.println("list of dealers"+ size);
	          int count=0;

				  for(int i=0;i<=3; i++) {

				  String Visible = defaultDealerlist.get(i).getAttribute("class");
				 // System.out.println(Visible);
				  if(Visible.equalsIgnoreCase(defaultDealerlist.get(i).getAttribute("class"))) {
				  System.out.println(defaultDealerlist.get(i).getText());

				  }

				  else {
					  count=0;
					  defaultDealerlist.get(0).click();
					  System.out.println(defaultDealerlist.get(i).getText());

				  }
				  count++;
				  System.out.println("list of deafault dealers:" + count);
				  }
			//	  System.out.println("list of deafault dealers:" + count);
			 * List<WebElement> autosuggestDealerDetails = driver.findElements(dealerList);
			 * boolean val =false; int count = 0; int i=0; while(i<=3) {
			 *
			 * val= autosuggestDealerDetails.get(i).isSelected();
			 *
			 * if( val = true){
			 *
			 * autosuggestDealerDetails.get(i).click(); count++;
			 * System.out.println(count);
			 *
			 * } else { autosuggestDealerDetails.get(0).click(); }
			 *
			 * break; }

			//	 Assert.assertEquals(true,(((WebElement) dealerChoice).isSelected()));
	        	//Assert.assertEquals(isElementPresent(driver,dealerChoice ),"Postal code of Second one is not Selected.");

				 // clickElement(driver,viewMore, 2);
				  while(getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button["+k+"]"), 5)!=null&&
							getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button["+k+"]"), 5)!="") {
						System.out.println("Current XPath is: "+By.xpath("//*[@id=\"dealerList\"]/button["+k+"]"));
						System.out.println(getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button["+k+"]"), 5));
						count =count+1;
						k=k+1;
					}


	        }*/ catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to select Second Postal code ", e);
        }
    }


    @Test(description = "Verify Number of Default Visible List After Clicking More Link")
    public void verifyNumberofDefaultVisibleListAftClickingMore(String postalCode, String email, String name,
                                                                String phone, String resultDirectory, ExtentTest NodeORSubNode,String Brand, String Country)
            throws InterruptedException {
        try {
            //if (validateDealerChoiceInFeatureSwitch(resultDirectory, NodeORSubNode)) {
                if (isElementPresent(driver, goToBasketBtn)) {
                    NodeORSubNode.log(Status.PASS, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is present");
                    Thread.sleep(2000);
                    //clickElement(driver, By.id("TESTING_TO_BASKET_BOX_INTERESTEDBOX"), 10);
                } else {
                    NodeORSubNode.log(Status.FAIL, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is not present");
                }
                clickElement(driver, viewMore, 2);
                System.out.println("Clicked on View More Button");
                NodeORSubNode.log(Status.INFO, "Clicked on View More Button");
                Assert.assertEquals(6, getSizeofVisibleList(resultDirectory, NodeORSubNode));
                clickElement(driver, viewMore, 2);
                System.out.println("Clicked on View More Button");
                NodeORSubNode.log(Status.INFO, "Clicked on View More Button");
                Assert.assertEquals(9, getSizeofVisibleList(resultDirectory, NodeORSubNode));
                clickElement(driver, viewMore, 2);
                System.out.println("Clicked on View More Button");
                NodeORSubNode.log(Status.INFO, "Clicked on View More Button");
                Assert.assertEquals(12, getSizeofVisibleList(resultDirectory, NodeORSubNode));
                if (isPageScrollable(driver)) {
                    NodeORSubNode.log(Status.PASS, "Page is scrollable");
                    System.out.println("Page is scrollable");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Page is not scrollable");
                    System.err.println("Page is not scrollable");
                }
            //clickElement(driver, By.xpath("//*[@id=\"dealerList\"]/button[2]"), 5);
                clickElement(driver, By.xpath("(//button[contains(@data-testid,'dealer-')])[2]"), 5);
                validateDealer(resultDirectory, NodeORSubNode);
                validateOpeningClosingHours(resultDirectory, NodeORSubNode);
                validateLink1(resultDirectory, NodeORSubNode,Brand);
                if(!Country.equalsIgnoreCase("ES")){
                    validateLink2(resultDirectory, NodeORSubNode);
                }
                validateLink3(postalCode, email, name, phone, resultDirectory, NodeORSubNode,Brand);
                validateCashTotalPrice(resultDirectory, NodeORSubNode,Brand,Country);
                Thread.sleep(5000);
                if (isElementPresent(driver, goToBasketBtn,30)) {
                    NodeORSubNode.log(Status.PASS, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is present");
                    //Thread.sleep(2000);
                    scrollToTop(driver);
                    clickElement(driver, goToBasketBtn, 10);
                    Thread.sleep(10000);
                    waitForUrlContains("/basket",driver,30);
                } else {
                    NodeORSubNode.log(Status.FAIL, "TESTING_TO_BASKET_BOX_INTERESTEDBOX button is not present");
                }
                NodeORSubNode.log(Status.INFO, "Clicked on TESTING_TO_BASKET_BOX_INTERESTEDBOX Button");
                waitForUrlContains("/basket", driver, 20);
                if (driver.getCurrentUrl().contains("/basket")) {
                    NodeORSubNode.log(Status.PASS, "Current URL contains /basket");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Current URL does not contain /basket");
                }
                //Assert.assertEquals(true, driver.getCurrentUrl().contains("/basket"));
            /*}else{
                System.err.println("Dealer Choice In Feature Switch is false");
                NodeORSubNode.log(Status.FAIL, "Dealer Choice In Feature Switch is false");
            }*/
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to select Second Postal code ", e);
        }
    }

    /*
     * List<WebElement> autoDealerDetails = driver.findElements(dealerList);
     * System.out.println("list of dealers after clicking view more"+
     * autoDealerDetails.size());
     */

    public int getSizeofVisibleList(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        int j = 1;
        int cal = 0;
        try {
            /*while (getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button[" + j + "]"), 5) != null &&(
                    getAnyText(driver, By.xpath("//*[@id=\"dealerList\"]/button[" + j + "]"), 5) != "")
            && (driver.findElement(By.xpath("//*[@id=\"dealerList\"]/button[" + j + "]")).isDisplayed()) )
*/          while (getAnyText(driver, By.xpath("(//button[contains(@data-testid,'dealer-')])[" + j + "]"), 5) != null &&(
                    getAnyText(driver, By.xpath("(//button[contains(@data-testid,'dealer-')])[" + j + "]"), 5) != "")
                    && (driver.findElement(By.xpath("(//button[contains(@data-testid,'dealer-')])[" + j + "]")).isDisplayed()) )
            {
                System.out.println("Current XPath is: " + By.xpath("(//button[contains(@data-testid,'dealer-')])[" + j + "]"));
                System.out.println(getAnyText(driver, By.xpath("(//button[contains(@data-testid,'dealer-')])[" + j + "]"), 5));
                cal = cal + 1;
                j = j + 1;
            }

        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get size of visible text ", e);
        }
        System.out.println("List of of the visible dealers is: "+cal);
        NodeORSubNode.log(Status.INFO, "List of of the visible dealers is: " + cal);

        // return the list of dealers
        return cal;
    }
    public List<WebElement> getDealerList(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        List<WebElement> allDealerss = null;
        int numdlr;
        try {

            // waitForElementClickable(driver,dealerList,5);
            allDealerss = driver.findElements(dealerList);
            System.out.println("Got the list of dealers: " + allDealerss.size());
            NodeORSubNode.log(Status.INFO, "Got the list of dealers: " + allDealerss.size());

        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to select Second Postal code ", e);
        }

        // return the liste of dealerss
        return allDealerss;
        // System.out.println("list of Dealers", );
    }

    @Test(description = "Clicking on Dealer Step before basket Continue")
    public void verifyGoToBasketScreenAfterClickingContinue(String resultDirectory, ExtentTest NodeORSubNode)
            throws InterruptedException {
        try {
            waitForUrlContains("/basket", driver, 20);
            Thread.sleep(10000);
            //Assert.assertEquals(true, driver.getCurrentUrl().contains("/basket"));
            if (driver.getCurrentUrl().contains("/basket")) {
                NodeORSubNode.log(Status.PASS, "Go to Basket Screen is verified");
            } else {
                NodeORSubNode.log(Status.FAIL, "Go to Basket Screen is not verified as the current url does not have basket in it: " + driver.getCurrentUrl());
            }
            //clickElement(driver, clickOnDealerStepbbContinue, 2);
            //System.out.println("Clicked on Dealer Step before basket Continue ");
            //NodeORSubNode.log(Status.INFO, "Clicked on Dealer Step before basket Continue");

        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver,
                    "Unable to verify Go to Basket Screen", e);
        }
    }

}
