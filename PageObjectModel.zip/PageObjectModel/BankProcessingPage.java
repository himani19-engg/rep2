package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import solRetailIHM.ProjSpecFunctions.LoginUser;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash.rightPanel_personalInfo;
import static solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash.totalMonthlyPriceIdentificationFloat;
import static solRetailIHM.ProjSpecFunctions.ReprisePXcheckout.FinanceCashRepriseFloat;
import static solRetailIHM.ProjSpecFunctions.ValidateBasket.MonthlyTotalBasketFin;
import static solRetailIHM.ProjSpecFunctions.ValidateOrderCash.orderValidation;
import static solRetailIHM.ProjSpecFunctions.ValidateOrderFinance.checkPayment;
import static solRetailIHM.ScenarioMainClass.ScenarioMain_FR.logger;
import static solRetailIHM.ScenarioMainClass.ScenarioMain_FR.resultDirectory;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class BankProcessingPage extends UniversalMethods {

	private WebDriver driver;
	public static ExtentTest bankProcessing;
	public static ExtentTest threeIcons;

	By CheckBox = By.xpath("//*[@id='cgu']/div/label");
	By CashOrderValidation = By.xpath("//*[@id='main-app-container']/section/article/app-summary/article/section[3]/section/div[2]/button | (//*[@class=\"ng-star-inserted\"])[7]");
	By demandForFinance = By.xpath("//article/section/h1[contains(@class,'title-processing')]");
	By notesForDemandForFinance = By.xpath("//div[contains(@class,'note-processing')]");
	By threeIconsCombined = By.xpath("//*[contains(@class,'description')]//*[contains(@class,'description')]");
	By cashOrderValidation_OV = By.xpath("//button[@data-testid='TESTING_CONTINUE_BUTTON']");


	public BankProcessingPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void getBankProcessingTitle(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,String brand,String Country) throws InterruptedException
   	{
   		try {
			System.out.println("validate Bank Processing");
			if(Country.equalsIgnoreCase("FR")) {
				if (brand.equals("OV")) {
					//clickElement(driver, cashOrderValidation_OV);
					//orderSummaryValidation.log(Status.INFO, "Clicked on cash Order Validation Button");
				} else {
					waitForElementPresent(driver,demandForFinance,50);
					if (isElementPresent(driver, demandForFinance)) {
						logger.log(Status.PASS, "Demand for Finance Page has appeared and the demand context is: ");
						logger.log(Status.INFO, getAnyText(driver,demandForFinance));

						if (getAnyText(driver, notesForDemandForFinance) != null) {
							logger.log(Status.PASS, "Notes for Demand for Bank Processing is available and that is: ");
							logger.log(Status.INFO, getAnyText(driver, notesForDemandForFinance));
						} else {
							logger.log(Status.FAIL, "Notes for Demand for Bank Processing is not available");
						}
					} else {
						logger.log(Status.FAIL, "Demand for Finance Page has not appeared");
					}
				}
			}

		} catch (Exception e){
			   e.printStackTrace();
			catchFailDetails(resultDirectory, checkPayment, driver, "Test Failed while doing Order Validation", e);
		}
   	}

	public void validateThreeIcons(String brand,String Country) throws InterruptedException
	{
		threeIcons = bankProcessing.createNode("validateThreeIcons", "Validation of three icons while Bank Processing");
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			System.out.println("validate three icons");
			if (brand.equals("OV")) {
				//clickElement(driver, cashOrderValidation_OV);
				//orderSummaryValidation.log(Status.INFO, "Clicked on cash Order Validation Button");
			} else {
				if (isElementPresent(driver, threeIconsCombined,10)) {
					bankProcessing.log(Status.PASS, "Icons are present");

					if(driver.findElements(threeIconsCombined).size()==3) {
						bankProcessing.log(Status.PASS, "Total No. of Icons present are: "+3);
						bankProcessing.log(Status.INFO, "Those three Icons present are: ");
						for (WebElement ele:driver.findElements(threeIconsCombined)
							 ) {
							if(ele.getText()!=null){
								bankProcessing.log(Status.INFO, ele.getText());
							}else{
								bankProcessing.log(Status.FAIL, "Icon is not present");
							}
						}
					}else{
						bankProcessing.log(Status.PASS, "Total No. of Icons present are not equal to 3");
					}
				}else{
					bankProcessing.log(Status.FAIL, "Three icons are not present");
				}
			}

		} catch (Exception e){
			e.printStackTrace();
			catchFailDetails(resultDirectory, checkPayment, driver, "Test Failed while doing 3 icon Validation", e);
		}
	}
}