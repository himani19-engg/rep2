package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;

import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CookieAccepter extends UniversalMethods{
	WebDriver driver=null;	
	By contAccepter=By.id("_psaihm_id_accept_all_btn");
	By contRejecter=By.id("_psaihm_id_input_param");
	By sms=By.id("_psaihm_button_param_accept");
	
	public CookieAccepter(WebDriver driver) {
		this.driver=driver;
	}
	
	public void clickContAccepter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			//clickElement(driver, ContSansAccepter);
			waitForElementPresent(driver,contAccepter,40);
			if(isElementPresent(driver,contAccepter)) {
				//waitForElementPresent(driver,contAccepter,40);
				clickUsingJS(driver, contAccepter);
				NodeORSubNode.log(Status.INFO, "Clicked Accepter Btn");
				System.out.println("Clicked Accepter Btn");
			}
		}catch(Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with Clicking on Accepter Btn",e);
		}
		 
	}
	public void clickContRejecter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			//clickElement(driver, ContSansAccepter);
			waitForElementPresent(driver,contRejecter,40);
			if(isElementPresent(driver,contRejecter)) {
				//waitForElementPresent(driver,contAccepter,40);
				clickUsingJS(driver, contRejecter);
				NodeORSubNode.log(Status.INFO, "Clicked Rejecter Btn");
				System.out.println("Clicked Rejecter Btn");
			}
		}catch(Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with Clicking on Rejecter Btn",e);
		}

	}
	public void saveMySettings(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			waitForElementPresent(driver,sms,40);
			if(isElementPresent(driver,sms)) {
				//waitForElementPresent(driver,contAccepter,40);
				clickUsingJS(driver, sms);
				NodeORSubNode.log(Status.INFO, "Clicked save my settings Btn");
				System.out.println("Clicked save my settings Btn");
			}
		}catch(Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Error with Clicking on save my settings Btn",e);
		}
	}
}
