package solRetailIHM.PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class PaymentCashPage extends UniversalMethods {
	WebDriver driver = null;
	
	By CardNumber = By.xpath("//div//input[@name='cardnumber']");
		
	//By ExpiryDate = By.xpath("//*[@id='root']/div/div/input");
	By ExpiryDate = By.name("cc-exp");
	
	By Name = By.name("ccname");
		
	By CVC = By.name("cvc"); 
		
	By Validate = By.xpath("//*[@id='submit-button']"); 
	//By confirm_ES = By.xpath("//*[@id='Submit']"); 
	By confirm = By.id("continue-transaction");
	
	//By orderValidTitle_ES = By.xpath("//h1[contains(text(),'Muchas gracias')]");
	By orderValidTitle_ES = By.xpath("//*[contains(text(),'Muchas gracias')]");
	//By orderValidTitle_FR = By.xpath("//h2/b[contains(text(), 'Ma commande est')]");
	By orderValidTitle_FR = By.xpath("//h1[contains(text(), 'commande est')]");
	By orderValidTitle_FR_AC = By.xpath("//*[contains(text(), 'Nous vous')]");
	By orderValidTitle_FR_OV = By.xpath("//span[contains(text(), 'NOUS VOUS CONFIRMONS')]");
	By orderInvalidTitle= By.xpath("//*[text()='Une erreur est survenue lors du paiement'] | //section[@class='errorPaiement popin']/div/section/section/div/h2 | //span[contains(text(),\"Désolé, votre paiement n'a pas abouti. Merci de vérifier les informations de la carte.\")]");

	
	public boolean getOrderValidTitle(String country, String brand)  throws InterruptedException {
		boolean check = false;
		System.out.println("Getting order validation");
		if(country.equals("ES")) {
			check = isElementPresent(driver, orderValidTitle_ES);
		}
		if(country.equals("FR")) {
			if(brand.equals("OV")) {
				check = isElementPresent(driver, orderValidTitle_FR_OV);
			}else if(brand.equals("AC")) {
				check = isElementPresent(driver, orderValidTitle_FR_AC);
			}else{
				check = isElementPresent(driver, orderValidTitle_FR);
			}
		}
		return check;
	}
		
	public boolean getOrderInvalidTitle()  throws InterruptedException {
		System.out.println("Getting OrderInvalidTitle");
		return isElementPresent(driver, orderInvalidTitle);
	}	
	
	public void EnterCardNumber(String NumCard) throws InterruptedException 
	{
		System.out.println("enter card number");
		waitForPageToLoad(driver,5);
		Thread.sleep(4000);
		waitForUrlContains("hipay",driver,10);
		driver.switchTo().frame(0);
		waitForElementPresent(driver, CardNumber, 30);
		enterData(driver, CardNumber, NumCard );
	}  
    
	public void EnterCardName1() throws InterruptedException, AWTException 
   	{
   		System.out.println("enter card name");
   		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		
		scroling(driver,Name);
		Robot robot = new Robot();
		
		String NAME = "TEST";
		StringSelection stringSelection = new StringSelection(NAME);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);
		
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_DELETE);
	    Thread.sleep(500); 
   	}  
	
	public void EnterCardName() throws InterruptedException, AWTException 
   	{
   		System.out.println("enter card name");
   		String nm = "TEST";
   		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		
		Robot robot = new Robot();
		clickElement(driver, Name);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_DELETE);
		robot.keyRelease(KeyEvent.VK_DELETE);
	    Thread.sleep(500); 
	    enterData(driver, Name, nm);
	    Thread.sleep(500);
   	}
    
    public void EnterExpiryDate(String Date) throws InterruptedException 
	{
		System.out.println("enter Expiry Date");
		driver.switchTo().defaultContent();
		driver.switchTo().frame(2);
		enterData(driver, ExpiryDate, Date);
	}
    
    public void EnterCVC(String CardCVC) throws InterruptedException 
	{
		System.out.println("enter CVC");
		driver.switchTo().defaultContent();
		driver.switchTo().frame(3);
		enterData(driver, CVC, CardCVC );
	}
    
    public void Validate() throws InterruptedException 
	{
		System.out.println("validate");
		driver.switchTo().defaultContent();
		//	clickElement(driver, Validate );
		Actions click= new Actions(driver);
		if(isElementPresent(driver,By.xpath("//*[@id='submit-button']"))) {
			highlightElement(driver, By.xpath("//*[@id='submit-button']"));
			click.moveToElement(driver.findElement(By.xpath("//*[@id='submit-button']"))).click().perform();
		}
	}
    
    public void confirm() throws InterruptedException 
	{
		System.out.println("confirm");
		clickElement(driver, confirm,8);
	}
    
    public PaymentCashPage(WebDriver driver) {
		this.driver = driver;
	}
	
	
		
	
	
}