package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash;
import solRetailIHM.Utilities.UniversalMethods;

import java.text.SimpleDateFormat;
import java.time.LocalDate;

import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeoutException;

import static org.apache.maven.surefire.shared.lang3.ArrayUtils.remove;
import static org.apache.maven.surefire.shared.lang3.ArrayUtils.shift;
import static solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash.PersonnalInfoPg;
import static solRetailIHM.ProjSpecFunctions.ChooseDealerCash.RetailerToBeSelected;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class PersonnalInfoPage extends UniversalMethods {

	private WebDriver driver;
	public static ExtentTest CompareVehicleName;

	public static ExtentTest DateValidations;
	By PersonnalInfo_UK_AC = By.xpath("//*[text()='Personal information']/../div[3]");
	By PersonnalInfo= By.xpath("//*[text()='Identification']/../div[3]");
	
	By LoginButton = By.xpath("//button[@data-testid='TESTING_LOGIN']");
	
	By Email = By.xpath("//*[@data-testid='TESTING_USER_EMAIL']");
	By Phone = By.xpath("(//div[@class='userDetailsRow userDetailsState']/child::span[1])[1]");
    By Initials = By.xpath("//div[@class='userShortName']/span[1]");
    By FirstName = By.name("firstname");
    By LastName = By.name("lastname");
    By Address = By.xpath("(//div[@class='userDetailsRow userDetailsState'])[2]");

	By RetailerAddress = By.xpath("//div[contains(@class,'seller-address')]");

	//By threeIcons = By.xpath("//footer[contains(@class,'assurance assurance')]");
	By threeIcons = By.xpath("//*[contains(@class,'box-img')] | //footer[contains(@class,'assurance assurance')]");
    //By CashEmail = By.id("field_email");
    By CashEmail = By.xpath("(//*[contains(@class,'user-info-container')]//*[@class='info-value'])[3]//span");
    By CashPhone = By.xpath("(//*[contains(@class,'user-info-container')]//*[@class='info-value'])[2]//span");
    By CashName = By.xpath("(//*[contains(@class,'user-info-container')]//*[@class='info-value'])[1]//span");
    By CashAdress1 = By.xpath("(//*[@class='user-info-address']/p)[1]");
    By CashAdress2 = By.xpath("(//*[@class='user-info-address']/p)[2]");
    By CashAdress3 = By.xpath("(//*[@class='user-info-address']/p)[3]");
    By CashAdress = By.id("field_address");
	By CashAdress_OV = By.xpath("//*[@placeholder='Address 1']");
    By CashCity = By.id("field_city");
	By CashCity_OV = By.xpath("//*[@placeholder='City']");
    By CashZipCode = By.id("field_zipCode");
	By CashZipCode_OV=By.xpath("//*[@placeholder='Post code']");
    By CashNIF = By.id("field_nif");
    By validateBtn = By.xpath("(//button[@type='submit'])[2]");
    By validateBtn_FR = By.xpath("(//button[@type='submit'])");
    By guestUser_CashValidate = By.xpath("//button[@type='submit']");
	By guestUser_CashValidate_OV = By.xpath("//button[@data-testid='myDetailsSubmit']");
    By Validate = By.xpath("//button[@data-testid='TESTING_CONTINUE_BUTTON']");
    
    //By CashIdentification = By.xpath("//*[@class='text-div-container ng-tns-c0-0 current-step ng-star-inserted']/p");
	//By CashIdentification = By.xpath("//div[contains(@class, 'breadcrumb-pagination')]/div[1]/p");
    By CashIdentification_FR = By.xpath("//div[contains(@class, 'breadcrumb-pagination')]/div[1]/p | //div[contains(@class, 'DS_TabStepTodo_Light_Desktop')]/div[2]");
	//By CashIdentification_ES = By.xpath("//div[contains(@class, 'breadcrumb-pagination')]/div[2]/p");
	By CashIdentification_ES = By.xpath("(//div[contains(@class, 'breadcrumb-pagination')]/div/p)[1]");
    By CashIdentification_AC = By.xpath("//div[@id='breadcrumb-app']/div/div/div[2][contains(@class, 'current')]");
    
    By EmailEc41 = By.xpath("(//div[@class='info-value'])[3]");
    By continuButton = By.xpath("//*[@type='submit']");
    By continuButtonLogin = By.xpath("(//*[@type='button'])[1]");
    
    By civilityBox = By.id("field_civility");

	By civilityBox_OV = By.xpath("(//*[contains(@class, ' css-1hwfws3')])[2]");
    By firstNameTextbox = By.id("field_firstName");

	By firstNameTextbox_OV=By.xpath("//*[@placeholder='First name']");
    By lastNameTextbox = By.id("field_lastName");
	By lastNameTextbox_OV=By.xpath("//*[@placeholder='Last name']");
    By phoneTextbox = By.id("field_phone");
	By phoneTextbox_OV=By.xpath("//*[@placeholder='Phone']");
    By confirmEmailTextbox = By.id("field_confirmEmail");
	By confirmEmailTextbox_OV = By.xpath("//*[@placeholder='Email confirmation']");
    By enterEmail = By.xpath("//input[@id='field_email']");

	By enterEmailErrorMsg= By.id("field_email_error");
	By enterEmail_OV = By.className("input-section-input");
    By clickContinueAsGuestButton = By.xpath("//button[contains(@class,'form-submit-btn-email-guest')] | //button[contains(@class,'form-submit-btn-login')] | //*[@id='guest']");
    By clickOnModify = By.xpath("//*[contains(@class,'underline')]");
    By cashPriceOnPersonalInfo = By.xpath("//div[contains(@class, 'price-total row')]//span[contains(@class, 'price-total-price')]");
	//By financePriceOnPersonalInfo = By.xpath("//p[@class='prix_mois']/span[2]");
	By financePriceOnPersonalInfo = By.xpath("//div[contains(@class, 'price-total row')]//span[contains(@class, 'price-total-price')]");
	By financePriceOnPersonalInfo_ES = By.xpath("//p[@class='prix_mois']/span");
	By financePriceOnPersonalInfo_AP_ES=By.xpath("//*[@class='price-total-price']");

	By financePriceOnPersonalInfo_DS_ES=By.xpath("//*[@class='price-total-price']");
	By existingAccount_OV = By.xpath("//button[text()='clicking here']");
	By email_OV = By.xpath("//input[@placeholder='Email']|//*[@data-testid='checkout-user-email']");
	By confirmEmail_OV = By.xpath("//input[@placeholder='Email confirmation']|//*[@data-testid='checkout-user-confirmation-email']");
	By firstName_OV = By.xpath("//input[@placeholder='First name']|//*[@data-testid='checkout-user-firstName']");
	By lastName_OV = By.xpath("//input[@placeholder='Last name']|//*[@data-testid='checkout-user-lastName']");
	By phone_OV = By.xpath("//input[@placeholder='Phone'] | //input[@id='field_phone']|//*[@data-testid='checkout-user-phoneNumber']");
	By address_OV = By.xpath("//input[@placeholder='Address 1'] | //input[@id='field_address']|//*[@data-testid='checkout-user-address1']");
	By city_OV = By.xpath("//input[@placeholder='City'] | //input[@id='field_city']|//*[@data-testid='checkout-user-city']");
	By postalCode_OV = By.xpath("//input[@placeholder='Post code'] | //input[@id='field_zipCode']|//*[@data-testid='checkout-user-postalCode']");
	By submitBtn_OV = By.xpath("//div[@class='confirm-section']/button");
 static By getIdentificationPgVahicleName = By.xpath("//*[@class='versionLabel']");

	public PersonnalInfoPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void ContinueButtonClick () throws Exception {
		System.out.println("click continue button");
		clickElement(driver, continuButton);
	}
	
	public void ContinueButtonLogin (String brand, String Country) throws Exception {
		System.out.println("click continue button login");
		isElementPresent(driver,continuButtonLogin,10);
		if(brand.equalsIgnoreCase("AC")&&Country.equalsIgnoreCase("FR")){
			clickUsingJS(driver, continuButtonLogin);
		} else{
		    clickElement(driver, continuButtonLogin,10);
		}
	}
	
	public void ClickOnModifyLink () throws Exception {
		System.out.println("click on modify");
		clickElement(driver, clickOnModify);
	}
	
	public void Address(String Address,String Brand) throws Exception {
		System.out.println("Entered Address");
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, CashAdress_OV, Address,10);
		} else {
			enterData(driver, CashAdress, Address,10);
		}
	}
	
	public void City(String City,String Brand) throws Exception {
		System.out.println("Entered City");
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, CashCity_OV, City);
		} else {
			enterData(driver, CashCity, City);
		}
	}
	
	public void NIF(String NIF) throws Exception {
		System.out.println("Entered NIF");
		enterData(driver, CashNIF, NIF);
	}
	
	public void ZipCode(String ZipCode, String Brand) throws Exception {
		System.out.println("Entered ZipCode");
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, CashZipCode_OV, ZipCode);
		} else{
			enterData(driver, CashZipCode, ZipCode);
		}
	}
	
	public void clickValidate() {
		clickElement(driver, validateBtn);
		System.out.println("Clicked on validate button");
	}

	public void validateRetailerAddress(WebDriver driver,ExtentTest logger ) {
		try {
			String currentRetailer = getAnyText(driver, By.xpath("//section[@class='recap-aside-contener']//section[contains(@class, 'recap-aside-seller')]//article//div[contains(@class,'seller-address')]"));
			String[] linescurrentRetailer = currentRetailer.split("\n");
			linescurrentRetailer = remove(linescurrentRetailer, 1);
			currentRetailer = linescurrentRetailer.toString();
			String RetailerOnSelectionPage = RetailerToBeSelected.replace("Seleccionar", "").replace("SELECCIONAR", "");
			String[] linesOnSelectionPage = RetailerOnSelectionPage.split("\n");
			linesOnSelectionPage = remove(linesOnSelectionPage, 1);
			RetailerOnSelectionPage = linesOnSelectionPage.toString();
			System.out.println(findSimilarity(RetailerOnSelectionPage, currentRetailer));
			if (findSimilarity(RetailerOnSelectionPage, currentRetailer) >= 0.95) {
				logger.log(Status.PASS, "Selected Retailer's Address is matched");
			} else {
				logger.log(Status.FAIL, "Selected Retailer's Address could not be matched");
			}
		} catch (Exception e){
			e.printStackTrace();
			logger.log(Status.FAIL,"Test failed while selecting retailer address");
		}
	}

	public void validatePersonalInformation(WebDriver driver,ExtentTest logger ) {
		String currentPersonalInfo=getAnyText(driver, By.xpath("//app-recap-personal-info//section[contains(@class, 'recap-aside-seller')]//div[contains(@class,'seller-address')]"));
		String[] linescurrentRetailer = currentPersonalInfo.split("\n");
		linescurrentRetailer=remove(linescurrentRetailer,1);
		currentPersonalInfo=linescurrentRetailer.toString();
		String RetailerOnSelectionPage=RetailerToBeSelected.replace("Seleccionar","").replace("SELECCIONAR","");
		String[] linesOnSelectionPage = RetailerOnSelectionPage.split("\n");
		linesOnSelectionPage=remove(linesOnSelectionPage,1);
		RetailerOnSelectionPage=linesOnSelectionPage.toString();
		System.out.println(findSimilarity(RetailerOnSelectionPage,currentPersonalInfo));
		if(findSimilarity(RetailerOnSelectionPage,currentPersonalInfo)>=0.95){
			logger.log(Status.PASS, "Filled personal information is matched");
		}else{
			logger.log(Status.FAIL, "Filled personal information could not be matched");
		}
	}
	
	public void clickValidate_FR() {
		clickElement(driver, validateBtn_FR,8);
		System.out.println("Clicked on validate button");
	}
	
	public void guestUser_ValidateCash(String Brand) throws InterruptedException{
		System.out.println("Clicked on validate");
		if(Brand.equalsIgnoreCase("OV")){
			clickElement(driver, guestUser_CashValidate_OV);
		} else{
			clickElement(driver, guestUser_CashValidate);
		}
	}
	
	public String PersonnalInfo() throws InterruptedException
	{
		return getClassValue (driver, PersonnalInfo);
	}
	
	public String PersonnalInfo_UK_AC() throws InterruptedException
	{
		return getClassValue (driver, PersonnalInfo_UK_AC);
	}
	
	public void Login() throws InterruptedException
	{
		System.out.println("Login");
		clickElement(driver, LoginButton);
	}
	
	public void Validate() throws InterruptedException
	{
		System.out.println("Clicked on continue");
		clickElement(driver, Validate);
	}
	
	public String getCashPriceOnPersonalInfo() throws TimeoutException {
		System.out.println("Getting cash price on personal information page");
		return getAnyText(driver,cashPriceOnPersonalInfo,20);
	}
	
	public String getFinancePriceOnPersonalInfo(String Country,String Brand) {
		String str = null;
		System.out.println("Getting finance price on personal information page");
		try {

			if (Country.equalsIgnoreCase("FR")) {
				str = getAnyText(driver, financePriceOnPersonalInfo);
			} else if (Country.equalsIgnoreCase("ES") && Brand.equalsIgnoreCase("AP")) {
				str = getAnyText(driver, financePriceOnPersonalInfo_AP_ES);
			} else if (Country.equalsIgnoreCase("ES") && Brand.equalsIgnoreCase("DS")) {
				str = getAnyText(driver, financePriceOnPersonalInfo_AP_ES);
			} else {
				str = null;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return str.replaceAll(" ", "").replaceAll("€", "").replaceAll("\\p{Z}", "");
	}
	
	public String getEmail() {
		System.out.println("Getting Email");
		return getAnyText(driver, Email);
	}
	
	public String getEmailEc41() {
		System.out.println("Getting Email EC41");
		return getAnyText(driver, EmailEc41);

	}
	
	public void EmailCash(String EmailId) throws Exception {
		System.out.println("Entered Email");
		enterData(driver, CashEmail, EmailId);
	}

	
	public String getCashIdentification(String Country) {
		System.out.println("check arrive on personnal info page cash");
		if(Country.equalsIgnoreCase("ES")){
			waitForElementClickable(driver,CashIdentification_ES,30);
			return getAnyText(driver, CashIdentification_ES);
		} else{
			waitForElementClickable(driver,CashIdentification_FR,30);
			return getAnyText(driver, CashIdentification_FR);
		}
//		waitForElementClickable(driver,CashIdentification,10);
//		return getAnyText(driver, CashIdentification);
	}
	
	public String getCashIdentification_AC() throws TimeoutException {
		System.out.println("check arrive on personnal info page cash");
		return getAnyText(driver, CashIdentification_AC,200);
	}

	public String getInitials() {
		
		return getAnyText(driver, Initials);

	}
	public String getFirstName() {
		
		return getAnyText(driver, FirstName);

	}
	public String getLastName() {
		
		return getAnyText(driver, LastName);

	}
	public String getPhone() {
		System.out.println("Getting Phone");
		return getAnyText(driver, Phone);

	}
	public String getemailCash() {
		System.out.println("Getting email");
		return getAnyText(driver, CashEmail);

	}
	
	public String getphoneCash() {
		System.out.println("Getting Phone");
		return getAnyText(driver, CashPhone);

	}
	public String getnameCash() {
		System.out.println("Getting Name");
		return getAnyText(driver, CashName);

	}
	
	public String getadressCash() {
		System.out.println("Getting Address");
		String text1 = getAnyText(driver, CashAdress1);
		String text2 = getAnyText(driver, CashAdress2);
		String text3 = getAnyText(driver, CashAdress3);
		String Adress = text1 + text2 + text3;
		System.out.println(Adress);
		return Adress.replaceAll(" ", "");
	}
	
	public String getAddress() {
		System.out.println("Getting Address");
		return getAnyText(driver, Address);

	}

	public String getRetailerAddress(WebDriver driver) throws TimeoutException {
		String str=null;
			str=getAnyText(driver,RetailerAddress,10);
		return str;
	}

	public Boolean validateThreeicons(WebDriver driver) throws TimeoutException {
		Boolean bool=false;
		WebDriverWait wait = new WebDriverWait(driver,50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(threeIcons));
		if(isElementPresent(driver,threeIcons)){
			bool=true;
		}
		return bool;
	}

	public String contextOfThreeicons(WebDriver driver) throws TimeoutException {
		String threeIconContext=null;
		if(isElementPresent(driver,threeIcons,10)){
			threeIconContext=getAnyText(driver,threeIcons);
		}
		return threeIconContext;
	}
	
	public void enterEmail(String EmailId,String Brand) throws Exception {
		System.out.println("Entered email id");
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, enterEmail_OV, EmailId,10);
		} else{
			enterData(driver, enterEmail, EmailId,10);
		}

	}

	public boolean enterEmailError(String resultDirectory,WebDriver driver, ExtentReports extent, ExtentTest logger) throws Exception {
		boolean bool=false;
		System.out.println("Entered email id");
		if(isElementPresent(driver,enterEmailErrorMsg)) {
			String status = driver.findElement(enterEmailErrorMsg).getAttribute("style");
			if (status.contains("hidden")) {
				bool = true;
			} else {
				bool = false;
			}
		}
		/*if(isElementPresent(driver,enterEmailErrorMsg)){
			bool=true;
		}else{
			bool=false;
		}*/
		return bool;
	}
	
	public void ContinueAsGuestButtonClick () throws Exception {
		System.out.println("click continue as guest button");
		clickElement(driver, clickContinueAsGuestButton,10);
	}
	
	public void selectCivility(String Brand) throws Exception {
		if(Brand.equalsIgnoreCase("OV")){
			selectDropdownValueByIndex(driver, civilityBox_OV, 1);
		} else{
			selectDropdownValueByIndex(driver, civilityBox, 1);
		}
	}
	
	public void enterConfirmEmail(String EmailId,String Brand) throws Exception {
		
		System.out.println("Entered confirm email id");
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, confirmEmailTextbox_OV, EmailId);
		} else {
			enterData(driver, confirmEmailTextbox, EmailId);
		}
	}
	
	public void enterFirstName(String firstName,String Brand) throws Exception {
		System.out.println("Entered first name");
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, firstNameTextbox_OV, firstName);
		} else {
		    enterData(driver, firstNameTextbox, firstName);
		}
	}
	
	public void enterLastName(String lastName,String Brand) throws Exception {
		System.out.println("Entered last name");
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, lastNameTextbox_OV, lastName);
		} else{
			enterData(driver, lastNameTextbox, lastName);
		}
	}
	
	public void enterPhone(String phone, String Brand) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		if(Brand.equalsIgnoreCase("OV")){
			enterData(driver, phoneTextbox_OV, phone);
		}else{
			enterData(driver, phoneTextbox, phone);
		}
		System.out.println("Entered phone no");
	}
	
	public void enterPhone_OV(String phone) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, phone_OV, phone);
		System.out.println("Entered phone no");
	}
	
	public void enterEmail_OV(String email) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, email_OV, email);
		System.out.println("Entered email");
	}
	
	public void enterConfirmEmail_OV(String email) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, confirmEmail_OV, email);
		System.out.println("Entered confirm email");
	}
	
	public void enterFirstName_OV(String name) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, firstName_OV, name);
		System.out.println("Entered first name");
	}
	
	public void enterLastName_OV(String name) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, lastName_OV, name);
		System.out.println("Entered last name");
	}
	
	public void enterAddress_OV(String address) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, address_OV, address);
		System.out.println("Entered address");
	}
	
	public void enterCity_OV(String city) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, city_OV, city);
		System.out.println("Entered city");
	}
	
	public void enterPostalCode_OV(String postalCode) throws Exception {
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		enterData(driver, postalCode_OV, postalCode);
		System.out.println("Entered postalCode");
	}

	public void agreeToTermsAndConditions() throws Exception {
		//Agreeing to Terms and Conditions
		waitForPageToLoad(driver,5);
		for(int i=1;i<=3;i++) {
			highlightElement(driver,By.id("toggle-"+i+"-agree"));
			clickElement(driver, By.id("toggle-"+i+"-agree"));
			System.out.println("Agreed to Terms and Condition");
		}
	}
	
	public void clickExistingAccount_OV () throws Exception {
		System.out.println("click continue existing axccount button");
		clickElement(driver, existingAccount_OV);
	}
	
	public void clickSubmitBtn_OV () throws Exception {
		System.out.println("click submit button");
		clickElement(driver, submitBtn_OV);
	}
	@Test(description = "Compare vehicale name string")
	public static void compareVehicaleName(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String VehicleName, String PageName, By by) throws Exception {
		if (driver != null) {
			try {

			CompareVehicleName = logger.createNode("VehicleNameDetails", "Validate vehicle name on Personal Info Page");
			String anotherPageVehicaleName = getAnyText(driver, by);
			/*if (anotherPageVehicaleName.toUpperCase().equalsIgnoreCase(VehicleName.toUpperCase(Locale.ROOT))) {
				CompareVehicleName.log(Status.PASS, "Vehicle name on " + PageName + " " + VehicleName + " is matched with Basket page");
			}*//*
			if("NOUVELLE 208 GT PURETECH 100 S&S BVM6".contains("NOUVELLE 208 5 PORTES")){

			}else {
				CompareVehicleName.log(Status.FAIL, "Vehicle name on " + PageName + " " + VehicleName + " could not be matched with Basket page");
			}*/
			int exist =0;
				String[] list1 = VehicleName.trim().split(" ");
				String[] list2 = anotherPageVehicaleName.trim().split(" ");
				ArrayList<String> strList = new ArrayList<String>(
						Arrays.asList(list1));
				ArrayList<String> strList1 = new ArrayList<String>(
						Arrays.asList(list2));
				boolean boolval = strList.contains(strList1); //returns true because lists are equal
				System.out.println(boolval+" "+strList.get(0)+" "+strList1.get(0));
				for(int i=0; i<=list1.length-1;i++){
					for(int j=0;j<=list2.length-1;j++){
						if((list1[i].toUpperCase()).contains(list2[j].toUpperCase())){
							System.out.println("Exist : "+list1[i]);
							exist=exist+1;
						}
					}
				}
				if(exist>=1)
				{
					CompareVehicleName.log(Status.PASS, "Vehicle name on " + PageName + " " + VehicleName + " is matched with Basket page");

				}else {
					CompareVehicleName.log(Status.FAIL, "Vehicle name on " + PageName + " " + VehicleName + " is not matched with Basket page");

				}
			} catch (Exception e){
				failWithScreenshot("Failed while comparing vehicle name",resultDirectory,driver,extent,logger);
			}

		}
	}


	@Test(description = "Compare Date validations")
	public static void dateValidations(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String Country) throws Exception {
		if (driver != null) {
			DateValidations = logger.createNode("Date Validations Details", "Date Validations Details");
			String dateInFin1 = getAnyText(driver,By.xpath("//*[contains(@class,'availabilityDatesDiv')]//strong[1]"));
			String dateInFin2 = getAnyText(driver,By.xpath("//*[contains(@class,'availabilityDatesDiv')]//strong[2]"));
			Date DateFormat1;
			Date DateFormat2;

			if (Country.equalsIgnoreCase("FR")) {
				Locale localeFi = new Locale("fr", "FR");
				SimpleDateFormat francedateFormat = new SimpleDateFormat("dd MMMMM yyyy", localeFi);
				System.out.println(francedateFormat.parse(dateInFin1));
				DateFormat1 = francedateFormat.parse(dateInFin1);
				DateFormat2 = francedateFormat.parse(dateInFin2);
			} else {
				Locale locSpanish = new Locale("es", "ch");
				SimpleDateFormat spanishdateFormat = new SimpleDateFormat("d 'de' MMMM 'de' yyyy", locSpanish);
				System.out.println(spanishdateFormat.parse(dateInFin1));
				DateFormat1 = spanishdateFormat.parse(dateInFin1);
				DateFormat2 = spanishdateFormat.parse(dateInFin2);
			}
			System.out.println(DateFormat1 + " " + DateFormat2);
			SimpleDateFormat sdfDestination = new SimpleDateFormat("dd-MMMM-yyyy");
			System.out.println("hello"+sdfDestination.format(DateFormat1));
			String d1 = sdfDestination.format(DateFormat1).toString();
			String d2 = sdfDestination.format(DateFormat2).toString();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMMM-yyyy");
			LocalDate date1 = LocalDate.parse(d1, DateTimeFormatter.ofPattern("dd-MMMM-yyyy"));
			LocalDate date2 = LocalDate.parse(d2,formatter);
			System.out.println(date1+ " " +date2);
			if ( date1!= null )
			{
				System.out.println( "Date is not null" );
				DateValidations.log(Status.PASS, "This date is not null");

			}
			else
			{
				System.out.println( "Date is null" );
				DateValidations.log(Status.FAIL, "Date is null");

			}
			if(date2.compareTo(date1) > 0)
			{
				System.out.println("Date 1 comes after Date 2");
				DateValidations.log(Status.PASS, ""+date2+" is greater than "+date1+".");
			}
			else if(date1.compareTo(date2) == 0)
			{
				System.out.println("Both dates are equal");
				DateValidations.log(Status.PASS, ""+date2+ "is equal with "+date1+".");

			}else {

			}
			Year CurrentYear = Year.now();
			System.out.println(CurrentYear);
			String[] dateParts = d2.split("-");
			String day2 = dateParts[0];
			String month2 = dateParts[1];
			String year2 = dateParts[2];
			System.out.println(year2 + " " + month2 + " " + day2);
			Year firstYear = Year.of(Integer.parseInt(year2));
			if(CurrentYear.compareTo(firstYear) == -1) {
				// Compare the two years and print the
				// comparator value
				System.out.println(firstYear.compareTo(CurrentYear));
				DateValidations.log(Status.PASS, ""+firstYear+" year is greater than current year "+CurrentYear+".");

			}else if(CurrentYear.compareTo(firstYear) == 0)
			{
				System.out.println(firstYear.compareTo(CurrentYear));
				DateValidations.log(Status.PASS, ""+firstYear+" year is same with current year "+CurrentYear+".");

			}
			//find diffrence between two dates
			long difference_In_Time = DateFormat2.getTime() - DateFormat1.getTime();
			long difference_In_Days = (difference_In_Time / (1000 * 60 * 60 * 24)) % 365;
			System.out.println(difference_In_Days + "Days");
if(difference_In_Days>14)
{
	DateValidations.log(Status.PASS, "Both Dates has difference more than 14 days");

}else{
	DateValidations.log(Status.PASS, "Both Dates has difference less than 14 days");

}

		}
			}
}