package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import solRetailIHM.ProjSpecFunctions.LoginUser;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.MonthlyTotalBasketCash;
import static solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash.rightPanel_personalInfo;
import static solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash.totalMonthlyPriceIdentificationFloat;
import static solRetailIHM.ProjSpecFunctions.ReprisePXcheckout.FinanceCashRepriseFloat;
import static solRetailIHM.ProjSpecFunctions.ReprisePXcheckout.MonthlyTotalCashRepriseFloat;
import static solRetailIHM.ProjSpecFunctions.ValidateBasket.MonthlyTotalBasketFin;
import static solRetailIHM.ProjSpecFunctions.ValidateOrderCash.orderValidation;
import static solRetailIHM.ProjSpecFunctions.ValidateOrderFinance.checkPayment;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class OrderPage extends UniversalMethods {

	private WebDriver driver;
	public static Float FinancePriceOrderSummary;
	public static ExtentTest orderSummaryValidation;

	public static ExtentTest orderSummaryPageValidations;

	public static String rightPanel_orderSummary;

	By Title_UK = By.xpath("//*[text()='YOUR ONLINE ORDER']");
	By Title_FR = By.xpath("//*[text()='FINALISATION DE VOTRE COMMANDE']");
	By Title_UK_DS = By.xpath("//*[text()='FINALISING YOUR CAR PURCHASE']");

	By MoPId = By.id("__NEXT_DATA__");
	
	By Validate = By.xpath("//*[@data-testid='TESTING_CONTINUE_BUTTON']");
	By ConsentCheckbox = By.className("checkbox-label");
	
	By TitleReview = By.xpath("//*[text()='Finance']/../div[3]");
	By TitleReviewAC = By.xpath("//*[text()='Finance application']/../div[3]");
	
	By DCheckbox = By.xpath("//*[@for='checkDeliveryTime']");
	
	By OrderConfirmation = By.className("subTitle");
	
	By OderRejected = By.xpath("//*[@data-testid='TESTING_CHECKOUT_TITLE']");
	
	By cashTermsofUseCK = By.xpath("//*[@for='optinTermsOfUse']");

	By OrderSummaryCashPrice=By.xpath("//span[contains(@class,'price-total-price')] | //span[contains(@data-testid,'TESTING_TOTAL_CASH_PRICE')]");
	By cashTermsofUseCK_OV = By.xpath("//span[@class='checkbox-content']");
	By CashDeliveryCK = By.xpath("//*[@for='optionTermOfDeliveryDate']");
	By financeOkCheckbox = By.xpath("//*[@for='snedData']");
	By optionCommandCheckbox = By.xpath("//*[@for='optionCommandAnticipation']");
	//By threeIcons = By.xpath("//div[contains(@class,'box-description')]");
	By threeIcons = By.xpath("//*[contains(@class,'box-img')] | //footer[contains(@class,'assurance assurance')]");
	//By CashOrderValidation = By.xpath("//*[contains(@class,'btn-inscription')]");

	By CheckBox = By.xpath("//*[@id=\"cgu\"]/div/label");
	//By CashOrderValidation = By.xpath("//*[@id=\"main-app-container\"]/section/article/app-summary/article/section[3]/section/div[2]/button | (//*[@class=\"ng-star-inserted\"])[7] | //button[contains(@class,\"btn-order\")]");

	By CashOrderValidation = By.xpath("//button[contains(@class,\"btn-order\")]/div");

	By cashOrderValidation_OV = By.xpath("//button[@data-testid='TESTING_CONTINUE_BUTTON']");
	//By financeOrderValidation = By.xpath("//*[starts-with(@class,'1 btn-inscription')]");
	//By financeOrderValidation = By.xpath("//button[contains(@class, 'focus_button btn-inscription')][contains(@class, 'right-arrow-icon')]");
	//By financeOrderValidation = By.xpath("//button[contains(@class, 'btn-inscription')][contains(@class, 'right-arrow-icon')]");
	By financeOrderValidation = By.xpath("//button[contains(@class, 'btn-inscription focus')] | //div[text()=\"Demander un financement\"]");
	By catalanCheckBox = By.xpath("//label[@for='catalan']");
	//By finance_OrderStatus = By.xpath("//section[@class='big-Title']/h1");

	By finance_OrderStatus = By.xpath("//section[@class='big-Title' or 'FirstBloc']/h1");

	public OrderPage(WebDriver driver) {
		this.driver = driver;
	}

    public String OrderRejected() {

		return getAnyText(driver, OderRejected);

	}

	public String OrderConfirmation() {

		return getAnyText(driver, OrderConfirmation);

	}

	public void ValidateCashOrder(String brand,String Country,String PaymentMode) throws InterruptedException
   	{
		orderSummaryValidation = orderValidation.createNode("OrderSummaryRightSidePanelValidation", "Validation of Right Side Panel Context");
   		try {
			System.out.println("validate order cash");
			if (brand.equals("OV")) {
				clickElement(driver, cashOrderValidation_OV);
				orderSummaryValidation.log(Status.INFO, "Clicked on cash Order Validation Button");
			} else {
				if (!((brand.equalsIgnoreCase("AP") || brand.equalsIgnoreCase("AC")||brand.equalsIgnoreCase("DS"))
						//&& Country.equalsIgnoreCase("FR")
						//&& PaymentMode.equalsIgnoreCase("Cash")
						)) {
					clickElement(driver, CheckBox);
					orderSummaryValidation.log(Status.INFO, "Clicked on CheckBox");
				}
				//clickUsingJS(driver,CashOrderValidation);
				if (brand.equalsIgnoreCase("AC")
						//&& Country.equalsIgnoreCase("FR")
						&& PaymentMode.equalsIgnoreCase("Cash")) {
					//CashOrderValidation=By.xpath("//*[contains(text(),'COMMANDER')]");
					CashOrderValidation = By.xpath("//*[contains(@class,'citroen big-btn-with-icon')]");
				} else if(brand.equalsIgnoreCase("DS")
						//&& Country.equalsIgnoreCase("FR")
						&& PaymentMode.equalsIgnoreCase("Cash")){
					CashOrderValidation=By.xpath("(//*[@class='ng-star-inserted'])[9]");
				}
				waitForPageToLoad(driver,30);
				waitForElementPresent(driver,CashOrderValidation,30);
				scrollToTop(driver);
				rightPanel_orderSummary=getAnyText(driver,By.xpath("//div[@class='bloc-recap-detail']"),10);
				orderSummaryValidation.log(Status.INFO, "<=====Right Side Panel Context of Order Summary Screen Starts Here=====>");
				orderSummaryValidation.log(Status.INFO,rightPanel_orderSummary );
				orderSummaryValidation.log(Status.INFO, "<=====Right Side Panel Context of Order Summary Screen Ends Here=====>");
				String diffInText=differenceInText(rightPanel_personalInfo,rightPanel_orderSummary);
				System.out.println("Similarity is: "+findSimilarity(rightPanel_personalInfo,rightPanel_orderSummary));
				if(findSimilarity(rightPanel_personalInfo,rightPanel_orderSummary)==1.0 ||diffInText==""){
					orderSummaryValidation.log(Status.PASS, "Right Side Panel Context of Personal Info Page is same as of Order Summary Screen");
				}else{
					orderSummaryValidation.log(Status.FAIL, "Right Side Panel Context of Personal Info Page is not same as of Order Summary Screen and the difference in context is: "+diffInText);
				}
				if(Country.equalsIgnoreCase("ES") && brand.equalsIgnoreCase("AC"))
				{
				clickElement(driver,By.xpath("//button[contains(@class,'3 btn-inscription btn-order citroen big-btn-with-icon focus_button')]"));
					//clickUsingJS(driver,By.xpath("//button[contains(@class,'3 btn-inscription btn-order citroen big-btn-with-icon focus_button')]"));
				}else if(Country.equalsIgnoreCase("ES") && brand.equalsIgnoreCase("DS"))
				{
					clickElement(driver,By.xpath("//button[contains(@class,'3 btn-inscription btn-order ds big-btn-with-icon focus_button')]"));
					//clickUsingJS(driver,By.xpath("//button[contains(@class,'3 btn-inscription btn-order ds big-btn-with-icon focus_button')]"));
				} else {
					waitForPageToLoad(driver,30);
highlightElement(driver,CashOrderValidation);
					clickElement(driver, CashOrderValidation);
					//clickUsingJS(driver, CashOrderValidation);
				}
				waitForPageToLoad(driver,10);
				orderSummaryValidation.log(Status.INFO, "Clicked on Cash Order Validation Button");
			}
			//Thread.sleep(5000);
			waitForPageToLoad(driver,20);
		} catch (Exception e){
			   e.printStackTrace();
		}
   	}

	public void orderSummaryPageURLVerification(String resultDirectory, WebDriver driver, ExtentReports extent,
								ExtentTest logger,String brand, String Country, String PaymentMode, String Name, String PostalCode, String EmailId) throws InterruptedException {
		Thread.sleep(10000);
		if (brand.equalsIgnoreCase("OV") != true){
			if (driver.getCurrentUrl().contains("order-summary")) {
				logger.log(Status.PASS, "Landed on Order Summary Page Successfully");
			} else {
				logger.log(Status.FAIL, "Could not Land on Order Summary Page");
			}
	}else{
			if (driver.getCurrentUrl().contains("pre-order")) {
				logger.log(Status.PASS, "Landed on Pre-Order Page Successfully");
			} else {
				logger.log(Status.FAIL, "Could not Land on Pre-Order Page");
			}
		}
	}

	public void orderValidationOfSuccessMessage(String resultDirectory, WebDriver driver, ExtentReports extent,
												ExtentTest logger,String brand, String Country, String PaymentMode) {
		String SuccessMessage;
		orderSummaryPageValidations = logger.createNode("OrderSummaryPageValidations", "Validation of Right Side Panel Context");
		if (brand.equalsIgnoreCase("OV") != true) {

			if (Country.equalsIgnoreCase("FR")) {
				waitForElementPresent(driver, By.xpath("//*[contains(text(),\"Félicitations, vous êtes à la dernière\")]"), 50);
				if (isElementPresent(driver, By.xpath("//*[contains(text(),\"Félicitations, vous êtes à la dernière\")]"))) {
					SuccessMessage = getAnyText(driver, By.xpath("//*[contains(text(),\"Félicitations, vous êtes à la dernière\")]"));
					orderSummaryPageValidations.log(Status.PASS, "Success message of order summary page " + SuccessMessage);
				} else {
					orderSummaryPageValidations.log(Status.FAIL, "On order summary page success message is not displayed");
				}


			} else {
				if (isElementPresent(driver, By.xpath("//*[contains(text(),\"Enhorabuena, ya estás más\")]"))) {
					SuccessMessage = getAnyText(driver, By.xpath("//*[contains(text(),\"Enhorabuena, ya estás más\")]"));
					orderSummaryPageValidations.log(Status.PASS, "Success message of order summary page " + SuccessMessage);
				} else {
					orderSummaryPageValidations.log(Status.FAIL, "On order summary page success message is not displayed");
				}

			}
			if (isElementPresent(driver, By.xpath("//*[@for='optinTermsOfUse']"))) {
				orderSummaryPageValidations.log(Status.PASS, "Checkbox is Display on order summary page");
			} else {
				orderSummaryPageValidations.log(Status.FAIL, "Checkbox is not Display on order summary page");
			}
			if (isElementPresent(driver, By.xpath("//*[contains(@class,'btn-order')] | (//*[contains(@class,'focus_button')])[1]"))) {
				orderSummaryPageValidations.log(Status.PASS, "Order Summary button is Display on order summary page");
			} else {
				orderSummaryPageValidations.log(Status.FAIL, "Order Summary button is not Display on order summary page");
			}
		}
	}

	public String getOrderSummaryCashPrice() throws TimeoutException {
		String Str=null;
		Str=getAnyText(driver, OrderSummaryCashPrice,10).replace(" ","").replace(",",".");
		return Str;
	}

	public void validateOrderSummaryMonthlyPricewithIdentificationPrice(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
																		String country, String PaymentMode, String Brand) {
		LoginUser LogincashPr=new LoginUser();
		Float OrderSumPrice;
		try {
			if (country.equals("FR")) {
				//OrderSumPrice= Float.valueOf(getOrderSummaryCashPrice());
				OrderSumPrice= extractFloatFromString(getOrderSummaryCashPrice());
				System.out.println("Monthly Price on Order Summary Screen is: "+OrderSumPrice);
				if(OrderSumPrice!=null && Brand.equalsIgnoreCase("OV")!=true) {
					System.out.println(LogincashPr.cashPriceOnPersonalInfo);
					if ((OrderSumPrice-MonthlyTotalCashRepriseFloat)<=1) {
						logger.log(Status.PASS, "Cash Price on Identification Page is same as on Order Summary Page");
					} else {
						logger.log(Status.FAIL, "Cash Price on Identification Page is not same as on Order Summary Page");
					}
				}else if(OrderSumPrice!=null && Brand.equalsIgnoreCase("OV")==true){
					System.out.println(MonthlyTotalBasketFin);
					if ((OrderSumPrice-MonthlyTotalBasketFin)<=1) {
						logger.log(Status.PASS, "Cash Price on Basket Page is same as on Pre-Order Page");
					} else {
						logger.log(Status.FAIL, "Cash Price on Basket Page is not same as on Pre-Order Page");
					}
				}else{
					logger.log(Status.WARNING, "Cash Price on Identification Page is not Available, hence there is nothing to test");
				}

				if(PaymentMode.equalsIgnoreCase("Finance") && (Brand.equalsIgnoreCase("OV")!=true)){
					FinancePriceOrderSummary=extractFloatFromString(getAnyText(driver,By.xpath("//p[@class='prix_mois']"),10).replace(" ","").replace(",","."));
					if((FinanceCashRepriseFloat-FinancePriceOrderSummary)<=1){
						logger.log(Status.PASS, "Finance Price on Reprise Page "+FinanceCashRepriseFloat+" is same as Finance Price on Order Summary Page "+FinancePriceOrderSummary);
					}else{
						logger.log(Status.FAIL, "Finance Price on Reprise Page "+FinanceCashRepriseFloat+" is not same as Finance Price on Order Summary Page "+FinancePriceOrderSummary);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			catchFailDetails(resultDirectory, logger,driver, "Test Failed while comparing monthly Price on Order Summary screen with Identification Screen",e);
		}
	}


	//verification of Box Image
	public void boxImageVerification(String resultDirectory, WebDriver driver, ExtentReports extent,
								ExtentTest logger,String brand, String Country, String PaymentMode, String Name, String PostalCode, String EmailId) {
		By by1=By.xpath("//div[@class='box-img' ]//figure[@title='BONO DE PEDIDO'] | //div[@class='box-img' ]//figure[@title='VOTRE RENDEZ-VOUS']");
		if (isElementPresent(driver, by1)) {
			highlightElement(driver,by1);
			logger.log(Status.PASS, driver.findElement(by1).getAttribute("title")+" icon appeared");
		} else {
			logger.log(Status.FAIL, driver.findElement(by1).getAttribute("title")+" icon could not be appeared");
		}

		By by2=By.xpath("//div[@class='box-img' ]//figure[@title='PAGO DEL SALDO'] | //div[@class='box-img' ]//figure[@title='PAIEMENT DU SOLDE']");
		if (isElementPresent(driver,by2 )) {
			highlightElement(driver,by2);
			logger.log(Status.PASS, driver.findElement(by2).getAttribute("title")+" icon appeared");
		} else {
			logger.log(Status.FAIL, driver.findElement(by2).getAttribute("title")+" icon could not be appeared");
		}

		By by3=By.xpath("//div[@class='box-img' ]//figure[@title='ENTREGA'] | //div[@class='box-img' ]//figure[@title='LIVRAISON']");
		if (isElementPresent(driver, by3)) {
			highlightElement(driver,by3);
			logger.log(Status.PASS, driver.findElement(by3).getAttribute("title")+" icon appeared");
		} else {
			logger.log(Status.FAIL, driver.findElement(by3).getAttribute("title")+" icon could not be appeared");
		}
	}

	public void closerToCarInfo(String resultDirectory, WebDriver driver, ExtentReports extent,
								  ExtentTest logger,String brand, String Country, String PaymentMode, String Name, String PostalCode, String EmailId) throws InterruptedException, TimeoutException {
		String CloserToCarInfo;
		if(isElementPresent(driver,By.xpath("//article[contains(@class,'section-commande')]"))){
			CloserToCarInfo = getAnyText(driver, By.xpath("//article[contains(@class,'section-commande')]"), 10);
		}else {
			CloserToCarInfo = getAnyText(driver, By.xpath("//div[contains(@class,'summary-note ')]"), 10);
		}
		if (((CloserToCarInfo.contains("@" + brand + "." + Country.toLowerCase() + "-" + Country.toUpperCase() + ".FO.SUMMARY.DEPOSIT.CONFIRM"))
				&& (CloserToCarInfo.contains("@" + brand + "." + Country.toLowerCase() + "-" + Country.toUpperCase() + ".FO.SUMMARY.DEPOSIT.VALID"))
				&& (CloserToCarInfo.contains("@" + brand + "." + Country.toLowerCase() + "-" + Country.toUpperCase() + ".FO.SUMMARY.DEALER.APPOINTMENT")))
				|| (CloserToCarInfo.contains("Enhorabuena, ya est"))){
			logger.log(Status.PASS, "Closer To Car Info is Verified successfully");
		} else {
			logger.log(Status.FAIL, "Closer To Car Info could not be Verified ");
		}
	}

	public void userInfoVerification(String resultDirectory, WebDriver driver, ExtentReports extent,
								  ExtentTest logger,String brand, String Country, String PaymentMode, String Name, String PostalCode, String EmailId) throws InterruptedException {
		//Validating User Info
		String UserAddress;
		if(brand.equalsIgnoreCase("OV")!=true) {
			UserAddress = getAnyText(driver, By.xpath("//div[contains(@class,'bloc-seller')]//app-recap-personal-info//section[contains(@class, 'recap-aside-seller')]"));
		}else{
			UserAddress = getAnyText(driver, By.xpath("//div[@class='summaryContent']//div[@class='summaryRow']//div[@class='left']"));
		}
		System.out.println("User Address is: " + UserAddress);
			if (UserAddress.contains(Name) | UserAddress.contains(EmailId)) {
				logger.log(Status.PASS, "User Info in the third grid is verified");
			} else {
				logger.log(Status.FAIL, "User Info in the third grid could not be verified");
			}
	}

	public void CashTermsofUseCK(String brand) throws InterruptedException, TimeoutException {
   		System.out.println("validate CashTermsofUseCK");
   		if(brand.equals("OV")) {
			scrollIntoView(driver,cashTermsofUseCK_OV);
   			clickElement(driver, cashTermsofUseCK_OV,10);
   		}else if(brand.equalsIgnoreCase("AC")) {
			WebElement label = driver.findElement(By.xpath("//*[@for='optinTermsOfUse']"));
   			new Actions(driver).moveToElement(label, 1 , 1).click().perform();
		   } else {
   			/*WebElement label = driver.findElement(By.xpath("//*[@for='optinTermsOfUse']"));
   			new Actions(driver).moveToElement(label, -450 , 0).click().perform();*/
			//clickElement(driver,By.xpath("//*[@id=\"main-app-container\"]/section/article/app-summary/article/section[3]/section/div[2]/button/div/small"),10);
			//clickElement(driver,By.xpath("//*[@for='optinTermsOfUse']"),10);
			String terms= getAnyText(driver,By.xpath("//*[@for='optinTermsOfUse']"),10);
			//clickElement(driver, By.xpath("//*[@for='optinTermsOfUse']"));
			WebElement TermsOfUse=driver.findElement(By.xpath("//*[@for='optinTermsOfUse']"));
			clickElement(driver,By.xpath("//*[@for='optinTermsOfUse']"));
			/*Actions builder = new Actions(driver);
			builder.moveToElement(TermsOfUse, 2, 2).click().build().perform();*/
			System.out.println("Terms of Use is: "+terms);
   		}
   	}

	public void CashDeliveryCK() throws InterruptedException
   	{
   		System.out.println("validate CashDeliveryCK");
   		clickElement(driver, CashDeliveryCK);
   	}

	public void clickFinanceOkCheckbox() throws InterruptedException{
		if(isElementPresent(driver,financeOkCheckbox,5)) {
			System.out.println("validate finance ok checkbox");
			clickElement(driver, financeOkCheckbox, 8);
		}
   	}

	public void clickOptionCommandCheckbox() throws InterruptedException{
		  if(isElementPresent(driver,optionCommandCheckbox,5)) {
			  System.out.println("validate finance ok checkbox");
			  clickElement(driver, optionCommandCheckbox);
		  }
   	}

	public Boolean validateThreeIcons() throws InterruptedException{
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		Boolean bool=false;
		if(isElementPresent(driver,threeIcons,10)) {
			bool=true;
		}
		return bool;
	}

	public int validateThreeIconsSize() throws InterruptedException{
		int number=0;
		if(isElementPresent(driver,threeIcons,10)) {
			number=driver.findElements(threeIcons).size();
		}
		return number;
	}

	public ArrayList<String> contextOfThreeIcons() throws InterruptedException{
		ArrayList<String> context = new ArrayList<String>();
		for(int i=0;i<validateThreeIconsSize();i++){
			context.add(driver.findElements(threeIcons).get(i).getText());
		}

		return context;
	}

	public void clickOnFinanceOrderValidate(String Country,String Brand, String PaymentMode) throws InterruptedException{
		try {
			System.out.println("validate finance order button");
			if(Country.equalsIgnoreCase("ES")&&Brand.equalsIgnoreCase("AC")&&PaymentMode.equalsIgnoreCase("Finance")){
				financeOrderValidation=By.xpath("//*[contains(text(),'SOLICITAR UNA FINANCIACIÓN')]");
			} else if(Country.equalsIgnoreCase("ES")&&Brand.equalsIgnoreCase("DS")&&PaymentMode.equalsIgnoreCase("Finance")){
				financeOrderValidation=By.xpath("//button[contains(@class, 'btn-inscription')]");
			}

			clickElement(driver, financeOrderValidation,10);
			checkPayment.log(Status.INFO,"Clicked on Finance Order Validation");
		}catch(Exception e){
			checkPayment.log(Status.FAIL,"Error with Clicking on Finance Order Validation");
			checkPayment.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
   	}

	 public void TCCheckbox(WebDriver driver) throws InterruptedException
	   	{
	   		System.out.println("clicked terms and conditions checkbox");
	   		WebElement label = driver.findElement(By.xpath("//*[@for='checkTermsAndConditions']"));
			   highlightElement(driver,By.xpath("//*[@for='checkTermsAndConditions']"));
	   		new Actions(driver).moveToElement(label, -100 , 0).click().perform();
	   	}

	 public void DCheckbox() throws InterruptedException
	   	{
	   		System.out.println("clicked delivery checkbox");
	   		clickElement(driver, DCheckbox);
	   	}

	public String TitleReview(String Brand) throws InterruptedException
	{
		String text;
		if (Brand.equals("AC")) {text = getClassValue (driver, TitleReviewAC);}
		else {text = getClassValue (driver, TitleReview);}
		return text;
	}

	public String getTitle_FR() {

		return getAnyText(driver, Title_FR);

	}

    public String getTitle_UK() {

		return getAnyText(driver, Title_UK);

	}

    public String getTitle_UK_DS() {

		return getAnyText(driver, Title_UK_DS);

	}

    public String getMOp() throws InterruptedException {
		System.out.println("Get MOP ID");
		return getInnerText(driver, MoPId);

	}

    public void Validate() throws InterruptedException
	{
		System.out.println("Validate order");
		scroling(driver, Validate);
	}

    public void ConsentCheckbox() throws InterruptedException
   	{
   		System.out.println("clicked ConsentCheckbox");
   		scroling(driver, ConsentCheckbox);
   	}

    public void clickCatalanCheckBox() throws InterruptedException{
   		System.out.println("Clicked on Catalan checkbox");
   		clickElement(driver, catalanCheckBox);
   	}

    public String getCatalanCheckboxText() throws InterruptedException {
		return getAnyText(driver, catalanCheckBox);
	}

    public String getFinanceOrderStatusText() {
		String str = null;
		try {
			str= getAnyText(driver, finance_OrderStatus);
		}catch(Exception e){
			e.printStackTrace();
		}
		return str;
	}
}