package solRetailIHM.PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class UserAccountPage extends UniversalMethods {
	
	private WebDriver driver;
	
	By OfferGoToMyAccount = By.xpath("//*[@data-testid='TESTING_VIEW_MY_ACC']");
	By ViewSavedOffers = By.xpath("//*[@href='/my-account/my-saves']");
	By ViewSavedOffersDetail = By.xpath("(//*[@class='Collapsible__trigger is-closed'])[1]");
	
	By DealerDisplayAdress = By.xpath("//div[@data-testid='TESTING_DEALER_ADDRESS']"); 
	
	By GotoBasket = By.xpath("//*[@href='/basket']");
	
	By SavedOfferDate = By.xpath("//*[@class='offer_demanded_line']/..");
	
	
	public UserAccountPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String  DealerDisplayAdress() throws InterruptedException {
		String text = getAnyText(driver, DealerDisplayAdress);
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		System.out.println(text);
		return text;

	}
	
	public void GoToBasket() throws InterruptedException
	{
		System.out.println("go to basket");
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollTo(0,0)");
	    Thread.sleep(2000);
		clickElement(driver, GotoBasket);
	}
	
	public void OfferGoToMyAccount() throws InterruptedException
	{
		System.out.println("offer go to my account");
		clickElement(driver, OfferGoToMyAccount);
	}
	
	public void ViewSavedOffers() throws InterruptedException
	{
		System.out.println("view saved offers");
		clickElement(driver, ViewSavedOffers);
	}
	
	public void ViewSavedOffersDetail() throws InterruptedException
	{
		System.out.println("view saved offers detail");
		clickElement(driver, ViewSavedOffersDetail);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,150)");
        Thread.sleep(1000);
	}
	
	public Boolean OfferDate() throws InterruptedException {
		System.out.println("Saved Offer Date"); 
		boolean equal = false;
		String text = getAnyText(driver, SavedOfferDate);
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
	
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String ExpectedText = "DEMANDED'OFFREENVOYÉEle"+ date.format(formatter);
		if (text.equals(ExpectedText)) { equal = true;}
		
		return equal; 
		

	}
	
	
}