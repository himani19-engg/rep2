package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.OR.OrderEmail;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.CheckShareEmailOnBasket.shareEmail;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;
import static solRetailIHM.ProjSpecFunctions.YopMailConfirmationMsg.validateEmail;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class OrderEmailPage extends UniversalMethods {
	public static ExtentTest yopmailEmail;
	WebDriver driver = null;
	OrderEmail obj;
	
	By YopmailCookiesAcception =  By.id("accept");

	By messageContainer=By.xpath("//div[@class='message-container']");
	By YopmailEmailField = By.className("ycptinput");
	By confirmYopmailEmailField = By.id("refreshbut");
	By YopmailRefresh = By.id("refresh");
	By YopmailIframe = By.name("ifmail");
	By YopmailEmailActivationFR = By.xpath("//span[contains(text(),'Activez votre compte My Citroën')]");
	By YopmailEmailActivationIT = By.xpath("//span[contains(text(),'Attiva il tuo Account My Citroën')]");  
	By YopmailEmailActivationES = By.xpath("//*[contains(text(),'La teva comanda està confirmada!') "
				                                  + "or contains(text(), 'LA TEVA COMANDA ESTÀ CONFIRMADA')"
				                                  + "or contanis(text()='¡Tu pedido está confirmado!') "
				                                  + "or contains(text()='TU PEDIDO ESTA CONFIRMADO')"
				                                  + "or contains(text()='MUCHAS GRACIAS POR SU PEDIDO')"
			                                      + "or contains(text()='Restablecer tu contraseña')]");
	By fromEmail = By.xpath("//span[@class='ellipsis b']");
	By emailSubject = By.xpath("//div[@class='fl']/div[1]");
	By deleteYopMail = By.xpath("//span[text()='Delete']");
	By activationButton_ES = By.xpath("//*[contains(text(), 'ACTIV') and contains(text(), 'CUENTA')]");
	//By activationButton_FR = By.xpath("//a[contains(text(), 'ACTIV') and contains(text(), 'COMPTE')]");
	By activationButton_FR = By.xpath("//a[contains(@href, 'click.contact')]|//a[contains(@href,'accounts.verifyEmail')]");
	By activateContinueBtn = By.xpath("//a[@class='btn btn-primary link']|//*[@title='CONTINUE']");
	
	By AcceptCookies = By.id("accept");
	By mySettingsButton = By.xpath("(//a[contains(@href, 'click')])[2]");
	By mySettingsButton_AP = By.xpath("//a[contains(@href, 'click')]");
	By mySettingsButton_OV = By.xpath("//a[contains(@href, 'click')]");
	                                 
	By clickOnArrow = By.xpath("//i[@class='material-icons-outlined f36']");

	public OrderEmailPage(WebDriver driver) {
		this.driver = driver;
		obj = new OrderEmail();
	}
		
	public void AcceptCookies() throws InterruptedException {
		if (driver.findElements((obj.OrderEmail_Loc("AcceptCookies"))).size() != 0) {
			clickElement(driver, obj.OrderEmail_Loc("AcceptCookies"));
		}
		//if (driver.findElements(AcceptCookies).size() != 0) {
		//	clickElement(driver, AcceptCookies);
		//}
	}	

	@Test(description = "Opening Yopmail email")
	public void openYOPEmail(String resultDirectory, ExtentTest NodeORSubNode,ExtentTest logger) {
		if(validateEmail!=null) {
			yopmailEmail = validateEmail.createNode("YopmailEmailPage", "Validate triggered mail via yopmail Email");
		}else if(yopmailEmail!=null){
			yopmailEmail = shareEmail.createNode("YopmailEmailPage", "Validate triggered mail via yopmail Email");
		}else{
			yopmailEmail = logger.createNode("YopmailEmailPage", "Validate Forgot Password via yopmail Email");
		}
		try {
			Thread.sleep(3000);
			driver.get("http://www.yopmail.com/en/");
			waitForUrlContains("yopmail", driver, 10);
			System.out.println("Yopmail is Launched: " + driver.getTitle());
			yopmailEmail.log(Status.INFO, "Yopmail is Launched: " + driver.getTitle());
			if(isElementPresent(driver,messageContainer)){
				if(getAnyText(driver,messageContainer).contains("Access Blocked")){
					yopmailEmail.log(Status.FAIL, "Yopmail is Launched but blocked by Network as Script in running from Local and in Mumbai Office");
					failWithScreenshot("Yopmail is Launched but blocked by Network as Script in running from Local and in Mumbai Office", resultDirectory, driver, yopmailEmail);
					driver.quit();
				}else{
					yopmailEmail.log(Status.PASS, "Yopmail is Launched and it is not blocked by Network");
				}
			}
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Yopmail", e);
		}
		if (isElementPresent(driver, YopmailCookiesAcception, 5)) {
			clickElement(driver, YopmailCookiesAcception, 5);
			yopmailEmail.log(Status.INFO, "Accepted Yopmail cookies");
		}

	}

	@Test(description = "Entering Mail Id")
	public void enterEmailId(String emailId,String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			enterData(driver, YopmailEmailField, emailId);
			NodeORSubNode.log(Status.INFO, "Email is entered");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to enter email",e);
		}
	}
	
	@Test(description = "confirm Yopmail Email")
	public void confirmEmail(String resultDirectory, ExtentTest NodeORSubNode) {
		try {
			//driver.findElement(confirmYopmailEmailField).click();
			clickElement(driver, confirmYopmailEmailField,10);
			waitForUrlContains("https://yopmail.com/en/wm", driver, 30);
			NodeORSubNode.log(Status.INFO, "Clicked on Confirm Yopmail Email");
			System.out.println("Clicked on Confirm Yopmail Email");
		} catch (Exception e) {
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Confirm Yopmail Email",e);
		}
	}
	
	@Test(description = "clicking on refresh")
	public void clickRefresh(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		System.out.println("Refresh email");
		//driver.findElement(YopmailRefresh).click();
		clickElement(driver, YopmailRefresh,15);
		NodeORSubNode.log(Status.INFO, "Clicked on Refresh icon");
		System.out.println("Clicked on Refresh icon");
	}

	@Test(description = "Switching to Mail Frame")
	public void switchToMailFrame() throws InterruptedException {
		//WebDriverWait wait = new WebDriverWait(driver,10);
		//wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(YopmailIframe));
		WebElement mailFrame = driver.findElement(YopmailIframe);
		driver.switchTo().frame(mailFrame);
		//Thread.sleep(1000);
	}

	@Test(description = "Checking if Mail present")
	public boolean verifyEmailText(String country) throws InterruptedException {
		boolean value = false;
		if(country.equals("FR")) {
			value= isElementPresentWithoutWait(driver, YopmailEmailActivationFR);
			} 
	   if(country.equals("ES")) {
		   System.out.println("In ES");
		   value= isElementPresentWithoutWait(driver,YopmailEmailActivationES);
		}
	return value;
	}

	@Test(description = "getting From Email Text")
	public String getFromEmailText(String resultDirectory, ExtentTest NodeORSubNode) {
		String str=null;
		try {
			str= getAnyText(driver, fromEmail,5);
			NodeORSubNode.log(Status.INFO, "Got From Email Text: "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Text from Email",e);
		}

		return str;
	}

	@Test(description = "deleting email")
	public void deleteEmail() {
		//driver.findElement(deleteYopMail).click();
		clickElement(driver, deleteYopMail);
	}

	@Test(description = "clicking On Activation Button")
	public void clickOnActivationButton(String country,String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
		try {
			if (country.equals("ES")) {
				clickElement(driver, activationButton_ES);
			}
			if (country.equals("FR")){
				clickElement(driver, activationButton_FR);
			}
			NodeORSubNode.log(Status.INFO, "Clicked On Activation Button from Yopmail");
			//Thread.sleep(2000);
		}catch(Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click On Activation Button from Yopmail",e);
		}
	}
	
	@Test(description = "clicking On Activation Continue Button")
	public void clickActivateContinueButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException{
		try {
			clickElement(driver, activateContinueBtn,10);
			System.out.println("Clicked On Activation Continue Button form the SOL Website");
			NodeORSubNode.log(Status.INFO, "Clicked On Activation Continue Button form the SOL Website");
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click On Activation Continue Button form the SOL Website",e);
		}
		//Thread.sleep(500);
	}
	
	@Test(description = "clicking On My setting Button")
	public void clickMySettingsButton(String brand) throws InterruptedException{
		if(brand.equals("AP"))
			clickElement(driver, mySettingsButton_AP);
		else if(brand.equals("OV"))
			clickElement(driver, mySettingsButton_OV);
		else
			clickElement(driver, mySettingsButton);
		System.out.println("My setting button  clicked");
		Thread.sleep(1000);
	}
	
	@Test(description = "clicking On Arrow")
	public void clickOnArrow() throws InterruptedException {
		clickElement(driver, clickOnArrow);
		//Thread.sleep(2000);
	}
	
	public String getEmailSubject() {
		return getAnyText(driver, emailSubject);
	}
}
