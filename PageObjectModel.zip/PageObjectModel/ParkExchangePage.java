package solRetailIHM.PageObjectModel;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ParkExchangePage extends UniversalMethods {
    WebDriver driver = null;

    By RepriseButton = By.id("widgetView");
    // Immatriculation
    By ImmatriculationField = By.id("enter-vrm");
    By OverallMileage = By.id("overallMileage");
    By ConfirmImmatriculation = By.id("button-init-immat");
    // Version
    //By VersionField = By.id("version_chosen");
    By versionField = By.id("version");
    By chooseFirtIndexVersion = By.xpath("//*[@id = 'version_chosen'] /div/ul//* [@data-option-array-index = '1']");
    By versionSubmitButton = By.id("button-version");
    By repriseTick = By.xpath("//span[(text()='Reprise') or (text()='Trade in') or (text()='Tasación')]/preceding-sibling::span| //*[contains(text(), 'Tasaci')]/preceding-sibling::span");

    //Personal Information
    By MisterCheckbox = By.xpath("//input[@id = 'civility1']/../span");
    By FirstNameField = By.id("firstName");
    By LastNameField = By.id("lastName");
    By PostalCodeFieldFR = By.id("zipCode");
    By EmailField = By.id("mail");
    By PhoneNumberFieldFR = By.id("phoneNumber");
    By ContactSubmitButton = By.id("button-contact");

    By MarkPXDS = By.xpath("//*[@class ='estimate-title margin-top-reset margin-bottom-double']/../div/p[2]/span|//div[@class='row']/div[2]/div[@class='row']/div/div/p[2]/span[@class='bold']");
    By MarkPX = By.xpath("//div[@class='row']/div[2]/div[@class='row']/div/div/p[3]/span[@class='bold']");
    By ModelPX = By.xpath("//div[@class='row']/div[2]/div[@class='row']/div/div/p[4]/span[@class='bold']");
    By PlatePX = By.xpath("//div[@class='row']/div[2]/div[@class='row']/div/div/p[1]/span[@class='bold']");
    //By PricePX = By.xpath("//*[@class ='reprise-ferme-value']");
    By PricePX = By.xpath("//*[@class ='reprise-ferme-value'] | //*[@class='pxSection_value']/span[2]/span");

    By MarkPXconfig = By.xpath("//*[@data-testid='TESTING_MARK']");
    By ModelPXconfig = By.xpath("//*[@data-testid='TESTING_MODEL']");
    By markAndModelPXConfig = By.xpath("//div[@class='detail']/div[2]/p[1]/span[2]");
    By PlatePXconfig = By.xpath("//div[@class='detail']/div[2]/p[2]/span[2]");
    By PricePXconfig = By.xpath("//p[@class='summaryValue']/span");

    //confirmEstimation
    By ContinueWithEstimationButton = By.id("add_to_cart_estimate");

    //Estimation Message
    By EstimationMessageFR = By.xpath("//*[contains(text(),'Votre estimation provisoire de reprise')]");
    By EstimationMessageUKVX = By.xpath("//*[contains(text(),'Your estimated valuation')]");
    By EstimationMessageUK = By.xpath("//*[contains(text(),'Your provisional recovery estimate')]");
    By EstimationMessageES = By.className("pxEstimateText");
    By submitButton=By.xpath("//*[@type='submit']");

    public ParkExchangePage(WebDriver driver) {
        this.driver = driver;
    }

    public String MarkPX(String Brand) {
        String text = "";
        try {
            System.out.println("Getting MarkPX");
            if (Brand.equals("DS")) {
                text = getAnyText(driver, MarkPXDS, 40);
            } else {
                text = getAnyText(driver, MarkPX, 40);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return text;
    }

    public String getMakeAndModel() {
        String str = "";
        try {
            System.out.println("Getting make and model");
            Thread.sleep(10000);
            str = getAnyText(driver, markAndModelPXConfig, 30);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str;
    }

    public String MarkPXconfig() {
        System.out.println("Getting MarkPXconfig");
        return getAnyText(driver, MarkPXconfig);
    }

    public String ModelPX() throws TimeoutException {
        System.out.println("Getting ModelPX");
        return getAnyText(driver, ModelPX, 150);
    }

    public String ModelPXconfig() {
        System.out.println("Getting ModelPXconfig");
        return getAnyText(driver, ModelPXconfig);
    }

    public String PlatePX() throws TimeoutException {
        System.out.println("Getting PlatePX");
        String plate = getAnyText(driver, PlatePX,30);
        plate = plate.replace("-", "");
        return plate;

    }

    public String PlatePXconfig() {
        String str = "";
        try {
            System.out.println("Getting PlatePXconfig");
            str = getAnyText(driver, PlatePXconfig);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str;
    }

    public String PricePX() {
        int numval;
        String val = "";
        try {
            System.out.println("Getting PricePX");
            waitForElementClickable(driver, PricePX, 30);
            String price = getAnyText(driver, PricePX);
            numval = extractNumericFromString(price);
            val = String.valueOf(numval);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return val;
    }

    public String PricePXconfig() {
        int numval;
        String val = "";
        try {
            System.out.println("Getting PricePXconfig");
            String price = getAnyText(driver, PricePXconfig);
            numval = extractNumericFromString(price);
            val = String.valueOf(numval);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return val;
    }


    public void clickOnRepriseYes() throws InterruptedException, AWTException {
        System.out.println("Clicked on yes for Reprise");
        //clickUsingJS(driver, RepriseButton);
        Actions actions = new Actions(driver);
        //WebElement elementLocator = driver.findElement(By.id("widgetView"));
        WebElement elementLocator = driver.findElement(By.xpath("//*[@data-testid='TESTING_TRADE_IN_SELECTION_YES']"));
        //elementLocator.click();
        actions.click(elementLocator).perform();
//		Robot r=new Robot();
//		r.keyPress(KeyEvent.VK_DOWN);
//		r.keyRelease(KeyEvent.VK_DOWN);
//		Thread.sleep(2000);
//		clickElement(driver, RepriseButton);
        //Thread.sleep(2000);
    }

    public Object[] FillCarImmatriculationAndMileage(String Brand, String Plate) throws InterruptedException {
        Object[] PXinfo = new Object[0];
        try {
            driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
            System.out.println("Fill Reprise Car information");
            waitForElementClickable(driver, ImmatriculationField, 25);
            enterData(driver, ImmatriculationField, Plate);
            enterData(driver, OverallMileage, "25000");
            //driver.findElement(ImmatriculationField).sendKeys(Plate);
            //driver.findElement(OverallMileage).sendKeys("25000");
            clickElement(driver, ConfirmImmatriculation,8);
            Thread.sleep(4000);
            PXinfo = new Object[3];
            PXinfo[0] = MarkPX(Brand);
            PXinfo[1] = ModelPX();
            PXinfo[2] = PlatePX();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PXinfo;
    }

    public void ChooseCarVersion() throws InterruptedException {
        System.out.println("Version was Chosen");
        clickElement(driver, versionField);
        //clickElement(driver, ChooseFirtIndexVersion);
        selectDropdownValueByIndex(driver, versionField, 1);
        clickElement(driver, versionSubmitButton);
        //Thread.sleep(1000);
    }

    public void FeelPersonalInformation(String Brand, String Country, String PaymentMode, String PostalCode, String EmailId, String Name, String Phone, String Plate) throws InterruptedException {
        try {

            System.out.println("Personal Information Entered");
            Thread.sleep(500);
            if ((Brand.equals("AC")) || (Brand.equals("AP"))) {
                String firstName = null;
                String lastName = null;

                if (isElementPresent(driver, MisterCheckbox, 10)) {
                    if (Brand.equals("AC")) {
                        if (isElementPresent(driver, MisterCheckbox)) {
                            clickElement(driver, MisterCheckbox);
                        }
                    }
                    if (Brand.equals("AP") && Country.equals("FR")) {
                        if (isElementPresent(driver, MisterCheckbox)) {
                            clickElement(driver, MisterCheckbox);
                        }
                    }
                    if (Country.equals("FR")) {
                        String[] name = Name.split(" ");
                        if (PaymentMode.equals("Cash")) {
                            firstName = name[1];
                            lastName = name[2];
                        } else {
                            firstName = name[0];
                            lastName = name[1];
                        }
                    }
                    if (Country.equals("UK")) {
                        String[] name = Name.split(" ");
                        firstName = name[1];
                        lastName = name[2];

                    }
                    if (Country.equals("ES")) {
                        String[] name = Name.split(" ");
                        firstName = name[0];
                        lastName = name[1];

                    }

                    driver.findElement(FirstNameField).sendKeys(firstName);
                    driver.findElement(LastNameField).sendKeys(lastName);
                    driver.findElement(PostalCodeFieldFR).sendKeys(PostalCode);
                    driver.findElement(EmailField).sendKeys(EmailId);
                    driver.findElement(PhoneNumberFieldFR).sendKeys(Phone);
                    clickElement(driver, ContactSubmitButton);
                    Thread.sleep(1000);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void ClickOnConfirmEstimation() throws InterruptedException {
        System.out.println("The estimation Is confirmed");
        clickElement(driver, ContinueWithEstimationButton);
        Thread.sleep(1000);

    }

    public boolean checkConfirmationMessage(String Brand, String Country) throws InterruptedException {
        System.out.println("Checking Confirmation Message");
        Thread.sleep(5000);
        boolean present = false;
        if (Country.equals("FR")) {
            present = isElementPresentWithoutWait(driver, EstimationMessageFR);
        }
        if ((Country.equals("UK")) && (Brand.equals("VX"))) {
            present = isElementPresentWithoutWait(driver, EstimationMessageUKVX);
        }
        if ((Country.equals("UK")) && (!Brand.equals("VX"))) {
            present = isElementPresentWithoutWait(driver, EstimationMessageUK);
        }
        if (Country.equals("ES")) {

            if (isElementPresentWithoutWait(driver, EstimationMessageES)) {
                if (getAnyText(driver, EstimationMessageES).trim().equalsIgnoreCase("Tasación del vehículo"))
                    present = true;
                else
                    present = false;
            }
        }
        return present;
    }

    public String getRepriseTickAttribute(String name) {
        String attribute = "";
        try {
            attribute = getAttributeValue(driver, repriseTick, name,10);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return attribute;
    }
    public void clickSubmitButton(){
        try{
            clickElement(driver,submitButton);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}