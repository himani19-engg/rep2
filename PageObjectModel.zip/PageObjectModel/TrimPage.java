package solRetailIHM.PageObjectModel;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.CheckNotificationForm;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class TrimPage extends UniversalMethods {
    WebDriver driver = null;

    //By openFeatureSwitch = By.linkText("Open feature switches");
    By openFeatureSwitch =By.xpath("//*[@data-testid='TESTING_OPEN_FEATURE_SWITCHES_BUTTON']");
    By eachSwitch = By.xpath("//*[@class=\"featureSwitches__wrapper\"]/div");

    By closeModelWindow = By.xpath("//div[@class='modalWindow__wrap__header']/button[@data-testid='TESTING_CLOSE_MODAL']");
    //By contactSalesman = By.xpath("//div[@class='links']/button/span[@class='label']");
    By contactSalesman=By.xpath("//*[@data-testid='TESTING_CONFIG_CONTACT_SALESMAN_LINK']/span[1]");
    //By SubTitle = By.className("subTitle");
    By SubTitle=By.xpath("//*[@data-testid='TESTING_SELECTOR_FILTERS_OPEN_BUTTON']/following-sibling::span");
    //By topContinueBtn = By.xpath("//div[@class='wrapper']/div[@class='buttonSection']/div[@class='button']");
    By topContinueBtn=By.xpath("//*[@data-testid='TESTING_TO_CONFIG_BOX_ORDERPANEL']");
    //By catalogPriceTxt = By.xpath("//*[@class='catalogPrice']");
    By catalogPriceTxt=By.xpath("//*[@data-testid='TESTING_SELECTOR_CASH_PRICE']/parent::div/preceding-sibling::div|//*[@class='heading']");
    //By bottomContinueBtn = By.xpath("//div[@class='btn-section']/div/button[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX']");
    By bottomContinueBtn = By.xpath("//*[@data-testid='TESTING_TO_BASKET_BOX_INTERESTEDBOX']");
    //By TrimTitle = By.className("trimTitle");
    By TrimTitle =By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_SPECK_PACK_0']");
    //By exteriorViewIcon = By.xpath("//div[@class='toggle']/button/span[starts-with(@class,'ext')]");
    By exteriorViewIcon = By.xpath("//*[@data-testid='TESTING_IMAGE_SECTION_EXTERIOR_SWITCHER']");
    By nextCarButtonExt = By.xpath("//div[@class='ext']/div/div/button[@aria-label='Go to next slide']");

    By currentcarExt = By.xpath("//div[@class='ext']/div/div/ul[@class='react-multi-carousel-track ']/li[4]/div[@class='image-wrapper']");

    By nextCarButtonInt = By.xpath("//div[@class='int']/div/div/button[@aria-label='Go to next slide']");
    By currentcarInt = By.xpath("//div[@class='int']/div/div/ul[@class='react-multi-carousel-track ']/li[4]/div[@class='image-wrapper']");

    //By interiorViewIcon = By.xpath("//div[@class='toggle']/button/span[starts-with(@class,'int')]");
    By interiorViewIcon = By.xpath("//*[@data-testid='TESTING_IMAGE_SECTION_INTERIOR_SWITCHER']");
    //By defaultSelectedRadioButton = By.xpath("//*[@class='trims ']/div/button[@class='trim isSelected ']/div[@class='inner']/span[@class='trimTitle']/span/span[@class='selected']");
    By defaultSelectedRadioButton=By.xpath("//*[contains(@data-testid,'TESTING_TRIM_ITEM_SPECK_PACK')]/span/span");
    //By allTrims = By.xpath("//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']");
    By allTrims=By.xpath("//*[contains(@data-testid,'TESTING_TRIM_ITEM_SPECK_PACK')]/parent::div");
    By IndividualTrimTitle = By.xpath("(//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/span[@class='trimTitle'])");

    By trimContentTitle = By.xpath("//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/div[@class='trimContent title']");
    By BasketButton = By.xpath("//*[@id = 'TESTING_BASKET']/ span");

    By Description = By.xpath("//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/span[@class='trimDescription']");
    By Price = By.xpath("//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/span[@class='trimPrice']");

    //By StickyBarCashPrice = By.xpath("//*[@class='priceSection']/div[@class='price ']/div[@class='cashPrice ']");
    By StickyBarCashPrice = By.xpath("//*[@data-testid='TESTING_SELECTOR_CASH_PRICE']");
    //By StickyBarMonthlyPrice = By.xpath("//*[@class='priceSection']/div[@class='price ']/div[@class='monthlyPrice']/div[@class='price']/span/span[@class='formatMoney']");
    By StickyBarMonthlyPrice=By.xpath("//*[@data-testid='TESTING_SELECTOR_FINANCE_PRICE']/span");
    //By LinkSectionTitle = By.xpath("//*[@class='links-section']/div[@class='section']/span[@class='title'] | (//span[@class='title'])[2]");
    //By LinkSectionTitle=By.xpath("//*[@data-testid='TESTING_SELECTOR_FILTERS_OPEN_BUTTON']/parent::div/span[1]");
    By LinkSectionTitle=By.xpath("//*[@data-testid='TESTING_SELECTOR_TRIM_NAME']");
    By LinkSectionElements = By.xpath("//*[@class='links-section']/div[@class='section']/div[@class='elements']");
    //By LinkSectionByPhone = By.xpath("(//*[@class='links-section']/div[@class='section']/div[@class='elements']/div[@class='link'])[1] | //*[@class='needHandSection_phone']");
    By LinkSectionByPhone =By.xpath("//*[@data-testid='TESTING_NEED_A_HAND_SECTION_PHONE_LINK']");
    //By ContactYourAdvisor = By.xpath("(//*[@class='links-section']/div[@class='section']/div[@class='elements']/div[@class='link'])[2]/div/button | //*[@class='modalLink']/span");
    By ContactYourAdvisor=By.xpath("//*[@data-testid='TESTING_CONFIG_CONTACT_SALESMAN_LINK']/span|//*[@class='desktopContactSection']/span[1]");
    //By legalText= By.xpath("//*[@class='links-section']/div[@class='section']/div[@class='elements']/p[@class='legal-text']/span");

    //By seeTheMainEquipmentLink = By.xpath("(//div[@class='trims ']/div/button[@class='trim  ']/div/span[@class='trimFeature'])[1]");
    By seeTheMainEquipmentLink = By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_FEATURES_OPEN_LINK_0']");
    //By modelHeader = By.xpath("//div[@id='modal_header']/span[@class='modalSidebar__wrap__header__title']");
    //By modelHeader=By.xpath("(//*[@data-testid='TESTING_CLOSE_MODAL'])[2]/parent::div/span");
    By modelHeader=By.xpath("//*[@data-testid='TESTING_FEATURES_MODAL_TITLE']");
    //By modelTitle = By.xpath("//div[@id='modal_body']/div/div[@class='title']");
    By modelTitle = By.xpath("//*[@data-testid='TESTING_FEATURES_MODEL_PACK']");
    //By keyTitle = By.xpath("//div[@class='keys']/span[@class='label']");
    By keyTitle=By.xpath("//*[@data-testid='TESTING_FEATURES_MODEL_CATEGORIES']/span");
    //By categories = By.xpath("//div[@class='keys']/div[@class='categories']");
    By categories = By.xpath("//*[contains(@data-testid,'TESTING_TRIM_FEATURES_CATEGORY_TITLE')]/parent::div");
    //By categoriesNum = By.xpath("//div[@class='keys']/div[@class='categories']/span");
    By categoriesNum = By.xpath("//*[contains(@data-testid,'TESTING_TRIM_FEATURES_CATEGORY_TITLE')]");
    By grids = By.xpath("//div[@class='modalSidebar__wrap__modalBody withPadding']/div/div");

    By gridsStd = By.xpath("//div[@class='configurations']/div[@class='configuration']");

    By allOptions = By.xpath("//div[@class='configurations']/div/div");
    By eachCategory = By.xpath("(//div[@class='keys']/div[@class='categories']/span)[1]");
    By eachEquipmentExceptStandardEquipments = By.xpath("(//div[@id='modal_body']/div/div)[1]");
    //By engineLabel = By.xpath("//div[@class='engines']/span[@class='label']");
    By engineLabel = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_ENGINE']");
    By engineMainEqp = By.id("engine");

    By interiorMainEqp = By.id("interior");
    By MainEqp = By.xpath("//div[@class='interiors']/span[@class='label' and text()='Principaux équipements']");
    //By MainEqp = By.xpath("//*[text()='Principaux équipements']");
    By colorsMain = By.xpath("//div[@class='colors']");
    By interiorsMainEqp = By.xpath("//div[@class='interiors'][1] | //*[text()='Intérieurs']");

    //By engineConfiguration = By.xpath("//div[@class='engines']/div[@class='configurations']");
    By engineConfiguration = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_ENGINE']/parent::span/following-sibling::div");
    //By comfortConfiguration = By.xpath("(//div[@class='configurations']/div[@class='configuration']/div[@class='options'])[1]");
    By comfortConfiguration = By.xpath("//span[contains(@data-testid,'TESTING_TRIM_FEATURES_FEATURE_CATEGORY')][1]/parent::div/div");
    By securityConfiguration = By.xpath("(//div[@class='configurations']/div[@class='configuration']/div[@class='options'])[2]");

    By aestheticConfiguration = By.xpath("(//div[@class='configurations']/div[@class='configuration']/div[@class='options'])[3]");

    By audioCommunicationConfiguration = By.xpath("(//div[@class='configurations']/div[@class='configuration']/div[@class='options'])[4]");

    By RimsConfiguration = By.xpath("(//div[@class='configurations']/div[@class='configuration']/div[@class='options'])[5]");
    //By MainEquipmentLabel = By.xpath("(//div[@class='interiors']/span[@class='label'])[1]");
    By MainEquipmentLabel = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_INTERIOR']");
    //By MainEquipmentConfiguration = By.xpath("(//div[@class='interiors']/div[@class='configurations'])[1]");
    By MainEquipmentConfiguration = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_INTERIOR']/parent::div/div");
    //By colorsLabel = By.xpath("//div[@class='colors']/span[@class='label']");
    By colorsLabel = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_COLOR']");
    //By colorsConfiguration = By.xpath("//div[@class='colors']/div[@class='configurations']/div/button");
    By colorsConfiguration = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_COLOR']/parent::div/div/div/button");
    //By interiorLabel = By.xpath("//div[@class='interiors']/span[@class='label']");
    By interiorLabel = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_INTERIOR']");
    //By interiorConfiguration = By.xpath("//div[@class='interiors']/div[@class='configurations']");
    By interiorConfiguration = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_INTERIOR']/parent::div/div");
    //By seeStandardEquipment = By.xpath("//div[@id='feature']/span[@class='title']");
    By seeStandardEquipment = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_FEATURE']");
    //By descriptionStd = By.xpath("//div[@id='feature']/p[@class='description']");
    By descriptionStd = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_FEATURE']/following-sibling::p");
    //By allCategoriesStd = By.xpath("//div[@id='feature']/div[@class='categories']");
    By allCategoriesStd = By.xpath("//*[@data-testid='TESTING_TRIM_FEATURES_FEATURE_CATEGORY_ALL']/parent::div");
    By eachCategoryStd = By.xpath("//div[@id='feature']/div[@class='categories']/span | (//*[@class='categories'])[2]/button");

    By comfortText = By.xpath("//div[@class='configuration']/span[@class='label' and (text()='Confort')]");
    //By comfortLabel = By.xpath("(//div[@class='configurations']/div[@class='configuration']/span[@class='label'])[1]");
    By comfortLabel = By.xpath("(//span[contains(@data-testid,'TESTING_TRIM_FEATURES_FEATURE_CATEGORY')])[10]");
    //By securityLabel = By.xpath("(//div[@class='configurations']/div[@class='configuration']/span[@class='label'])[2]");
    By securityLabel = By.xpath("(//span[contains(@data-testid,'TESTING_TRIM_FEATURES_FEATURE_CATEGORY')])[11]");
    By securityText = By.xpath("//div[@class='configuration']/span[@class='label' and (text()='Sécurité')]");

    By aestheticLabel = By.xpath("(//div[@class='configurations']/div[@class='configuration']/span[@class='label'])[3]");

    By AestheticText = By.xpath("//div[@class='configuration']/span[@class='label' and (text()='Esthétique')]");

    By electricalEnv=By.xpath("//div[@class='configuration']/span[@class='label' and (text()='Environnement électrique')]");
    By audioCommLabel = By.xpath("(//div[@class='configurations']/div[@class='configuration']/span[@class='label'])[4]");

    By rimsLabel = By.xpath("(//div[@class='configurations']/div[@class='configuration']/span[@class='label'])[5]");

    By rimsText =By.xpath("//div[@class='configuration']/span[@class='label' and (text()='Jantes')]");

    By multiMediaAndNavigationText= By.xpath("//div[@class='configuration']/span[@class='label' and (text()='Multimédia et Navigation')]");

    By closeModel = By.xpath("(//button[@data-testid='TESTING_CLOSE_MODAL'])[2]");
    By selectedCategoryStd = By.xpath("//div[@id='feature']/div[@class='categories']/span[@class='selected']");
    By eachCategoryLRStd = By.xpath("(//div[@id='feature']/div[@class='configurations']/div)[1]");
    By eachCategoryLabelStd = By.xpath("(//div[@id='feature']/div[@class='configurations']/div[@class='configuration']/span[@class='label'])[1]");
    By eachCategoryOptionStd = By.xpath("(//div[@id='feature']/div[@class='configurations']/div[@class='configuration']/div[@class='options'])[1]");

    //By OfferPaymentModelTexts = By.xpath("//*[@id=\"__next\"]/div[1]/div[2]/div[4]/div/div[2]/div[4]");
    //By OfferPaymentModelTexts=By.xpath("//*[@data-testid='TESTING_LEGAL_TEXT']/parent::div/parent::div/following-sibling::div");
    By OfferPaymentModelTexts=By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_KEYWORDS']");
    By logoLink = By.xpath("//a[@data-testid='TESTING_LOGO_BTN']");
    //By CarListe = By.xpath("//div/p[@class='aprDescription']");
    By carList_ES = By.xpath("//button[contains(@class, 'aprDescription')]");
    //By carList_FR = By.id("infoCircle");
    By carList_FR = By.xpath("//div[contains(@class, 'infoIcon')]");
    //By cash_Price = By.xpath("//*[@class=\"priceSection\"]//div[@class=\"price \"]//div[@class=\"cashPrice \"]//span[@class=\"formatMoney\"]");
    By cash_Price = By.xpath("//*[@data-testid='TESTING_SELECTOR_CASH_PRICE']/span[1]/span");
    //By monthlyPrice = By.xpath("//div[@class='monthlyPrice']//span[@class='formatMoney']");
    By monthlyPrice = By.xpath("//div[@data-testid='TESTING_SELECTOR_FINANCE_PRICE']/span/span");
    By monthlyPriceInformationPage = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_3_1']");
    //By monthlyPriceInformationPage_ES = By.xpath("//span[(text()='CUOTA MENSUAL') or (text()='CUOTA MENSUAL FINANCIERA') or (contains(text(), 'Cuota mensual'))]/../following-sibling::div/span");
    By monthlyPriceInformationPage_ES = By.xpath("//*[@data-testid='TESTING_FINANCE_PRICE_1_7']");
    By closeButton = By.xpath("//button[@data-testid='TESTING_CLOSE_MODAL'][contains(@class, 'closeBtn')]");
    By PriceText = By.xpath("//*[@class = 'price']");
    By NextButton = By.xpath("//*[@data-testid='TESTING_NEXT_BTN']");
    By trimPageHeader = By.xpath("//h1[@class='content-title']");
    By vehicleName = By.xpath("//div/h3");
    //By resetButton = By.xpath("//button[@class='reset']");
    By resetButton = By.xpath("//*[@data-testid='TESTING_FILTER_RESET_BUTTON']");
    //By validateBtn = By.xpath("//button[@class='validate']");
    By validateBtn = By.xpath("//*[@data-testid='TESTING_FILTER_VALIDATE_BUTTON']");
    By filterBtn = By.xpath("//button[@class='filter']");
    //By filterButton=By.xpath("//*[@class=\"trimBenefitsContainer\"]/following-sibling::button");
    By filterButton=By.xpath("//*[@data-testid='TESTING_SELECTOR_FILTERS_OPEN_BUTTON']");
    By retourBtn = By.xpath("//button[@data-testid='TESTING_BACK']");
    //By legalText = By.xpath("//p[@class='legal-text']");
    By legalText = By.xpath("//*[@data-testid='TESTING_LEGAL_TEXT']");
    public static By financeVehicle = By.xpath("//span[@class='trimPrice']//descendant::span[contains(@class, 'monthly')]");

    //Values on Trim page
    By entradaPrice = By.xpath("//div[@class='priceNotice']//span[@class='amount'][1]");
    //By prixCatalogPrice = By.xpath("//span[@class='catalogPriceAmount']/span");
    By prixCatalogPrice = By.xpath("//*[@class='catalog-price-title']/span[@class='formatMoney']");
    //By prixCatalogPrice_FR_DS = By.xpath("//div[@class='cashPrice']/span/span");
    By prixCatalogPrice_FR_DS = By.xpath("//*[@class='catalog-price-title']/span[@class='formatMoney']");
    By promotionalAmount = By.xpath("//span[@class='promotionalText']/following-sibling::span[@class='amount']");
    By promotionalText = By.xpath("//span[@class='promotionalText']/span[2]");
    By colorText = By.xpath("(//div[@class='colorText']/span)[1]");
    By engineText = By.xpath("(//div[@class='engineText']/span)[1]");
    By noOfVehicles = By.xpath("//div[contains(@class, 'equipmentSubtitle')]");

    //Values on Trim Info popup
    By cashPrice_InfoPopup = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_1_2']");
    By entradaPrice_InfoPopup_ES = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_1_3']");
    By entradaPrice_InfoPopup_FR = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_2_1']");
    By TAE_InfoPopup = By.xpath("//span[text()='TAE']/../following-sibling::div/span");
    By prixCatalogPrice_InfoPopup = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_1_1']");
    By promotionalAmount_InfoPopup = By.xpath("//*[@data-testid ='TESTING_FINANCE_PRICE_2_1']");
    //By infoPopupBtn_FR = By.xpath("//*[contains(@aria-labelledby, 'svgImgSeeFinanceDetails')]");
    By infoPopupBtn_FR = By.xpath("//*[@data-testid='TESTING_SELECTOR_FINANCE_PRICE_INFO_ICON']/div/span");
    //By infoPopupBtn_ES = By.xpath("//div[@class='apr']/button");
    By ErrorPopup = By.className("errorContainer");

    //By infoPopupBtn_ES = By.xpath("//*[contains(text(), 'Ejemplo TAE') or contains(text(), 'Ejemplo Renting')]");
    By infoPopupBtn_ES = By.xpath("//*[@data-testid='finance-detail-text']");
    By notifMsg = By.xpath("//div[@id='modal_body']");

    // Range
    By rangeStartPrice = By.xpath("//span[@data-testid='TESTING_START_RANGE']/span");
    By rangeEndPrice = By.xpath("//span[@data-testid='TESTING_END_RANGE']/span");
    By rangeCashPriceList = By.xpath("//*[contains(@data-testid, 'TESTING_TOTAL_PRICE')]");

    //Energy
    //By energyFilter = By.xpath("//div[@class='energy']/div//label");
    By energyFilter = By.xpath("//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_FUEL_ITEM_')]/label");
    //Gear
    //By gearFilter = By.xpath("//div[@class='gear']/div//label");
    By gearFilter = By.xpath("//*[contains(@data-testid,'TESTING_FILTER_CATEGORY_GEARBOX_ITEM')]");
    // Notification form
    By notificationButton = By.xpath("(//div[@class='elements'])/div[2]/div/button");
    By civilityBox = By.xpath("//* [@data-key = 'civility']/div/div/label[1]");
    By firstNameField = By.xpath("//* [@name = 'firstName']");
    By lastNameField = By.xpath("//* [@name = 'lastName']");
    By phoneNumberField = By.xpath("//* [@name = 'phone']");
    By emailField = By.xpath("//* [@name = 'emailCust']");
    By emailFieldCheckBox = By.xpath("//input[contains(@name, 'legal1')]");
    By postalCodeField = By.xpath("//* [@name = 'postCode']");
    By postalCodeFieldUK = By.xpath("//* [@name = 'customerpostcode']");
    By submitButton = By.xpath("//* [@class = 'submit-button button btn btn-primary']");
    By closeFormButton = By.xpath("//*[@class='modalSidebar__wrap__header__closeBtn']");
    By adressField = By.xpath("//*[@name = 'address1']");
    By townField = By.xpath("//*[@name = 'townAddress']");
    By emailFieldCheckBox_UK = By.xpath("//input[contains(@name, 'emailPreference')]");
    By emailFieldCheckBox_UKVX = By.xpath("//input[contains(@name, 'newsChannel')]");


    public TrimPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickOpenFeatureSwitch(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, openFeatureSwitch);
            System.out.println("Clicked on Open Feature Switch");
            NodeORSubNode.log(Status.INFO, "Clicked on Open Feature Switch");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Open Feature Switch", e);
        }

    }

    public void waitForSwitch(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            waitForElementClickable(driver, eachSwitch, 15);
            System.out.println("Waiting for Feature switch to be clickable");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Feature switch is not clickable", e);
        }

    }

    public void closeModelWindow(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, closeModelWindow);
            System.out.println("Closed Model Window");
            NodeORSubNode.log(Status.INFO, "Closed Model Window");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Close Model Window", e);
        }

    }

    //div[@class='modalWindow__wrap__header']/button[@data-testid='TESTING_CLOSE_MODAL']

    public List<WebElement> listofAllFeatureSwitchElements(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> listSwitch = null;
        try {
            waitForSwitch(resultDirectory, NodeORSubNode);
            listSwitch = getListofElements(driver, eachSwitch);
            System.out.println("Total number of switches are: " + listSwitch.size());
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Feature switch is not clickable", e);
        }

        return listSwitch;
    }

    public String getContactSalesman(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, contactSalesman);
            System.out.println("Got the Link for Contacting Salesman: " + str);
            NodeORSubNode.log(Status.INFO, "Got the Link for Contacting Salesman: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Link for Contacting Salesman", e);
        }
        return str;

    }

    public String getSubTitle(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, SubTitle);
            System.out.println("Got the SubTitle: " + str);
            NodeORSubNode.log(Status.INFO, "Got the SubTitle: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Subtitle", e);
        }
        return str;

    }


    public void validateTopContBtn(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            if (isElementPresent(driver, topContinueBtn)) {
                System.out.println("Got the Top Continue Button");
                NodeORSubNode.log(Status.PASS, "Got the Top Continue Button");
            } else {
                System.out.println("Unable to get the Top Continue Button");
                NodeORSubNode.log(Status.FAIL, "Unable to get the Top Continue Button");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Top Continue Button", e);
        }

    }

    public void validateCatalogFromText(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            if (isElementPresent(driver, catalogPriceTxt)) {
                System.out.println("Catalogue Price Text section is present");
                NodeORSubNode.log(Status.PASS, "Catalogue Price Text section is present");
                if ((getAnyText(driver, catalogPriceTxt) != null) && (getAnyText(driver, catalogPriceTxt).contains("from"))||getAnyText(driver,catalogPriceTxt).contains("desde")
                        ||getAnyText(driver,catalogPriceTxt).contains("partir de")) {
                    System.out.println("Catalogue Price Text (from word) is present");
                    NodeORSubNode.log(Status.PASS, "Catalogue Price Text (from word) is present");
                } else {
                    System.out.println("Unable to get Catalogue Price Text (from word) is present");
                    NodeORSubNode.log(Status.FAIL, "Unable to get Catalogue Price Text (from word) is present");
                }
            } else {
                System.out.println("Unable to get Catalogue Price Text section is present");
                NodeORSubNode.log(Status.FAIL, "Unable to get Catalogue Price Text section is present");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Catalogue Price Text section is present", e);
        }

    }

    public void validateBottomContBtn(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            if (isElementPresent(driver, bottomContinueBtn)) {
                System.out.println("Got the bottom Continue Button");
                NodeORSubNode.log(Status.PASS, "Got the bottom Continue Button");
            } else {
                System.out.println("Unable to get the bottom Continue Button");
                NodeORSubNode.log(Status.FAIL, "Unable to Get the bottom Continue Button");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the bottom Continue Button", e);
        }

    }

    public void validateContactSalesman(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getSubTitle(resultDirectory, NodeORSubNode) != null) {
            System.out.println("Contact Salesman is present: " + getContactSalesman(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Contact Salesman is present: " + getContactSalesman(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Contact Salesman is not present: " + getContactSalesman(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    //div[@class='wrapper']/div[@class='buttonSection']/div[@class='button']

    public void validateTopContinueBtn(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getSubTitle(resultDirectory, NodeORSubNode) != null) {
            System.out.println("Contact Salesman is present: " + getContactSalesman(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Contact Salesman is present: " + getContactSalesman(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Contact Salesman is not present: " + getContactSalesman(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public void validateSubTitle(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getSubTitle(resultDirectory, NodeORSubNode) != null) {
            System.out.println("Subtitle is: " + getSubTitle(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Subtitle is: " + getSubTitle(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Subtitle is: " + getSubTitle(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String getTrimTitle(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, TrimTitle);
            System.out.println("Got the TrimTitle: " + str);
            NodeORSubNode.log(Status.INFO, "Got the TrimTitle: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the TrimTitle", e);
        }
        return str;

    }

    public void validateTrimTitle(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        String str=getTrimTitle(resultDirectory, NodeORSubNode);
        if (str != null) {
            System.out.println("Trim Title is: " + str);
            NodeORSubNode.log(Status.PASS, "Trim Title is: " + str);
        } else {
            failWithScreenshot("Trim Title is: " + str, resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public boolean validateDefaultSelectedTrim(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        boolean bool = false;
        try {
            if (isElementPresent(driver, defaultSelectedRadioButton, 4)) {
                NodeORSubNode.log(Status.PASS, "Default Selected Trim is present");
                bool = true;
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Default Selected Trim", e);
        }
        return bool;
    }

    public void verifyDefaultSelectedTrim(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        Boolean bool=validateDefaultSelectedTrim(resultDirectory, NodeORSubNode);
        if (bool!= false) {
            System.out.println("Default Selected Trim is: " + bool);
            NodeORSubNode.log(Status.PASS, "Default Selected Trim is: " + bool);
        } else {
            failWithScreenshot("Default Selected Trim is: " + bool, resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public int getNoOfTrims(String resultDirectory, ExtentTest NodeORSubNode) {
        List<WebElement> vehicles = null;
        try {
            waitForElementClickable(driver, allTrims, 5);
            vehicles = driver.findElements(allTrims);
            NodeORSubNode.log(Status.INFO, "Got number of Trims: " + vehicles.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get number of trims", e);
        }
        return vehicles.size();
    }

    public void validateAndClickseeTheMainEquipmentLink(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, seeTheMainEquipmentLink);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "See The Main Equipment Link is " + str);
                Thread.sleep(3000);
                scrollToTop(driver);
                clickElement(driver, seeTheMainEquipmentLink,10);
                NodeORSubNode.log(Status.INFO, "Clicked on " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "See The Main Equipment Link is " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with See The Main Equipment Link", e);
        }
    }

    public void validateStandardEquipmentTitle(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, seeStandardEquipment);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "See The Standard Equipment Title is " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "See The Standard Equipment Title is " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with See The Standard Equipment Title", e);
        }
    }

    public void validateStandardEquipmentDescription(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, descriptionStd);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Standard Equipment description is " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Standard Equipment description is " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Standard Equipment description", e);
        }
    }


    public void validateModelHeader(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, modelHeader);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Model Header is " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Model Header is " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Model Header", e);
        }
    }

    public void validateModelTitle(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, modelTitle);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Model Title is " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Model Title is " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Model Title", e);
        }
    }

    public void validateKeyTitle(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, keyTitle);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Model Key Title is " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Model Key Title is " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Model Key Title", e);
        }
    }

    public int validateCategories(String resultDirectory, ExtentTest NodeORSubNode) {
        List<WebElement> catg = null;
        List<WebElement> allCatg = null;
        List<WebElement> allGrids = null;
        try {
            waitForElementClickable(driver, categories, 5);
            catg = driver.findElements(categories);
            if (catg.size() > 0) {
                NodeORSubNode.log(Status.PASS, "Categories section is present");
            } else {
                NodeORSubNode.log(Status.PASS, "Categories section is not present");
            }

            allCatg = driver.findElements(categoriesNum);
            if (allCatg.size() > 0) {
                NodeORSubNode.log(Status.PASS, "All category in Categories section is present and are: " + allCatg.size());
            } else {
                NodeORSubNode.log(Status.PASS, "All category in Categories section is not present");
            }
            for (int i = 0; i < allCatg.size(); i++) {
                String indCatg = allCatg.get(i).getText();
                if (indCatg != null) {
                    NodeORSubNode.log(Status.PASS, "Individual category is: " + indCatg);
                    /*List<WebElement> elements = java.util.Collections.singletonList(allCatg.get(i));
                    clickElement(driver,elements);*/
                    allCatg.get(i).click();
                    waitForElementClickable(driver, grids);
                    Thread.sleep(500);
                    allGrids = driver.findElements(grids);
                    if (allGrids.size() == 6 && i == 0) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Categories section is present and are: " + (allGrids.size() - 2));
                        NodeORSubNode.log(Status.INFO, "<======Validating if Motorization engine,Main Equipment Color and Interior are present======> ");
                        if (isElementPresent(driver, engineMainEqp)) {
                            NodeORSubNode.log(Status.PASS, "Motorization engine is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Motorization engine is not present");
                        }
                        if (isElementPresent(driver, MainEqp)) {
                            NodeORSubNode.log(Status.FAIL, "Main Equipment is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Main Equipment engine is not present");
                        }
                        if (isElementPresent(driver, colorsMain)) {
                            NodeORSubNode.log(Status.PASS, "Color is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Color is not present");
                        }
                        if (isElementPresent(driver, interiorsMainEqp)) {
                            NodeORSubNode.log(Status.PASS, "Interior is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Interior is not present");
                        }

                    } else if (allGrids.size() == 3 && i == 1) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Categories section is present and are: " + (allGrids.size() - 2));
                        NodeORSubNode.log(Status.INFO, "<======Validating if only Motorization engine is present======> ");
                        if (isElementPresent(driver, engineMainEqp)) {
                            NodeORSubNode.log(Status.PASS, "Motorization engine is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Motorization engine is not present");
                        }
                        if (isElementPresent(driver, MainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Main Equipment is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Main Equipment engine is not present");
                        }
                        if (isElementPresent(driver, colorsMain, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Color is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Color is not present");
                        }
                        if (isElementPresent(driver, interiorsMainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Interior is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Interior is not present");
                        }
                    } else if (allGrids.size() == 3 && i == 2) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Categories section is present and are: " + (allGrids.size() - 2));
                        NodeORSubNode.log(Status.INFO, "<======Validating if only Main Equipment engine is present======> ");
                        if (isElementPresent(driver, engineMainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Motorization engine is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Motorization engine is not present");
                        }
                        if (isElementPresent(driver, MainEqp)) {
                            NodeORSubNode.log(Status.FAIL, "Main Equipment is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Main Equipment engine is not present");
                        }
                        if (isElementPresent(driver, colorsMain, 1)) {
                            NodeORSubNode.log(Status.PASS, "Color is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Color is not present");
                        }
                        if (isElementPresent(driver, interiorsMainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Interior is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Interior is not present");
                        }
                    } else if (allGrids.size() == 3 && i == 3) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Categories section is present and are: " + (allGrids.size() - 2));
                        NodeORSubNode.log(Status.INFO, "<======Validating if only color is present======> ");
                        if (isElementPresent(driver, engineMainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Motorization engine is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Motorization engine is not present");
                        }
                        if (isElementPresent(driver, MainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Main Equipment is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Main Equipment engine is not present");
                        }
                        if (isElementPresent(driver, colorsMain)) {
                            NodeORSubNode.log(Status.FAIL, "Color is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Color is not present");
                        }
                        if (isElementPresent(driver, interiorsMainEqp, 1)) {
                            NodeORSubNode.log(Status.PASS, "Interior is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Interior is not present");
                        }
                    } else if (allGrids.size() == 3 && i == 4) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Categories section is present and are: " + (allGrids.size() - 2));
                        NodeORSubNode.log(Status.INFO, "<======Validating if only interior is present======> ");
                        if (isElementPresent(driver, engineMainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Motorization engine is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Motorization engine is not present");
                        }
                        if (isElementPresent(driver, MainEqp, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Main Equipment is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Main Equipment engine is not present");
                        }
                        if (isElementPresent(driver, colorsMain, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Color is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Color is not present");
                        }
                        if (isElementPresent(driver, interiorMainEqp)) {
                            NodeORSubNode.log(Status.FAIL, "Interior is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Interior is not present");
                        }
                    } else if (allGrids.size() == 3 && i == 5) {
                        NodeORSubNode.log(Status.INFO, "<======Validating if All Options are present======> ");
                        if (isElementPresent(driver, allOptions)) {
                            int NumOptions = driver.findElements(allOptions).size();
                            if (NumOptions == 5) {
                                NodeORSubNode.log(Status.PASS, "All Options are available and are: " + NumOptions);
                            } else {
                                NodeORSubNode.log(Status.FAIL, "All Options are not available and are: " + NumOptions);
                            }
                        }
                    }
                    else if (allGrids.size() == 7 && i == 0) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Categories section is present and are: " + (allGrids.size() - 2));
                        NodeORSubNode.log(Status.INFO, "<======Validating if Motorization engine,Main Equipment Color and Interior are present======> ");

                        if (isElementPresent(driver, engineMainEqp)) {
                            NodeORSubNode.log(Status.PASS, "Motorization engine is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Motorization engine is not present");
                        }
                        if (isElementPresent(driver, MainEqp)) {
                            NodeORSubNode.log(Status.FAIL, "Main Equipment is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Main Equipment engine is not present");
                        }
                        if (isElementPresent(driver, colorsMain)) {
                            NodeORSubNode.log(Status.PASS, "Color is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Color is not present");
                        }
                        if (isElementPresent(driver, interiorsMainEqp)) {
                            NodeORSubNode.log(Status.PASS, "Interior is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Interior is not present");
                        }

                    }
                    else {
                        NodeORSubNode.log(Status.FAIL, "Total grids in Categories section could not be verified");
                    }
                } else {
                    NodeORSubNode.log(Status.FAIL, "Missing Individual category is: " + indCatg);
                }

                allCatg.get(0).click();
                Thread.sleep(500);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate categories section", e);
        }
        return catg.size();
    }

    public int validateStandardEquipmentCategories(String resultDirectory, ExtentTest NodeORSubNode) {
        List<WebElement> catg = null;
        List<WebElement> allCatg = null;
        List<WebElement> allGrids = null;
        try {
            waitForElementClickable(driver, allCategoriesStd, 5);
            catg = driver.findElements(allCategoriesStd);
            if (catg.size() > 0) {
                NodeORSubNode.log(Status.PASS, "Standard Equipment Categories section is present");
            } else {
                NodeORSubNode.log(Status.FAIL, "Standard Equipment Categories section is not present");
            }

            allCatg = driver.findElements(eachCategoryStd);
            for (int i = 0; i < allCatg.size(); i++) {
                if (allCatg.get(i).getText() != null) {
                    System.out.println("Current category is: " + allCatg.get(i).getText());
                    NodeORSubNode.log(Status.PASS, "Standard Equipment Individual category is: " + allCatg.get(i).getText());
                    allCatg.get(i).click();
                    waitForElementClickable(driver, gridsStd);
                    Thread.sleep(500);
                    allGrids = driver.findElements(gridsStd);
                    NodeORSubNode.log(Status.INFO,"Grid size= "+allGrids.size()+" value of i= "+i);
                    if (allGrids.size() == 5 && i == 0) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Standard Equipment Categories section is present and are: " + allGrids.size());
                        NodeORSubNode.log(Status.PASS, "<====Validate if Comfort, Security,Aesthetic, Rims and Multiple & Navigation are present====>");
                        if (isElementPresent(driver, comfortText)) {
                            NodeORSubNode.log(Status.PASS, "Comfort is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Comfort is not present");
                        }
                        Thread.sleep(3000);
                        if (isElementPresent(driver, AestheticText)) {
                            NodeORSubNode.log(Status.PASS, "Aesthetic is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Aesthetic is not present");
                        }
                        if (isElementPresent(driver, rimsText)) {
                            NodeORSubNode.log(Status.PASS, "Rims is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Rims is not present");
                        }
                        if (isElementPresent(driver, multiMediaAndNavigationText)) {
                            NodeORSubNode.log(Status.PASS, "Multimedia and Navigation is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Multimedia and Navigation is not present");
                        }
                        if (isElementPresent(driver, securityText)) {
                            NodeORSubNode.log(Status.PASS, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Security is not present");
                        }
                    } else if (allGrids.size() == 1 && i == 1) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Standard Equipment Categories section is present and are: " + allGrids.size());
                        NodeORSubNode.log(Status.PASS, "<====Validate if only Comfort is present====>");
                        if (isElementPresent(driver, comfortText)) {
                            NodeORSubNode.log(Status.PASS, "Comfort is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Comfort is not present");
                        }
                        Thread.sleep(3000);
                        if (isElementPresent(driver, AestheticText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Aesthetic is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Aesthetic is not present");
                        }
                        if (isElementPresent(driver, rimsText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Rims is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Rims is not present");
                        }
                        if (isElementPresent(driver, multiMediaAndNavigationText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Multimedia and Navigation is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Multimedia and Navigation is not present");
                        }
                        if (isElementPresent(driver, securityText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Security is not present");
                        }
                    } else if (allGrids.size() == 1 && i == 2) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Standard Equipment Categories section is present and are: " + allGrids.size());
                        NodeORSubNode.log(Status.PASS, "<====Validate if only Aesthetic is present====>");
                        if (isElementPresent(driver, comfortText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Comfort is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Comfort is not present");
                        }
                        Thread.sleep(3000);
                        if (isElementPresent(driver, AestheticText)) {
                            NodeORSubNode.log(Status.PASS, "Aesthetic is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Aesthetic is not present");
                        }
                        if (isElementPresent(driver, rimsText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Rims is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Rims is not present");
                        }
                        if (isElementPresent(driver, multiMediaAndNavigationText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Multimedia and Navigation is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Multimedia and Navigation is not present");
                        }
                        if (isElementPresent(driver, securityText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Security is not present");
                        }
                    } else if (allGrids.size() == 1 && i == 3) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Standard Equipment Categories section is present and are: " + allGrids.size());
                        NodeORSubNode.log(Status.PASS, "<====Validate if only Rims is present====>");
                        if (isElementPresent(driver, comfortText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Comfort is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Comfort is not present");
                        }
                        Thread.sleep(3000);
                        if (isElementPresent(driver, AestheticText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Aesthetic is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Aesthetic is not present");
                        }
                        if (isElementPresent(driver, rimsText)) {
                            NodeORSubNode.log(Status.PASS, "Rims is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Rims is not present");
                        }
                        if (isElementPresent(driver, multiMediaAndNavigationText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Multimedia and Navigation is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Multimedia and Navigation is not present");
                        }
                        if (isElementPresent(driver, securityText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Security is not present");
                        }
                    } else if (allGrids.size() == 1 && i == 4) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Standard Equipment Categories section is present and are: " + allGrids.size());
                        NodeORSubNode.log(Status.PASS, "<====Validate if only Multimedia & Navigation is present====>");
                        if (isElementPresent(driver, comfortText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Comfort is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Comfort is not present");
                        }
                        Thread.sleep(3000);
                        if (isElementPresent(driver, AestheticText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Aesthetic is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Aesthetic is not present");
                        }
                        if (isElementPresent(driver, rimsText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Rims is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Rims is not present");
                        }
                        if (isElementPresent(driver, multiMediaAndNavigationText)) {
                            NodeORSubNode.log(Status.PASS, "Multimedia and Navigation is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Multimedia and Navigation is not present");
                        }
                        if (isElementPresent(driver, securityText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Security is not present");
                        }
                    } else if (allGrids.size() == 1 && i == 5) {
                        NodeORSubNode.log(Status.PASS, "Total grids in Standard Equipment Categories section is present and are: " + allGrids.size());
                        NodeORSubNode.log(Status.PASS, "<====Validate if only Security is present====>");
                        if (isElementPresent(driver, comfortText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Comfort is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Comfort is not present");
                        }
                        Thread.sleep(3000);
                        if (isElementPresent(driver, AestheticText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Aesthetic is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Aesthetic is not present");
                        }
                        if (isElementPresent(driver, rimsText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Rims is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Rims is not present");
                        }
                        if (isElementPresent(driver, multiMediaAndNavigationText, 1)) {
                            NodeORSubNode.log(Status.FAIL, "Multimedia and Navigation is present");
                        } else {
                            NodeORSubNode.log(Status.PASS, "Multimedia and Navigation is not present");
                        }
                        if (isElementPresent(driver, securityText)) {
                            NodeORSubNode.log(Status.PASS, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Security is not present");
                        }
                    }
                    else if (allGrids.size() == 6 && i == 0) {
                        if (isElementPresent(driver, comfortText)) {
                            NodeORSubNode.log(Status.PASS, "Comfort is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Comfort is not present");
                        }
                        Thread.sleep(3000);
                        if (isElementPresent(driver, AestheticText)) {
                            NodeORSubNode.log(Status.PASS, "Aesthetic is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Aesthetic is not present");
                        }
                        if (isElementPresent(driver, rimsText)) {
                            NodeORSubNode.log(Status.PASS, "Rims is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Rims is not present");
                        }
                        if (isElementPresent(driver, multiMediaAndNavigationText)) {
                            NodeORSubNode.log(Status.PASS, "Multimedia and Navigation is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Multimedia and Navigation is not present");
                        }
                        if (isElementPresent(driver, securityText)) {
                            NodeORSubNode.log(Status.PASS, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Security is not present");
                        }
                        //Environnement électrique
                        if (isElementPresent(driver, electricalEnv)) {
                            NodeORSubNode.log(Status.PASS, "Electrical Environment is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Electrical Environment is not present");
                        }

                    }
                    else if (allGrids.size() == 1 && i == 6) {
                        if (isElementPresent(driver, securityText)) {
                            NodeORSubNode.log(Status.PASS, "Security is present");
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Security is not present");
                        }
                    }
                    else {
                        System.out.println("Grid size= "+allGrids.size()+" and i value is "+i);
                        NodeORSubNode.log(Status.FAIL,"Grid size= "+allGrids.size()+" and i value is "+i);
                        NodeORSubNode.log(Status.FAIL, "Total grids in Standard Equipment Categories section could not be verified");
                    }

                } else {
                    NodeORSubNode.log(Status.FAIL, "Standard Equipment Missing Individual category is: " + allCatg.get(i).getText());
                }
            }
            allCatg.get(0).click();
            Thread.sleep(500);

            if (allCatg.size() > 0) {
                NodeORSubNode.log(Status.PASS, "All category in Standard Equipment Categories section is present and are: " + allCatg.size());
            } else {
                NodeORSubNode.log(Status.FAIL, "All category in Standard Equipment Categories section is not present");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate Standard Equipment categories section", e);
        }
        return catg.size();
    }

    public void validateEngineLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, engineLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "engine label is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get engine label", e);
        }
    }

    public void validateComfortLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, comfortLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available comfort label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "comfort label is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get comfort label", e);
        }
    }

    public void validatesecurityLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, securityLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available security label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "security label is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get security label", e);
        }
    }

    public void validateAestheticLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, aestheticLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available aesthetic label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "aesthetic label is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get security label", e);
        }
    }

    public void validateAudioCommunicationLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, audioCommLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available audio Communication Label label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "audio Communication is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get audio Communication label", e);
        }
    }

    public void validateRimsLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, rimsLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Rims Label label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Rims label is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Rims label", e);
        }
    }

    public void validateEngineConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, engineConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available Configuration for Motorisation is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Configuration for Motorisation is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Configuration for Motorisation", e);
        }
    }

    public void validateComfortConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, comfortConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available Configuration for comfort is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Configuration for comfort is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Configuration for comfort", e);
        }
    }

    public void validateSecurityConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, securityConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available security for comfort is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "security for comfort is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get security for comfort", e);
        }
    }

    public void validateAestheticConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, aestheticConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available aesthetic Configuration is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "aesthetic for configuration is not avilable " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get aesthetic for comfort", e);
        }
    }

    public void validateAudioCommunicationConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, audioCommunicationConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available audio Communication Configuration is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "audio Communication Configuration is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get audio Communication Configuration", e);
        }
    }

    public void validateRimsConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, RimsConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available Rims Configuration is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "Rims Configuration is not available: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Rims Configuration", e);
        }
    }


    public void validateMainEquipmentLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, MainEquipmentLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available MainEquipmentLabel is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "MainEquipmentLabel is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get MainEquipment Label", e);
        }
    }

    public void validateMainEquipmentConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, MainEquipmentConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available MainEquipment Configuration is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "MainEquipment Configuration is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get MainEquipment Configuration", e);
        }
    }

    public void validateColorsLabel(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, colorsLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available colors Label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "MainEquipment colors Label is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get colors Label", e);
        }
    }

    public void validateColorsConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        List<WebElement> colors = null;
        String str;
        try {
            if (isElementPresent(driver, colorsConfiguration)) {
                colors = driver.findElements(colorsConfiguration);
                int TotalColors = colors.size();
                if (TotalColors > 0) {
                    NodeORSubNode.log(Status.PASS, "No. of Colors available are" + TotalColors);
                    for (WebElement color : colors
                    ) {
                        str = color.getAttribute("style");
                        if (str != null) {
                            NodeORSubNode.log(Status.PASS, "Individual Color available is: " + str);
                        } else {
                            NodeORSubNode.log(Status.FAIL, "Individual Color is not available");
                        }
                    }
                } else {
                    NodeORSubNode.log(Status.FAIL, "Colors are not available");
                }

            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get colors Configuration", e);
        }
    }

    public void validateInteriorLabel(String resultDirectory, ExtentTest NodeORSubNode) {

        try {
            String str;
            Thread.sleep(3000);
            str = getAnyText(driver, interiorLabel);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available interior Label is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "MainEquipment interior Label is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get interior Label", e);
        }
    }

    public void validateInteriorConfiguration(String resultDirectory, ExtentTest NodeORSubNode) {
        String str;
        try {
            str = getAnyText(driver, interiorConfiguration);
            if (str != null) {
                NodeORSubNode.log(Status.PASS, "Available interior Configuration is: " + str);
            } else {
                NodeORSubNode.log(Status.FAIL, "MainEquipment interior Configuration is: " + str);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get interior Configuration", e);
        }
    }

    public void closeModel(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, closeModel);
            NodeORSubNode.log(Status.INFO, "closed model window");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to closeModel", e);
        }
    }

    public void validateNoOfTrims(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) {
        int noOfTrims=getNoOfTrims(resultDirectory, NodeORSubNode);
        if (noOfTrims != 0) {
            System.out.println("No. of Trim is: " + noOfTrims);
            NodeORSubNode.log(Status.PASS, "No. of Trim is: " + noOfTrims);
        } else {
            failWithScreenshot("No. of Trim is: " + noOfTrims, resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String getIndividualTrimTitle(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        //By by = By.xpath("(//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/span[@class='trimTitle'])" + "[" + i + "]");
        By by=By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_SPECK_PACK_"+i+"']");
        try {
            str = getAnyText(driver, by);
            clickElement(driver, by);
            waitForElementClickable(driver, by);
            System.out.println("TrimTitle for the Trim Number " + (i+1) + " is: " + str);
            NodeORSubNode.log(Status.INFO, "TrimTitle for the Trim Number " + (i+1) + " is: " + str);
            validateExteriorView(driver, resultDirectory, NodeORSubNode);
            validateInteriorView(driver, resultDirectory, NodeORSubNode);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the TrimTitle for the Trim Number: " + i, e);
        }
        return str;

    }

    public void validateExteriorView(WebDriver driver, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException, TimeoutException {
        try {
            System.out.println("Exterior View");
            clickElement(driver, exteriorViewIcon);
            NodeORSubNode.log(Status.INFO, "Clicked on Exterior View icon");
            Thread.sleep(1000);
            for (int k = 0; k <= 4; k++) {
                clickElement(driver, nextCarButtonExt);
                NodeORSubNode.log(Status.INFO, "Clicked on Next Image Button");
                Thread.sleep(1500);
                String carImage = getAttributeValue(driver, currentcarExt, "title", 2);
                if (carImage != null) {
                    System.out.println("The Current Exterior Car is: " + carImage);
                    NodeORSubNode.log(Status.PASS, "The Current Exterior Car is: " + carImage);
                } else {
                    System.out.println("The Current Exterior Car is: " + carImage);
                    NodeORSubNode.log(Status.FAIL, "The Current Exterior Car is: " + carImage);
                }
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate Exterior view", e);
        }
    }

    public void validateInteriorView(WebDriver driver, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException, TimeoutException {
        try {
            System.out.println("Interior View");
            clickElement(driver, interiorViewIcon);
            NodeORSubNode.log(Status.INFO, "Clicked on Interior View icon");
            Thread.sleep(1000);

            for (int k = 0; k <= 4; k++) {
                clickElement(driver, nextCarButtonInt);
                NodeORSubNode.log(Status.INFO, "Clicked on Next Image Button");
                Thread.sleep(1000);
                String carImage = getAttributeValue(driver, currentcarInt, "title", 2);
                if (carImage != null) {
                    System.out.println("The Current Interior Car is: " + carImage);
                    NodeORSubNode.log(Status.PASS, "The Current Interior Car is: " + carImage);
                } else {
                    System.out.println("The Current Interior Car is: " + carImage);
                    NodeORSubNode.log(Status.FAIL, "The Current Interior Car is: " + carImage);
                }
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate interior view", e);
        }
    }

    public void validateIndividualTrimTitle(int i, String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getIndividualTrimTitle(i, resultDirectory, NodeORSubNode) != null) {
            System.out.println("Individual Trim Title " + (i+1) + " is visible ");
            NodeORSubNode.log(Status.PASS, "Individual Trim Title " + (i+1) + " is visible");
        } else {
            failWithScreenshot("Individual Trim Title " + (i+1) + " is not visible", resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public void vehicleFinanceVersion(int i, String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        int count=0;
        if (getIndividualTrimTitle(i, resultDirectory, NodeORSubNode) != null) {
            System.out.println("Individual Trim Title " + 1 + " is visible ");
            NodeORSubNode.log(Status.PASS, "Individual Trim Title " + i + " is visible");
        } else {
            failWithScreenshot("Individual Trim Title " + i + " is not visible", resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String getIndividualTrimContentTitle(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            //str = getAnyText(driver, By.xpath("(//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/div[@class='trimContent title'])" + "[" + i + "]"));
            //str=getInnerText(driver,By.xpath("(//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/span[@class='trimTitle'])"+ "[" + i + "]"));
            str=getInnerText(driver,By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_SPECK_PACK_"+i+"']"));
            System.out.println("Trim Content Title for the Trim Number " + (i+1) + " is" + str);
            NodeORSubNode.log(Status.INFO, "Trim Content Title for the Trim Number " + (i+1) + " is" + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Trim Content Title for the Trim Number: " + i, e);
        }
        return str;

    }

    public void validateIndividualTrimContentTitle(int i, String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getIndividualTrimContentTitle(i, resultDirectory, NodeORSubNode) != null) {
            System.out.println("Individual Trim Content Title is: " + getIndividualTrimContentTitle(i, resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Individual Trim Content Title is: " + getIndividualTrimContentTitle(i, resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Individual Trim Content Title is: " + getIndividualTrimContentTitle(i, resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String getIndividualTrimDescription(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;//"(//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/span[@class='trimDescription'])" + "[" + i + "]"
        try {
            if(isElementPresent(driver,By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_DESCRIPTION_"+i+"']"))){
                str = getAnyText(driver, By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_DESCRIPTION_"+i+"']"));
                System.out.println("Trim Description for the Trim Number " + i + " is" + str);
                NodeORSubNode.log(Status.INFO, "Trim Description for the Trim Number " + i + " is" + str);
            } else{
                System.out.println("Trim Description is not present for the Trim Number " + i);
                NodeORSubNode.log(Status.INFO, "Trim Description is not present for the Trim Number " + i);
            }
            } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Trim Description for the Trim Number: " + i, e);
        }
        return str;

    }

    public void validateIndividualTrimDescription(int i, String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        String str=getIndividualTrimDescription(i, resultDirectory, NodeORSubNode);
        if ( str!= null) {
            System.out.println("Individual Trim Description is: " + str);
            NodeORSubNode.log(Status.PASS, "Individual Trim Description is: " + str);
        } else {
            //failWithScreenshot("Individual Trim Description is: " + getIndividualTrimDescription(i, resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
            NodeORSubNode.log(Status.INFO,"Individual Trim Description is not present");
        }
    }

    public String getIndividualTrimPrice(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;//"(//*[@class='trims ']/div/button[starts-with(@class,'trim')]/div[@class='inner']/span[@class='trimPrice'])" + "[" + i + "]"
        By by=By.xpath("//*[@data-testid='TESTING_TRIM_ITEM_PRICE_"+i+"']");
        try {
            //scrollIntoView(driver,by);
            str = getAnyText(driver,by ,8);
            System.out.println("Trim Price for the Trim Number " + (i+1) + " is" + str);
            NodeORSubNode.log(Status.INFO, "Trim Price for the Trim Number " + (i+1)+ " is" + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Trim Price for the Trim Number: " + i, e);
        }
        return str;

    }

    public float validateIndividualTrimCashPrice(int i, String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent, String Country, String Brand) throws InterruptedException {
        float trimCashPrice = 0;
        String currentCashPrice = getIndividualTrimPrice(i, resultDirectory, NodeORSubNode);
        if (currentCashPrice != null) {
            System.out.println("Individual Trim Price is: " + currentCashPrice);
            NodeORSubNode.log(Status.PASS, "Individual Trim Price is: " + currentCashPrice);
            String cashP;
            if(Country.equalsIgnoreCase("ES") && Brand.equalsIgnoreCase("DS")){
                cashP = currentCashPrice.substring(12, 22).replaceAll(" ", "").replace(",",".").replace("€","");
            }else {
                cashP = currentCashPrice.substring(12, 18).replaceAll(" ", "").replace(",",".").replace("€","");
            }
            trimCashPrice = Float.parseFloat(cashP);
            NodeORSubNode.log(Status.INFO, "Individual Trim Cash Price is: " + trimCashPrice);
        } else {
            failWithScreenshot("Unable to get valid Individual Trim Cash Price. Current Individual Trim Cash Price is: " + trimCashPrice, resultDirectory, driver, extent, NodeORSubNode);
        }
        return trimCashPrice;
    }

    public float validateIndividualTrimMonthlyPrice(int i, String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        float trimMonthlyPrice = 0;
        boolean bool;
        String currentCashPrice = getIndividualTrimPrice(i, resultDirectory, NodeORSubNode);
        if (currentCashPrice != null) {
            if(currentCashPrice.contains("TTC/mois") && currentCashPrice!=null){
                bool=true;
                NodeORSubNode.log(Status.INFO, "Finance Price is available.");
                //Assert.assertTrue(bool);
            }else{
                bool=false;
                NodeORSubNode.log(Status.INFO, "Finance Price is not available. Alas! we are moving ahead with cash Vehicle: " + currentCashPrice);
                //Assert.assertTrue(false);
            }
            System.out.println("Current value of the boolean is: " + bool);
            System.out.println("Individual Trim Price is: " + currentCashPrice);
            NodeORSubNode.log(Status.PASS, "Individual Trim Price is: " + currentCashPrice);
            String monthP;
            waitForUrlContains("preprod",driver,5);
            if ((driver.getCurrentUrl().contains("-es-") != true) && (bool==true)) {
                monthP = currentCashPrice.substring(26, 30);
            } else if((driver.getCurrentUrl().contains("-es-") != true) && (bool==false)) {
                monthP = currentCashPrice.substring(12, 19).replace(",", ".").replace(" ", "");
            }else{
                monthP = currentCashPrice.substring(12, 20).replace(",", ".").replace(" ", "");
            }
            trimMonthlyPrice = Float.parseFloat(monthP);
            NodeORSubNode.log(Status.INFO, "Individual Trim Monthly Price is: " + trimMonthlyPrice);
        } else {
            failWithScreenshot("Individual Trim Monthly Price is: " + trimMonthlyPrice, resultDirectory, driver, extent, NodeORSubNode);
        }
        return trimMonthlyPrice;
    }

    public String getStickyBarCashPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, StickyBarCashPrice);
            System.out.println("Sticky Bar Cash Price is: " + str);
            NodeORSubNode.log(Status.INFO, "Sticky Bar Cash  Price is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Sticky Bar Cash Price", e);
        }
        return str;

    }

    public float validateStickyBarCashPrice(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        float stickyTrimCashPrice = 0;
        if (getStickyBarCashPrice(resultDirectory, NodeORSubNode) != null) {
            String currentStickyCashPrice = getStickyBarCashPrice(resultDirectory, NodeORSubNode);
            System.out.println("Sticky Bar Cash Price is: " + currentStickyCashPrice);
            NodeORSubNode.log(Status.PASS, "Sticky Bar Cash Price is: " + currentStickyCashPrice);
            String stickyCashP = currentStickyCashPrice.substring(0, 6).replace(" ", "");
            stickyTrimCashPrice = Float.parseFloat(stickyCashP);

        } else {
            failWithScreenshot("Unable to get valid Sticky Bar Cash Price. Current Sticky Bar Cash Price is: " + getStickyBarCashPrice(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
        return stickyTrimCashPrice;
    }

    public String getStickyBarMonthlyPrice(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, StickyBarMonthlyPrice,8);
            System.out.println("Sticky Bar Monthly Price is: " + str);
            NodeORSubNode.log(Status.INFO, "Sticky Bar Monthly Price is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Sticky Bar Monthly Price", e);
        }
        return str;

    }

    public float validateStickyBarMonthlyPrice(float stickyTrimMonthlyPrice, String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        stickyTrimMonthlyPrice = 0;
        if (getStickyBarMonthlyPrice(resultDirectory, NodeORSubNode) != null) {
            String currentStickyMonthPrice = getStickyBarMonthlyPrice(resultDirectory, NodeORSubNode);
            System.out.println("Sticky Bar Monthly Price is: " + currentStickyMonthPrice);
            NodeORSubNode.log(Status.PASS, "Sticky Bar Monthly Price is: " + currentStickyMonthPrice);
            String stickyMonthP = currentStickyMonthPrice.replace(" ","").replace("€","").replace(",",".");
            stickyTrimMonthlyPrice = Float.parseFloat(stickyMonthP.substring(0,stickyMonthP.length()-1));
        } else {
            failWithScreenshot("Unable to get valid Sticky Bar Monthly Price. Current Sticky Bar Monthly Price is: " + getStickyBarMonthlyPrice(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
        return stickyTrimMonthlyPrice;
    }

    public void validateTrimCashPrice(String resultDirectory, ExtentTest NodeORSubNode, float stickyTrimCashPrice, float trimCashPrice) throws InterruptedException {
        try {
            if ((stickyTrimCashPrice - trimCashPrice < 1) && (stickyTrimCashPrice != 0) && (trimCashPrice != 0)) {
                System.out.println("Cash Price of the current trim " + trimCashPrice + " is same as cash price of the sticky bar " + stickyTrimCashPrice);
                NodeORSubNode.log(Status.PASS, "Cash Price of the current trim " + trimCashPrice + " is same as cash price of the sticky bar " + stickyTrimCashPrice);
            } else {
                System.out.println("Cash Price of the current trim " + trimCashPrice + " is not same as cash price of the sticky bar " + stickyTrimCashPrice);
                NodeORSubNode.log(Status.FAIL, "Cash Price of the current trim " + trimCashPrice + " is not same as cash price of the sticky bar " + stickyTrimCashPrice);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate TrimCash Price", e);
        }
    }

    public void validateTrimMonthlyPrice(String resultDirectory, ExtentTest NodeORSubNode, float stickyTrimMonthlyPrice, float trimMonthlyPrice) throws InterruptedException {
        try {
            if ((stickyTrimMonthlyPrice - trimMonthlyPrice < 1) && (stickyTrimMonthlyPrice != 0) && (trimMonthlyPrice != 0)) {
                System.out.println("Monthly Price of the current trim " + stickyTrimMonthlyPrice + " is same as Monthly price of the sticky bar " + trimMonthlyPrice);
                NodeORSubNode.log(Status.PASS, "Monthly Price of the current trim " + stickyTrimMonthlyPrice + " is same as monthly price of the sticky bar " + trimMonthlyPrice);
            } else {
                System.out.println("Monthly Price of the current trim " + stickyTrimMonthlyPrice + " is not same as Monthly price of the sticky bar " + trimMonthlyPrice);
                NodeORSubNode.log(Status.PASS, "Monthly Price of the current trim " + stickyTrimMonthlyPrice + " is not same as monthly price of the sticky bar " + trimMonthlyPrice);
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate Trim Monthly Price", e);
        }
    }

    public String getLinkSectionTitle(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, LinkSectionTitle);
            System.out.println("Link Section Title is: " + str);
            NodeORSubNode.log(Status.INFO, "Link Section Title is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Link Section Title", e);
        }
        return str;

    }

    public void validateLinkSectionTitle(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getLinkSectionTitle(resultDirectory, NodeORSubNode) != null) {
            System.out.println("Link Section Title is: " + getLinkSectionTitle(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Link Section Title is: " + getLinkSectionTitle(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Link Section Title is: " + getLinkSectionTitle(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String getLinkSectionElements(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, LinkSectionElements);
            System.out.println("Link Section Element is: " + str);
            NodeORSubNode.log(Status.INFO, "Link Section Element is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Link Section Element", e);
        }
        return str;

    }

    public void validateLinkSectionElements(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getLinkSectionElements(resultDirectory, NodeORSubNode) != null) {
            System.out.println("Link Section Elements is: " + getLinkSectionElements(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Link Section Elements is: " + getLinkSectionElements(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Link Section Elements is: " + getLinkSectionElements(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String getLinkSectionByPhone(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, LinkSectionByPhone);
            System.out.println("Link Section By Phone is: " + str);
            NodeORSubNode.log(Status.INFO, "Link Section By Phone is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Link Section By Phone", e);
        }
        return str;

    }

    public void validateLinkSectionByPhone(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (getLinkSectionByPhone(resultDirectory, NodeORSubNode) != null) {
            System.out.println("Link Section By Phone is: " + getLinkSectionByPhone(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Link Section By Phone is: " + getLinkSectionByPhone(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Link Section By Phone is: " + getLinkSectionByPhone(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String contactYourAdvisor(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, ContactYourAdvisor);
            System.out.println("Link Contact Your Advisor is: " + str);
            NodeORSubNode.log(Status.INFO, "Link Contact Your Advisor is: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Link Contact Your Advisor", e);
        }
        return str;

    }

    public void validateContactYourAdvisor(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (contactYourAdvisor(resultDirectory, NodeORSubNode) != null) {
            System.out.println("contact Your Advisor is: " + contactYourAdvisor(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "contact Your Advisor is: " + contactYourAdvisor(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("contact Your Advisor is: " + contactYourAdvisor(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public String OfferPaymentModelTexts(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, OfferPaymentModelTexts);
            System.out.println("Offer Payment Model Texts are: " + str);
            NodeORSubNode.log(Status.INFO, "Offer Payment Model Texts are: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Offer Payment Model Texts", e);
        }
        return str;

    }

    public void validateOfferPaymentModelTexts(String resultDirectory, ExtentTest NodeORSubNode, ExtentReports extent) throws InterruptedException {
        if (OfferPaymentModelTexts(resultDirectory, NodeORSubNode) != null) {
            System.out.println("Offer Payment Model Texts are: " + OfferPaymentModelTexts(resultDirectory, NodeORSubNode));
            NodeORSubNode.log(Status.PASS, "Offer Payment Model Texts are: " + OfferPaymentModelTexts(resultDirectory, NodeORSubNode));
        } else {
            failWithScreenshot("Offer Payment Model Texts are: " + OfferPaymentModelTexts(resultDirectory, NodeORSubNode), resultDirectory, driver, extent, NodeORSubNode);
        }
    }

    public List<WebElement> getCarsList(String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        List<WebElement> allCars = new ArrayList<WebElement>();
        try {
            if (country.equals("ES")) {
                waitForElementClickable(driver, carList_ES, 5);
                allCars = driver.findElements(carList_ES);
            }
            if (country.equals("FR")) {
                waitForElementClickable(driver, carList_FR, 5);
                allCars = driver.findElements(carList_FR);
            }
            System.out.println("Got the list of cars: " + allCars.size());
            NodeORSubNode.log(Status.INFO, "Got the list of cars: " + allCars.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the list of cars", e);
        }
        return allCars;
    }

    public String getFinantialPriceTrim(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, By.xpath("(//div [@class = 'monthlyPrice'])[" + i + "]/span[1]"));
            System.out.println("Got the financial price");
            //System.out.println("//* [@id = 'top-level-grid']/../div[3]/div/div/ul/li[" + i + "]");
            NodeORSubNode.log(Status.INFO, "Got Financial Price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Financial Price", e);
        }
        return str;

    }

    public String getFinantialPriceTrimInfoPage(int i, String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String text = null;
        try {

            //System.out.println("//* [@id = 'top-level-grid']/../div[3]/div/div/ul/li[" + i + "]");
            Thread.sleep(1000);
            if (country.equalsIgnoreCase("ES")) {
                System.out.println(" In to click info popup " + i);
                clickUsingJS(driver, By.xpath("(//div/button[contains(@class,'aprDescription')])[" + i + "]"));
                text = getAnyText(driver, monthlyPriceInformationPage_ES);
            }
            if (country.equalsIgnoreCase("FR")) {
                //clickElement(driver, By.xpath("(//*[@id='infoCircle'])[" + i + "]/../.."));
                clickElement(driver, By.xpath("(//div[contains(@class, 'infoIcon')])[" + i + "]"));
                text = getAnyText(driver, monthlyPriceInformationPage);

            }
            System.out.println("Got the financial price info page: " + text);
            NodeORSubNode.log(Status.INFO, "Got the financial price info page: " + text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the financial price info page", e);
        }
        return text;
    }

    public String getFinantialPriceInfoPage() throws InterruptedException {

        System.out.println("get the financial info page");
        return getAnyText(driver, monthlyPriceInformationPage);

    }

    public String getFinantialText() throws InterruptedException {

        System.out.println("get the financial info page");
        return getAnyText(driver, monthlyPriceInformationPage);

    }

    public boolean finantialPricePresent(int i) throws InterruptedException {
        return isElementPresent(driver, By.xpath("(//div [@class = 'monthlyPrice'])[" + i + "]"));
    }

    public String getPriceText(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, By.xpath("(//*[contains(@class , 'priceBoxWrapper')]) [" + i + "]"));
            System.out.println("Got the financial info page: " + str);
            NodeORSubNode.log(Status.INFO, "got the financial info page: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the financial info page", e);
        }
        return str;
    }

    public void clickonFinantialInformation(int i) throws InterruptedException {
        System.out.println("Click on information for UK");
        clickElement(driver, By.xpath("(//* [@class = 'vertical'])[" + i + "]"));
        Thread.sleep(1000);
    }

    public void clickOnNext() {

        try {
            clickElement(driver, NextButton);
            System.out.println("Click on Next");
            //NodeORSubNode.log(Status.INFO, "Clicked on Next");
        } catch (Exception e) {
            //catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to Click on Next",e);
        }
    }

    public String getTrimPageHeaderText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, trimPageHeader);
            NodeORSubNode.log(Status.INFO, "Got Trim Page Header Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get Trim Page Header Text", e);
        }

        return str;
    }

    public void closeInfoPopup(String resultDirectory, ExtentTest NodeORSubNode) {
        try {
            clickElement(driver, closeButton);
            NodeORSubNode.log(Status.INFO, "Clicked on close Info Popup button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click close Info Popup button", e);
        }
    }

    public String getVehicleName() {
        System.out.println("Getting Vehicle name");
        return getAnyText(driver, vehicleName);
    }

    public String getCashPrice(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, cash_Price,10);
            System.out.println("Got cash price: " + str);
            NodeORSubNode.log(Status.INFO, "Got cash price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get cash price", e);
        }
        return str;
    }

    public Long getVehicleCashPrice(int i) {
        String cashPrice = getAnyText(driver, By.xpath("(//*[contains(@data-testid, 'TESTING_TOTAL_PRICE')])[" + i + "]//div[@class='cashPrice']//span[@class='formatMoney']"));
        return Long.valueOf(extractNumericFromString(cashPrice));
    }

    public String getMonthlyPrice(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            str = getAnyText(driver, monthlyPrice);
            System.out.println("Got monthly price: " + str);
            NodeORSubNode.log(Status.PASS, "Got monthly price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get monthly price", e);
        }
        return str;
    }

    public String geEntradaPrice() {
        System.out.println("Get entrada price");
        return getAnyText(driver, entradaPrice);
    }

    public String getPrixCatalogPrice(String country, String brand, String resultDirectory, ExtentTest NodeORSubNode) {
        System.out.println("Getting prix catalog price");
        String text = null;
        try {
            if (country.equals("FR") && brand.equals("DS")) {
                text = getAnyText(driver, prixCatalogPrice_FR_DS).trim();
            } else {
                text = getAnyText(driver, prixCatalogPrice).trim();
            }
            NodeORSubNode.log(Status.INFO, "Got prix catalog price: " + text);
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get prix catalog price", e);
        }
        return text;
    }

    public String getPromotionalText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            str = getAnyText(driver, promotionalText);
            System.out.println("Got promotional text: " + str);
            NodeORSubNode.log(Status.INFO, "Got promotional text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get promotional text", e);
        }
        return str;
    }

    public String getCashPriceOnInfoPopup(String resultDirectory, ExtentTest NodeORSubNode) {

        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            str = getAnyText(driver, cashPrice_InfoPopup).trim();
            System.out.println("Got cash price on info popup: " + str);
            NodeORSubNode.log(Status.INFO, "Got cash price on info popup: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get cash price on info popup", e);
        }
        return str;
    }

    public String getEntradaPriceOnInfoPopup(String country, String resultDirectory, ExtentTest NodeORSubNode) {
        String text = null;
        try {
            if (country.equals("ES")) {
                text = getAnyText(driver, entradaPrice_InfoPopup_ES).trim();
            }
            if (country.equals("FR")) {
                text = getAnyText(driver, entradaPrice_InfoPopup_FR).trim();
            }
            System.out.println("Got entrada price on info popup: " + text);
            NodeORSubNode.log(Status.INFO, "Got entrada price on info popup: " + text);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get entrada price on info popup", e);
        }
        return text;
    }

    public String getTAEOnInfoPopup(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
            str = getAnyText(driver, TAE_InfoPopup).trim();
            System.out.println("Got TAE on info popup: " + str);
            NodeORSubNode.log(Status.INFO, "Got TAE on info popup: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get TAE on info popup", e);
        }
        return str;
    }

    public String getCashPrice(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, By.xpath("(//div[@class='cashPrice']//span[@class='formatMoney']) [" + i + "]")).trim();
            System.out.println("Got cash price");
            NodeORSubNode.log(Status.INFO, "Got cash price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get cash price", e);
        }
        return str;
    }

    public String getEntradaPrice(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, By.xpath("(//div[@class='priceNotice']//span[@class='amount'][1]) [" + i + "]")).trim();
            System.out.println("Got entrada price");
            NodeORSubNode.log(Status.INFO, "Got entrada price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get entrada price", e);
        }
        return str;
    }

    public String getPromotionalText(int i, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        String str = null;
        try {
            str = getAnyText(driver, By.xpath("(//div[@class='priceNotice']/div[2]//span[@class='promotionalText']) [" + i + "]")).trim();
            System.out.println("Got promotional text: " + str);
            NodeORSubNode.log(Status.INFO, "Got promotional text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get promotional text", e);
        }
        return str;
    }

    public String getVehicleSubtitle(int i, String resultDirectory, ExtentTest NodeORSubNode) {
        String xpath = "(//div[contains(@class, 'equipmentSubtitle')]/p)[" + i + "]";
        String str = null;
        try {
            str = getAnyText(driver, By.xpath(xpath));
            System.out.println("Got vehicle Subtitle: " + str);
            NodeORSubNode.log(Status.INFO, "Got vehicle Subtitle: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get vehicle Subtitle", e);
        }
        return str;
    }

    public String getVehicleEnabledOrDisabled(int i, String resultDirectory, ExtentTest NodeORSubNode) {
        String xpath = "(//div[contains(@class, 'equipmentSubtitle')]/p//ancestor::div[@class='trimContainer']/..)[" + i + "]";
        String str = null;
        try {
            str = getAttributeValue(driver, By.xpath(xpath), "data-testid");
            System.out.println("Got vehicle attribute value: " + str);
            NodeORSubNode.log(Status.INFO, "Got vehicle attribute value: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get vehicle attribute value", e);
        }
        return str;
    }

    public int getNoOfVehicles(String resultDirectory, ExtentTest NodeORSubNode) {
        List<WebElement> vehicles = null;
        try {
            waitForElementClickable(driver, noOfVehicles, 5);
            vehicles = driver.findElements(noOfVehicles);
            NodeORSubNode.log(Status.INFO, "Got number of Vehicles: " + vehicles.size());
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get number of vehicles", e);
        }
        return vehicles.size();
    }

    public String getColorTextForFirstVehicle() {
        System.out.println("get color text");
        return getAnyText(driver, colorText).trim();
    }

    public String getEngineTextForFirstVehicle() {
        System.out.println("get color text");
        return getAnyText(driver, engineText).trim();
    }

    public String getCarOfferDataTestIdAttribute(int i) {
        String dataTestId = getAttributeValue(driver, By.xpath("(//div[contains(@data-testid, 'TESTING') and contains(@data-testid, 'TRIM')])[" + i + "]"), "data-testid");
        return dataTestId;
    }

    public void adjustRange(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //By by = By.className("rc-slider");
        By by = By.xpath("//*[@data-testid='TESTING_FILTER_CATEGORY_PRICE_RANGE']/div/div");
        highlightElement(driver, by);
        WebElement e = driver.findElement(by);
        waitForElementClickable(driver, by, 4);
        //WebElement e = driver.findElement(By.xpath("//div[@class='rc-slider']/div[4]"));
        try {
            Actions move = new Actions(driver);
            move.moveToElement(e).clickAndHold().moveByOffset(0, 250).release().perform();
            NodeORSubNode.log(Status.INFO, "Adjusted Range Using Slider");
        } catch (Exception e1) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Adjust Range Using Slider", e1);
        }
        //Thread.sleep(4000);
    }

    public Float getRangeEndPrice(String resultDirectory, ExtentTest NodeORSubNode) {
        String price;
        Float EndPrice = null;
        try {
            price = getAnyText(driver, rangeEndPrice).replace(",",".");
            EndPrice = extractFloatFromString(price);
            NodeORSubNode.log(Status.INFO, "Got the Range of End Price: " + EndPrice);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Range of End Price", e);
        }
        return EndPrice;
    }

    public Float getRangeStartPrice(String resultDirectory, ExtentTest NodeORSubNode) {
        String price;
        Float StartPrice = null;
        try {
            price = getAnyText(driver, rangeStartPrice).replace(",",".");
            StartPrice = extractFloatFromString(price);
            NodeORSubNode.log(Status.INFO, "Got the Range of Start Price: " + StartPrice);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get the Range of Start Price", e);
        }
        return StartPrice;
    }

    public List<WebElement> getRangeCashPriceCarList() {
        System.out.println("get the list of cars in between range price");
        waitForElementPresent(driver, rangeCashPriceList, 2);
        List<WebElement> priceCarList = driver.findElements(rangeCashPriceList);
        return priceCarList;
    }

    public void clickReset(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            Thread.sleep(500);
            clickElement(driver, resetButton, 10);
            NodeORSubNode.log(Status.INFO, "Clicked on Reset");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Reset", e);
        }
        //Thread.sleep(3000);
    }

    public void clickValidate(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, validateBtn, 5);
            NodeORSubNode.log(Status.INFO, "Clicked on Validate Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Validate Button", e);
        }
    }

    public void clickFilter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            //if(isElementPresent(driver,By.className("header"))!=true) {
            Thread.sleep(3000);
            scrollToTop(driver);
            Thread.sleep(500);
            clickElement(driver, filterBtn, 10);
            NodeORSubNode.log(Status.INFO, "Clicked on Filter");
            //}
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Filter", e);
        }
        //Thread.sleep(2000);
    }
    public void clickFilterButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            //if(isElementPresent(driver,By.className("header"))!=true) {
            Thread.sleep(3000);
            scrollToTop(driver);
            Thread.sleep(500);
            clickElement(driver, filterButton, 10);
            NodeORSubNode.log(Status.INFO, "Clicked on Filter");
            //}
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Filter", e);
        }
        //Thread.sleep(2000);
    }


    public void clickRetourBtn() throws InterruptedException {
        clickElement(driver, retourBtn);
        Thread.sleep(3500);
    }

    public String getLegalText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            str = getAnyText(driver, legalText);
            NodeORSubNode.log(Status.INFO, "Got Legal Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get Legal Text", e);
        }
        return str;
    }

    public String getPrixCataloguePrice() {
        System.out.println("get prix catalogue price");
        return getAnyText(driver, prixCatalogPrice).trim();
    }

    public String getPromotionalAmount(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            str = getAnyText(driver, promotionalAmount).trim();
            System.out.println("Got promotional price: " + str);
            NodeORSubNode.log(Status.INFO, "Got promotional price: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get promotional price", e);
        }
        return str;
    }

    public String getPrixCataloguePrice_InfoPopup(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            str = getAnyText(driver, prixCatalogPrice_InfoPopup).trim();
            System.out.println("Got prix catalogue price on info popup: " + str);
            NodeORSubNode.log(Status.INFO, "Got prix catalogue price on info popup: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get prix catalogue price on info popup", e);
        }
        return str;
    }

    public String getMonthlyPrice_InfoPopup(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            str = getAnyText(driver, monthlyPriceInformationPage_ES, 2).trim();
            System.out.println("Got monthly price on info popup: " + str);
            NodeORSubNode.log(Status.INFO, "Got monthly price on info popup: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get monthly price on info popup", e);
        }
        return str.substring(0,str.length()-1);
    }

    public String getPromotionalAmount_InfoPopup(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            str = getAnyText(driver, promotionalAmount_InfoPopup).trim();
            System.out.println("Got promotional price on info popup: " + str);
            NodeORSubNode.log(Status.INFO, "Got promotional price on info popup: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Get promotional price on info popup", e);
        }
        return str;
    }

    public void clickInfoPopupBtn(String country, String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            if (country.equalsIgnoreCase("FR")) {
                clickElement(driver, infoPopupBtn_FR, 8);
            }
            if (country.equalsIgnoreCase("ES")) {
                clickElement(driver, infoPopupBtn_ES,8);
            }

            NodeORSubNode.log(Status.INFO, "Clicked on Info Pop-up Button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to clicked on Info Pop-up Button", e);
        }
        //Thread.sleep(3500);
    }

    public boolean validateInfoPopup(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        boolean bool = false;
        try {
            if (isElementPresent(driver, ErrorPopup, 4)) {
                NodeORSubNode.log(Status.WARNING, "Error Info Popup is present");
                bool = true;
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with Error Info Popup", e);
        }
        //Thread.sleep(3500);
        return bool;
    }

    public void selectEnergyFilter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, energyFilter);
            NodeORSubNode.log(Status.INFO, "Clicked on Energy Filter");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Energy Filter", e);
        }
    }

    public void selectGearFilter(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, gearFilter, 5);
            NodeORSubNode.log(Status.INFO, "Selected Gear Filter");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to select Gear Filter", e);
        }
        //Thread.sleep(3500);
    }

    public String getEnergyText(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            System.out.println("get energy text");
            str = getAnyText(driver, energyFilter).trim();
            NodeORSubNode.log(Status.INFO, "Got Energy Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to get energy text", e);
        }
        return str;
    }

    public String getGearText(String resultDirectory, ExtentTest NodeORSubNode) {

        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            System.out.println("get gear text");
            str = getAnyText(driver, gearFilter, 10).trim();
            NodeORSubNode.log(Status.INFO, "Got GearBox Text: " + str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error in getting gearbox text", e);
        }
        return str;
    }

    public void selectFinanceVehicle(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, financeVehicle, 10);
            System.out.println("Selected finance vehicle on Trim page");
            NodeORSubNode.log(Status.INFO, "Selected finance vehicle on Trim page");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to select finance vehicle on Trim page", e);
        }
        //Thread.sleep(3500);
    }

    public void clickLogoLink(String resultDirectory, ExtentTest logger) throws InterruptedException {
        try {
            clickElement(driver, logoLink);
            System.out.println("Clicked on logo link");
            logger.log(Status.INFO, "Clicked on logo link on Trim page");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, logger, driver, "Unable to select finance vehicle on Trim page", e);
        }
        //Thread.sleep(3500);
    }

    public void fillNotificationForm(String brand, String country, String postalCode, String email, String name,
                                     String phone, String address) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            System.out.println("Fill Notification Form");
            clickElement(driver, notificationButton);
            CheckNotificationForm.notificationForm.log(Status.INFO, "Clicked on Notification Form button");
            Thread.sleep(1500);

            if (!country.equalsIgnoreCase("UK")) {
                waitForElementClickable(driver, postalCodeField);
                clickUsingJS(driver, civilityBox);
                Thread.sleep(2000);
                clickUsingJS(driver, civilityBox);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Clicked on civilityBox");
                //Thread.sleep(1000);
                enterText(driver, postalCodeField, postalCode);
                System.out.println("PostalCodeField");
                CheckNotificationForm.notificationForm.log(Status.INFO, "Clicked on Postal Code Field");
                //Thread.sleep(1000);
                clickElement(driver, emailFieldCheckBox);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Clicked on Email Field CheckBox");
                //Thread.sleep(1000);
            }
            //Thread.sleep(1000);
            enterData(driver, firstNameField, name);
            System.out.println("FirstNameField");
            CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in First Name field");
            //Thread.sleep(1000);
            enterData(driver, lastNameField, name);
            System.out.println("LastNameField");
            CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Last Name Field");
            //Thread.sleep(1000);
            enterData(driver, phoneNumberField, phone);
            System.out.println("PhoneNumberField");
            CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Phone Number Field");
            //Thread.sleep(1000);
            enterData(driver, emailField, email);
            System.out.println("EmailField");
            CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Email Field");
            //Thread.sleep(1000);

            if (country.equalsIgnoreCase("UK") && !brand.equalsIgnoreCase("VX")) {
                enterData(driver, postalCodeField, postalCode);
                //Thread.sleep(1000);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Postal Code Field");
                enterData(driver, adressField, address);
                //Thread.sleep(1000);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Address Field");
                enterData(driver, townField, postalCode);
                //Thread.sleep(1000);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Postal Field");
                clickElement(driver, emailFieldCheckBox_UK);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Email Field");
                //Thread.sleep(1000);
            } else if (country.equalsIgnoreCase("UK") && brand.equalsIgnoreCase("VX")) {
                enterData(driver, postalCodeFieldUK, postalCode);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Postal Code Field");
                //Thread.sleep(1000);
                clickElement(driver, emailFieldCheckBox_UKVX);
                //Thread.sleep(1000);
                CheckNotificationForm.notificationForm.log(Status.INFO, "Entered in Email Field");
            }

            clickElement(driver, submitButton);
            System.out.println("submit button");
            CheckNotificationForm.notificationForm.log(Status.INFO, "Click on Submit Button");
            //Thread.sleep(2000);
            //Validating form submission

            if (isElementPresent(driver, notifMsg)) {
                CheckNotificationForm.notificationForm.log(Status.PASS, "Notification Form is submitted");
                if (getAnyText(driver, notifMsg, 5) != null) {
                    CheckNotificationForm.notificationForm.log(Status.PASS, "Form Submission Message is: " + getAnyText(driver, notifMsg));
                } else {
                    CheckNotificationForm.notificationForm.log(Status.FAIL, "Form Submission message could not be displayed");
                }
            } else {
                CheckNotificationForm.notificationForm.log(Status.PASS, "Notification Form Message could not be displayed");
            }

            clickElement(driver, closeFormButton, 10);
            System.out.println("Clicked on Close Model window Button");
            CheckNotificationForm.notificationForm.log(Status.INFO, "Clicked on Close Model window Button");
            //Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
