package solRetailIHM.PageObjectModel;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.List;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ChooseVehicleVersion extends UniversalMethods {
    WebDriver driver = null;
    By PersonalizeBtn_FR = By.linkText("PERSONNALISEZ*");
    By PersonalizeBtn_UK = By.linkText("PERSONALISE");
    By ConfigurerBtn = By.linkText("CONFIGURER");
    By PersonalizeOffer = By.linkText("PERSONALISE OFFER");

    By configPageFinnancePrice = By.className("financeContainer-price");
    By backToTrimPage = By.className("topnavbar-returnlink__text");

    By VehiculeTypeOffers = By.xpath("//*[@data-testid='TESTING_ENABLED_TRIM']");
    By VehiculeTypeNext = By.xpath("//*[@data-testid='TESTING_NEXT_BTN']");
    By VehiculeTypeButton = By.xpath("//button[starts-with(@id,'TESTING_GO_TO_DETAIL_')]");

    By ViewVehicleTypeBtn = By.id("TESTING_GO_TO_DETAIL_0");
    //By trimContinueBtn = By.xpath("//div[@class='links']/following-sibling::div[@class='button']/button");
    //By trimContinueBtn = By.id("TESTING_TO_BASKET_BOX_INTERESTEDBOX");
    //By trimContinueBtn = By.xpath("//div[@class='buttonSection']/div[@class='button']/button");
    By trimContinueBtn = By.xpath("//*[@data-testid='TESTING_TO_CONFIG_BOX_ORDERPANEL']|//*[@data-testid='TESTING_TO_BASKET_BOX_INTERESTEDBOX']");
    //By ViewVehicleTypeBtn = By.id("TESTING_TO_BASKET_BOX");

    UniversalMethods un = new UniversalMethods();

    public ChooseVehicleVersion(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isPresentConfigPageFinnancePrice() throws InterruptedException {
        return isElementPresent(driver, configPageFinnancePrice);
    }

    public void clickBackToTrimPage() throws InterruptedException {

        System.out.println("Go back to trim page");
        clickElement(driver, backToTrimPage);
    }

    public void clickViewVehicleType(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //un.scroling(driver, ViewVehicleTypeBtn);
        try {
            clickElement(driver, ViewVehicleTypeBtn);
            System.out.println("Clicked on view vehicle type button");
            NodeORSubNode.log(Status.INFO, "Clicked on view vehicle type button");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on view vehicle type button", e);
        }
        //driver.findElement(ViewVehicleTypeBtn).click();
    }

    public void navigateToConfigPage(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        //scrollIntoView(driver, trimContinueBtn);
        try {
            if(isElementPresent(driver,trimContinueBtn)) {
                clickElement(driver, trimContinueBtn);
                System.out.println("Clicked on Continue button on Trim page");
                NodeORSubNode.log(Status.INFO, "Clicked on Continue button on Trim page");
            }
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to Click on Continue button on Trim page", e);
        }
    }

//    public void validateTrimAndConfigPagePrices(String resultDirectory, ExtentTest NodeORSubNode, String PaymentMode) {
//        try {
//            float trimPageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
//            float configPageCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//*[@data-testid='TESTING_SELECTOR_CASH_PRICE'] | //*[@data-testid='TESTING_CONFIG_CASH_PRICE']")).replace(",", "."));
//            if (configPageCashPrice - trimPageCashPrice < 1) {
//                NodeORSubNode.log(Status.PASS, "Trim Page cash price " + trimPageCashPrice + " is same as Config page cash price");
//            } else {
//                NodeORSubNode.log(Status.FAIL, "Trim Page cash price " + trimPageCashPrice + " is not same as Config page cash price");
//            }
//            if (PaymentMode.equalsIgnoreCase("Finance")) {
//
//                float trimPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
//                float configPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//*[@data-testid='TESTING_SELECTOR_FINANCE_PRICE']")).replace(",", "."));
//
//                if (configPageFinancePrice - trimPageFinancePrice < 1) {
//                    NodeORSubNode.log(Status.PASS, "Trim Page Finance price" + trimPageFinancePrice + " is same as config page finance price");
//                } else {
//                    NodeORSubNode.log(Status.FAIL, "Trim page Finance price" + trimPageFinancePrice + " is not same as config page finance price");
//                }
//            }
//        } catch (Exception e) {
//            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate prices", e);
//        }
//    }

    public void validateTrimAndConfigPagePrices(String resultDirectory, ExtentTest NodeORSubNode, String PaymentMode) {
        try {
            float trimPageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
            float configPageCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//*[@data-testid='TESTING_SELECTOR_CASH_PRICE'] | //*[@data-testid='TESTING_CONFIG_CASH_PRICE']")).replace(",", "."));
            if (configPageCashPrice - trimPageCashPrice < 1) {
                NodeORSubNode.log(Status.PASS, "Trim Page cash price " + trimPageCashPrice + " is same as Config page cash price");
            } else {
                NodeORSubNode.log(Status.FAIL, "Trim Page cash price " + trimPageCashPrice + " is not same as Config page cash price");
            }
            if (PaymentMode.equalsIgnoreCase("Finance")) {

                float trimPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
                float configPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//*[@data-testid='TESTING_SELECTOR_FINANCE_PRICE']")).replace(",", "."));

                if (configPageFinancePrice - trimPageFinancePrice < 1) {
                    NodeORSubNode.log(Status.PASS, "Trim Page Finance price" + trimPageFinancePrice + " is same as config page finance price");
                } else {
                    NodeORSubNode.log(Status.FAIL, "Trim page Finance price" + trimPageFinancePrice + " is not same as config page finance price");
                }
            }
        } catch (Exception e){
            catchFailDetails(resultDirectory,NodeORSubNode,driver,"Unable to validate prices",e);
        }
    }

    public void clickPersonalizeBtn(String Country) throws InterruptedException {
        try {
            if (Country.equalsIgnoreCase("FR")) {
                if (!driver.getCurrentUrl().contains("citroen")) {
                    System.out.println("Clicked on Personalize Button");
                    clickElement(driver, PersonalizeBtn_FR);
                } else {
                    System.out.println("Clicked on Configurer Button");
                    clickElement(driver, ConfigurerBtn);
                }
            }
            if (Country.equalsIgnoreCase("UK")) {
                if ((!driver.getCurrentUrl().contains("citroen")) && (!driver.getCurrentUrl().contains("ds"))) {
                    System.out.println("Clicked on Personalize Button");
                    clickElement(driver, PersonalizeBtn_UK);
                } else {
                    System.out.println("Clicked on Personalize Button");
                    clickElement(driver, PersonalizeOffer);
                }


            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void clickSelectFinanceOfferType(String Country, ExtentTest logger) throws InterruptedException {
        try {
            driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
            List<WebElement> allEle = driver.findElements(VehiculeTypeOffers);
            for (int i = 0; i <= (allEle.size() - 1); i++) {
                System.out.println("The whole text of the brand is: " + allEle.get(i).getText());
                Boolean clickBrand = false;
                if (Country.equalsIgnoreCase("FR")) {
                    clickBrand = (allEle.get(i).getText().contains("TTC")) && ((allEle.get(i).getText().contains("TTC/MOIS")) || (allEle.get(i).getText().contains("TTC/mois")));
                }
                if (Country.equalsIgnoreCase("UK")) {
                    clickBrand = (allEle.get(i).getText().contains("OTR")) && ((allEle.get(i).getText().contains("pm")) || (allEle.get(i).getText().contains("PM")));
                }

                if (clickBrand) {

                    scroling(driver, By.id("TESTING_GO_TO_DETAIL_" + i));
                    boolean present = isPresentConfigPageFinnancePrice();
                    System.out.println(" isPresentConfigPageFinnancePrice : " + present);
                    if (present) {
                        break;
                    }
                    if (!present) {
                        clickBackToTrimPage();
                        if (i < (allEle.size() - 1)) {
                            clickElement(driver, VehiculeTypeNext);
                        }

                    }

                } else {
                    if (i < (allEle.size() - 1)) {
                        clickElement(driver, VehiculeTypeNext);
                    } else {
                        logger.log(Status.FAIL, "Finance vehicle type has not appeared");
                        driver.quit();
                        org.testng.Assert.fail();
                    }

                }


            }
        } catch (Exception e) {
            e.printStackTrace();
            //failWithScreenshot("Error while selecting finance offer type",driver,logger);
            //catchFailDetails(resultDirectory, logger,driver, "Error while selecting finance offer type",e);
        }

    }
}


 //   public void validateBasketPageandDelaerpagePrices(String resultDirectory, ExtentTest NodeORSubNode, String PaymentMode) {
//       Float dealerPageCashPrice = null;
//        writeToProperties("currentCashPrice", String.valueOf(dealerPageCashPrice));
//        try {
//            Float dealerpageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
//            Float basketPageCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//div[@data-testid='TESTING_TOTAL_CASH_PRICE']")));
//            if (dealerpageCashPrice - basketPageCashPrice < 1) {
//                NodeORSubNode.log(Status.PASS, "dealer page Cash price " + dealerpageCashPrice + "is same as basket page cash price");
//            } else {
//                NodeORSubNode.log(Status.FAIL, "dealer Page Cash Price" + dealerpageCashPrice + "is not same as basket page cash price");
//            }
//
//            if (PaymentMode.equalsIgnoreCase("Finance")) {
//                Float dealerPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
//                Float basketPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@data-testid='TESTING_TOTAL_MONTHLY_PRICE']")));
//                if (dealerPageFinancePrice - basketPageFinancePrice < 1) {
//                    NodeORSubNode.log(Status.PASS, "dealer page Finance price " + dealerPageFinancePrice + "is same as basket page finance price");
//                } else {
//                    NodeORSubNode.log(Status.FAIL, "dealer Page Finance Price" + dealerPageFinancePrice + "is not same as basket page finance price");
//                }
//            }
//        } catch (Exception e) {
//            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to validate prices of delaer and basket", e);
//        }
//    }
//}



