package solRetailIHM.PageObjectModel;

import java.awt.AWTException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;

import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.UserRegistration.registerUser;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class RegistrationPage extends UniversalMethods {
    WebDriver driver = null;

    By registrationButton = By.xpath("//button[@data-testid='TESTING_REGISTER']");
    By emailTextbox = By.xpath("//*[@id='email'] | (//*[@gigya-default-aria-label='Email'])[3]");
    //By emailTextbox = By.xpath("(//*[@gigya-default-aria-label='Email'])[3]");
    By passwordTextbox = By.xpath("(//input[@name='password'])[6] | //input[@id='password']");
    By passwordConfirmTextbox = By.xpath("(//input[@name='passwordRetype'])[6] | //input[@id='passwordConfirm']");
    By lastNameTextbox = By.xpath("//*[@id='USR_LAST_NAME'] | (//*[@gigya-default-aria-label=\"Last name\"])[3] | (//input[@name='profile.lastName'])[4]");
    By firstNameTextbox = By.xpath("//*[@id='USR_FIRST_NAME'] | (//*[@gigya-default-aria-label=\"First name\"])[3] | (//input[@name='profile.firstName'])[4]");
    By radmarketing=By.xpath("(//div//input[@name='preferences.marketing.isConsentGranted'])[7]");
    By radprofiling=By.xpath("(//div//input[@name='preferences.profiling.isConsentGranted'])[7]");
    By radthirdPartiesMarketing=By.xpath("(//div//input[@name='preferences.thirdPartiesMarketing.isConsentGranted'])[7]");
    By validateBtn = By.xpath("(//input[@type='submit' and @class='gigya-input-submit'])[17] | //input[@id='submit']");
    By continueBtn = By.xpath("//a[@class='btn btn-primary']");
    By headerMessage = By.xpath("//div[@id='page_title ']/h2");
    //By emailErrorMsg = By.className("mail-error");
    By emailErrorMsg = By.xpath("//*[(@class='errors')] | //*[(@class='errorMessage')]/li | (//*[@data-bound-to='email'])[9]| //*[contains(@class, 'gigya-error-type-server')]");
    //By emailErrorMsg = By.xpath("(//*[@data-bound-to='email'])[9]");
    //By captchaVerifyButton=By.xpath("//*[@id='recaptcha-verify-button']");
    //By popUp=By.xpath("//*[@id='rc-imageselect']");
    By okButton=By.xpath("//*[@class='gigya-button']");
    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickOnAccountRegisterButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            waitForElementClickable(driver,registrationButton,10);
            clickElement(driver, registrationButton,8);
            System.out.println("Registration Button Clicked");
            NodeORSubNode.log(Status.INFO, "Registration Button Clicked");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Error with clicking on Registration Button", e);
        }

    }

    public String fillRegistrationForm(String country, String brand, String resultDirectory, ExtentReports extent, ExtentTest logger) throws InterruptedException, IOException, AWTException {
        //String Email = "Testsolretail" + (Math.floor(Math.random() * (+10000000 + 1 - +1)) + +1 )+ "@yopmail.com";
        String email = null;
        ExtentTest fillForm=registerUser.createNode("RegisterUserPage","User registration Form");
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            int randomNo = generateRandomNumber();
            System.out.println(country+brand+randomNo);
            email = "Testretail" + country.toLowerCase() + brand.toLowerCase() + randomNo + "@yopmail.com";
            System.out.println(email);
            String password = "This@9124";
            String lastName = "Telly";
            String firstName = "Talker";
            if(country.equalsIgnoreCase("ES")){
                waitForUrlContains("/gigya/", driver, 10);
            }else {
                waitForUrlContains("/account/", driver, 10);
            }
            Thread.sleep(2000);
            //driver.switchTo().defaultContent();
            waitForElementClickable(driver,emailTextbox,10);
            fillForm.log(Status.INFO, "Entering email into email Text Box");
            enterData(driver, emailTextbox, email.toLowerCase(),10);
            writeToProperties("RegisterEmail", email);
            fillForm.log(Status.INFO, "Entering password into password Text Box");
            enterData(driver, passwordTextbox, password);
            writeToProperties("RegisterPassword", password);
            fillForm.log(Status.INFO, "Entering confirm password into confirm password Text Box");
            enterData(driver, passwordConfirmTextbox, password);
            fillForm.log(Status.INFO, "Entering First Name");
            enterData(driver, firstNameTextbox, firstName);
            fillForm.log(Status.INFO, "Entering Last Name");
            enterData(driver, lastNameTextbox, lastName);
            fillForm.log(Status.INFO, "Clicked on Marketing Radio Button");
            clickElement(driver,radmarketing);
            fillForm.log(Status.INFO, "Clicked on Profiling Radio Button");
            clickElement(driver,radprofiling);
            fillForm.log(Status.INFO, "Clicked on third Parties Marketing Radio Button");
            clickElement(driver,radthirdPartiesMarketing);
            fillForm.log(Status.INFO, "Clicked on third Parties Marketing Radio Button");
            String url1=driver.getCurrentUrl();
            clickElement(driver, validateBtn);
            Thread.sleep(2000);
                if(isElementPresent(driver,okButton)){
                    clickElement(driver,okButton);
                    fillForm.log(Status.PASS,"OK button clicked");
                } else{
                    driver.quit();
                }
            String url2=driver.getCurrentUrl();
            if(url1.equalsIgnoreCase(url2)){
                fillForm.log(Status.FAIL, "Registration could not be done");
                failWithScreenshot("Test Failed while Registering User", resultDirectory, driver, extent, fillForm);
                driver.quit();
            }else{
                fillForm.log(Status.PASS, "Registration could not be done");
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, fillForm,driver, "Test Failed while Registering User",e);
        }

        return email;
    }

    public void clickOnValidateButton() throws InterruptedException {
        clickElement(driver, validateBtn);
        System.out.println("Validate button clicked");
        Thread.sleep(500);
    }

    public String getHeaderMessage(String resultDirectory, ExtentTest NodeORSubNode) {
        String str = null;
        try {
            driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
            str = getAnyText(driver, headerMessage);
            NodeORSubNode.log(Status.INFO, "Got the Header Message: "+str);
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get the Header Message: ",e);
        }
        return str;
    }

    public void clickOnContinueButton(String resultDirectory, ExtentTest NodeORSubNode) throws InterruptedException {
        try {
            clickElement(driver, continueBtn);
            System.out.println("Continue button clicked");
            NodeORSubNode.log(Status.INFO, "Continue button clicked");
        } catch (Exception e) {
            catchFailDetails(resultDirectory, NodeORSubNode, driver, "Unable to click on Continue button", e);
        }
    }

    public String getExistingUserEmailErrorMessage(String email) {
        String errorMsg = "";
        try {
            enterData(driver, emailTextbox, email);
            Thread.sleep(500);
            clickElement(driver, firstNameTextbox);
            Thread.sleep(500);
            errorMsg = getAnyText(driver, emailErrorMsg);
        } catch (Exception e) {

        }
        return errorMsg;
    }

}
