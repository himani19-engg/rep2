package solRetailIHM.PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class FinancialWidgetPage extends UniversalMethods {
	WebDriver driver = null;
	
	By FinancialButton = By.xpath("//* [@class ='financeContainer__personalize'] / span[1]");
	By PackdgeListe = By.id("package-list_container");
    By MonthChoose = By.xpath("//* [@class = 'repaymentPeriod-container-body '] / div[1]");
    By AnnualMileage = By.xpath("//* [@class = 'rc-slider rc-slider-with-marks  ']/ div[3]/ span[2]");
    By AssuranceSouscription = By.xpath("//* [@id = 'assurances-container'] /div[3]//span/span");
    By ConcentButton = By.xpath("//* [@id = 'assurances-container'] /div[4]//span/span");
    By ConfirmButton = By.xpath("//* [@id= 'Fipsa-button-action']/button");
    By ConfirmButtonVX = By.xpath("(//* [@class= 'ovfSimWid-btn'])[2]");
	
	public FinancialWidgetPage(WebDriver driver) {
		this.driver = driver;
	}
	

	
	public void ClickOnFinantialButton() throws InterruptedException {
		System.out.println("Clicked on change financial info");
		Thread.sleep(2000);
		clickUsingJS(driver, FinancialButton);
		Thread.sleep(2000);
	}
	
	public void ChooseMonthPeriod() throws InterruptedException {
		System.out.println("Month period chosen");
		Thread.sleep(2000);
		clickElement(driver, MonthChoose);
		Thread.sleep(2000);
	}
	
	public void ChooseAnnualMileage() throws InterruptedException {
		System.out.println("Annual Mileage choosen");
		Thread.sleep(2000);
		clickElement(driver, AnnualMileage);
		Thread.sleep(2000);
	}
	
	public void SubscribeAssurance() throws InterruptedException {
		System.out.println("Assurance not subscribed");
		Thread.sleep(2000);
		clickElement(driver, AssuranceSouscription);
		Thread.sleep(2000);
		clickElement(driver, ConcentButton);
		Thread.sleep(2000);
	}
	
	public void ClickOnContinue(String Brand) throws InterruptedException {
		System.out.println("Continue Button Clicked");
		Thread.sleep(2000);
		if (Brand.equals("VX")) {
		clickElement(driver, ConfirmButtonVX);
		Thread.sleep(2000);}
		
		else {
			clickElement(driver, ConfirmButton);
			Thread.sleep(2000);}	
		}
	}
	

	

	
	
	
