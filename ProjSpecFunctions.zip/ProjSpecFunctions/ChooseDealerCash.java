package solRetailIHM.ProjSpecFunctions;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.ChooseDealerPage;
import solRetailIHM.PageObjectModel.CookieAccepter;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ChooseDealerCash extends UniversalMethods {
    public static String StrPOSPV;
    public static ExtentTest searchingAndSelectingRetailer;
    public static ExtentTest blueUnderLineTab;
    public static ExtentTest footerCheck;
    public static ExtentTest sidePanel;
    public static ExtentTest retailerData;
    public static ExtentTest retailer;
    public static ExtentTest footer;

    public static String RetailerToBeSelected;

    public static String[] eachText;

    public static String [] selectedDealerCleanAddress_BP_ES;

    public static ExtentTest navigateToBasketAndValidation;



    @Test(description = "validating URL Blue UnderLine and Title")
    public static void validateURLBlueUnderLineTitle(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                     ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage)
            throws Exception {
        blueUnderLineTab = searchingAndSelectingRetailer.createNode("DealerPage-BlueUnderLine", "Checking Dealer page Blue Underline");
        try {
            driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
            PersonnalInfoPage pi = new PersonnalInfoPage(driver);
            ChooseDealerPage dea = new ChooseDealerPage(driver);
            //SoftAssert sa=new SoftAssert();
            // check arrival on choose dealer page
            if (!Brand.equals("OV")) {
                Thread.sleep(9000);
				/*if (Country.equals("FR")) {
					waitForUrlContains("/personnal-information", driver, 15);
					if(driver.getCurrentUrl().contains("personnal-information")){
						searchingAndSelectingRetailer.log(Status.PASS, "personnal-information is found in the current URL");
					}else{
						searchingAndSelectingRetailer.log(Status.FAIL, "personnal-information is not found in the current URL");
					}
				} else {*/

                waitForUrlContains("/point-vente", driver, 60);
                WebDriverWait wait = new WebDriverWait(driver,50);
                wait.until(ExpectedConditions.urlContains("point-vente"));
                if (driver.getCurrentUrl().contains("point-vente")) {
                    blueUnderLineTab.log(Status.PASS, "point-vente is found in the current URL");
                } else {
                    blueUnderLineTab.log(Status.FAIL, "point-vente is not found in the current URL");
                }

                //Total Number of Tabs present
                List<WebElement> allTabs=driver.findElements(By.xpath("//div[contains(@class, 'breadcrumb-pagination')]/div[contains(@class, '-step ng-star-inserted')] | //div[contains(@class, '-step ng-star-inserted')]/div[2] | //div[@class='container']//button//span[@class='title']"));
                System.out.println("Total Number of Tabs available: "+ (allTabs.size()-1));
                blueUnderLineTab.log(Status.INFO, "Total Number of Tabs available: "+ (allTabs.size()-1));
                for (int i=0;i<allTabs.size();i++) {
                    String str = allTabs.get(i).getText();
                    if (i == 0) {
                        if (str.contains("Punto de venta") ||str.contains("Punto de venta".toUpperCase(Locale.ROOT))|| str.contains("Pay")) {
                            System.out.println("Tab " + (i + 1) + " is: " + str);
                            blueUnderLineTab.log(Status.PASS, "Tab " + (i + 1) + " is: " + str);
                        } else {
                            System.err.println("Punto de venta/Pay Tab is not available");
                            blueUnderLineTab.log(Status.FAIL, "Punto de venta/Pay Tab is not available");
                        }
                    } else if (i == 1) {
                        if (str.contains("Identificación") ||str.contains("Identificaci") || str.contains("Identificación".toUpperCase(Locale.ROOT)) || str.contains("Appraisal")) {
                            System.out.println("Tab " + (i + 1) + " is: " + str);
                            blueUnderLineTab.log(Status.PASS, "Tab " + (i + 1) + " is: " + str);
                        } else {
                            System.err.println("Identificación/Appraisal Tab is not available");
                            blueUnderLineTab.log(Status.FAIL, "Identificación/Appraisal Tab is not available");
                        }
                    } else if (i == 2) {
                        if (str.contains("Recapitulativo") || str.contains("Recapitulativo".toUpperCase(Locale.ROOT)) || str.contains("additional costs") || str.contains("Resumen")) {
                            System.out.println("Tab " + (i + 1) + " is: " + str);
                            blueUnderLineTab.log(Status.PASS, "Tab " + (i + 1) + " is: " + str);
                        } else {
                            System.err.println("Recapitulativo/additional costs Tab is not available");
                            blueUnderLineTab.log(Status.FAIL, "Recapitulativo/additional costs Tab is not available");
                        }
                    } else {
                        if (str.contains("@"+Brand+".es-ES.FO.BREADCRUMB.bankprocessing.label") || str.contains("Complements") || str.contains("Mi pago") || str.contains("Mi pago".toUpperCase(Locale.ROOT))|| str.contains("Financiero solicitud") || str.contains("Confirmación")) {
                            System.out.println("Tab " + (i + 1) + " is: " + str);
                            blueUnderLineTab.log(Status.PASS, "Tab " + (i + 1) + " is: " + str);
                        } else {
                            System.err.println("@"+Brand+".es-ES.FO.BREADCRUMB.bankprocessing.label/Complements/Mi pago Tab is not available");
                            blueUnderLineTab.log(Status.FAIL, "@"+Brand+".es-ES.FO.BREADCRUMB.bankprocessing.label/Complements/Mi pago Tab is not available");
                        }
                    }
                }
                //}
                //waitForUrlContains("/personnal-information", driver, 10);
                //waitForUrlContains("/point-vente", driver, 20);
                Thread.sleep(5000);
            }
            if ((!Brand.equalsIgnoreCase("DS") && !Brand.equalsIgnoreCase("OV")) ||
                    (Brand.equalsIgnoreCase("DS") && Country.equalsIgnoreCase("ES")
                            && PaymentMode.equalsIgnoreCase("Finance"))) {
                String dealerHeader = null;
                if (Brand.equals("OV"))
                    dealerHeader = dea.getDealerHeader_OV();
                else if (Brand.equals("AC"))
                    dealerHeader = dea.getDealerHeader_AC();
                else
                    dealerHeader = dea.getDealerHeader();

                if ((dealerHeader.contains("Point de vente"))
                        || (dealerHeader.contains("point de vente"))
                        || (dealerHeader.contains("POINT DE VENTE"))
                        || (dealerHeader.contains("PUNTO DE VENTA"))
                        || (dealerHeader.contains("Punto de venta"))) {
                    blueUnderLineTab.log(Status.PASS, dealerHeader + " page has appeared");
                } else {
                    failWithScreenshot("CHOOSE DEALER PAGE page has not appeared", resultDirectory, driver, extent, searchingAndSelectingRetailer);
                }

                By blueTab;

                if(Brand.equalsIgnoreCase("AC")!=true) {
                    blueTab = By.xpath("//div[contains(@class,\"current-step\")]");
                }else{
                    blueTab = By.xpath("(//div[contains(@class,\"current-step\")])[5]");
                }
                String blueTabText = getAnyText(driver, blueTab);

                if (blueTabText.contains("Point de vente")
                        || blueTabText.contains("point de vente")
                        || blueTabText.contains("POINT DE VENTE")
                        || blueTabText.contains("PUNTO DE VENTA")
                        || blueTabText.contains("Punto de venta")) {
                    System.out.println("Point of Sale Tab is Highlighted");
                    blueUnderLineTab.log(Status.PASS, blueTabText + " page has appeared with Blue underLine");
                } else {
                    blueUnderLineTab.log(Status.FAIL, blueTabText + " page has not appeared with Blue underLine");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "Validating Dealer Page Footer Links")
    public static void validateDealerPageFooterLinks(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                                     String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage)
            throws Exception {
        // Footer
        footerCheck(resultDirectory, driver, extent, logger, Brand, Country, VehicleChoice, Retailer);
        logger.log(Status.INFO, "Footer checked on Dealer page");
    }

    @Test(description = "Getting Side Panel of the Retailer Page")
    public static String getSidePanelString(String resultDirectory, WebDriver driver, ExtentReports extent,
                                            ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage)
            throws Exception {
        String strPOS = getAnyText(driver, By.className("bloc-recap-detail"));
        System.out.println("<==========================R.H.S. Point of Sale======================>");
        System.out.println(strPOS);
        System.out.println("<==========================R.H.S. Point of Sale======================>");

        return strPOS;
    }

    @Test(description = "Validating Side Panel of the Retailer Page with respect to Identification")
    public static void validateSidePanel(String resultDirectory, WebDriver driver, ExtentReports extent,
                                         ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage)
            throws Exception {
        sidePanel = searchingAndSelectingRetailer .createNode("DealerPage-SidePanel", "Checking Dealer page Side Panel");
        ChooseDealerPage dea = new ChooseDealerPage(driver);
        //Validation of the side Bar (R.H.S.)

        if (!Brand.equals("OV")) {
            if(isElementPresent(driver,By.xpath("//*[@class='main-title']"),5)) {
                System.out.println("Title is: "+getAnyText(driver,By.xpath("//*[@class='main-title']")));
                sidePanel.log(Status.PASS, "Title is available: "+" Choose your Dealer");
            }else{
                sidePanel.log(Status.FAIL, "Title is not available: "+" Choose your Dealer");
            }
            if(isElementPresent(driver,By.xpath("//figure//img[@class='img']"),5)) {
                System.out.println("Car Image Link is: "+driver.findElement(By.xpath("//figure//img[@class='img']")).getAttribute("src"));
                sidePanel.log(Status.PASS, "Car Image is available");
            }  else {
                sidePanel.log(Status.FAIL, "Car Image is available");
            }
        }

        StrPOSPV = getSidePanelString(resultDirectory, driver, extent,
                sidePanel, Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage);
        // get cash price and finance price
        if (!Brand.equals("OV")) {
            if (PaymentMode.equalsIgnoreCase("Cash")) {
                String cashPriceNo = dea.getCashPrice().split("€")[0].trim();
                dea.writeToProperties("dealear_CashPrice", cashPriceNo);
                sidePanel.log(Status.PASS, "Price displayed in right section : " + cashPriceNo);
            }

            if (PaymentMode.equalsIgnoreCase("Finance")) {
                if(dea.getFinancePrice()!=null) {
                    String financePriceNo = dea.getFinancePrice().split("€")[0].trim();
                    dea.writeToProperties("dealear_FinancePrice", financePriceNo);
                }
            }
        }
    }

    @Test(description = "validate Retailer data")
    public static void validateRetailerData(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                   ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage)
            throws Exception {

        //retailerData = searchingAndSelectingRetailer.createNode("DealerPage-Validating each Retailer", "Checking each Retailer");
        //Write code for validating Retailer's data
        waitForPageToLoad(driver,5);
        waitForElementClickable(driver, By.id("dealers_list"), 60);
        //Thread.sleep(3000);
        scrollToTop(driver);
        List<WebElement> allRetailers = driver.findElements(By.xpath("//div[@class='dealers_sheet']"));
        if (allRetailers.size() > 1) {
            System.out.println("Retailer is visible and List of Retailers are available: " + allRetailers.size());
            logger.log(Status.PASS, "List of Retailers are available: " + allRetailers.size());
        } else {
            System.err.println("Retailer is not visible as the List of Retailers are not available");
            logger.log(Status.FAIL, "Retailer is not visible as the List of Retailers are not available");
        }

        for (int i = 0; i < allRetailers.size(); i++) {
            String allTexts = getAnyText(driver, By.xpath("(//div[@class='dealers_sheet'])[" + (i + 1) + "]"));
            if(i==0){
                RetailerToBeSelected=allTexts;
            }
            scrollIntoView(driver, By.xpath("(//div[@class='dealers_sheet'])[" + (i + 1) + "]"));
            eachText = allTexts.split("\\r?\\n");
            System.out.println("Length is: " + eachText.length);
            if ((eachText.length == 6)||(eachText.length == 5)) {
                System.out.println("All required elements are available in the grid: " + (i + 1));
                logger.log(Status.PASS, "All required elements are available in the grid: " + (i + 1));
            } else {
                System.err.println("All required elements are not available in the grid: " + (i + 1));
                logger.log(Status.FAIL, "All required elements are not available in the grid: " + (i + 1));
            }

            for (int k = 0; k < (eachText.length - 1); k++) {
                try {
                    //Validating Retailer's Name
                    System.out.println("Each Text is: " + eachText[k]);
                    if (k == 0) {
                        if (eachText[k] != null) {
                            System.out.println("Retailer Name is available in the grid: " + (i + 1));
                            logger.log(Status.PASS, "Retailer Name is available in the grid: " + (i + 1));
                        } else {
                            System.err.println("Retailer Name is not available in the grid: " + (i + 1));
                            logger.log(Status.FAIL, "Retailer Name is not available in the grid: " + (i + 1));
                        }
                    }

                    //Validating Retailer's distance
                    if ((k == 1 && eachText[k] != null)) {
                        System.out.println("Each Text is: " + eachText[k]);
                        if (eachText[k].contains("KM") || eachText[k].contains("Km")) {
                            logger.log(Status.PASS, "KM is available in the grid");
                            //System.out.println(Float.parseFloat(eachText[k].replace(" KM", "")));
                            //Float value=Float.parseFloat(eachText[k].replace(" KM", ""));
                            try {
                                if(eachText[k].contains("KM")) {
                                    Float.parseFloat(eachText[k].replace(" KM", ""));
                                    System.out.println(eachText[k].replace(" KM", "") + " is a valid Float");
                                }else{
                                    eachText[k] = eachText[k].replace(" Km", "");
                                    Float.parseFloat(eachText[k]);
                                    System.out.println(eachText[k].replace(" Km", "") + " is a valid Float");
                                }

                                System.out.println("Retailer distance is available in the grid: " + (i + 1));
                                logger.log(Status.PASS, "Retailer distance is available in the grid: " + (i + 1));
                            } catch (NumberFormatException e) {
                                if(Brand.equalsIgnoreCase("AC")!=true) {
                                    System.out.println(eachText[k].replace(" KM", "") + " is not a valid Float");
                                }else{
                                    System.out.println(eachText[k].replace(" Km", "") + " is not a valid Float");
                                }
                                System.err.println("Retailer distance in Float is not available in the grid: " + (i + 1));
                                logger.log(Status.FAIL, "Retailer distance in Float is not available in the grid: " + (i + 1));
                            }
                        } else {
                            System.err.println("Retailer distance (KM) is not available in the grid: " + (i + 1));
                            logger.log(Status.FAIL, "Retailer distance (KM) is not available in the grid: " + (i + 1));
                        }
                    }
                    //Validating Retailer's address
                    if (k == 2) {
                        System.out.println("Each Text is: " + eachText[k]);
                        if (eachText[k] != null) {
                            System.out.println("Retailer Address is available in the grid: " + (i + 1));
                            logger.log(Status.PASS, "Retailer Address is available in the grid: " + (i + 1));
                        } else {
                            System.err.println("Retailer Address is not available in the grid: " + (i + 1));
                            logger.log(Status.FAIL, "Retailer Address is not available in the grid: " + (i + 1));
                        }
                    }

                    //Validating Retailer's pincode and city
                    if (k == 3 && eachText.length>5) {
                        System.out.println("Each Text is: " + eachText[k]);
                        if (eachText[k] != null) {
                            System.out.println("Address is little long in the grid: " + (i + 1));
                            logger.log(Status.PASS, "Address is little long in the grid: " + (i + 1));
                        } else {
                            System.out.println("Address size is perfect in the grid: " + (i + 1));
                            logger.log(Status.FAIL, "Address size is perfect in the grid: " + (i + 1));
                        }
                    }

                    if ((k == 4 && eachText.length>5)||(k == 4 && eachText.length<=5)) {
                        System.out.println("Each Text is: " + eachText[k]);
                        if (eachText[k] != null && (isNumeric(eachText[k].substring(0, 3)))) {
                            System.out.println("Retailer Pincode and City is available in the grid: " + (i + 1));
                            logger.log(Status.PASS, "Retailer Pincode and City is available in the grid: " + (i + 1));
                        } else {
                            System.err.println("Retailer Pincode and City is not available in the grid: " + (i + 1));
                            logger.log(Status.FAIL, "Retailer Pincode and City is not available in the grid: " + (i + 1));
                        }
                    }

                    //Validating Retailer's Selection Button
                    if (k == 4 && eachText.length<=5) {
                        System.out.println("Each Text is: " + eachText[k]);
                        if (eachText[k].contains("Seleccionar")) {
                            System.out.println("Retailer Selection Button is available in the grid: " + (i + 1));
                            logger.log(Status.PASS, "Retailer Selection Button is available in the grid: " + (i + 1));
                        } else {
                            System.err.println("Retailer Selection Button is not available in the grid: " + (i + 1));
                            logger.log(Status.FAIL, "Retailer Selection Button is not available in the grid: " + (i + 1));
                        }
                    }

                    if (k == 5 && eachText.length>5) {
                        System.out.println("Each Text is: " + eachText[k]);
                        if (eachText[k].contains("Seleccionar")) {
                            System.out.println("Retailer Selection Button is available in the grid: " + (i + 1));
                            logger.log(Status.PASS, "Retailer Selection Button is available in the grid: " + (i + 1));
                        } else {
                            System.err.println("Retailer Selection Button is not available in the grid: " + (i + 1));
                            logger.log(Status.FAIL, "Retailer Selection Button is not available in the grid: " + (i + 1));
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    catchFailDetails(resultDirectory, logger, driver, "Test Failed with Validating each Retailer in the Map", e);
                }
            }

            System.out.println("<==========Checking Retailer Details for Retailer- " + (i + 1) + " ===============>");
            for (String str : eachText
            ) {
                System.out.println(str);
            }
            System.out.println("<==========Checking Retailer Details for Retailer- " + (i + 1) + " is done===============>");
        }
        //defaultRetailersAddress = getAnyText(driver,By.xpath("(//div[@class='dealers_sheet'])[1]"));
       // defaultRetailersAddress = defaultRetailersAddress.replaceAll("Seleccionar","");
        if(Country.equalsIgnoreCase("ES")){
            String defaultSelectedDealer= getAnyText(driver,By.xpath("(//div[@class='dealers_sheet'])[1]"));
            System.out.println("Default Selected Dealer's Unclean Address: ");
            System.out.println(defaultSelectedDealer);
            //selectedDealerCleanAddress_BP_ES = new String[]{defaultSelectedDealer.replace(".", "")};
            selectedDealerCleanAddress_BP_ES=defaultSelectedDealer.split("[\\r\\n]");
            selectedDealerCleanAddress_BP_ES=removeStringFromStringArray(selectedDealerCleanAddress_BP_ES,1);
            selectedDealerCleanAddress_BP_ES=removeStringFromStringArray(selectedDealerCleanAddress_BP_ES,2);
            selectedDealerCleanAddress_BP_ES=removeStringFromStringArray(selectedDealerCleanAddress_BP_ES,3);
            System.out.println("Default Selected Dealer's Clean Address: ");
            //navigateToBasketAndValidation.log(Status.INFO, "Default Selected Dealer's Clean Address: ");
            for(int i=0;i<selectedDealerCleanAddress_BP_ES.length;i++) {
                System.out.println(selectedDealerCleanAddress_BP_ES[i]);
                //navigateToBasketAndValidation.log(Status.INFO, selectedDealerCleanAddress_BP_ES[i]);
            }
        }


    }

    @Test(description = "verifying Retailer Page")
    public static void validateAndSelectRetailer(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                   ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage,String PersoV)
            throws Exception {
        retailer = searchingAndSelectingRetailer.createNode("DealerPage-Validating Retailer", "Validating and Selecting Retailer");
        ChooseDealerPage dea = new ChooseDealerPage(driver);
        try {

            if (!Brand.equals("OV")) {
                dea.enterCashRetailer(Retailer);
                retailer.log(Status.INFO, "Searched for retailer");
            }
            if(!(PersoV.equalsIgnoreCase("yes"))){
                validateRetailerData(resultDirectory, driver, extent,
                    retailer, Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage);
            }
            // Select Retailer
            dea.CashRetailerStore(Brand);
            retailer.log(Status.INFO, "Retailer has been selected");
            //Thread.sleep(3000);
            waitForPageToLoad(driver,5);

            if (Brand.equals("OV")) {
                dea.clickCashRetailerContinueBtn();
                retailer.log(Status.INFO, "Clicked on Cash Retailer Continue Button");
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, retailer, driver, "Test Failed with Validating And Selecting Retailer", e);
        }
    }

    @Test(description = "Searching And Selecting Retailer")
    public static void searchAndSelectRetailer(String resultDirectory, WebDriver driver, ExtentReports extent,
                                               ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage, String PersoV)
            throws Exception {
        String strIdentification;
        String strPOS = null;
        searchingAndSelectingRetailer = logger.createNode("ES-DealerPage", "Checking Dealer page Search and Select Retailer");
        try {
            ChooseDealerPage dea = new ChooseDealerPage(driver);
            PersonnalInfoPage pi = new PersonnalInfoPage(driver);
            IdentificationPageCash identity = new IdentificationPageCash();
            CookieAccepter accept = new CookieAccepter(driver);
            accept.clickContAccepter(resultDirectory, searchingAndSelectingRetailer);

            //Validation of the Header Title of the Tab with Blue UnderLine
            //Validation of the Side Bar (Right Hand Side)
            //Validation of the Footer
            //Validation of all dealers available in the result after search

            validateURLBlueUnderLineTitle(resultDirectory, driver, extent,
                    searchingAndSelectingRetailer, Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage);

            validateSidePanel(resultDirectory, driver, extent,
                    searchingAndSelectingRetailer, Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage);

            validateDealerPageFooterLinks(resultDirectory, driver, extent, searchingAndSelectingRetailer,
                    Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage);

            // Enter Retailer
            waitForPageToLoad(driver,5);
            //Thread.sleep(5000);
            validateAndSelectRetailer(resultDirectory, driver, extent,
                    searchingAndSelectingRetailer, Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage,PersoV);


            if (!VehicleChoice.equals("ec41")) {
                identity.validateIdentificationTab(resultDirectory, driver, extent,
                        searchingAndSelectingRetailer, Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage);
            }
        } catch (Exception e) {
			/*searchingAndSelectingRetailer.log(Status.FAIL,"Test Failed with searching And Selecting Retailer");
			failWithScreenshot("Test Failed with searching And Selecting Retailer", resultDirectory, driver, extent, searchingAndSelectingRetailer);
			searchingAndSelectingRetailer.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            e.printStackTrace();
            catchFailDetails(resultDirectory, searchingAndSelectingRetailer, driver, "Test Failed with searching And Selecting Retailer", e);
        }
    }


    @Test(description = "Checking footer")
    public static void footerCheck(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                   String Brand, String Country, String VehicleChoice, String Retailer) throws Exception {
        try {
            footer = searchingAndSelectingRetailer.createNode("DealerPage-Footer", "Checking Dealer page Footer");
            ChooseDealerPage dea = new ChooseDealerPage(driver);
            dea.clickFirstFooter(Brand);
            footer.log(Status.INFO, "Clicked on First Footer");
            ArrayList<String> tabs_windows = new ArrayList<String>(driver.getWindowHandles());
            ArrayList<String> tabs = new ArrayList<String>(tabs_windows);
            footer.log(Status.INFO, "Total Opened tabs are: " + tabs.size());
            if (tabs.size() == 2) {
                footer.log(Status.PASS, "Total 2 Tabs are Opened");
                driver.switchTo().window(tabs_windows.get(1));
                Thread.sleep(1000);
                driver.close();
                driver.switchTo().window(tabs_windows.get(0));
                footer.log(Status.INFO, "First footer checked");
            }else{
                footer.log(Status.FAIL, "Total Opened Tabs are Not equal to 2");
            }
            Thread.sleep(5000);
            dea.clickSecondFooter(Brand);
            footer.log(Status.INFO, "Clicked on Second Footer");
            ArrayList<String> tabs_windows1 = new ArrayList<>(driver.getWindowHandles());
            ArrayList<String> tabs1 = new ArrayList<>(tabs_windows1);
            footer.log(Status.INFO, "Total Opened tabs are: " + tabs1.size());
            if (tabs1.size() == 2) {
                footer.log(Status.PASS, "Total 2 Tabs are Opened");
                driver.switchTo().window(tabs_windows1.get(1));
                Thread.sleep(3000);
                driver.close();
                driver.switchTo().window(tabs_windows1.get(0));
                footer.log(Status.INFO, "Second footer checked");
                Thread.sleep(3000);
            }else{
                footer.log(Status.FAIL, "Total Opened Tabs are Not equal to 2");
            }
        } catch (Exception e) {
			/*failWithScreenshot("Test Failed with Footer Check", resultDirectory, driver, extent, logger);
			logger.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            catchFailDetails(resultDirectory, footer, driver, "Test Failed with Footer Check", e);
        }
    }
}
