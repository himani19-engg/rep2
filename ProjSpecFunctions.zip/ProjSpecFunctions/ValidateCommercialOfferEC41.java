package solRetailIHM.ProjSpecFunctions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.ChooseDealerPage;
import solRetailIHM.PageObjectModel.UserAccountPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ValidateCommercialOfferEC41 extends UniversalMethods {

    @Test(description = "Search And Select Retailer")
    public static void searchAndSelectRetailer(String resultDirectory, WebDriver driver, ExtentReports extent,
                                               ExtentTest logger, String Country, String PaymentMode, String VehicleChoice, String City, String Retailer,
                                               String EmailId, String Password) throws Exception {
        try {
            driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);

            ChooseDealerPage dea = new ChooseDealerPage(driver);

            UserAccountPage uap = new UserAccountPage(driver);
            //SoftAssert sa = new SoftAssert();

            // Select dealer
            dea.enterCity(City);
            dea.searchRetailer();
            logger.log(Status.INFO,
                    MarkupHelper.createLabel("Search for retailer at " + City + " location", ExtentColor.BLUE));
            Thread.sleep(2000);
            dea.SelectRetailer();
            logger.log(Status.INFO, MarkupHelper.createLabel("Retailler has been selected", ExtentColor.BLUE));

            // check dealer choosen

            String SelectedAddress = dea.DealerChoiceAdress();

            String PostSelectionAddress = dea.DealerDisplayAdress();

            if (SelectedAddress.contains(PostSelectionAddress)) {
                logger.log(Status.PASS, MarkupHelper.createLabel("Dealer has been selected", ExtentColor.GREEN));
                //sa.assertTrue(true);
            } else {
                failWithScreenshot("Dealer has not been selected", resultDirectory, driver, extent, logger);
                //sa.assertTrue(false, "Dealer has not been selected");
                //	driver.close();
            }

            // validate dealer choosen
            dea.DealerContinue();

            // Validate arriving on login page
            waitForUrlContains("/offers/login", driver, 120);
            logger.log(Status.INFO, MarkupHelper.createLabel("Dealer is validated", ExtentColor.BLUE));

            // Login
            //LoginUser.loginAccount(resultDirectory, driver, extent, logger, Country, PaymentMode, VehicleChoice,EmailId, Password);

            // Go to my account Page
            uap.OfferGoToMyAccount();

            waitForUrlContains("/my-account", driver, 120);
            logger.log(Status.INFO, MarkupHelper.createLabel("Go to my account", ExtentColor.BLUE));

            // View Saves offers
            uap.ViewSavedOffers();

            waitForUrlContains("/my-account/my-saves", driver, 120);
            logger.log(Status.INFO, MarkupHelper.createLabel("View saved offers", ExtentColor.BLUE));

            // Verify offer date
            if (uap.OfferDate()) {
                logger.log(Status.PASS, MarkupHelper.createLabel("Offer date is OK", ExtentColor.GREEN));
                //sa.assertTrue(true);
            } else {
                failWithScreenshot("Offer date is not OK", resultDirectory, driver, extent, logger);
                //sa.assertTrue(false, "Offer date is not OK");
                //driver.close();
            }

            // Verify offer Data
            uap.ViewSavedOffersDetail();

            String OfferDealerAddress = uap.DealerDisplayAdress();
            if (OfferDealerAddress.contains(SelectedAddress)) {
                logger.log(Status.PASS, MarkupHelper.createLabel("Offer Dealer address is OK", ExtentColor.GREEN));
                //sa.assertTrue(true);
            } else {
                failWithScreenshot("Offer Dealer address is not OK", resultDirectory, driver, extent, logger);
                //sa.assertTrue(false, "Offer Dealer address is not OK");
                //driver.close();
            }

            // go to basket
            uap.GoToBasket();
            waitForUrlContains("basket", driver, 120);
            //sa.assertAll();
        } catch (Exception e) {
            failWithScreenshot("Test Failed while Search And Select Retailer", resultDirectory, driver, extent, logger);
            e.printStackTrace();
            //driver.close();

        }

    }

}
