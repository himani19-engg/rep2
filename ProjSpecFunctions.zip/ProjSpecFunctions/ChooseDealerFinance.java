package solRetailIHM.ProjSpecFunctions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import solRetailIHM.PageObjectModel.ChooseDealerPage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ChooseDealerFinance extends UniversalMethods {

	@Test(description = "Selecting Dealer Finance")
	public static void searchAndSelectRetailer(WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Country, String City) throws Exception {
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);

			ChooseDealerPage dea = new ChooseDealerPage(driver);
			PersonnalInfoPage pi = new PersonnalInfoPage(driver);
			//SoftAssert sa = new SoftAssert();

			// case not opel
			if (!driver.getCurrentUrl().contains("opel")) {

				waitForUrlContains("checkout", driver, 320);

				// Select dealer
				dea.enterCity(City);
				dea.searchRetailer();
				logger.log(Status.INFO, "Search for retailer at " + City + " location");
				Thread.sleep(2000);
				dea.SelectRetailer();
				logger.log(Status.INFO,"Retailler has been selected");

				// check dealer choosen

				String SelectedAddress = dea.DealerChoiceAdress();

				String PostSelectionAddress = dea.DealerDisplayAdress();

				if (SelectedAddress.contains(PostSelectionAddress)) {
					logger.log(Status.PASS,"Dealer has been selected");

					//sa.assertTrue(true);
				} else {
					logger.log(Status.FAIL,"Dealer has not been selected");

					//sa.assertTrue(false, "Dealer has not been selected");
					//driver.quit();
					// org.testng.Assert.fail();
				}

				// validate dealer choosen
				dea.DealerContinue();
				waitForUrlContains("checkout/my-details", driver, 320);
				Thread.sleep(3000);

				// Validate arriving on personnal info page
				if (Country.equalsIgnoreCase("FR")) {
					if (pi.PersonnalInfo().equals("progressCar progressCar-confirmation")) {
						logger.log(Status.PASS,
								MarkupHelper.createLabel("PERSONNAL INFO PAGE page has appeared", ExtentColor.GREEN));
						//sa.assertTrue(true);
					} else {
						logger.log(Status.FAIL,
								MarkupHelper.createLabel("PERSONNAL INFO PAGE page has not appeared", ExtentColor.RED));
						//sa.assertTrue(false, "Vehicle name on basket page is not correct");
						//driver.quit();
						// org.testng.Assert.fail();
					}
				}

				if (Country.equalsIgnoreCase("UK")) {

					if (!driver.getCurrentUrl().contains("citroen")) {

						if (pi.PersonnalInfo().equals("progressCar progressCar-confirmation")) {
							logger.log(Status.PASS,"PERSONNAL INFO PAGE page has appeared");
							//sa.assertTrue(true);
						} else {
							logger.log(Status.FAIL,"PERSONNAL INFO PAGE page has not appeared");
							//sa.assertTrue(false, "PERSONNAL INFO PAGE page has not appeared");
							//driver.quit();
							// org.testng.Assert.fail();
						}
					} else {

						if (pi.PersonnalInfo_UK_AC().equals("progressCar progressCar-confirmation")) {
							logger.log(Status.PASS,"PERSONNAL INFO PAGE page has appeared");
							//sa.assertTrue(true);
						} else {
							logger.log(Status.FAIL,"PERSONNAL INFO PAGE page has not appeared");
							//sa.assertTrue(false, "PERSONNAL INFO PAGE page has not appeared");
							//driver.quit();
							// org.testng.Assert.fail();
						}

					}

				}

			}

			// case opel
			if (driver.getCurrentUrl().contains("opel")) {

				// validate fianancial configuration
				dea.ValidateOpelFinance();
				logger.log(Status.INFO,
						MarkupHelper.createLabel("Finance configuration has been validated", ExtentColor.BLUE));

				waitForUrlContains("/form-sol/", driver, 120);

				if (dea.OpelDealerLocator().contains("Sélectionnez votre point de vente:")) {
					logger.log(Status.PASS,"CHOOSE DEALER page has appeared");
					//sa.assertTrue(true);
				} else {
					logger.log(Status.FAIL,"CHOOSE DEALER page has not appeared");
					//sa.assertTrue(false, "CHOOSE DEALER page has not appeared");
					//driver.quit();
					// org.testng.Assert.fail();
				}

				// choose and select retailler
				dea.clickOpelRetailer();
				logger.log(Status.INFO, MarkupHelper.createLabel("Retailler has been selected", ExtentColor.BLUE));

				dea.validateOpelRetailer();
				logger.log(Status.INFO, MarkupHelper.createLabel("Retailler choice is validated", ExtentColor.BLUE));

				waitForUrlContains("/form-sol/", driver, 120);

				if (dea.OpelInfosLocator().contains("Bienvenue dans votre Opel Store")) {
					logger.log(Status.PASS,"PERSONNAL INFO page has appeared");
					//sa.assertTrue(true);
				} else {
					logger.log(Status.FAIL,"PERSONNAL INFO page has not appeared");
					//sa.assertTrue(false, "PERSONNAL INFO page has not appeared");
				//	driver.quit();
					// org.testng.Assert.fail();
				}

			}
			//sa.assertAll();
		} catch (Exception e1) {
			logger.log(Status.FAIL,
					MarkupHelper.createLabel("Error with Selecting Dealer Finance", ExtentColor.RED));
			e1.printStackTrace();

		}

	}

}
