package solRetailIHM.ProjSpecFunctions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.PaymentCashPage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ScenarioMainClass.ScenarioMain_FR.logger;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

@Test(description = "Payment Transaction along with validation")
public class BankProcessingPage extends UniversalMethods {
	public static ExtentTest paymentTransactionAlongWithValidation;
	public static ExtentTest bankProcessing;
	public static void bankProcessingValidation(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String brand, String country) {
		if(driver!=null) {
			bankProcessing = logger.createNode("BankProcessing", "Validation of Bank Processing");
			try {
				solRetailIHM.PageObjectModel.BankProcessingPage bp=new solRetailIHM.PageObjectModel.BankProcessingPage(driver);
				bp.getBankProcessingTitle(resultDirectory,driver,extent,bankProcessing,brand,country);
			} catch (Exception e) {
				catchFailDetails(resultDirectory, paymentTransactionAlongWithValidation, driver, "Test Failed while doing Payment Transaction along with validation", e);
			}
		}

	}

}
