package solRetailIHM.ProjSpecFunctions;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;
import solo2c.ProjSpecFunctions.ChoosePaymentMode;

@Listeners(solRetailIHM.Runner.ListenerTest.class)


public class ChooseCarOptions extends UniversalMethods {

	@Test(description="Selecting Car Options")
	public static void CarOptions(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Brand, String Country, String PaymentMode) throws InterruptedException {
		if(driver!=null) {
			ExtentTest selectingCarOptions = extentCP.createNode("SelectCarOptions", "Selecting car options on config page");
			try {
				//driver.manage().window().maximize();
				// choose motor engine
				selectAndVerifyAllMotorOption(resultDirectory, driver, extent, selectingCarOptions, Brand, Country,PaymentMode);
				//selectingCarOptions.log(Status.INFO,"Engine has been choosen");

				// choose color option
				selectAndVerifyAllColours(resultDirectory, driver, extent, selectingCarOptions, Brand, Country,PaymentMode);
				//selectingCarOptions.log(Status.INFO,"Color has been choosen");

				// choose interior option
				selectAndVerifyAllInteriorOptions(resultDirectory, driver, extent, selectingCarOptions, Brand, Country,PaymentMode);
				//selectingCarOptions.log(Status.INFO,"Interior has been choosen");

				// Choose Options item
				selectAndVerifyOptions(resultDirectory, driver, extent, selectingCarOptions, Brand, Country,PaymentMode);
				//selectingCarOptions.log(Status.INFO,"Option has been choosen");
				//driver.manage().window().setSize(new Dimension(1920, 1080));

			} catch (Exception e) {
			/*selectingCarOptions.log(Status.FAIL,"Test Failed in Config page while selecting different options");
			failWithScreenshot("Test Failed in Config page while selecting different options", resultDirectory, driver, extent, selectingCarOptions);
			selectingCarOptions.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, selectingCarOptions, driver, "Test Failed in Config page while selecting different options", e);
				//	driver.close();
			}
		}
	}
	
	@Test(description="Selecting and Verifying All Colours")
	public static void selectAndVerifyAllColours (String resultDirectory,
  			WebDriver driver,
            ExtentReports extent, 
            ExtentTest logger,
            String Brand, 
            String Country,
	        String PaymentMode) throws InterruptedException, AWTException {
		
		ConfigPage config = new ConfigPage(driver);
		int size = 0;
		String attribute = null;
		String colourName = null;
		Robot r=new Robot();
		//SoftAssert sa=new SoftAssert();
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			size = config.getColoursList().size();

			for (int i = 1; i <= (size-1); i++) {
				Thread.sleep(3000);
				for(int j=0;j<=size;j++) {
					r.keyPress(KeyEvent.VK_UP);
					r.keyRelease(KeyEvent.VK_UP);
					Thread.sleep(100);
					r.keyPress(KeyEvent.VK_UP);
					r.keyRelease(KeyEvent.VK_UP);
					Thread.sleep(100);
				}
				System.out.println("Scrolled up to colour label");
				System.out.println("color i :"+i);
				if(i<=5) {
					config.selectColor(i);
				}
				Thread.sleep(5000);
				attribute = config.getSelectedColorAttribute(i,resultDirectory,logger);
				colourName = config.getColourName(resultDirectory,logger);
				if (i >= 6) {
					config.hoverColor(i);
					r.keyPress(KeyEvent.VK_UP);
					r.keyRelease(KeyEvent.VK_UP);
					Thread.sleep(100);
					r.keyPress(KeyEvent.VK_UP);
					r.keyRelease(KeyEvent.VK_UP);
					Thread.sleep(100);
					r.keyPress(KeyEvent.VK_UP);
					r.keyRelease(KeyEvent.VK_UP);
					Thread.sleep(100);
					config.clickColorGoToNextSlide(resultDirectory,logger);
					config.selectColor(i);
					Thread.sleep(1000);
				}
				Thread.sleep(3000);
				float initialCashPrice=Float.parseFloat(readFromProperties("stickyBarCashPrice"));
				float currentCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_CASH_PRICE']")).replace(",","."));
				float currentColorCashPrice=0.0f;
				if(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_COLOR_PRICE']")).contains("Inclus")){
					currentColorCashPrice=0.0f;
				} else{
				 	currentColorCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_COLOR_PRICE']/span[2]")).replace(",","."));
				}
				if(currentCashPrice-initialCashPrice-currentColorCashPrice<1){
					logger.log(Status.PASS,"Current sticky bar cash price "+currentCashPrice+" includes color price");
				} else{
					logger.log(Status.FAIL,"Current sticky bar cash price "+currentCashPrice+" does not include color price");
				}
				writeToProperties("stickyBarCashPrice",String.valueOf(currentCashPrice));
				if(PaymentMode.equalsIgnoreCase("Finance")){
					float initialFinancePrice=Float.parseFloat(readFromProperties("stickyBarFinancePrice"));
					float currentFinancePrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_FINANCE_PRICE']/span[1]/span")).replace(",","."));
					float currentColorFinancePrice=0.0f;
					if(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_COLOR_PRICE']")).contains("Inclus")){
						currentColorFinancePrice=0.0f;
					} else{
						currentColorFinancePrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_COLOR_PRICE']/span[5]")).replace(",","."));
					}
					if(currentFinancePrice-initialFinancePrice-currentColorFinancePrice<1){
						logger.log(Status.PASS,"Current sticky bar finance price "+currentFinancePrice+" includes color price");
					} else{
						logger.log(Status.FAIL,"Current sticky bar finance price "+currentFinancePrice+" does not include color price");
					}
					writeToProperties("stickyBarFinancePrice",String.valueOf(currentFinancePrice));
				}
				if(attribute.contains("is-selected")) {
					logger.log(Status.PASS, "Selected color is displayed : "+colourName);
				//sa.assertTrue(true);
				}else if(attribute.contains("disabled")){
					if(config.getTextForDisabledColorConfiguration(i,resultDirectory,logger)==null||config.getTextForDisabledColorConfiguration(i,resultDirectory,logger).contains("This Color isn't available with current configuration")){
						logger.log(Status.PASS, "Selected color is "+colourName+" disabled with current configuration");
					}else {
						failWithScreenshot("Selected color is not working", resultDirectory, driver, extent, logger);
					}
				}
				else {
					failWithScreenshot("Selected color is not displayed : "+colourName, resultDirectory, driver, extent, logger);
					//sa.assertTrue(false, "Selected color is not displayed");
				}

			}
		}catch(Exception e) {
			/*failWithScreenshot("Test Failed in select colour", resultDirectory, driver, extent, logger);*/
			e.printStackTrace();
			catchFailDetails(resultDirectory, logger,driver, "Test Failed in select colour",e);
		}
	}
  
	@Test(description="Selecting And Verifying All Interior Options")
	public static void selectAndVerifyAllInteriorOptions (String resultDirectory,
  			WebDriver driver,
            ExtentReports extent, 
            ExtentTest logger,
            String Brand, 
            String Country,
	        String PaymentMode) throws InterruptedException {
		
		ConfigPage config = new ConfigPage(driver);
		int size = 0;
		List<Integer> list=null;
		String attribute = "";
		try {
			size = config.getInteriorList(resultDirectory,logger).size();
			list = new ArrayList<>();
			for (int i = 1; i <= size; i++) {
				config.selectInteriorOption(i,resultDirectory,logger);
				Thread.sleep(1000);
				Float currentStickyBarCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_CASH_PRICE']/span[1]")).replace(",","."));
				Float initialStickyBarCashPrice=Float.parseFloat(readFromProperties("stickyBarCashPrice"));
				Float interiorCashPrice=0.0f;
				String priceString=getAnyText(driver,By.xpath("//*[@data-testid='TESTING_INTERIOR_PRICE_"+(i-1)+"']"));
				if(priceString.contains("Inclus")){
					interiorCashPrice=0.0f;
				} else{
					interiorCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_INTERIOR_PRICE_"+(i-1)+"']/span[2]")).replace(",","."));
				}
				if(currentStickyBarCashPrice-initialStickyBarCashPrice-interiorCashPrice<1){
					logger.log(Status.PASS,"Current sticky bar cash price "+currentStickyBarCashPrice+" includes interior price");
				} else{
					logger.log(Status.PASS,"Current sticky bar cash price "+currentStickyBarCashPrice+" does not include interior price");
				}
				writeToProperties("stickyBarCashPrice",String.valueOf(currentStickyBarCashPrice));
				if(PaymentMode.equalsIgnoreCase("Finance")){
					float currentStickyBarFinancePrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_FINANCE_PRICE']/span[1]")).replace(",","."));
					float initialStickyBarFinancePrice=Float.parseFloat(readFromProperties("stickyBarFinancePrice"));
					float interiorFinancePrice=0.0f;
					if(priceString.contains("Inclus")){
						interiorFinancePrice=0.0f;
					} else{
						interiorFinancePrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_INTERIOR_PRICE_"+(i-1)+"']/span[5]")).replace(",","."));
					}
					if(currentStickyBarFinancePrice-initialStickyBarFinancePrice-interiorFinancePrice<1){
						logger.log(Status.PASS,"Current sticky bar finance price "+currentStickyBarFinancePrice+" includes interior price");
					} else{
						logger.log(Status.FAIL,"Current sticky bar finance price "+currentStickyBarFinancePrice+" does  not include interior price");
					}
					writeToProperties("stickyBarFinancePrice",String.valueOf(currentStickyBarFinancePrice));
				}
				if(isElementPresent(driver,ConfigPage.optionLabel,10)){
					list.add(i);
				}
				attribute = config.getSelectedInteriorOptionAttribute(i,resultDirectory,logger);
				if(attribute.contains("Selected")) {
					logger.log(Status.PASS, "Selected interior option is displayed");
				//sa.assertTrue(true);
				}
				else {
					failWithScreenshot("Selected interior option is not displayed", resultDirectory, driver, extent, logger);
					//sa.assertTrue(false, "Selected interior option is not displayed");
				}
			}

			System.out.println("Total elements (for which option is available) among which we could select is: "+list.size());
			config.selectInteriorOption(getListElement(list),resultDirectory,logger);
		}catch(Exception e) {
			/*failWithScreenshot("Test Failed in selecting interior", resultDirectory, driver, extent, logger);
			e.printStackTrace();*/
			catchFailDetails(resultDirectory, logger,driver, "Test Failed in selecting interior",e);
		}
	}
	
	@Test(description="Selecting And Verifying All Motor Option")
	public static void selectAndVerifyAllMotorOption (String resultDirectory,
  			WebDriver driver,
            ExtentReports extent, 
            ExtentTest logger,
            String Brand, 
            String Country, String PaymentMode) throws InterruptedException {
		
		ConfigPage config = new ConfigPage(driver);
		int size = 0;
		List<Integer> list=null;
		//int i;
		String attribute = null;
		//SoftAssert sa=new SoftAssert();
		try {
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Thread.sleep(2000);
			size = config.getMotorList(resultDirectory,logger).size();
			list = new ArrayList<>();
			for (int i = 1; i <= size; i++) {
				config.selectMotor(i,resultDirectory,logger);
				Thread.sleep(6000);
				if(isElementPresent(driver,ConfigPage.optionLabel)){
					list.add(i);
				}
				attribute = config.getSelectedMotorAttribute(i,resultDirectory,logger);
				if(attribute.contains("Selected")) {
					//logger.log(Status.PASS, MarkupHelper.createLabel("Selected motor option is displayed", ExtentColor.GREEN));
					logger.log(Status.PASS, "Selected motor option is displayed");
					//sa.assertTrue(true);
				}else {
					failWithScreenshot("Selected motor option is not displayed", resultDirectory, driver, extent, logger);
				//sa.assertTrue(false, "Selected motor option is not displayed");
				}
				float stickyBarCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_CASH_PRICE']/span[1]")).replace(",","."));
				float motorisationCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_ENGINE_PRICE_"+(i-1)+"']/span[1]")).replace(",","."));
				if(stickyBarCashPrice==motorisationCashPrice){
					logger.log(Status.PASS, "Both sticky bar cash price and motorisation cash price displayed are same("+stickyBarCashPrice+") for motorisation "+i);
				} else{
					logger.log(Status.FAIL, "Both sticky bar cash price and motorisation cash price displayed are not same sticky bar price: "+stickyBarCashPrice+" and motorisation price :"+motorisationCashPrice+"for motorisation"+i);
				}
				writeToProperties("stickyBarCashPrice",String.valueOf(stickyBarCashPrice));
				if(PaymentMode.equalsIgnoreCase("Finance")) {
					int stickyBarFinancePrice=extractNumericFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_FINANCE_PRICE']")));
					float motorisationFinancePrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_ENGINE_PRICE_"+(i-1)+"']/span[2]")).replace(",","."));
					if(stickyBarFinancePrice-motorisationFinancePrice<1){
						logger.log(Status.PASS, "Both sticky bar finance price and motorisation finance price displayed are same("+stickyBarFinancePrice+") for motorisation "+i);
					} else{
						logger.log(Status.FAIL, "Both sticky bar finance price and motorisation finance price displayed are not same sticky bar price: "+stickyBarFinancePrice+" and motorisation price :"+motorisationFinancePrice+"for motorisation"+i);
					}
					writeToProperties("stickyBarFinancePrice",String.valueOf(stickyBarFinancePrice));
				}
			}
			/*System.out.println("Total engines among which we could select is: "+list.size());
			scrollUp();
			config.selectMotor(getListElement(list),resultDirectory,logger);*/
		}catch(Exception e) {
			/*failWithScreenshot("Test Failed in selecting motor", resultDirectory, driver, extent, logger);
			 */
			e.printStackTrace();
			catchFailDetails(resultDirectory, logger,driver, "Test Failed in selecting motor",e);}
	}
	
	@Test(description="Selecting And Verify All Options")
	public static void selectAndVerifyAllOptions (String resultDirectory,
  			WebDriver driver,
            ExtentReports extent, 
            ExtentTest logger,
            String Brand, 
            String Country) throws InterruptedException {
		
		ConfigPage config = new ConfigPage(driver);
		int size = 0;
		String attribute = null;
		//SoftAssert sa=new SoftAssert();
		try {
			size = config.getNoOfOptionsList(resultDirectory,logger).size();
			if(size > 0) {
				for (int i = 1; i <= 1; i++) {
					config.clickOptionIcon(i,resultDirectory,logger);
					//Thread.sleep(1000);
					config.selectOptionItem(i,resultDirectory,logger);
					//Thread.sleep(2000);
					attribute = config.getSelectedOptionItemAttribute(i,resultDirectory,logger);
					if(attribute.contains("Selected")) {
						//logger.log(Status.PASS, MarkupHelper.createLabel("Selected option is displayed", ExtentColor.GREEN));
						logger.log(Status.PASS, "Selected option is displayed");
						//sa.assertTrue(true);
					}
					else {
						failWithScreenshot("Selected option is not displayed", resultDirectory, driver, extent, logger);
						//sa.assertTrue(false,"Selected  option is not displayed");
					}
					config.clickOptionIcon(i,resultDirectory,logger);
					//Thread.sleep(1000);
				}
			}			
		}catch(Exception e) {
			/*failWithScreenshot("Test Failed", resultDirectory, driver, extent, logger);
			e.printStackTrace();*/
			catchFailDetails(resultDirectory, logger,driver, "Test Failed while Selecting And Verify All Options",e);
		}
	}
	
	public static void selectAndVerifyOptions(String resultDirectory, WebDriver driver, ExtentReports extent, 
            ExtentTest logger, String Brand, String Country, String PaymentMode
				) throws InterruptedException {
		
		ConfigPage config = new ConfigPage(driver);
		String optionText;
		String optionTitle;
		try {
			config.clickToCollapseExpandFirstOptions(resultDirectory,logger);
			optionText = config.getFirstOptionItemText(resultDirectory,logger);
			config.clickOptionDetailLink(Brand,resultDirectory,logger);
			if(config.clickOptionIcon(resultDirectory,logger)) {
				optionTitle = config.getOptionDetailTitle(resultDirectory, logger);
				config.clickCloseFormPopup(resultDirectory, logger);
				if (optionText.equalsIgnoreCase(optionTitle)) {
					logger.log(Status.PASS, "Selected option text is correct " + optionText);
				} else {
					failWithScreenshot("Selected option text is not correct " + optionText, resultDirectory, driver, extent, logger);
				}
			}
			config.clickOptionDetailLink(Brand,resultDirectory,logger);
			//Thread.sleep(1000);
			config.selectFirstOptionItem(resultDirectory,logger);
			if(config.getSelectedOptions(resultDirectory,logger).equalsIgnoreCase("1")) {
				logger.log(Status.PASS, "Selected option count is displayed correctly "+config.getSelectedOptions(resultDirectory,logger));
			}else {
				failWithScreenshot("Selected option count is not displayed correctly "+config.getSelectedOptions(resultDirectory,logger), resultDirectory, driver, extent, logger);
			}
			Float currentStickyBarCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_OPTIONS_PRICE']/span[2]")).replace(",","."));
			Float initialStickyBarCashPrice=Float.parseFloat(readFromProperties("stickyBarCashPrice"));
			Float optionsCashPrice=0.0f;
			String priceString=getAnyText(driver,By.xpath("//*[@data-testid='TESTING_OPTIONS_PRICE']"));
			if(priceString.contains("Inclus")){
				optionsCashPrice=0.0f;
			} else{
				optionsCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_OPTIONS_PRICE']/span[2]")).replace(",","."));
			}
			if(currentStickyBarCashPrice-initialStickyBarCashPrice-optionsCashPrice<1){
				logger.log(Status.PASS,"Current sticky bar cash price "+currentStickyBarCashPrice+" includes options price");
			} else{
				logger.log(Status.FAIL,"Current sticky bar cash price "+currentStickyBarCashPrice+" does not include options price");
			}
			if(PaymentMode.equalsIgnoreCase("Finance")){
				Float currentStickyBarFinancePrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_FINANCE_PRICE']/span[1]/span")).replace(",","."));
				Float initialStickyBarFinancePrice=Float.parseFloat(readFromProperties("stickyBarFinancePrice"));
				Float optionsFinancePrice=0.0f;
				if(priceString.contains("Inclus")){
					optionsFinancePrice=0.0f;
				} else{
					optionsFinancePrice=extractFloatFromString(getAnyText(driver, By.xpath("//*[@data-testid='TESTING_OPTIONS_PRICE']/span[5]")).replace(",","."));
				}
				if(currentStickyBarFinancePrice-initialStickyBarFinancePrice-optionsFinancePrice<1){
					logger.log(Status.PASS,"Current sticky bar Finance price "+currentStickyBarFinancePrice+" includes options price");
				} else{
					logger.log(Status.FAIL,"Current sticky bar Finance price "+currentStickyBarFinancePrice+" does not include options price");
				}
			}
			config.clickToCollapseExpandFirstOptions(resultDirectory,logger);
					
		}catch(Exception e) {
			/*failWithScreenshot("Test failed in select options", resultDirectory, driver, extent, logger);
			 */
			e.printStackTrace();
			catchFailDetails(resultDirectory, logger,driver, "Test failed in select options",e);
		}
	}
	
	public static void verifyColorAndEngineWithTrim (String resultDirectory,
  			WebDriver driver,
            ExtentReports extent, 
            ExtentTest logger,
            String Brand, 
            String Country) throws InterruptedException {
		ConfigPage config = new ConfigPage(driver);
		int noOfColors = 0, noOfEngines = 0;
		int trimColors = 0, trimEngines = 0;
		try {
			noOfColors = config.getColoursList().size();
			noOfEngines = config.getMotorList(resultDirectory,logger).size();
			trimColors = extractNumericFromString(config.readFromProperties("TrimColor"));
			trimEngines = extractNumericFromString(config.readFromProperties("TrimEngine"));
			if(noOfColors == trimColors) {
				logger.log(Status.PASS, MarkupHelper.createLabel("No of colors : "+noOfColors+" from Config page matches with Trim page : "+trimColors, ExtentColor.GREEN));
			}else {
				failWithScreenshot("No of colors : "+noOfColors+" from Config page does not match with Trim page : "+trimColors, resultDirectory, driver, extent, logger);
			}
			
			if(noOfEngines == trimEngines) {
				logger.log(Status.PASS, MarkupHelper.createLabel("No of engines : "+noOfEngines+" from Config page matches with Trim page : "+trimEngines, ExtentColor.GREEN));
			}else {
				failWithScreenshot("No of engines : "+noOfEngines+" from Config page does not match with Trim page : "+trimEngines, resultDirectory, driver, extent, logger);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
