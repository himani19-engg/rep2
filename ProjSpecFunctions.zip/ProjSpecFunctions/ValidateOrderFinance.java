package solRetailIHM.ProjSpecFunctions;

import org.codehaus.jettison.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.MOP_APIs.MOPAPIs;
import solRetailIHM.PageObjectModel.OrderPage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.Iterator;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.getbasketPgVehicleName;


@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ValidateOrderFinance extends UniversalMethods {
	public static ExtentTest checkPayment;
	public static ExtentTest pricevalidation;

	@Test(description = "Order Validation")
	public static void orderValidation(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String Brand,
			String Country, String MopValidation, String PaymentMode, String ScenarioName, String EmailId, String PostalCode, String City, String Phone, String Name) throws Exception {
		if(driver!=null) {
			checkPayment = logger.createNode("Payment", "Check Payment page");
			try {
				System.out.println(ScenarioName);
				OrderPage or = new OrderPage(driver);
				BankProcessingPage bp = new BankProcessingPage();
				MOPAPIs mop = new MOPAPIs();

				if(!Brand.equalsIgnoreCase("OV")) {
					or.orderValidationOfSuccessMessage(resultDirectory, driver, extent, checkPayment, Brand, Country, PaymentMode);
					CheckPersonnalInfoCash.validatePersonalInfo(resultDirectory, driver, extent, checkPayment, Brand, Country, EmailId, PostalCode, City, Phone, Name);
					CheckPersonnalInfoCash.validateRetailerAddress(resultDirectory, driver, extent, checkPayment, Brand, Country);
					CheckPersonnalInfoCash.validateRefundableFeeAmount(resultDirectory, driver, extent, checkPayment, Brand, Country, PaymentMode);
					PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, checkPayment, getbasketPgVehicleName, "PaymentPage", By.xpath("//*[@class='versionLabel']"));
					PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, checkPayment, Country);
					//	ValidateOrderFinance.Pricevalidations(resultDirectory,driver,extent,checkPayment,Country,PaymentMode);

					//CheckPersonnalInfoCash.validatePersonalInfo(resultDirectory, driver, extent, orderValidation, brand, country, EmailId, PostalCode, City, Phone, Name);
				}


				//Validating CashPrice on Order Summary Page
				or.validateOrderSummaryMonthlyPricewithIdentificationPrice(resultDirectory, driver, extent, checkPayment, Country, PaymentMode, Brand);
				String mopId = null;
				try {
					/*clickElement(driver,By.xpath("//*[@class=\"selectRight \"]"));
					//driver.navigate().refresh();
					// get MOP ID value corresponding to order from source code
					Thread.sleep(3000);
					clickElement(driver,By.xpath("//*[@data-testid=\"assistedFinanceSection\"]"));
*/
					waitForPageToLoad(driver, 30);
					driver.navigate().refresh();
					waitForPageToLoad(driver, 30);
					//String scriptToExecute = "var performance = window.performance || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; var network = performance.getEntries() || {}; return JSON.stringify(network);";
					// String scriptToExecute = "return mopId";
					//driver.navigate().refresh();


					//System.out.println(scriptToExecute);
					JavascriptExecutor js = (JavascriptExecutor) driver;
					String sessionStorage = (String) js.executeScript(String.format("return window.sessionStorage.getItem('%s');", "_mopId"));
					System.out.println("Session Storage" + sessionStorage);
					mopId = sessionStorage;

					//String netData = js.executeScript(scriptToExecute).toString();
					//	System.out.println(netData);
					//	mopId = netData.split("mopId/")[1].split("\"")[0];
					System.out.println("MOPID : " + mopId);
					checkPayment.log(Status.INFO, "MOPID has been found : " + mopId);
				} catch (Exception e1) {
					System.out.println("MOPID : " + e1);

					catchFailDetails(resultDirectory, checkPayment, driver, "Test Failed while MOP ID getting as null", e1);
				}


				Thread.sleep(3000);
				String url = driver.getCurrentUrl();
				//Checking for Payment Rejected
				if (url.contains("/error") == false || PaymentMode.equalsIgnoreCase("Finance")) {
					or.CashTermsofUseCK(Brand);
					checkPayment.log(Status.INFO, "Clicked terms of use checkbox");
					//Thread.sleep(3000);
					or.clickFinanceOkCheckbox();
					checkPayment.log(Status.INFO, "Clicked finance ok checkbox");
					//Thread.sleep(2000);
					or.clickOptionCommandCheckbox();
					//Thread.sleep(1000);
					checkPayment.log(Status.INFO, "Clicked option command checkbox");
					if (or.validateThreeIcons()) {
						checkPayment.log(Status.PASS, "icons are present");
						if (or.validateThreeIconsSize() == 3) {
							checkPayment.log(Status.PASS, "no. of total icons present are 3");
							checkPayment.log(Status.INFO, "The three icons are: " + or.contextOfThreeIcons());
						} else {
							checkPayment.log(Status.FAIL, "no. of total icons present are not 3");
						}
					} else {
						checkPayment.log(Status.FAIL, "3 icons are not present");
					}
					// or.Validate();
					or.clickOnFinanceOrderValidate(Country, Brand, PaymentMode);
					bp.bankProcessingValidation(resultDirectory, driver, extent, checkPayment, Brand, Country);
					checkPayment.log(Status.INFO, "Clicked on order validation");
					if (Country.equalsIgnoreCase("ES")) {
						Thread.sleep(30000);
					} else {
						Thread.sleep(8000);
					}
				}

				if (MopValidation.equalsIgnoreCase("yes")) {
					// MOP validation
					mop.postRequestAccept(Country, mopId, Brand, MopValidation);
					checkPayment.log(Status.INFO, "MOP validation for accept");
					Thread.sleep(20000);
				}

				if (MopValidation.equalsIgnoreCase("no")) {
					// MOP validation
					mop.postRequestRefused(Country, mopId, Brand, MopValidation);
					checkPayment.log(Status.INFO, "MOP validation for reject");
					Thread.sleep(20000);
				}
				// opening order page
				mop.getRequest(driver, Country, mopId, Brand, MopValidation);
				//waitForUrlContains("checkout/order-review", driver, 30);
				waitForUrlContains("order", driver, 30);
				Thread.sleep(3000);

				// Validate arriving on order page
				if (MopValidation.equalsIgnoreCase("yes")) {
					if (Country.equalsIgnoreCase("ES")) {
						if (or.getFinanceOrderStatusText().contains("ACEPTADA")) {
							checkPayment.log(Status.PASS, "FINANCE APPLICATION ACCEPTED");
						} else {
							failWithScreenshot("FINANCE APPLICATION IS REJECTED", resultDirectory, driver, extent, checkPayment);
						}
						or.CashTermsofUseCK(Brand);
						or.clickOnFinanceOrderValidate(Country, Brand, PaymentMode);
						waitForUrlContains("confirmation", driver, 30);
						if (or.getFinanceOrderStatusText().contains("Muchas gracias")) {
							checkPayment.log(Status.PASS, "Finance order completed successfully");
						} else {
							failWithScreenshot("Finance order not completed", resultDirectory, driver, extent, checkPayment);
						}
					}

					if (Country.equalsIgnoreCase("FR")) {
						if (or.getFinanceOrderStatusText().contains("accepté")
								|| or.getFinanceOrderStatusText().contains("ACCEPTÉ")) {
							checkPayment.log(Status.PASS, "FINANCE APPLICATION ACCEPTED");
						} else {
							failWithScreenshot("FINANCE APPLICATION IS REJECTED", resultDirectory, driver, extent, checkPayment);
						}
						or.CashTermsofUseCK(Brand);
						Thread.sleep(5000);
						or.clickOnFinanceOrderValidate(Country, Brand, PaymentMode);
						waitForUrlContains("confirmation", driver, 30);
						if (or.getFinanceOrderStatusText().contains("Merci")
								|| or.getFinanceOrderStatusText().contains("MERCI")) {
							checkPayment.log(Status.PASS, "Finance order completed successfully");
						} else {
							failWithScreenshot("Finance order not completed", resultDirectory, driver, extent, checkPayment);
						}
					}
				}

				String currentURL = driver.getCurrentUrl();

				if (MopValidation.equalsIgnoreCase("no")) {
					if (Country.equalsIgnoreCase("ES")) {
						try {
							if (or.getFinanceOrderStatusText().contains("RECHAZADA") ||
									currentURL.contains("error")) {
								checkPayment.log(Status.PASS, "FINANCE APPLICATION REJECTED");
							} else {
								failWithScreenshot("FINANCE APPLICATION IS NOT REJECTED", resultDirectory, driver, extent, checkPayment);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
//					if (driver != null) {
//						pricevalidation = logger.createNode("Date Validations Details", "Date Va"):
//						if (Country.equalsIgnoreCase("FR")) {
//							try {
//								Float PersonalPageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
//								//   waitForElementPresent(driver, By.xpath("//span[@class='price-total-price']"), 50);
//								Float OrdersummaryCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@class='price-total-price']")).replace(" ", "").replace(",", "."));
//								Thread.sleep(2000);
//								if (PersonalPageCashPrice - OrdersummaryCashPrice < 1) {
//									Thread.sleep(2000);
//									pricevalidation.log(Status.PASS, "Personalinfopage Cash price " + PersonalPageCashPrice + "is not same as Ordersummary cash price");
//								} else {
//									Thread.sleep(2000);
//									pricevalidation.log(Status.FAIL, "Personalinfopage Cash Price" + PersonalPageCashPrice + "is same as Ordersummary cash price");
//								}
//								if (PaymentMode.equalsIgnoreCase("Finance")) {
//									Float PersonalinfoFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
//									//   waitForElementPresent(driver, By.xpath("//span[@class='price-total-price']"), 50);
//									Float OrdersummaryFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@class='span1 ng-star-inserted']")).replace(" ", "").replace(",", "."));
//									Thread.sleep(2000);
//									if (PersonalinfoFinancePrice - OrdersummaryFinancePrice < 1) {
//										Thread.sleep(2000);
//										pricevalidation.log(Status.PASS, "Personalinfopage Finance price " + PersonalinfoFinancePrice + "is same as Reprise Finance price");
//									} else {
//										Thread.sleep(2000);
//										pricevalidation.log(Status.FAIL, "Personalinfopage Finance Price" + PersonalinfoFinancePrice + "is not same as Reprise Finance price");
//									}
//								}
//
//							} catch (Exception e) {
//								catchFailDetails(resultDirectory, pricevalidation, driver, "Unable to validate the ordersummary prices", e);
//								e.printStackTrace();
//							}
//						}
//					}



						if (Country.equalsIgnoreCase("FR")) {
							try {
								System.out.println(or.getFinanceOrderStatusText() + " " + currentURL);
								if ((or.getFinanceOrderStatusText() != null && or.getFinanceOrderStatusText().contains("REFUSE")) ||
										(or.getFinanceOrderStatusText() != null && or.getFinanceOrderStatusText().contains("Nous ne pouvons pas créer d'offre d'achat pour ce véhicule.")) ||
										currentURL.contains("error")) {
									checkPayment.log(Status.PASS, "FINANCE APPLICATION REJECTED");
								} else {
									failWithScreenshot("FINANCE APPLICATION IS NOT REJECTED", resultDirectory, driver, extent, checkPayment);
								}
							} catch (Exception e) {
								e.printStackTrace();
							}

						}

					}
				} catch(Exception e3){
			/*checkPayment.log(Status.FAIL,"Test Failed while doing Order Validation");
			failWithScreenshot("Test Failed while doing Order Validation", resultDirectory, driver, extent, checkPayment);
			checkPayment.log(Status.FAIL, String.valueOf(e1.getStackTrace()));*/
					catchFailDetails(resultDirectory, checkPayment, driver, "Test Failed while doing Order Validation", e3);
				}
			}
		}
	}




