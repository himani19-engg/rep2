package solRetailIHM.ProjSpecFunctions;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckCalculatorOnConfigPage extends UniversalMethods {

    @Test(description = "validation of Default Calculator Price")
    public static void validateDefaultCalculatorPrice(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                      ExtentTest logger, String brand, String country, String PaymentMode) throws Exception {

        ExtentTest validationOfDefaultCalculatorPrice = extentCP.createNode("ValidationOfDefaultCalculatorPrice", "Validation of default calculator price");
        ConfigPage configPage = new ConfigPage(driver);
        try {

            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            String config_monthlyPrice = null;
            //SoftAssert sa = new SoftAssert();
            if (isElementPresent(driver, configPage.clickOnPersonalizeFinanceButton, 10)) {
                configPage.clickOnPersonalizeFinanceButton(resultDirectory, validationOfDefaultCalculatorPrice);
                //validationOfDefaultCalculatorPrice.log(Status.INFO, "Click on Personalize Finance button");
                Thread.sleep(5000);
                if ((configPage.techProblemError(resultDirectory,validationOfDefaultCalculatorPrice)==null)||(!configPage.techProblemError(resultDirectory,validationOfDefaultCalculatorPrice).contains("SE HA PRODUCIDO UN ERROR")==true)) {
                    Thread.sleep(10000);
                String config_DurationPrice = configPage.getFinanceDurationPrice(resultDirectory, validationOfDefaultCalculatorPrice, country, brand,PaymentMode);
                System.out.println("config_DurationPrice: "+config_DurationPrice);
                config_monthlyPrice = configPage.getFinanceContainerPriceAmount(resultDirectory, validationOfDefaultCalculatorPrice);
                System.out.println("config_monthlyPrice: "+config_monthlyPrice);
                if ((Float.parseFloat(config_monthlyPrice))-(Float.parseFloat(config_DurationPrice))<1) {
                    validationOfDefaultCalculatorPrice.log(Status.PASS, "Default finance duration price "
                            + config_DurationPrice + " on calculator popup and Config page matches");
                    //sa.assertTrue(true);
                } else {
                    failWithScreenshot("Default finance duration price " + config_DurationPrice + " on calculator popup and config page " + config_monthlyPrice + " is not correct", resultDirectory, driver, extent, validationOfDefaultCalculatorPrice);
                    //sa.assertTrue(false, "Default price on calculator popup and config page is not correct");
                }
                //sa.assertAll();
                //Thread.sleep(5000);
                //configPage.clickClosePopup(resultDirectory, validationOfDefaultCalculatorPrice);
                //validationOfDefaultCalculatorPrice.log(Status.INFO, "Calculator popup close");
                //	logger.log(Status.INFO, MarkupHelper.createLabel("Calculator popup close", ExtentColor.BLUE));
                //Thread.sleep(4000);
            }else{
                    validationOfDefaultCalculatorPrice.log(Status.WARNING, "Default Calculator Price can not be validate as the link itself is not available or the technical Error Page is appeared");
                    failWithScreenshot("Default Calculator Price can not be validate as the link itself is not available or the technical Error Page is appeared",resultDirectory, driver, extent, validationOfDefaultCalculatorPrice);
                    //configPage.clickClosePopup(resultDirectory, validationOfDefaultCalculatorPrice);
                }
            } else {
                validationOfDefaultCalculatorPrice.log(Status.WARNING, "Default Calculator Price can not be validated as the link itself is not available");
                failWithScreenshot("Default Calculator Price can not be validate as the link itself is not available",resultDirectory, driver, extent, validationOfDefaultCalculatorPrice);
            }

        } catch (Exception e1) {
            e1.printStackTrace();
			/*validationOfDefaultCalculatorPrice.log(Status.FAIL,"Test Failed");
			failWithScreenshot("Test Failed", resultDirectory, driver, extent, validationOfDefaultCalculatorPrice);
			validationOfDefaultCalculatorPrice.log(Status.FAIL, String.valueOf(e1.getStackTrace()));*/
            catchFailDetails(resultDirectory, validationOfDefaultCalculatorPrice, driver, "Unable to validate Default Calculator Price", e1);
            //configPage.clickClosePopup(resultDirectory, validationOfDefaultCalculatorPrice);

        }
    }

    @Test(description = "validation After Default Calculator Price")
    public static void validateAfterDefaultCalculatorPrice(String resultDirectory, WebDriver driver,
                                                           ExtentReports extent, ExtentTest logger, String brand, String country, String PaymentMode) throws Exception {
        ExtentTest validationOfDefaultCalculatorPriceAfterChangingDuration = extentCP.createNode("ValidationOfDefaultCalculatorPriceAfterChangingDuration", "Validation of default calculator price after changing duration");
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            ConfigPage configPage = new ConfigPage(driver);
            String config_monthlyPrice = null;
            //SoftAssert sa = new SoftAssert();
            if (isElementPresent(driver, ConfigPage.clickOnPersonalizeFinanceButton, 10)) {
                //configPage.clickOnPersonalizeFinanceButton(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration);
                validationOfDefaultCalculatorPriceAfterChangingDuration.log(Status.INFO, "click on Personalize Finance Button");
                //	logger.log(Status.INFO, MarkupHelper.createLabel("click on Personalize Finance Button", ExtentColor.BLUE));
                Thread.sleep(500);
                configPage.clickFinanceDurationButton(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration);
                //validationOfDefaultCalculatorPriceAfterChangingDuration.log(Status.INFO, "Click on finance duration button");
                //	logger.log(Status.INFO, MarkupHelper.createLabel("Click on finance duration 36 button", ExtentColor.BLUE));
                Thread.sleep(3000);
                if (country.equals("FR")) {
                    if (!brand.equals("OV")) {
                        configPage.selectAssuranceCheckbox(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration);
                        Thread.sleep(3000);
                        configPage.selectAssuranceConfirmCheckbox(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration);
                        Thread.sleep(500);
                    }
                }
                String config_CalculatorDurationPrice = configPage.getFinanceDurationPrice(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration, country, brand, PaymentMode);

                configPage.clickOnCalculatorContinueButton(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration);
                //Thread.sleep(5000);

                config_monthlyPrice = configPage.getFinanceContainerPriceAmount(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration);
                if (Float.parseFloat(config_monthlyPrice)-Float.parseFloat(config_CalculatorDurationPrice)<=1) {
                    validationOfDefaultCalculatorPriceAfterChangingDuration.log(Status.PASS, "After duration change on Calculator, price "
                            + config_CalculatorDurationPrice + " on Calculator popup and Config page matches");
                    //sa.assertTrue(true);
                } else {
                    failWithScreenshot("After duration change on Calculator popup, calculator price " + config_CalculatorDurationPrice + " and config page price " + config_monthlyPrice + " does not match", resultDirectory, driver, extent, validationOfDefaultCalculatorPriceAfterChangingDuration);
				/*sa.assertTrue(false,
						"After duration change on Calculator popup, calculator price and config page price does not match");*/
                }
                //sa.assertAll();
            } else {
                validationOfDefaultCalculatorPriceAfterChangingDuration.log(Status.INFO, "Default Calculator is not available");
            }
        } catch (Exception e1) {
			/*validationOfDefaultCalculatorPriceAfterChangingDuration.log(Status.FAIL,"Test Failed");
			failWithScreenshot("Test Failed", resultDirectory, driver, extent, validationOfDefaultCalculatorPriceAfterChangingDuration);
			validationOfDefaultCalculatorPriceAfterChangingDuration.log(Status.FAIL, String.valueOf(e1.getStackTrace()));*/
            catchFailDetails(resultDirectory, validationOfDefaultCalculatorPriceAfterChangingDuration, driver, "Error with validation After Default Calculator Price", e1);
        }
    }

}
