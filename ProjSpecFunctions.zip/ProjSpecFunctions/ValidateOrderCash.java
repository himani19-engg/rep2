package solRetailIHM.ProjSpecFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.PageObjectModel.ReprisePage;
import solRetailIHM.Utilities.UniversalMethods;
import solRetailIHM.PageObjectModel.OrderPage;
import solo2c.ProjSpecFunctions.ChoosePaymentMode;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.getbasketPgVehicleName;


@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ValidateOrderCash extends UniversalMethods {
	public static ExtentTest orderValidation;
	@Test(description = "Validate Order Cash")
	public static void orderValidation(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country, String catalan,String PaymentMode,String Name,String PostalCode,String EmailId, String City, String Phone) throws Exception {
		if(driver!=null) {
			orderValidation = logger.createNode("OrderSummary", "Check Order Summary page");
			try {
				OrderPage or = new OrderPage(driver);
				ReprisePXcheckout cashPr = new ReprisePXcheckout();
				waitForPageToLoad(driver, 20);
				// Validating Order Summary Page URL
				if(!brand.equalsIgnoreCase("OV")) {
					CheckPersonnalInfoCash.validatePersonalInfo(resultDirectory, driver, extent, orderValidation, brand, country, EmailId, PostalCode, City, Phone, Name);
					CheckPersonnalInfoCash.validateRetailerAddress(resultDirectory, driver, extent, orderValidation, brand, country);
					CheckPersonnalInfoCash.validateRefundableFeeAmount(resultDirectory, driver, extent, orderValidation, brand, country, PaymentMode);
					PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, orderValidation, getbasketPgVehicleName, "PaymentPage", By.xpath("//*[@class='versionLabel']"));
					PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, orderValidation, country);
					//CheckPersonnalInfoCash.validatePersonalInfo(resultDirectory, driver, extent, orderValidation, brand, country, EmailId, PostalCode, City, Phone, Name);
				}

				or.orderValidationOfSuccessMessage(resultDirectory, driver, extent, orderValidation, brand, country, PaymentMode);
				or.orderSummaryPageURLVerification(resultDirectory, driver, extent,
						orderValidation, brand, Country, PaymentMode, Name, PostalCode, EmailId);

				//Validating CashPrice on Order Summary Page
				or.validateOrderSummaryMonthlyPricewithIdentificationPrice(resultDirectory, driver, extent, orderValidation, country, PaymentMode, brand);

				// click on terms of use checkbox
				or.CashTermsofUseCK(brand);
				orderValidation.log(Status.INFO, "Clicked terms of use checkbox");

				// click deliveryDateCheckbox
			/*if (!country.equalsIgnoreCase("ES")) {
				or.CashDeliveryCK();
				logger.log(Status.INFO, MarkupHelper.createLabel("Clicked Delivery checkbox", ExtentColor.BLUE));
			}*/

				// click on catalan checkbox
				if (country.equalsIgnoreCase("ES") && (catalan.equalsIgnoreCase("yes"))) {
					or.clickCatalanCheckBox();
					orderValidation.log(Status.INFO, "Clicked on Catalan checkbox");
					if (or.getCatalanCheckboxText().contains("catalán")) {
						orderValidation.log(Status.INFO, "Catalan text appeared");
						Assert.assertTrue(true);
					} else {
						failWithScreenshot("Catalan text not appeared", resultDirectory, driver, extent, orderValidation);
					}
				}

				if (brand.equalsIgnoreCase("OV") != true && country.equalsIgnoreCase("ES")&& (!catalan.equalsIgnoreCase("yes"))) {
					//verification of Box Images
					or.boxImageVerification(resultDirectory, driver, extent,
							orderValidation, brand, country, PaymentMode, Name, PostalCode, EmailId);

					//Closer To Car Info Verification
					or.closerToCarInfo(resultDirectory, driver, extent,
							orderValidation, brand, country, PaymentMode, Name, PostalCode, EmailId);
				}

				if (country.equalsIgnoreCase("ES")) {
					//Validating User Info
					or.userInfoVerification(resultDirectory, driver, extent,
							orderValidation, brand, country, PaymentMode, Name, PostalCode, EmailId);

				}


				// validate order
				or.ValidateCashOrder(brand, country, PaymentMode);
				orderValidation.log(Status.INFO, "Order validation");
				//Thread.sleep(1000);

				// Validate arriving on payment page
				//waitForUrlContains("-gateway.hipay-tpp.com/", driver, 10);
				waitForPageToLoad(driver, 50);
				if(driver.getCurrentUrl().contains("payment/confirmation")) {

				}else {
					waitForUrlContains("-gateway.hipay-tpp.com/", driver, 100);
					//Thread.sleep(3000);
					WebDriverWait wait = new WebDriverWait(driver, 50);
					wait.until(ExpectedConditions.urlContains("-gateway.hipay-tpp.com/"));
					if (driver.getCurrentUrl().contains("-gateway.hipay-tpp.com/")) {
						orderValidation.log(Status.PASS, "Payment page has appeared");
					} else {
						orderValidation.log(Status.FAIL, "Payment page has not appeared");
					}
				}
				//Thread.sleep(2000);
				waitForPageToLoad(driver, 5);
			} catch (Exception e) {
			/*orderValidation.log(Status.FAIL,"Test Failed while Validate Order Cash");
			failWithScreenshot("Test Failed while Validate Order Cash", resultDirectory, driver, extent, orderValidation);
			orderValidation.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				e.printStackTrace();
				catchFailDetails(resultDirectory, orderValidation, driver, "Test Failed while Validate Order Cash", e);
			}
		}
	}

}
