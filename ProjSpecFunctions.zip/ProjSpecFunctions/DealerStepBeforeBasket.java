package solRetailIHM.ProjSpecFunctions;

import static solRetailIHM.PageObjectModel.HomePage.getHomePageVahicleName;
import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.*;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)
@Test(description = "Navigate to Dealet Step Before Basket and Validation ")
public class DealerStepBeforeBasket extends UniversalMethods {

    public static ExtentTest navigateToDealerStepBeforeBasketAndValidation;

    public static String getDealerPageVehicalename;
    public static void goToDealerStep(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                      String Country, String PostalCode, String DealerPage, String Brand, String PaymentMode) throws Exception {
        navigateToDealerStepBeforeBasketAndValidation = extentCP.createNode("Navigate To New Dealer before BasketPage", "Navigating To NewDealerbeforeBasket Page");
        if(driver!=null) {
            try {
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                ConfigPage cyp = new ConfigPage(driver);
                DealerStepBeforeBasketPage dsbkt = new DealerStepBeforeBasketPage(driver);
                waitForPageToLoad(driver, 15);
                writeToProperties("currentCashPrice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_CASH_PRICE']/span[1]")).replace(",","."))));
                if(PaymentMode.equalsIgnoreCase("Finance")){
                    writeToProperties("currentFinanceprice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_CONFIG_FINANCE_PRICE']/span[1]")).replace(",","."))));
                }
                if(isElementPresent(driver,By.xpath("//*[@data-testid='TESTING_CLOSE_MODAL']"))){
                    clickElement(driver,By.xpath("//*[@data-testid='TESTING_CLOSE_MODAL']"));
                }
                cyp.clickConfigcontinue(resultDirectory, navigateToDealerStepBeforeBasketAndValidation,Country,Brand);

                waitForPageToLoad(driver, 15);
                Thread.sleep(3000);
                if(driver.getCurrentUrl().contains("/summary")){
                    waitForPageToLoad(driver, 15);
                    clickElement(driver,By.xpath("//*[@data-testid='TESTING_CLOSE_MODAL']"));
                    int monthlyTotalPriceOrderSummarySize=driver.findElements(By.xpath("//div[contains(@class,'cashPrice')]")).size();
                    Float monthlyTotalPriceOrderSummary=extractFloatFromString(getAnyText(driver,By.xpath("(//div[contains(@class,'cashPrice')])["+monthlyTotalPriceOrderSummarySize+"]")).replace("","").replace(",",""));
                    int FinancePriceOrderSummarySize=driver.findElements(By.xpath("//div[contains(@class,'monthlyPrice')]")).size();
                    if(FinancePriceOrderSummarySize!=0){
                        Float FinancePriceOrderSummary=extractFloatFromString(getAnyText(driver,By.xpath("(//div[contains(@class,'monthlyPrice')])["+FinancePriceOrderSummarySize+"]")).replace("","").replace(",","."));
                    }
                    Float configPageCashPrice=Float.parseFloat(readFromProperties("currentCashPrice"));
                    Float summaryPageCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("(//*[@data-testid='TESTING_VEHICLE_SUMMARY_STORE_PRICE'])[2]")).replace(",","."));
                    if(configPageCashPrice-summaryPageCashPrice<1){
                        navigateToDealerStepBeforeBasketAndValidation.log(Status.PASS,"Summary Page cash price "+summaryPageCashPrice+" is same as Config Page cash price");
                    } else{
                        navigateToDealerStepBeforeBasketAndValidation.log(Status.FAIL,"Summary Page cash price "+summaryPageCashPrice+" is not same as Config Page cash price");
                    }
                    writeToProperties("currentCashPrice",String.valueOf(summaryPageCashPrice));
                    if(PaymentMode.equalsIgnoreCase("Finance")) {
                        Float configPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
                        Float summaryPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("(//div[@data-testid='TESTING_VEHICLE_SUMMARY_MONTHLY_PRICE'])[2]")).replace(",", "."));
                        if (configPageFinancePrice - summaryPageFinancePrice < 1) {
                            navigateToDealerStepBeforeBasketAndValidation.log(Status.PASS, "Summary page Finance Price" + summaryPageFinancePrice + "is same as config page finance price");
                        } else {
                            navigateToDealerStepBeforeBasketAndValidation.log(Status.FAIL, "Summary page Finance Price" + summaryPageFinancePrice + "is not same as config page finance price");
                        }
                        writeToProperties("currentFinanceprice",String.valueOf(summaryPageFinancePrice));
                    }
                    if(Brand.equalsIgnoreCase("AC")&&Country.equalsIgnoreCase("FR")){
                        clickUsingJS(driver, By.xpath("(//*[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX'])[2]"));
                        Thread.sleep(9000);
                    }
                    else{
                        clickElement(driver, By.xpath("(//*[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX'])[2]"));
                        Thread.sleep(9000);
                    }
                    //cyp.clickConfigcontinue(resultDirectory, navigateToDealerStepBeforeBasketAndValidation, Brand,Country);
                }
                waitForUrlContains("/dealers", driver, 90);
                Thread.sleep(9000);
                if (driver.getCurrentUrl().contains("/dealers")) {
                    navigateToDealerStepBeforeBasketAndValidation.log(Status.
                            PASS, "Redirection to dealer step before basket page is completed");
                } else {
                    navigateToDealerStepBeforeBasketAndValidation.log(Status.FAIL, "Redirection to dealer step before basket page is not completed");
                }

                if (DealerPage.equalsIgnoreCase("yes")) {
                    //waitForUrlContains("/dealers", driver, 20);
                    waitForPageToLoad(driver, 10);
                    waitForUrlContains("/dealers", driver, 20);
                    clickElement(driver,By.xpath("//span[@data-testid='TESTING_VEHICLE_SUMMARY_TITLE_ICON']"));
                    //summary page and dealer page
                    writeToProperties("currentCashPrice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("(//span[@data-testid='TESTING_VEHICLE_SUMMARY_STORE_PRICE'])[1]|//*[@data-testid='TESTING_VEHICLE_SUMMARY_TOTAL_CASH_PRICE']")).replace(",","."))));
                  //  writeToProperties("currentCashPrice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("//div[@data-testid='TESTING_VEHICLE_SUMMARY_BASE_PRICE']")).replace(",","."))));
                    if(PaymentMode.equalsIgnoreCase("Finance")){
                        writeToProperties("currentFinanceprice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("(//div[@data-testid='TESTING_VEHICLE_SUMMARY_MONTHLY_PRICE'])[1]|//div[@data-testid='TESTING_VEHICLE_SUMMARY_TOTAL_MONTHLY_PRICE']")).replace(",","."))));
                       // writeToProperties("currentFinanceprice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("//div[@data-testid='TESTING_VEHICLE_SUMMARY_TOTAL_MONTHLY_PRICE']")).replace(",","."))));
                    }
                    //
                    Thread.sleep(4000);
                    String URl = driver.getCurrentUrl();

                    //  if (URl.contains("/dealers") && (getAnyText(driver, By.className("title")).equalsIgnoreCase("Choisissez votre concessionnaire vendeur"))) {
                    //if (URl.contains("/dealers") && (getAnyText(driver, By.className("title")).equalsIgnoreCase("Dealer selection") || getAnyText(driver, By.className("title")).equalsIgnoreCase("Choisissez votre concessionnaire vendeur"))) {
                    if (URl.contains("/dealers") && (getAnyText(driver, By.xpath("//*[@data-testid='TESTING_DEALER_CHOICE_TITLE']")).equalsIgnoreCase("Dealer selection") || getAnyText(driver, By.xpath("//*[@data-testid='TESTING_DEALER_CHOICE_TITLE']")).equalsIgnoreCase("Choisissez votre concessionnaire vendeur"))) {
                        navigateToDealerStepBeforeBasketAndValidation.log(Status.PASS, "Redirection to dealer step before basket page is completed");
                    } else {
                        navigateToDealerStepBeforeBasketAndValidation.log(Status.FAIL, "Redirection to dealer step before basket page is NOT completed");
                    }
                }


            } catch (Exception e) {
		/*failWithScreenshot("Test Failed while Navigating To Basket and Validations", resultDirectory, driver, extent, navigateToBasketAndValidation);
		navigateToBasketAndValidation.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                e.printStackTrace();
                catchFailDetails(resultDirectory, navigateToDealerStepBeforeBasketAndValidation, driver, "Test Failed while Navigating To Deler Step Basket and Validations", e);
            }
        }
        //dealer page finance price
       if(PaymentMode.equalsIgnoreCase("Finance")){
            Float summaryPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
            //clickElement(driver,By.xpath("//span[@data-testid='TESTING_VEHICLE_SUMMARY_TITLE_ICON']"));
           Thread.sleep(2000);
            Float dealerPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//div[@data-testid='TESTING_VEHICLE_SUMMARY_TOTAL_MONTHLY_PRICE']")));
            if(summaryPageFinancePrice - dealerPageFinancePrice<1){
                navigateToDealerStepBeforeBasketAndValidation.log(Status.PASS,"Dealer Page Finance Price" + dealerPageFinancePrice + "is same as Summary page finance price");
            }else{
                navigateToDealerStepBeforeBasketAndValidation.log(Status.FAIL,"Dealer Page Finance Price" + dealerPageFinancePrice + "is not same as Summary page finance price");
            }

        }
//
    }

    public static void DealerPagePASS(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                             String Country, String PostalCode, String emailId, String name, String phone, String Brand) throws Exception {
        if(driver!=null) {
            navigateToDealerStepBeforeBasketAndValidation = logger.createNode("DealerBeforeBasketPage", "Verifying Dealer Choice");
            try {
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                DealerStepBeforeBasketPage dsbkt = new DealerStepBeforeBasketPage(driver);
                waitForUrlContains("/dealers", driver, 10);
                dsbkt.enterpostalCode(resultDirectory, PostalCode, navigateToDealerStepBeforeBasketAndValidation);
                dsbkt.clickOnSearchButton(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);
                //clickElement(driver,By.xpath("//*[@data-testid='TESTING_LOCATION_PREDICTED_PLACE_0']"));
            } catch (Exception e) {
		/*failWithScreenshot("Test Failed while Navigating To Basket and Validations", resultDirectory, driver, extent, navigateToBasketAndValidation);
		navigateToBasketAndValidation.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                e.printStackTrace();
                catchFailDetails(resultDirectory, navigateToDealerStepBeforeBasketAndValidation, driver, "Test Failed while Navigating To Deler Step Basket and Validations", e);
            }
        }
    }

    public static void verifyTheDealerChoice(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                             String Country, String PostalCode, String emailId, String name, String phone, String Brand) throws Exception {
        if(driver!=null) {
            navigateToDealerStepBeforeBasketAndValidation = logger.createNode("DealerBeforeBasketPage", "Verifying Dealer Choice");
            try {
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

                DealerStepBeforeBasketPage dsbkt = new DealerStepBeforeBasketPage(driver);
                waitForUrlContains("/dealers", driver, 10);
                //Call all those developed Functions here
                if (dsbkt.validateDealerChoiceInFeatureSwitch(resultDirectory, navigateToDealerStepBeforeBasketAndValidation)) {
                    dsbkt.clickSearchPostalCode(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.enterpostalCode(resultDirectory, PostalCode, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.clickOnSearchButton(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.deletePostalCode(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.clickSearchPostalCode(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.enterpostalCode(resultDirectory, PostalCode, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.clickOnSearchButton(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.verifyDefaultSelectedDealer(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.verifyNumberofDefaultVisibleList(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    //    dsbkt.getDealerList(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.verifyNumberofDefaultVisibleListAftClickingMore(PostalCode, emailId, name, phone, resultDirectory, navigateToDealerStepBeforeBasketAndValidation, Brand, Country);

                    //   dsbkt.getDealerList(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);

                    dsbkt.verifyGoToBasketScreenAfterClickingContinue(resultDirectory, navigateToDealerStepBeforeBasketAndValidation);
                } else {
                    navigateToDealerStepBeforeBasketAndValidation.log(Status.FAIL, "is dealer choice enabled: False");
                }


            } catch (Exception e) {
		/*failWithScreenshot("Test Failed while Navigating To Basket and Validations", resultDirectory, driver, extent, navigateToBasketAndValidation);
		navigateToBasketAndValidation.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                e.printStackTrace();
                catchFailDetails(resultDirectory, navigateToDealerStepBeforeBasketAndValidation, driver, "Test Failed while Navigating To Deler Step Basket and Validations", e);
            }
        }
    }

}
		
