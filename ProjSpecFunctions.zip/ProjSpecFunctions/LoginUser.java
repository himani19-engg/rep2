package solRetailIHM.ProjSpecFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.testng.asserts.SoftAssert;
import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.PageObjectModel.ChooseDealerPage;
import solRetailIHM.PageObjectModel.LoginUserPage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.Utilities.UniversalMethods;

import static java.lang.Integer.parseInt;
import static solRetailIHM.PageObjectModel.HomePage.getHomePageVahicleName;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.MonthlyTotalBasketCash;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.getbasketPgVehicleName;
import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.vehicleName;
import static solRetailIHM.ProjSpecFunctions.ValidateBasket.MonthlyTotalBasketFin;
import static solRetailIHM.ProjSpecFunctions.ValidateBasket.financePriceOnBasketPage;

@Listeners(solRetailIHM.Runner.ListenerTest.class)


@Test(description = "Login into Application")
public class LoginUser extends UniversalMethods {
	public static ExtentTest loginIntoApplication;
	public static Float cashPriceOnPersonalInfo;
	public static Float financePriceNo;
	public static Float totalMonthlyPriceIdentificationFloat;
	public static void loginAccount(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String brand, String Country, String PaymentMode, String VehicleChoice, String EmailId, String Password)
			throws Exception {
		if(driver!=null) {
			loginIntoApplication = logger.createNode("Identification", "Checking Identification page");
			try {
				PersonnalInfoPage pi = new PersonnalInfoPage(driver);
				ChooseDealerPage dea = new ChooseDealerPage(driver);
				LoginUserPage login = new LoginUserPage(driver);
				BasketPage bkt = new BasketPage(driver);
				SoftAssert sa = new SoftAssert();
				String financePriceOnPersonalInfo = "";

				// go to login page
				// if ((PaymentMode.equals("Finance")) || (VehicleChoice.equals("ec41"))) {
				// pi.Login();
				// logger.log(Status.INFO, MarkupHelper.createLabel("Go to login page" ,
				// ExtentColor.BLUE));}

				// if ((PaymentMode.equals("Cash")) && (!VehicleChoice.equals("ec41"))) {

				// get cash price and finance price on personal info page
				if (!brand.equals("OV")&&Country.equalsIgnoreCase("FR")) {
					CheckPersonnalInfoCash.validateRetailerAddress(resultDirectory,driver,extent,loginIntoApplication,brand, Country);
					CheckPersonnalInfoCash.validateRefundableFeeAmount(resultDirectory,driver,extent,loginIntoApplication,brand, Country, PaymentMode);
					System.out.println("HomePage vehicle Name is: "+vehicleName);
					PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, loginIntoApplication, getbasketPgVehicleName, "IdentificationPage", By.xpath("//*[@class='versionLabel']"));
					PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, loginIntoApplication, Country);
					String str;
					if (PaymentMode.equalsIgnoreCase("Cash")) {
						if(Country.equalsIgnoreCase("FR")) {
							 str = pi.getCashPriceOnPersonalInfo().replace(" ", "").replace(",", ".");
						}else {
							 str = pi.getCashPriceOnPersonalInfo().replace(" ", "");
							 if(str.contains("."))
							 {
								 str = str.replace(".","");
							 }
							 if(str.contains(","))
							 {
								 str = str.replace(",",".");
							 }

						}
						cashPriceOnPersonalInfo = extractFloatFromString(str);
						//String cashPriceNo = pi.getCashPriceOnPersonalInfo().substring(0, 6);

						//if (cashPriceNo.equals(pi.readFromProperties("dealear_CashPrice"))) {
						if(MonthlyTotalBasketCash!=null){
							if ((MonthlyTotalBasketCash-cashPriceOnPersonalInfo)<=1) {
								loginIntoApplication.log(Status.PASS, "Cash price " + cashPriceOnPersonalInfo +
										" on Basket Page and personal info page matches");
								//sa.assertTrue(true);
							} else {
								failWithScreenshot("Cash price " + cashPriceOnPersonalInfo + " on Basket page and personal info page does not match", resultDirectory, driver, extent, loginIntoApplication);
						/*sa.assertTrue(false, "Cash price " + cashPriceOnPersonalInfo
								+ " on delear page and personal info page does not match");*/
							}
						}
					}
				}

				if (!brand.equals("AC")&&Country.equalsIgnoreCase("FR")) {
					if (PaymentMode.equalsIgnoreCase("Finance")) {
						financePriceOnPersonalInfo = pi.getFinancePriceOnPersonalInfo(Country, brand);

						if (Country.equalsIgnoreCase("ES") && (brand.equalsIgnoreCase("AP"))) {
							financePriceNo = extractFloatFromString(pi.getFinancePriceOnPersonalInfo(Country, brand).replace(".", "").replace(",", ".").replace(" ", ""));
						} else {
							if (brand.equalsIgnoreCase("DS") == false) {
								financePriceNo = extractFloatFromString(pi.getFinancePriceOnPersonalInfo(Country, brand).replace(",", ".").replaceAll(" ", "").replaceAll(" ", ""));
								System.out.println("Finance Price is: " + financePriceNo);
							} else {
								if (brand.equalsIgnoreCase("DS") != true && Country.equalsIgnoreCase("FR") != true) {
									financePriceNo = extractFloatFromString(pi.getFinancePriceOnPersonalInfo(Country, brand).replace(".", "").replaceAll(" ", ""));
								} else {
									financePriceNo = extractFloatFromString(pi.getFinancePriceOnPersonalInfo(Country, brand).replace(".", "").replaceAll(" ", ""));
								}
								System.out.println("Finance Price is: " + financePriceNo);
							}
						}
						//System.out.println("Finance Price No. is: "+Float.parseFloat(financePriceNo));
						if (financePriceNo != null) {
							//System.out.println(Float.parseFloat(pi.readFromProperties("dealear_FinancePrice").replace(",", ".").replaceAll(" ", "")));
							System.out.println("Finance Price No.: " + financePriceNo);
							System.out.println("Finance Price No. from Property File: " + pi.readFromProperties("dealear_FinancePrice"));
							if ((financePriceNo- MonthlyTotalBasketFin)<=1) {
								loginIntoApplication.log(Status.PASS, "Finance price " + financePriceNo
										+ "on Basket page and personal info page matches");
							} else {
								failWithScreenshot("Finance price " + financePriceOnPersonalInfo + " on delear page and personal info page does not match", resultDirectory, driver, extent, logger);
								loginIntoApplication.log(Status.FAIL, "Finance price " + financePriceOnPersonalInfo
										+ "on Basket page and personal info page doesn't match");
							}

							totalMonthlyPriceIdentificationFloat=extractFloatFromString(getAnyText(driver,By.xpath("//p[@class='prix_mois']/span[2]"),60).replace(" ","").replace(",","."));
							if(financePriceOnBasketPage-totalMonthlyPriceIdentificationFloat<=1){
								loginIntoApplication.log(Status.PASS, "Finance Price on Basket Page is same as on total Monthly Price Identification/Personal Info Page which is: "+totalMonthlyPriceIdentificationFloat);
							}else{
								loginIntoApplication.log(Status.FAIL, "Finance Price on Basket Page is not same as on total Monthly Price Identification/Personal Info Page ");
							}

						} else {
							failWithScreenshot("Finance price is not found", resultDirectory, driver, extent, logger);
							loginIntoApplication.log(Status.FAIL, "Finance price is not found");
						}
					}
				}

				if (brand.equals("OV")) {
					pi.clickExistingAccount_OV();
				} else {
					// Enter mailId
					//Thread.sleep(1500);
					try {
						waitForPageToLoad(driver, 5);
						Thread.sleep(2000);
						waitForUrlContains("personnal-information", driver, 20);
						login.enterEmailID(EmailId.toLowerCase());
						Thread.sleep(1000);
						loginIntoApplication.log(Status.INFO, "Enter emailId");
						//waitForPageToLoad(driver, 20);
						//driver.switchTo().defaultContent();
						waitForElementPresent(driver, By.xpath("//div[contains(@class,'welcome-back')]"), 30);
						//waitForUrlContains("/personnal-information", driver, 20);
						pi.ContinueButtonLogin(brand,Country);
						loginIntoApplication.log(Status.INFO, "Click on validate button");
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				waitForPageToLoad(driver, 40);
				// enter email
				login.enterEmail(EmailId, resultDirectory, loginIntoApplication);

				// enter password
				login.enterPassword(Password, resultDirectory, loginIntoApplication);

				// validate login
				login.validate(resultDirectory, loginIntoApplication);
				//Thread.sleep(8000);
				waitForPageToLoad(driver, 60);
				//loginIntoApplication.log(Status.INFO,"Login validation");

				if (VehicleChoice.equals("ec41")) {
					waitForUrlContains("/basket?withOffersModal=true", driver, 540);
				} else {
					// if (PaymentMode.equals("Finance")) {
					// waitForUrlContains("checkout/my-details", driver, 540);}

					// if (PaymentMode.equals("Cash")) {
					// waitForUrlContains("personnal-information", driver, 540);
					//Thread.sleep(2000);
					//waitForPageToLoad(driver,5);
				}
				// }

				// Validate arriving on personnal info page
				if (VehicleChoice.equals("ec41")) {
					if (bkt.CommercialOfferPopup(resultDirectory, loginIntoApplication)) {
						loginIntoApplication.log(Status.PASS, "commercial offer popup has appeared");
						//sa.assertTrue(true);
					} else {
						failWithScreenshot("commercial offer popup has not appeared", resultDirectory, driver, extent, loginIntoApplication);
						//sa.assertTrue(false, "commercial offer popup has not appeared");
					}

				} else {
					if (PaymentMode.equals("Finance")) {
						Thread.sleep(7000);
						if (Country.equalsIgnoreCase("FR")) {
							String identificationHeader = "";
							if (brand.equals("OV"))
								identificationHeader = dea.getIdentificationHeader_OV();
							else if (brand.equals("AC"))
								identificationHeader = pi.getCashIdentification_AC();
							else
								identificationHeader = pi.getCashIdentification(Country);

							if ((identificationHeader.contains("Identification"))
									|| (identificationHeader.contains("IDENTIFICATION"))
									|| (identificationHeader.contains("Identificación"))
									|| (identificationHeader.contains("IDENTIFICACIÓN"))) {
								loginIntoApplication.log(Status.PASS, "Personnal Info page page has appeared");
								//sa.assertTrue(true);
							} else {
								failWithScreenshot("Personnal Info page has not appeared", resultDirectory, driver, extent,
										loginIntoApplication);
								//sa.assertTrue(false, "PERSONNAL INFO PAGE page has not appeared");
							}
						}

						if (Country.equalsIgnoreCase("UK")) {

							if (!driver.getCurrentUrl().contains("citroen")) {
								if (pi.PersonnalInfo().equals("progressCar progressCar-confirmation")) {
									loginIntoApplication.log(Status.PASS, "PERSONNAL INFO PAGE page has appeared");
									//sa.assertTrue(true);
								} else {
									failWithScreenshot("PERSONNAL INFO PAGE page has not appeared", resultDirectory,
											driver, extent, loginIntoApplication);
									//sa.assertTrue(false, "PERSONNAL INFO PAGE page has not appeared");
								}
							} else {

								if (pi.PersonnalInfo_UK_AC().equals("progressCar progressCar-confirmation")) {

									loginIntoApplication.log(Status.PASS, "PERSONNAL INFO PAGE page has appeared");

									//sa.assertTrue(true);
								} else {
									failWithScreenshot("PERSONNAL INFO PAGE page has not appeared", resultDirectory,
											driver, extent, loginIntoApplication);
									//sa.assertTrue(false, "PERSONNAL INFO PAGE page has not appeared");
								}
							}
						}

					} else if (PaymentMode.equals("Cash")) {
						Thread.sleep(7000);
						String identificationHeader = "";
						if (brand.equals("OV"))
							identificationHeader = dea.getIdentificationHeader_OV();
						else if (brand.equals("AC") ||
								(Country.equalsIgnoreCase("ES") && brand.equalsIgnoreCase("DS")))
							identificationHeader = pi.getCashIdentification_AC();
						else
							identificationHeader = pi.getCashIdentification(Country);

						if ((identificationHeader.contains("Identification"))
								|| (identificationHeader.contains("IDENTIFICATION"))
								|| (identificationHeader.contains("Identificación"))
								|| (identificationHeader.contains("Identificaci"))
								|| (identificationHeader.contains("IDENTIFICACIÓN"))) {
							loginIntoApplication.log(Status.PASS, "PERSONNAL INFO PAGE page has  appeared");
							//sa.assertTrue(true);
						} else {
							failWithScreenshot("Personnal Info page has not appeared", resultDirectory, driver, extent,
									loginIntoApplication);
							//sa.assertTrue(false, "PERSONNAL INFO PAGE page has not appeared");
						}
					}
				}
				//sa.assertAll();
				//}
			} catch (Exception e) {
			/*loginIntoApplication.log(Status.FAIL,"Test Failed while Login into Application");
			failWithScreenshot("Test Failed while Login into Application", resultDirectory, driver, extent, loginIntoApplication);
			loginIntoApplication.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				e.printStackTrace();
				catchFailDetails(resultDirectory, loginIntoApplication, driver, "Test Failed while Login into Application", e);
			}
		}
	}
}
