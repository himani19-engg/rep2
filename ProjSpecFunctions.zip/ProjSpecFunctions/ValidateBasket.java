package solRetailIHM.ProjSpecFunctions;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.PageObjectModel.CookieAccepter;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ValidateBasket extends UniversalMethods {
    public static Float financePriceOnBasketPage;
    public static Float MonthlyTotalBasketFin;

    //public static ExtentTest basketVerification;
    @Test(description = "Check Basket")
    public static void navigateToDealerPage(String resultDirectory, WebDriver driver, ExtentReports extent,
                                            ExtentTest logger, String Brand, String Country, String PaymentMode, String VehicleChoice,
                                            String PostalCode, String DealerPage) throws Exception {
        if (driver != null) {
            ExtentTest basketVerification = extentBP.createNode("NavigateToDealerPage", "Navigate to Dealer page");
            try {
                //driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
                BasketPage bkt = new BasketPage(driver);
                HomePage hmpg = new HomePage(driver);

                waitForUrlContains("/basket", driver, 30);

            /*if(PaymentMode.equalsIgnoreCase("Finance")) {
                String financePriceOnBasketPageText = getAnyText(driver, By.xpath("//span[@class='totalPrice_monthlyPrice_price']//span[@class='formatted']//span[@class='formatMoney']")).replace(" ", "").replace(",", ".");
                if (financePriceOnBasketPageText != null) {
                    financePriceOnBasketPage = Float.parseFloat(financePriceOnBasketPageText);
                }
            }*/

                MonthlyTotalBasketFin= extractFloatFromString(getAnyText(driver,By.xpath("//div[contains(@class,'totalPrice_cashPrice')]")).replace(" ","").replace(",","."));
                financePriceOnBasketPage = bkt.getFinancePrice(driver, resultDirectory, basketVerification, PaymentMode);


                // ValidateBasket
                Thread.sleep(2000);
                //driver.navigate().refresh();
                Thread.sleep(2000);
                CookieAccepter accept = new CookieAccepter(driver);
                accept.clickContAccepter(resultDirectory, basketVerification);
                bkt.clickBasketContinue(Country, resultDirectory, basketVerification);
                //Thread.sleep(5000);
                //basketVerification.log(Status.INFO, "Continue button is clicked on Basket page");

                // Thread.sleep(5000);
                // driver.get(driver.getCurrentUrl());
                // Thread.sleep(4000);

                //getScreenshot(driver, resultDirectory, "test");

                // Close book a test drive
                if ((Country.equalsIgnoreCase("UK")) && (Brand.equalsIgnoreCase("DS"))) {
                    hmpg.CloseBookTestDrive(resultDirectory, basketVerification);
                }

                // Validate we arrive on dealer page for finance scenario
			/*if ((PaymentMode.equals("Finance")) && (!driver.getCurrentUrl().contains("opel"))
					&& (!VehicleChoice.equals("ec41"))) {

				if (Country.equalsIgnoreCase("FR")) {
					if (dea.DealerPage_FR().equals("progressCar progressCar-confirmation")) {
						logger.log(Status.PASS, MarkupHelper.createLabel(
								"SELECTIONNEZ VOTRE CONCESSIONNAIRE page has appeared", ExtentColor.GREEN));
						Assert.assertTrue(true);
					} else {

						failWithScreenshot("SELECTIONNEZ VOTRE CONCESSIONNAIRE page has not appeared", resultDirectory,
								driver, extent, logger);
						//Assert.assertTrue(false,"SELECTIONNEZ VOTRE CONCESSIONNAIRE page has not appeared");
					}
				}

				if (Country.equalsIgnoreCase("UK")) {

					if (!driver.getCurrentUrl().contains("citroen")) {

						if (dea.DealerPage_UK().equals("progressCar progressCar-confirmation")) {
							logger.log(Status.PASS, MarkupHelper.createLabel("CHOOSE YOUR RETAILER page has appeared",
									ExtentColor.GREEN));
							Assert.assertTrue(true);
						} else {

							failWithScreenshot("CHOOSE YOUR RETAILER page has not appeared", resultDirectory, driver,
									extent, logger);
							Assert.assertTrue(false,"CHOOSE YOUR RETAILER page has not appeared");
						}
					} else {

						if (dea.DealerPage_UK_AC().equals("progressCar progressCar-confirmation")) {
							logger.log(Status.PASS, MarkupHelper.createLabel("CHOOSE YOUR RETAILER page has appeared",
									ExtentColor.GREEN));
							Assert.assertTrue(true);
						} else {

							failWithScreenshot("CHOOSE YOUR RETAILER page has not appeared", resultDirectory, driver,
									extent, logger);
							Assert.assertTrue(false,"CHOOSE YOUR RETAILER page has not appeared");
						}

					}

				}
			} else if ((PaymentMode.equals("Finance")) && (driver.getCurrentUrl().contains("opel"))
					&& (!VehicleChoice.equals("ec41"))) {
				waitForUrlContains("home/simulatore/", driver, 320);

				if (dea.OpelSimulatorLocator().contains("1. Personnaliser votre financement")) {
					logger.log(Status.PASS, MarkupHelper.createLabel("PERSONALISER VOTRE FINANCEMENT page has appeared",
							ExtentColor.GREEN));
					Assert.assertTrue(true);
				} else {

					failWithScreenshot("PERSONALISER VOTRE FINANCEMENT page has not appeared", resultDirectory, driver,
							extent, logger);
					Assert.assertTrue(false,"PERSONALISER VOTRE FINANCEMENT page has not appeared");
				}

			} else if (PaymentMode.equals("Cash") && (!VehicleChoice.equals("ec41"))) {

				if (Country.equalsIgnoreCase("FR")) {
					waitForUrlContains("/point-vente", driver, 320);
					if ((log.CreateAccountPageLocator().trim()
							.equalsIgnoreCase("Choisissez votre concessionnaire vendeur"))
							|| (log.CreateAccountPageLocator().trim().contains("DEALER"))) {
						logger.log(Status.PASS,
								MarkupHelper.createLabel("Choose your dealer page has appeared", ExtentColor.GREEN));
						Assert.assertTrue(true);
					} else {
						failWithScreenshot("Choose your dealer page has appeared", resultDirectory, driver, extent,
								logger);
						Assert.assertTrue(false,"Choose your dealer page has not appeared");
					}
				}

				if (Country.equalsIgnoreCase("ES")) {
					System.out.println("Create account ES");
					System.out.println("Text :" + log.CreateAccountPageLocator());
					if (log.CreateAccountPageLocator().trim().equalsIgnoreCase("Elige tu concesionario")) {
						logger.log(Status.PASS,
								MarkupHelper.createLabel("Elige tu concesionario has appeared", ExtentColor.GREEN));
						Assert.assertTrue(true);
					} else {
						failWithScreenshot("Elige tu concesionario page has not appeared", resultDirectory, driver,
								extent, logger);
						Assert.assertTrue(false,"Elige tu concesionario page has not appeared");
					}
				}
			} */

            } catch (Exception e) {
            /*basketVerification.log(Status.FAIL, "Test Failed while Verifying Basket");
            failWithScreenshot("Test Failed while Verifying Basket", resultDirectory, driver, extent, basketVerification);
            basketVerification.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, basketVerification, driver, "Test Failed while Verifying Basket", e);
            }
        }
    }

    public static void checkPrices(String resultDirectory, WebDriver driver, ExtentReports extent,
                                   ExtentTest logger, String Brand, String Country, String PaymentMode, String VehicleChoice,
                                   String PostalCode, String Page) throws Exception {
        if (driver != null) {
            ExtentTest verifyPrices = logger.createNode("VerifyPrices" + Page, "Verify prices");
            try {
                waitForPageToLoad(driver, 60);
                Thread.sleep(10000);
                IdentificationPageCash ip = new IdentificationPageCash();
                String firstAdditionalServiceText = ip.getServiceText(resultDirectory, verifyPrices, driver, Page);
                if (firstAdditionalServiceText != null) {
                    if (firstAdditionalServiceText.equalsIgnoreCase(ip.ServiceText)) {
                        verifyPrices.log(Status.PASS, "Service text displayed on basket and " + Page + " pages is same");
                    } else {
                        verifyPrices.log(Status.FAIL, "Service text displayed on basket and " + Page + "  pages is different");
                    }
                    String firstAdditionalServicePrice = ip.getServicePrice(resultDirectory, verifyPrices, driver, Brand, Page);
                    if (Brand.equalsIgnoreCase("OV")) {
                        int firstAdditionalServicePrice_OV = extractNumericFromString(firstAdditionalServicePrice) / 100;
                        if (firstAdditionalServicePrice_OV == extractNumericFromString(ip.FirstAdditionalServicePrice)) {
                            verifyPrices.log(Status.PASS, "Service price displayed on basket and " + Page + "  pages is same");
                        } else {
                            verifyPrices.log(Status.FAIL, "Service price displayed on basket and " + Page + "  pages is different");
                        }
                    } else if (Country.equalsIgnoreCase("ES")) {
                        if (extractNumericFromString(firstAdditionalServicePrice) == extractNumericFromString(ip.FirstAdditionalServicePrice) / 100) {
                            verifyPrices.log(Status.PASS, "Service price displayed on basket and " + Page + "  pages is same");
                        } else {
                            verifyPrices.log(Status.FAIL, "Service price displayed on basket and " + Page + "  pages is different");
                        }
                    } else {
                        if (extractNumericFromString(firstAdditionalServicePrice) == extractNumericFromString(ip.FirstAdditionalServicePrice)) {
                            verifyPrices.log(Status.PASS, "Service price displayed on basket and " + Page + "  pages is same");
                        } else {
                            verifyPrices.log(Status.FAIL, "Service price displayed on basket and " + Page + "  pages is different");
                        }
                    }
                } else {
                    verifyPrices.log(Status.WARNING, "Additional Services are not available. Hence nothing is available to test regarding Additional Services.");
                }
                if (Country.equalsIgnoreCase("FR")) {
                    String demarchesPrice = ip.getDemarchesPrice(resultDirectory, verifyPrices, driver, Brand, Page);
                    if (demarchesPrice != null) {
                        if (Brand.equalsIgnoreCase("OV")) {
                            int demarchesPrice_OV = extractNumericFromString(demarchesPrice) / 100;
                            if (demarchesPrice_OV == extractNumericFromString(ip.DemarchesFees)) {
                                verifyPrices.log(Status.PASS, "Demarches price displayed on basket and " + Page + " pages is same");
                            } else {
                                verifyPrices.log(Status.FAIL, "Demarches price displayed on basket and " + Page + " pages is different");
                            }
                        } else {
                            if (demarchesPrice.equalsIgnoreCase(ip.DemarchesFees)) {
                                verifyPrices.log(Status.PASS, "Demarches price displayed on basket and " + Page + " pages is same");
                            } else {
                                verifyPrices.log(Status.FAIL, "Demarches price displayed on basket and " + Page + " pages is different");
                            }
                        }
                    } else {
                        verifyPrices.log(Status.WARNING, "Demarches price is not available, hence nothing to test regarding demarches price");
                    }
                    if(!(Brand.equalsIgnoreCase("AC")&& Country.equalsIgnoreCase("FR"))) {
                        String carteGrisePrice = ip.getCarteGrisePrice(resultDirectory, verifyPrices, driver, Page);
                        if (carteGrisePrice != null) {
                            if (carteGrisePrice.equalsIgnoreCase(ip.CarteGrisePrice)) {
                                verifyPrices.log(Status.PASS, "Carte Grise price displayed on basket and " + Page + " pages is same");
                            } else {
                                verifyPrices.log(Status.FAIL, "Carte Grise price displayed on basket and " + Page + " pages is different");
                            }
                        } else {
                            verifyPrices.log(Status.WARNING, "Carte Grise price is not available, hence nothing to test regarding carte grise price");
                        }
                    } else {
                        verifyPrices.log(Status.WARNING, "Carte Grise price is not available, hence nothing to test regarding carte grise price");
                    }
                }
                String promoCodeText = ip.getPromoCodeText(resultDirectory, verifyPrices, driver, Page);
                if (promoCodeText != null) {
                if (promoCodeText.contains("DONT SUSPSEND OR ARCHIEVE THIS CODE")) {
                    verifyPrices.log(Status.PASS, "Promo code displayed on basket and " + Page + " pages is same");
                } else {
                    verifyPrices.log(Status.FAIL, "Promo code displayed on basket and " + Page + " pages is different");
                }
                String getPromoCode = ip.getPromoCodeValue(resultDirectory, verifyPrices, driver, Page);

                    int promoCodeValue = extractNumericFromString(getPromoCode.substring(1, 6));
                    int promoCodeCalValue;
                    if (Brand.equalsIgnoreCase("OV")) {
                        promoCodeCalValue = extractNumericFromString(ip.promoCodeVal.substring(0, 4));
                    } else {
                        promoCodeCalValue = extractNumericFromString(ip.promoCodeVal.substring(0, 4));
                    }
                    if (promoCodeValue == promoCodeCalValue) {
                        verifyPrices.log(Status.PASS, "Promo code value displayed on basket and " + Page + " pages is same");
                    } else {
                        verifyPrices.log(Status.FAIL, "Promo code value displayed on basket and " + Page + " pages is different");
                    }
                } else {
                    verifyPrices.log(Status.WARNING, "Promo code Text is not available, hence there is nothing to test regarding promo code");
                }
                if(Page.equalsIgnoreCase("Reprise")){
                    int reprisePriceReprisePage=extractNumericFromString(getAnyText(driver,By.xpath("//*[@class=\"price\"]")));
                    int reprisePriceBasketPage=extractNumericFromString(ip.Reprise);
                    if(reprisePriceReprisePage==reprisePriceBasketPage){
                        verifyPrices.log(Status.PASS,"Reprise price on Reprise and Basket page is same");
                    } else{
                        verifyPrices.log(Status.FAIL,"Reprise price on Reprise and basket Page is not same");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                catchFailDetails(resultDirectory, verifyPrices, driver, "Test failed while verifyting prices on " + Page + " page", e);
            }
        }

    }
}
