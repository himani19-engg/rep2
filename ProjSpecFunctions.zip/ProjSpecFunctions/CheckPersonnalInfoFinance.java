package solRetailIHM.ProjSpecFunctions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.OrderPage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckPersonnalInfoFinance extends UniversalMethods {

    @Test(description = "Checking and Filling Personal Details")
    public static void personalDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
                                       ExtentTest logger, String Brand, String Country, String EmailId, String Name, String Phone, String Address)
            throws Exception {

        try {

            driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
            PersonnalInfoPage pi = new PersonnalInfoPage(driver);
            OrderPage or = new OrderPage(driver);
            HomePage hmpg = new HomePage(driver);
            //SoftAssert sa = new SoftAssert();

            // check email ID
            System.out.println(pi.getEmail());
            System.out.println(EmailId);
            if (pi.getEmail().equals(EmailId)) {
                logger.log(Status.PASS, "EMAIL is valid");
                //logger.log(Status.PASS, MarkupHelper.createLabel("EMAIL is valid", ExtentColor.GREEN));
                //sa.assertTrue(true);
            } else {
                logger.log(Status.FAIL,"EMAIL is not valid");
                //sa.assertTrue(false, "EMAIL is not valid");
                //driver.quit();
                //org.testng.Assert.fail();

            }

            // check Phone Number
            System.out.println(pi.getPhone());
            System.out.println(Phone);
            if (pi.getPhone().equals(Phone)) {
                logger.log(Status.PASS, "Phone is valid");
                //sa.assertTrue(true);
            } else {
                logger.log(Status.FAIL,"Phone is not valid");
                //sa.assertTrue(false, "Phone is not valid");
                //driver.quit();
                // org.testng.Assert.fail();

            }

            // check Name
            String FullName = null;
            if (Country.equalsIgnoreCase("UK")) {
                FullName = pi.getInitials() + " " + pi.getFirstName() + " " + pi.getLastName();
            } else if (Country.equalsIgnoreCase("FR")) {
                FullName = pi.getFirstName() + " " + pi.getLastName();
            }
            System.out.println(FullName);
            System.out.println(Name);

            if (FullName.equals(Name)) {
                logger.log(Status.PASS, MarkupHelper.createLabel("User Name is valid", ExtentColor.GREEN));
                //sa.assertTrue(true);
            } else {
                logger.log(Status.FAIL, MarkupHelper.createLabel("User Name is not valid", ExtentColor.RED));
                //sa.assertTrue(false, "User Name is not valid");
                //driver.quit();
                // org.testng.Assert.fail();

            }

            // Check Address
            System.out.println(Address);
            System.out.println(pi.getAddress());
            if (pi.getAddress().equals(Address)) {
                logger.log(Status.PASS, MarkupHelper.createLabel("Address is valid", ExtentColor.GREEN));
                //sa.assertTrue(true);
            } else {
                failWithScreenshot("Address is not valid", resultDirectory, driver, extent, logger);
                //sa.assertTrue(false, "Address is not valid");
                //driver.close();
            }

            // Validate personnal Information
            // Close book a test drive
            if ((Country.equalsIgnoreCase("UK")) && (Brand.equalsIgnoreCase("DS"))) {
                hmpg.CloseBookTestDrive(resultDirectory,logger);
            }
            pi.Validate();
            waitForUrlContains("checkout/pre-order", driver, 30);
            Thread.sleep(3000);

            // Validate arriving on order page
            if (Country.equalsIgnoreCase("FR")) {
                if (or.getTitle_FR().equals("FINALISATION DE VOTRE COMMANDE")) {
                    logger.log(Status.PASS,
                            MarkupHelper.createLabel("ORDER PAGE page has appeared", ExtentColor.GREEN));
                    //sa.assertTrue(true);
                } else {
                    logger.log(Status.FAIL,
                            MarkupHelper.createLabel("ORDER PAGE page has not appeared", ExtentColor.RED));
                    //sa.assertTrue(false, "ORDER PAGE page has not appeared");
                    //driver.quit();
                    // org.testng.Assert.fail();

                }
            }
            if (Country.equalsIgnoreCase("UK")) {
                if (!driver.getCurrentUrl().contains("ds") && !driver.getCurrentUrl().contains("vauxhall")) {
                    if (or.getTitle_UK().equals("YOUR ONLINE ORDER")) {
                        logger.log(Status.PASS, "ORDER PAGE page has appeared");
                        //sa.assertTrue(true);
                    } else {
                        logger.log(Status.FAIL, "ORDER PAGE page has not appeared");
                        //sa.assertTrue(false, "ORDER PAGE page has not appeared");
                        //driver.quit();
                        // org.testng.Assert.fail();

                    }
                } else {
                    if (or.getTitle_UK_DS().equals("FINALISING YOUR CAR PURCHASE")) {
                        logger.log(Status.PASS, "ORDER PAGE page has appeared");
                        //sa.assertTrue(true);
                    } else {
                        logger.log(Status.FAIL,"ORDER PAGE page has not appeared");

                        //sa.assertTrue(false, "ORDER PAGE page has not appeared");
                        //driver.quit();
                        // org.testng.Assert.fail();

                    }
                }
            }
            //sa.assertAll();
        } catch (Exception e1) {

            e1.printStackTrace();

        }
    }

}
