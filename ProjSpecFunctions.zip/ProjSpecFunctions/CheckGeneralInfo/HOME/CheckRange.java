package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckRange extends UniversalMethods {
	public static ExtentTest checkRange;

	@Test(description = "Checking Range")
	public static void setRange(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String country, String brand) throws Exception {

		if(driver!=null) {
			try {
				driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				checkRange = extentHP.createNode("Check_HomePage_Range", "Checking Range");
				HomePage HP = new HomePage(driver);
				SoftAssert sa = new SoftAssert();
				HP.adjustRange(resultDirectory, checkRange);
				Float startPrice = HP.getRangeStartPrice(resultDirectory, checkRange);
				checkRange.log(Status.INFO, "Start range price is " + startPrice);
				Float endPrice = HP.getRangeEndPrice(resultDirectory, checkRange);
				checkRange.log(Status.INFO, "End range price is " + endPrice);
				HP.clickSelectBtn(resultDirectory, checkRange);
				Float cashPrice;
				String dataTestId = null;
				String dataTestIdDisabled = null;

				//waitForUrlContains("/configurable?prices="+startPrice.toString().replaceAll()+"%2C"+endPrice,driver,10);
			/*if(driver.getCurrentUrl().contains("-es-")) {
				waitForUrlContains("prices", driver, 10);
			}else{*/
				waitForUrlContains("configurable?", driver, 10);
				//}
			/*waitForUrlContains("/configurable?prices=",driver,10);
			waitForUrlContains("%2C",driver,5);*/
				int size;
				int TotalEnabledCars;
				int TotalDisabledCars;
				if (HP.getRangeCashPriceCarList(resultDirectory, checkRange) != null) {
					size = HP.getRangeCashPriceCarList(resultDirectory, checkRange).size();
				} else {
					size = 0;
				}
				if (HP.getRangeCashPriceEnabledCarList(resultDirectory, checkRange) != null) {
					TotalEnabledCars = HP.getRangeCashPriceEnabledCarList(resultDirectory, checkRange).size();
				} else {
					TotalEnabledCars = 0;
				}

				if (HP.getRangeCashPriceDisabledCarList(resultDirectory, checkRange) != null) {
					TotalDisabledCars = HP.getRangeCashPriceDisabledCarList(resultDirectory, checkRange).size();
				} else {
					TotalDisabledCars = 0;
				}

				if (size == TotalEnabledCars + TotalDisabledCars && size != 0) {
					checkRange.log(Status.PASS, "Total number of offered cars are equal to total number of disabled & enabled");
				} else {
					checkRange.log(Status.FAIL, "Total number of offered cars are not equal to total number of disabled & enabled");
				}
				if(isElementPresent(driver,By.xpath("//*[@data-testid='TESTING_CLOSE_MODAL']"))){
					clickElement(driver,By.xpath("//*[@data-testid='TESTING_CLOSE_MODAL']"));
				}

				int count = 0;
				if (size != 0) {
					for (int i = 1; i <= size; i++) {
						String cardText = getAnyText(driver, By.xpath("(//*[contains(@data-testid, 'TESTING_OFFER')])[" + i + "]"), 10);
						if (!cardText.contains("Need a hand?")) {
							cashPrice = HP.getCashPrice(i, resultDirectory, checkRange);
							if (cashPrice <= endPrice && cashPrice >= startPrice) {
								checkRange.log(Status.PASS, "Cash Price for grid " + i + " is less than the end Price and more than Start Price which is: " + cashPrice);
								dataTestId = HP.getCarOfferDataTestIdAttribute(i, resultDirectory, checkRange);
								System.out.println("Data Test Id : " + dataTestId);
								if (dataTestId.equalsIgnoreCase("TESTING_OFFER_ENABLED")) {
									checkRange.log(Status.PASS, "Car offer is between range & enabled and Cash price is " + cashPrice);
									//sa.assertTrue(true);
								} else {
									failWithScreenshot("Car offer is between range & disabled and Cash price is " + cashPrice, resultDirectory, driver, extent, checkRange);
									//sa.assertTrue(false, "Car offer is between range & disabled and Cash price is " + cashPrice);
								}
							}

							if ((cashPrice > endPrice || cashPrice < startPrice)) {
								//dataTestIdDisabled = HP.getCarOfferDataTestIdAttributeDisabled(((size+1)-i),resultDirectory,checkRange);
								count += 1;
								dataTestIdDisabled = HP.getCarOfferDataTestIdAttributeDisabled(count, resultDirectory, checkRange);
								System.out.println(dataTestIdDisabled);
								if (dataTestIdDisabled.equalsIgnoreCase("TESTING_OFFER_DISABLED")) {
									checkRange.log(Status.PASS, "Car offer is out of range & disabled and Cash price is " + cashPrice);
									//logger.log(Status.PASS, MarkupHelper.createLabel("Car offer is disabled and Cash price is " + cashPrice, ExtentColor.GREEN));
									sa.assertTrue(true);
								} else {
									failWithScreenshot("Car offer is out of range & enabled and Cash price is " + cashPrice, resultDirectory, driver, extent, checkRange);
									sa.assertTrue(false, "Car offer is out of range & enabled and Cash price is " + cashPrice);
								}
							}
						}
					}
				} else {
					checkRange.log(Status.WARNING, "Unable to perform Price Range validation as No cash cars are present");
					//driver.close();
				}
				//sa.assertAll();
				HP.clickReset(resultDirectory, checkRange);
				//Thread.sleep(3000);
				//checkRange.log(Status.INFO, "Price range is reset");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Price range is reset", ExtentColor.BLUE));
			} catch (Exception e1) {
			/*checkRange.log(Status.FAIL,"Test Failed in Homepage set range");
			failWithScreenshot("Test Failed in Homepage set range", resultDirectory, driver, extent, checkRange);
			checkRange.log(Status.FAIL, String.valueOf(e1.getStackTrace()));*/
				e1.printStackTrace();
				catchFailDetails(resultDirectory, checkRange, driver, "Test Failed in Homepage set range", e1);
			}
		}

	}
}
