package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.LoginUserPage;
import solRetailIHM.ProjSpecFunctions.YopMailConfirmationMsg;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckAccount extends UniversalMethods {
	
	public static ExtentTest accountCheck;

	@Test(description = "Account Details")
	public static void checkAccountDetails(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Country, String EmailId, String Name, String Phone, String Address, String Password, String Brand, String PaymentMode)
			throws Exception {

		if(driver!=null) {
			try {
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				accountCheck = extentHP.createNode("AccountCheck", "Checking account");
				HomePage hmpg = new HomePage(driver);
				LoginUserPage loginPage = new LoginUserPage(driver);
				// Click

				hmpg.clickonAccountButton(resultDirectory, accountCheck);
				accountCheck.log(Status.INFO, "Click on Account Icon");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Click on Account Icon", ExtentColor.BLUE));

				//Thread.sleep(2000);

				hmpg.clickonConnexionButton(Country, resultDirectory, accountCheck,PaymentMode,Brand);
				//accountCheck.log(Status.INFO, "Click on Connexion Button");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Click on Connexion Button", ExtentColor.BLUE));

				System.out.println("Url Contains login");

				//if(Country.equalsIgnoreCase("FR")){
				waitForUrlContains("/gigya/", driver, 30);
				waitForPageToLoad(driver, 20);
			/*}else {
				waitForUrlContains("login", driver, 20);
			}*/

				loginPage.enterEmail(EmailId, resultDirectory, accountCheck);
				//accountCheck.log(Status.INFO, "Entered email");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Entered email", ExtentColor.BLUE));
				//Thread.sleep(500);
				loginPage.enterPassword(Password, resultDirectory, accountCheck);
				//accountCheck.log(Status.INFO, "Entered password");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Entered password", ExtentColor.BLUE));
				//Thread.sleep(500);
				loginPage.validate(resultDirectory, accountCheck);
				//accountCheck.log(Status.INFO, "Clicked on Validate button");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Validate button", ExtentColor.BLUE));
				//hmpg.clickonConnexionButton(Country,resultDirectory,accountCheck);
				waitForUrlContains("my-account", driver, 30);
				accountCheck.log(Status.INFO, "The account page has appeared");
				//logger.log(Status.INFO, MarkupHelper.createLabel("The account page has appeared", ExtentColor.BLUE));

				Thread.sleep(30000);
				loginPage.clickLogout(resultDirectory, accountCheck, Country);
				//accountCheck.log(Status.INFO, "Clicked on Logout link");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Logout link", ExtentColor.BLUE));
				//Thread.sleep(2000);

				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>" + driver.getCurrentUrl());
				waitForUrlContains("configurable", driver, 20);

				// Close book a test drive
				if ((Country.equalsIgnoreCase("UK")) && (Brand.equalsIgnoreCase("DS"))) {
					hmpg.CloseBookTestDrive(resultDirectory, accountCheck);
				}
			} catch (Exception e1) {
			/*accountCheck.log(Status.FAIL,"Test Failed in account details");
			failWithScreenshot("Test failed in account details", resultDirectory, driver, extent, accountCheck);
			accountCheck.log(Status.FAIL, String.valueOf(e1.getStackTrace()));*/
				catchFailDetails(resultDirectory, accountCheck, driver, "Test Failed in account details", e1);
			}
		}
	}
	
	public static void checkForgotPassword(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String url,
			String country, String brand, String emailId, String PaymentMode) throws Exception {
		if(driver!=null) {
			HomePage homePage = new HomePage(driver);
			LoginUserPage loginPage = new LoginUserPage(driver);
			String text = null;
			try {
				accountCheck = extentHP.createNode("CheckForgotPassword", "Checking forgot password");
				homePage.clickonAccountButton(resultDirectory, accountCheck);
				//accountCheck.log(Status.INFO, "Click on Account Icon");
				//Thread.sleep(2000);
				homePage.clickonConnexionButton(Country, resultDirectory, accountCheck,PaymentMode,brand);
				//accountCheck.log(Status.INFO, "Click on Connexion Button");
				waitForUrlContains("login", driver, 60);
				loginPage.clickForgotPasswdLink();
				loginPage.enterEmail(emailId, resultDirectory, accountCheck);
				//accountCheck.log(Status.INFO, "Entered email");
				//Thread.sleep(500);
				loginPage.validate(resultDirectory, accountCheck);
				//accountCheck.log(Status.INFO, "Clicked on Validate button");
				text = loginPage.getForgotPasswdMsg();
				if (text.contains("Un email a été envoyé à l'adresse indiquée")
						|| text.contains("Hemos enviado un e-mail a la dirección de correo indicada")
						|| text.contains("An email regarding your password change has been sent to your email address.")
						|| text.contains("Un e-mail concernant votre modification de mot de passe a été envoyé à votre adresse e-mail.")) {
					accountCheck.log(Status.PASS, "Sent Forgot password email text is present");
					//logger.log(Status.PASS, MarkupHelper.createLabel("Sent Forgot password email text is present", ExtentColor.GREEN));
				} else {
					failWithScreenshot("Test failed in Homepage checks", resultDirectory, driver, extent, accountCheck);
					//logger.log(Status.FAIL, MarkupHelper.createLabel("Sent Forgot password email text is not present", ExtentColor.RED));
				}
				YopMailConfirmationMsg.checkForgotPasswordEmail(resultDirectory, driver, accountCheck, country, brand, emailId);
				driver.navigate().to(url);
			} catch (Exception e1) {
				//accountCheck.log(Status.FAIL,"Test Failed in forgot password");
			/*failWithScreenshot("Test failed in forgot password", resultDirectory, driver, extent, accountCheck);
			accountCheck.log(Status.FAIL, String.valueOf(e1.getStackTrace()));*/
				catchFailDetails(resultDirectory, accountCheck, driver, "Test failed in forgot password", e1);
			}
		}
	}

}
