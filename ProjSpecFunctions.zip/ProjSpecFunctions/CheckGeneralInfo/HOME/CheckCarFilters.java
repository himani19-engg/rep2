package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

import java.net.URLDecoder;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckCarFilters extends UniversalMethods {
	public static ExtentTest checkFilters;
	public static ExtentTest checkFilterOrder;
	@Test(description = "Filter Check")
	public static void filterCheck(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
								   String Brand, String country) throws Exception {

		int i;
		//int j;
		int k;
		int energyCount = 0;
		checkFilters= extentHP.createNode("FilterCheck","Checking filters on Homepage");
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			HomePage HP = new HomePage(driver);
			//SoftAssert sa = new SoftAssert();
			energyCount = HP.getEnergyList(resultDirectory,checkFilters).size();
			System.out.println("This is the number of energies:::::" + energyCount);
			String[] energyList = new String[10];
			//String[] gearBoxList = new String[10];
			checkFilters.log(Status.INFO, "Testing Car Filters");
			//logger.log(Status.PASS, MarkupHelper.createLabel("Testing Car Filters", ExtentColor.BROWN));
			// waitForUrlContains("trim", driver, 60);
			//driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			// driver.navigate().refresh();
			 //Thread.sleep(3000);
			for (i = 0; i < energyCount; i++) {
				HP.chooseAnEnergy(i, country,resultDirectory,checkFilters);
				// driver.navigate().refresh();

				 //Thread.sleep(2000);
				// HP.ChooseAnEnergy(i);

				String energy = "";
				// check that the url contains energy
				if (HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().contains("-")) {
					String[] energyTab = HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().split("-");
					for (int p = 0; p < energyTab.length; p++) {
						String energyP = energyTab[p].charAt(0) + energyTab[p].substring(1).toLowerCase();
						energy = energy + "-" + energyP;
					}
					energy = energy.substring(1);
					System.out.println("/....../////...." + energy);
				} else if (HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().contains(" ")) {
					String[] energyTab = HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().split(" ");
					for (int p = 0; p < energyTab.length; p++) {
						String energyP = energyTab[p].charAt(0) + energyTab[p].substring(1).toLowerCase();
						energy = energy + "+" + energyP;
					}
					energy = energy.substring(1);
					System.out.println("/....../////...." + energy);
				} else if (HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().equalsIgnoreCase("Hdi")) {
					energy = HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().charAt(0)
							+ HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().substring(1).toUpperCase();
					System.out.println("/....../////...." + energy);
				} else {
					energy = HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().charAt(0)
							+ HP.getEnergyList(resultDirectory,checkFilters).get(i).getText().substring(1).toLowerCase();
					System.out.println("/....../////...." + energy);
				}

				System.out.println("/....../////...." + energyList.length);
				String URL = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8").replaceAll(" ", "+");

			//	if(energy.equals("Gasolina")) {
			//		energy=energy.toUpperCase();
			//	}
				Thread.sleep(3000);
				if (URL.contains(energy)) {
					checkFilters.log(Status.PASS, "The URL contains filter " + energy);
					/*logger.log(Status.PASS,
							MarkupHelper.createLabel("The URL contains filter " + energy + "", ExtentColor.GREEN));*/
					Assert.assertTrue(true);
				} else {
					checkFilters.log(Status.FAIL, "The URL Doesn't contains filter " + energy);
					failWithScreenshot("The URL Doesn't contain filter " + energy + "", resultDirectory, driver, extent,
							checkFilters);
					Assert.assertTrue(false, "The URL Doesn't contain filter" + energy);
				}
				//waitForDecodeUrlContains(energy, driver, 60);

				System.out.println("*************************" + driver.getCurrentUrl());
				System.out.println(URLDecoder.decode(driver.getCurrentUrl(), "UTF-8"));
			}

			HP.clickOnResetButton(resultDirectory,checkFilters);
			//Thread.sleep(3000);
			waitForUrlNotContains("?", driver, 20);

			if (!driver.getCurrentUrl().contains("?")) {
				checkFilters.log(Status.PASS, "The URL Doesn't contain any filter after reset");
				/*logger.log(Status.PASS,
						MarkupHelper.createLabel("The URL Doesn't contain any filter after reset", ExtentColor.GREEN));*/
				Assert.assertTrue(true);
			} else {
				checkFilters.log(Status.FAIL, "The URL contains filter after reset");
				failWithScreenshot("The URL contains filter after reset", resultDirectory, driver, extent, checkFilters);
				Assert.assertTrue(false, "The URL contains any filter after reset");
			}
			
			//sa.assertAll();

			if (!Brand.equals("VX")) {

				int gearBoxCount = HP.getGearBoxList(resultDirectory,checkFilters).size();
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>" + HP.getGearBoxList(resultDirectory,checkFilters).size());

				for (k = 0; k < gearBoxCount; k++) {
					HP.chooseAGearBox(k,resultDirectory,checkFilters);
					//Thread.sleep(2000);

					String gearBox = "";

					if (HP.getGearBoxList(resultDirectory,checkFilters).get(k).getText().contains(" ")) {

						String[] gearboxTab = HP.getGearBoxList(resultDirectory,checkFilters).get(k).getText().split(" ");
						for (int p = 0; p < gearboxTab.length; p++) {

							String gearboxP = "";
							if (p == 0) {
								gearboxP = gearboxTab[p].charAt(0) + gearboxTab[p].substring(1).toLowerCase();
							} else {
								gearboxP = gearboxTab[p].toLowerCase();
							}

							gearBox = gearBox + "+" + gearboxP;

						}
						gearBox = gearBox.substring(1);
						System.out.println("/....../////...." + gearBox);
					}

					else {
						System.out.println("/....../////...." + HP.getGearBoxList(resultDirectory,checkFilters).get(k).getText().charAt(0));
						gearBox = HP.getGearBoxList(resultDirectory,checkFilters).get(k).getText().charAt(0)
								+ HP.getGearBoxList(resultDirectory,checkFilters).get(k).getText().substring(1).toLowerCase();
						System.out.println("/....../////...." + gearBox);
					}

					Thread.sleep(10000);
					System.out.println("*******************" + driver.getCurrentUrl());
					System.out.println(URLDecoder.decode(driver.getCurrentUrl(), "UTF-8"));

					String URL = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8").replaceAll(" ", "+");

					if (URL.contains(gearBox)) {
						checkFilters.log(Status.PASS, "The URL contains filter " + gearBox);
						/*logger.log(Status.PASS, MarkupHelper
								.createLabel("The URL contains filter " + gearBox + "", ExtentColor.GREEN));*/
					} else {
						checkFilters.log(Status.FAIL, "The URL doesn't contain filter " + gearBox);
						/*logger.log(Status.WARNING,
								MarkupHelper.createLabel("The URL doesn't contain filter " + gearBox + "", ExtentColor.ORANGE));*/
						failWithScreenshot("The URL doesn't contain filter " + gearBox,resultDirectory,driver,checkFilters);
					}
					HP.chooseAGearBox(k,resultDirectory,checkFilters);
					//Thread.sleep(2000);
				}
			}
			
		} catch (Exception e1) {
			/*logger.log(Status.FAIL,
					MarkupHelper.createLabel("Unable to Filter Check", ExtentColor.BLUE));*/
			catchFailDetails(resultDirectory, checkFilters,driver, "Error while Checking filters on Homepage",e1);
		}
	}
	public static void checkFilterOrder(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
										String Brand, String country) {
		if (driver != null) {
			try {
				driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				checkFilterOrder = extentHP.createNode("CheckFilterOrder", "Checking order of filters on Homepage");
				//clickElement(driver, By.xpath("//div[@class='desktop']/button[contains(@class,'fuel')]"), 5);
				clickElement(driver, By.xpath("//*[@data-testid='TESTING_FILTER_FUEL']"), 5);
				for (int i = 1; i <= 3; i++) {
					WebElement we = driver.findElement(By.xpath("(//*[@class='header']/following-sibling::div/div)[" + i + "]"));
					String att = "";
					if (i == 1) {
						att = "energy";
					} else if (i == 2) {
						att = "gear";
					} else if (i == 3) {
						att = "prices";
					}
					String classValue = we.getAttribute("class");
					//Assert.assertTrue(classValue.contains(att));
					if (classValue.contains(att)) {
						checkFilterOrder.log(Status.PASS, att + "filter is displayed at " + i + " position");
					} else {
						checkFilterOrder.log(Status.FAIL, "filter order is not correct");
					}
				}
			} catch (Exception e){
				e.printStackTrace();
				catchFailDetails(resultDirectory, checkFilterOrder, driver, "Test Failed while Checking Filter Order", e);

			}
		}
	}
	public static void checkEnergyFilter(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Brand, String country) throws Exception {
		if(driver!=null) {
			int energyCount = 0;
			String energy = "";
			String url = "";
			SoftAssert sa = new SoftAssert();
			try {
				driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				checkFilters = extentHP.createNode("EnergyFilterCheck", "Checking energy filters on Homepage");
				HomePage HP = new HomePage(driver);
				//clickElement(driver, By.xpath("//div[@class='desktop']/button[contains(@class,'fuel')]"), 5);
				clickElement(driver, By.xpath("//*[@data-testid='TESTING_FILTER_FUEL']"), 5);
				energyCount = HP.getEnergyList(resultDirectory, checkFilters).size();
				System.out.println("Number of energy filters :::::" + energyCount);
				checkFilters.log(Status.INFO, "Number of energy filters :::::" + energyCount);
				List<WebElement> allEnergy = HP.getEnergyList(resultDirectory, checkFilters);
				for (int i = 1; i <= energyCount; i++) {
					energy = allEnergy.get(i - 1).getText().trim();
					HP.chooseAnEnergy(i, country, resultDirectory, checkFilters);
					System.out.println("Energy :" + energy);
					checkFilters.log(Status.INFO, "Chosen An Energy for: " + energy);
					waitForUrlContains("fuel=", driver, 20);
					waitForPageToLoad(driver, 10);
					Thread.sleep(10000);
					//url = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8").replaceAll(" ", "+");
					//Thread.sleep(2000);
					url = URLDecoder.decode(driver.getCurrentUrl());
					checkFilters.log(Status.INFO, "Current URL after selecting " + energy + " :" + url);
					System.out.println("Current URL after selecting " + energy + " :" + url);
					//Thread.sleep(3000);
					if (url.contains(energy)) {
						checkFilters.log(Status.PASS, "The URL contains selected energy filter " + energy);
					} else {
						//checkFilters.log(Status.FAIL, "The URL doesn't contain selected energy filter "+energy);
						failWithScreenshot("The URL doesn't contain selected energy filter: " + energy + "", resultDirectory, driver, extent, logger);
					}
				}

				HP.clickOnResetButton(resultDirectory, checkFilters);
				//Thread.sleep(3000);
				waitForUrlContains("configurable", driver, 60);

				if (driver.getCurrentUrl().contains("configurable")) {
					checkFilters.log(Status.PASS, "Landed on Configuration Page");
					//logger.log(Status.PASS, MarkupHelper.createLabel("The URL doesn't contain any filter after reset*", ExtentColor.GREEN));
					//sa.assertTrue(true);
				} else {
					checkFilters.log(Status.FAIL, "Could not Land on Configuration Page");
					//failWithScreenshot("The URL contains any filter after reset", resultDirectory, driver, extent, logger);
					//sa.assertTrue(false, "Could not land on Configuration Page");
				}
				HP.closeFilterPopup(resultDirectory, checkFilters);
				//sa.assertAll();
			} catch (Exception e) {
			/*checkFilters.log(Status.FAIL,"Test Failed while Checking Energy Filter");
			failWithScreenshot("Test Failed while Checking Energy Filter", resultDirectory, driver, extent, checkFilters);
			checkFilters.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, checkFilters, driver, "Test Failed while Checking Energy Filter", e);
			}
		}
	}
	
	public static void checkGearboxFilter(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Brand, String country) throws Exception {
		if(driver!=null) {
			int gearBoxCount = 0;
			String gearBox = "";
			String url = "";
			SoftAssert sa = new SoftAssert();
			try {
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				checkFilters = extentHP.createNode("GearboxFilterCheck", "Checking Gearbox filters on Homepage");
				HomePage HP = new HomePage(driver);
				gearBoxCount = HP.getGearBoxList(resultDirectory, checkFilters).size();

				for (int k = 0; k < gearBoxCount; k++) {
					HP.chooseAGearBox(k, resultDirectory, checkFilters);
					Thread.sleep(4000);
					gearBox = HP.getGearBoxList(resultDirectory, checkFilters).get(k).getText().trim();
					System.out.println("GearBox :" + gearBox);
					waitForUrlContains("gearBox", driver, 5);
					url = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8");
					//.replaceAll(" ", "+");
					//url = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8");
					System.out.println("URL : " + url);

					if ((url.toLowerCase()).contains(gearBox.toLowerCase())) {
						System.out.println("The URL contains gearBox filter " + gearBox);
						checkFilters.log(Status.PASS, "The URL contains gearBox filter " + gearBox);
						//logger.log(Status.PASS, MarkupHelper.createLabel("The URL contains filter " + gearBox + "", ExtentColor.GREEN));
						//sa.assertTrue(true);
					} else {
						//checkFilters.log(Status.FAIL, "The URL doesn't contain gearBox filter "+gearBox);
						System.out.println("The URL doesn't contain gearBox filter " + gearBox);
						failWithScreenshot("The URL doesn't contain filter " + gearBox + "", resultDirectory, driver, extent, logger);
						//sa.assertTrue(false, "The URL doesn't contain gearBox filter " + gearBox);
					}
					HP.clickOnResetButton(resultDirectory, checkFilters);
					//Thread.sleep(3000);
					waitForUrlContains("configurable", driver, 20);
				}
				HP.closeFilterPopup(resultDirectory, checkFilters);
				//driver.navigate().refresh();
				//Thread.sleep(3000);
				//sa.assertAll();
			} catch (Exception e) {
			/*checkFilters.log(Status.FAIL,"Test Failed while Checking Gearbox Filter");
			failWithScreenshot("Test Failed while Checking Gearbox Filter", resultDirectory, driver, extent, checkFilters);
			checkFilters.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				e.printStackTrace();
				catchFailDetails(resultDirectory, checkFilters, driver, "Test Failed while Checking Gearbox Filter", e);
			}
		}
	}
	
}
