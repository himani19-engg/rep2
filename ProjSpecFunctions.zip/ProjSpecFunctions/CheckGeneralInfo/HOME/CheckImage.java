package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;
import java.util.ArrayList;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckImage extends UniversalMethods {
	public static ExtentTest bannerImageCheck;
	@Test(description = " Banner Image Check On HP")
	public static void imageCheckOnHP(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger)
			throws Exception {

		if(driver!=null) {

			try {
				bannerImageCheck = extentHP.createNode("BannerImageCheck", "Checking Banner Image");
				HomePage HP = new HomePage(driver);
				HP.imageCheckOnHP(resultDirectory, bannerImageCheck);
				//imageCheck.log(Status.INFO,"Banner image is displayed");
				//logger.log(Status.PASS, MarkupHelper.createLabel("Banner image is displayed", ExtentColor.BLUE));
			/*String url = HP.getImageURL(resultDirectory,bannerImageCheck);
			System.out.println(url);

			HP.openNewTab(driver);
			Thread.sleep(500);
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));
			System.out.println("Current URL to launch is: "+url);
			driver.navigate().to(url);
			int code = HP.getHTTPResponseCode(driver, url);
			System.out.println(code);
			if (code == org.apache.http.HttpStatus.SC_OK) {
				bannerImageCheck.log(Status.PASS,"Banner image is displayed and response code is " + code);
				//logger.log(Status.PASS,MarkupHelper.createLabel("Image is displayed and response code is " + code, ExtentColor.GREEN));

				Assert.assertTrue(true," Banner image is displayed and response code is " + code);
			} else {
				bannerImageCheck.log(Status.FAIL,"The image is broken. The url for it is: " + url);
				failWithScreenshot("The image is broken. The url for it is: " + url, resultDirectory, driver, extent,
						bannerImageCheck);
				Assert.fail();
				//Assert.assertTrue(false, "The image is broken. The url for it is: " + url);
				//driver.quit();
			}

			driver.close();
			ArrayList<String> tabs1 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs1.get(0));*/

			} catch (Exception e) {
			/*bannerImageCheck.log(Status.FAIL,"Test Failed in  Banner Image Check on Home Page");
			failWithScreenshot("Test Failed in Banner Image Check on Home Page", resultDirectory, driver, extent, bannerImageCheck);
			bannerImageCheck.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, bannerImageCheck, driver, "Test Failed in  Banner Image Check on Home Page", e);
			}
		}
	}
}