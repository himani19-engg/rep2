package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckInfoButton extends UniversalMethods {

    public static ExtentTest checkInfoPopup;

    @Test(description = "Checking Info")
    public static void checkInfo(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                 String brand, String country) throws Exception {
        if(driver!=null) {
            try {
                //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
                checkInfoPopup = extentHP.createNode("CheckInfoPopup", "Checking homepage Info popup");
                HomePage HP = new HomePage(driver);
                Float monthlyPrice;
                Float totalPrice;
                Float infoMonthlyPrice = null;
                Float infoTotalPrice = null;
                int size;

                if ((country.equals("ES") || country.equals("FR"))) {
                    if (isElementPresent(driver, HomePage.infoIcon_ES, 5)) {
                        size = HP.getInfoList(country, resultDirectory, checkInfoPopup).size();
                        System.out.println("Size : " + size);
                        for (int i = 1; i <= size; i++) {
                            System.out.println("******* " + i);
                            totalPrice = HP.getTotalPrice(i, resultDirectory, checkInfoPopup);
                            monthlyPrice = HP.getMonthlyPrice(i, resultDirectory, checkInfoPopup);
                            HP.clickInfo(i, country, resultDirectory, checkInfoPopup);
                            Boolean bool = false;
                            if ((isElementPresent(driver, HP.getInfoPopupMonthlyPriceBy(), 10) != true) &&
                                    (isElementPresent(driver, HP.getInfoPopupMonthlyPriceBy(), 10) != true)) {
                                bool = false;
                                checkInfoPopup.log(Status.WARNING, "Info Popup (Ejemplo Renting) Popup is not present instead the Error Popup " + driver.getTitle() + " is present");
                                failWithScreenshot("Info Popup (Ejemplo Renting) Popup is not present instead the Error Popup " + driver.getTitle() + " is present", resultDirectory, driver, extent, checkInfoPopup);
                                HP.closeInfoPopup(resultDirectory, checkInfoPopup);
                                break;
                            } else {
                                bool = true;
                                System.out.println("Is Monthly Price Element Present : " + bool);
                                if (bool == true) {
                                    if (country.equals("ES")) {
                                        infoMonthlyPrice = HP.getInfoPopupMonthlyPrice(resultDirectory, checkInfoPopup);
                                    } else if (country.equals("FR")) {
                                        infoMonthlyPrice = HP.getInfoPopupMonthlyPrice_FR(resultDirectory, checkInfoPopup);
                                    }

                                    if (country.equals("ES")) {
                                        infoTotalPrice = HP.getInfoPopupTotalPrice(resultDirectory, checkInfoPopup);
                                    } else if (country.equals("FR")) {
                                        infoMonthlyPrice = HP.getInfoPopupMonthlyPrice_FR(resultDirectory, checkInfoPopup);
                                    }
                                    HP.closeInfoPopup(resultDirectory, checkInfoPopup);
                                    System.out.println("monthlyPrice :" + monthlyPrice.getClass());
                                    System.out.println("infoMonthlyPrice :" + infoMonthlyPrice.getClass());
                                    if (monthlyPrice - infoMonthlyPrice <= 1) {
                                        checkInfoPopup.log(Status.PASS, "Monthly price " + monthlyPrice + " matches with info popup price " + infoMonthlyPrice);
                                    } else {
                                        failWithScreenshot("Monthly price " + monthlyPrice + " does not match with info popup price " + infoMonthlyPrice, resultDirectory, driver, extent, logger);
                                    }

                                    if (totalPrice - infoTotalPrice <= 1) {
                                        checkInfoPopup.log(Status.PASS, "total price " + totalPrice + " matches with info popup total price " + infoTotalPrice);
                                    } else {
                                        failWithScreenshot("total price " + totalPrice + " does not match with info popup total price " + infoTotalPrice, resultDirectory, driver, extent, logger);
                                    }
                                } else {
                                    failWithScreenshot("Error Popup  for the Popup No. :" + i, resultDirectory, driver, extent, checkInfoPopup);
                                    HP.closeInfoPopup(resultDirectory, checkInfoPopup);
                                }
                            }
                        }
                    } else {
                        failWithScreenshot("Info Popup (Ejemplo Renting) Popup is not present or the Error Popup " + driver.getTitle() + " present", resultDirectory, driver, extent, checkInfoPopup);
                        HP.closeInfoPopup(resultDirectory, checkInfoPopup);
                    }
                } else if (country.equals("UK")) {
                    if (isElementPresent(driver, HomePage.infoIcon_ES, 10)) {
                        size = HP.getInfoList(country, resultDirectory, checkInfoPopup).size();
                        for (int i = 1; i <= size; i++) {
                            HP.clickInfo(i, country, resultDirectory, checkInfoPopup);
                            //checkInfoPopup.log(Status.INFO, "Financial information clicked");
                            //logger.log(Status.PASS, MarkupHelper.createLabel("Financial information clicked", ExtentColor.BLUE));
                        }
                    } else {
                        failWithScreenshot("Info Popup (Ejemplo Renting) Popup is not present", resultDirectory, driver, extent, checkInfoPopup);
                        HP.closeInfoPopup(resultDirectory, checkInfoPopup);
                    }
                }
                HP.scrollToTop(driver);

            } catch (Exception e) {
			/*checkInfoPopup.log(Status.FAIL,"Test Failed on Info Popup");
			failWithScreenshot("Test Failed on Info Popup", resultDirectory, driver, extent, checkInfoPopup);
			checkInfoPopup.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                e.printStackTrace();
                catchFailDetails(resultDirectory, checkInfoPopup, driver, "Test Failed on Info Popup", e);
            }
        }
    }
}
