package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckPrice extends UniversalMethods {
	public static ExtentTest checkPrice;

	@Test(description = "verifying Cash And Finance Price")
	public static void verifyCashPrice(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String PaymentMode) throws Exception {

		if(driver!=null) {
			try {
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				checkPrice = extentHP.createNode("CheckPrice", "Checking price on Homepage");
				HomePage HP = new HomePage(driver);
				//SoftAssert sa = new SoftAssert();
				Float cashPrice;
				Float financePrice;

				int size = HP.validateCashCarList(resultDirectory,checkPrice);
				HP.validateCashCarList(resultDirectory, checkPrice);
			checkPrice.log(Status.INFO, "Total Number of Cash Cars Present are: "+size);
			for (int i = 1; i <=size; i++) {
				cashPrice = HP.getCashPrice(i,resultDirectory,checkPrice);
				if (cashPrice > 0) {
					checkPrice.log(Status.PASS, "Cash price is " + cashPrice + " displayed");
					//logger.log(Status.PASS, MarkupHelper.createLabel("Cash price is " + cashPrice + " displayed", ExtentColor.GREEN));
					//sa.assertTrue(true);
				} else {
					checkPrice.log(Status.FAIL, "Cash price is not displayed");
					//failWithScreenshot("Cash price is not displayed", resultDirectory, driver, extent, logger);
					//sa.assertTrue(false, "Cash price is not displayed");
				}
			}
			if(PaymentMode.equalsIgnoreCase("Finance")) {


				if (!brand.equalsIgnoreCase("OV")) {
					if (isElementPresent(driver, HomePage.monthly_Price, 10)) {
						int size1 = HP.getMonthlyPriceList(resultDirectory, checkPrice).size();
						for (int i = 1; i <= size1; i++) {
							financePrice = HP.getMonthlyPrice(i, resultDirectory, checkPrice);
							if (financePrice > 0) {
								checkPrice.log(Status.PASS, "Finance price is " + financePrice + " displayed");
								//logger.log(Status.PASS, MarkupHelper.createLabel("Finance price is " + financePrice + " displayed", ExtentColor.GREEN));
								//sa.assertTrue(true);
							} else {
								checkPrice.log(Status.FAIL, "Finance price is not displayed");
								//failWithScreenshot("Finance price is not displayed", resultDirectory, driver, extent, logger);
								//sa.assertTrue(false, "Finance price is not displayed");
							}
						}
					} else {
						checkPrice.log(Status.INFO, "Monthly Price is not available as none of Finance Vehicles are available in the Page till now");
						//driver.close();
					}
				}
			}
				//sa.assertAll();
			} catch (Exception e) {
				checkPrice.log(Status.FAIL, "Error with verifying Cash And Finance Price");
				failWithScreenshot("Error with verifying Cash And Finance Price", resultDirectory, driver, extent, checkPrice);
				checkPrice.log(Status.FAIL, String.valueOf(e.getStackTrace()));
			}
		}
	}
}
