package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.CookieAccepter;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

@Test(description = "Checking AC Store PRO")
public class CheckACStorePRO extends UniversalMethods {

	public static void CheckStorePro(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Country, String Brand) throws Exception {
		int i;
		int j;
		int k;
		CookieAccepter accept = new CookieAccepter(driver);

		try {

			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			HomePage HP = new HomePage(driver);

			// scroll to the top
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			Thread.sleep(500);

			if (Brand.equals("AC") && Country.equals("FR")) {
				logger.log(Status.PASS, MarkupHelper.createLabel("Testing Store PRO", ExtentColor.BROWN));
				HP.closePoUp(resultDirectory,logger);
				HP.openStorePro(resultDirectory,logger);
				accept.clickContAccepter(resultDirectory,logger);

				if (HP.getStoreProPageTitle(resultDirectory,logger).equals("PRO")) {

					logger.log(Status.PASS,
							MarkupHelper.createLabel("The Store Pro Page has been opened", ExtentColor.GREEN));
					Assert.assertTrue(true);
				} else {
					failWithScreenshot("The Store Pro Page has not been opened", resultDirectory, driver, extent,
							logger);
					Assert.assertTrue(false, "The Store Pro Page has not been opened");
					driver.quit();

				}

				waitForUrlContains("b2b", driver, 60);
				logger.log(Status.INFO, MarkupHelper.createLabel("Url Contains B2B ", ExtentColor.BLUE));

				HP.openB2CStore(resultDirectory,logger);
				waitForUrlContains("summit", driver, 60);
				logger.log(Status.INFO, MarkupHelper.createLabel("Returned to B2C Home Page ", ExtentColor.BLUE));

			}

		} catch (Exception e1) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Unable to Check AC Store PRO", ExtentColor.BLUE));
			e1.printStackTrace();

		}
	}

}
