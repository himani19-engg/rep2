package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static solRetailIHM.ProjSpecFunctions.GoToBasket.FinancePriceDealerBeforeBasket;


@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class PaymentMethodBasketPage extends UniversalMethods {

    public static ExtentTest extentBP;
    public static ExtentTest selectPaymentOption;

    public static ExtentTest BasketPageTradeInEstimation;
    public static Float MonthlyTotalBasketCash;
    public static Float financePriceBasket;

    public static String getbasketPgVehicleName;
    @Test(description = "To verify change payment option")
    public static void verifyChangePaymentOption(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                 ExtentTest logger, String brand, String country) throws Exception {
        BasketPage bkt = new BasketPage(driver);
        SoftAssert sa = new SoftAssert();
        ExtentTest changePayment = extentBP.createNode("ChangePayment", "Check payment change");
        try {
            driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
            if (Integer.valueOf(bkt.readFromProperties("financeVehiclesSize")) > 0) {
                //driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
                bkt.scrollToTop(driver);
                Thread.sleep(1000);
                bkt.clickOnMonthlyPaymentButton(resultDirectory,changePayment,brand,country);
                //logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Monthly payment option", ExtentColor.BLUE));
                changePayment.log(Status.INFO, "Clicked on Monthly payment option");
                //Thread.sleep(8000);
                String label = bkt.getMonthlyPaymentSuffixLabel(resultDirectory,changePayment);
                if (label.contains("mes") || label.contains("mois")) {
                    //logger.log(Status.PASS, MarkupHelper.createLabel("Monthly payment option is displayed", ExtentColor.GREEN));
                    changePayment.log(Status.PASS, "Monthly payment option is displayed");
                    sa.assertTrue(true);
                } else {
                    failWithScreenshot("Monthly payment option is not displayed", resultDirectory, driver, extent, changePayment);
                    sa.assertTrue(false, "Monthly payment option is not displayed");
                }
                bkt.clickOnCashPaymentButton(resultDirectory,changePayment);
                changePayment.log(Status.INFO, "Clicked on Cash payment option");
                String check = bkt.getCashPaymentAttribute(resultDirectory,changePayment);
                if (check.contains("selected")) {
                    changePayment.log(Status.PASS, "Cash payment option is displayed");
                    sa.assertTrue(true);
                } else {
                    failWithScreenshot("Cash payment option is not displayed", resultDirectory, driver, extent, changePayment);
                    sa.assertTrue(false, "Cash payment option is not displayed");
                }
                Thread.sleep(1000);
                scrollToTop(driver);
                bkt.clickOnMonthlyPaymentButton(resultDirectory,changePayment,brand,country);
                changePayment.log(Status.INFO, "Clicked on Monthly payment option again");
                Thread.sleep(1000);
                //Thread.sleep(8000);
                //sa.assertAll();
            }
        } catch (Exception e) {
            /*changePayment.log(Status.FAIL, "Test Failed while verifying change payment option");
            failWithScreenshot("Test Failed while verifying change payment option", resultDirectory, driver, extent, changePayment);
            changePayment.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            catchFailDetails(resultDirectory, changePayment,driver, "Test Failed while verifying change payment option",e);
        }
    }

    @Test(description = "To select payment option")
    public static void selectPaymentOption(String resultDirectory, WebDriver driver, ExtentReports extent,
                                           ExtentTest logger, String brand, String country, String paymentMode) {
        if(driver!=null) {
            BasketPage bkt = new BasketPage(driver);
            extentBP = logger.createNode("BasketPage", "Checking details on BasketPage");
            selectPaymentOption = extentBP.createNode("SelectPayment", "Selecting payment option");
            String paymentTick = null;
            try {
                //getbasketPgVehicleName=getAnyText(driver,By.xpath("(//*[contains(@class,'vehicle')]//span[contains(@class,'title')])[1]"));
                getbasketPgVehicleName=getAnyText(driver,By.xpath("//*[@data-testid='TESTING_SHOW_CHARACTERISTICS_BUTTON_BASKET_PAGE']/parent::div/span  | (//*[contains(@class,'vehicle')]//span)[1]"));
                driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
                if (paymentMode.equalsIgnoreCase("Cash")) {
                    bkt.clickOnCashPaymentButton(resultDirectory, selectPaymentOption);
                    selectPaymentOption.log(Status.INFO, "Clicked on Cash payment option");
                } else {
                    bkt.clickOnMonthlyPaymentButton(resultDirectory, selectPaymentOption,brand,country);
                    selectPaymentOption.log(Status.INFO, "Clicked on Monthly payment option");
                    driver.navigate().refresh();
                }
                //Thread.sleep(5000);
                waitForPageToLoad(driver, 5);
                if (paymentMode.equalsIgnoreCase("Finance")) {
                    //String financePriceNo = dea.getFinancePrice().split("€")[0].trim();
                    financePriceBasket = extractFloatFromString(bkt.getFinancePrice(brand, country).replace(",", ".").replace(" ", ""));
                    System.out.println(financePriceBasket);
                    /*if (Country.equalsIgnoreCase("FR")) {
                        if ((FinancePriceDealerBeforeBasket-financePriceBasket) <= 1) {
                            selectPaymentOption.log(Status.PASS, "Finance Price on Basket Page is same as on Dealer Step Before Basket Page, which is: " + financePriceBasket);
                        } else {
                            selectPaymentOption.log(Status.FAIL, "Finance Price on Basket Page is not same as on Dealer Step Before Basket Page");
                        }
                    }*/
                    bkt.writeToProperties("dealear_FinancePrice", String.valueOf(financePriceBasket));
                }
                Thread.sleep(6000);
                waitForPageToLoad(driver, 10);
                paymentTick = bkt.getPaymentTickAttribute("class", resultDirectory, selectPaymentOption);
                if (paymentTick.contains("selected")) {
                    selectPaymentOption.log(Status.PASS, "Payment option in header is ticked");
                } else {
                    selectPaymentOption.log(Status.FAIL, "Payment option in header is not ticked");
                }

                 // if(paymentMode.equalsIgnoreCase("Finance")){
//                Float dealerpageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
//                Float basketPageCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//div[@data-testid='TESTING_TOTAL_CASH_PRICE']")));
//                if (dealerpageCashPrice - basketPageCashPrice < 1) {
//                    selectPaymentOption.log(Status.PASS, "dealer page Cash price " + dealerpageCashPrice + "is same as basket page cash price");
//                } else {
//                    selectPaymentOption.log(Status.FAIL, "dealer Page Cash Price" + dealerpageCashPrice + "is not same as basket page cash price");
//                }
//                      if(paymentMode.equalsIgnoreCase("Finance")){
//                          Float dealerPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
//                          Float basketPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@data-testid='TESTING_TOTAL_MONTHLY_PRICE']")));
//                          if (dealerPageFinancePrice - basketPageFinancePrice < 1) {
//                              selectPaymentOption.log(Status.PASS, "dealer page Finance price " + dealerPageFinancePrice + "is same as basket page finance price");
//                          } else {
//                              selectPaymentOption.log(Status.FAIL, "dealer Page Finance Price" + dealerPageFinancePrice + "is not same as basket page finance price");
//                          }
//                }



//


                //String MonthlyTotalBasketCashSample=getAnyText(driver, By.xpath("//div[contains(@class,'totalPrice_cashPrice isCash')] | //div[contains(@class,'totalPrice_cashPrice')]")).replaceAll(" ","").replace(",",".").substring(0,8);
                String MonthlyTotalBasketCashSample=getAnyText(driver, By.xpath("//*[@data-testid='TESTING_TOTAL_CASH_PRICE']")).replaceAll(" ","").replace(",",".").substring(0,8);
                System.out.println(MonthlyTotalBasketCashSample);
                MonthlyTotalBasketCash= Float.valueOf(MonthlyTotalBasketCashSample);
                if(brand.equalsIgnoreCase("AC") && country.equalsIgnoreCase("FR")) {
                    bkt.tradeInEstimationReprise(resultDirectory, selectPaymentOption);
                }
            } catch (Exception e) {
                failWithScreenshot("Test Failed while selecting payment option", resultDirectory, driver, extent, selectPaymentOption);
                selectPaymentOption.log(Status.FAIL, String.valueOf(e.getStackTrace()));
            }
        }
    }

    @Test(description = "To select finance payment option")
    public static void selectFinancePaymentOption(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                  ExtentTest logger, String brand, String country) throws Exception {
        BasketPage bkt = new BasketPage(driver);
        selectPaymentOption = logger.createNode("BasketPage", "Selecting payment option");
        try {
            bkt.clickOnMonthlyPaymentButton(resultDirectory,selectPaymentOption,brand,country);
            //logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Monthly payment option", ExtentColor.BLUE));
            selectPaymentOption.log(Status.INFO, "Clicked on Monthly payment option");
        } catch (Exception e) {
            selectPaymentOption.log(Status.FAIL, "Unable to Click on Monthly payment option");
            failWithScreenshot("Unable to Click on Monthly payment option", resultDirectory, driver, extent, selectPaymentOption);
            selectPaymentOption.log(Status.FAIL, String.valueOf(e.getStackTrace()));
        }
    }

    @Test(description = "To select cash payment option")
    public static void selectCashPaymentOption(String resultDirectory, WebDriver driver, ExtentReports extent,
                                               ExtentTest logger, String brand, String country) throws Exception {
        BasketPage bkt = new BasketPage(driver);
        selectPaymentOption = logger.createNode("BasketPage", "Selecting payment option");
        try {
            bkt.clickOnCashPaymentButton(resultDirectory,selectPaymentOption);
            //logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Cash payment option", ExtentColor.BLUE));
            selectPaymentOption.log(Status.INFO, "Clicked on Cash payment option");
        } catch (Exception e) {
            selectPaymentOption.log(Status.FAIL, "Unable to Click on Cash payment option");
            failWithScreenshot("Unable to Click on Cash payment option", resultDirectory, driver, extent, selectPaymentOption);
            selectPaymentOption.log(Status.FAIL, String.valueOf(e.getStackTrace()));
        }
    }

    @Test(description = "To verify promo code")
    public static void verifyPromoCode(String resultDirectory,
                                       WebDriver driver,
                                       ExtentReports extent,
                                       ExtentTest logger,
                                       String Brand,
                                       String Country,
                                       String PaymentMode,
                                       String PromoCode) throws Exception {

        BasketPage bkt = new BasketPage(driver);
        SoftAssert sa = new SoftAssert();
        ExtentTest checkPromoCode = extentBP.createNode("CheckPromoCode", "Check Promo Code");
        try {
            driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
            //Apply PromoCode
            //bkt.clickOnprompcodeText();
            //Thread.sleep(1000);
            List<String> promocodes= Arrays.asList("TESTCHECKOUTWITHOUTDEPOSIT","TESTCHECKOUT1","Test500","TESTCHECKOUT",
                    "TESTCHECKOUTB2E","JANTEST500","OCTTEST200","UAT1000");
            int i=0,found=0;
            while(i<promocodes.size()){
                //checkPromoCode.log(Status.INFO, "Enter promo code");
                bkt.enterPromoCode(promocodes.get(i),resultDirectory,checkPromoCode);
                //click on Apply Button After entering promocode
                bkt.clickOnApplyButton(resultDirectory,checkPromoCode,Brand,Country);
                // Verify promo code success text
                //if (!Brand.equals("DS")) {
                Thread.sleep(3000);
                String promoSuccessText = bkt.getPromoSuccessText(resultDirectory,checkPromoCode);
                if (promoSuccessText.contains("Code promo ajouté") ||
                        promoSuccessText.contains("Código promocional añadido") ||
                        promoSuccessText.contains("digo promocional a")||
                        promoSuccessText.contains("Code promotionnel ajouté")) {
                    //logger.log(Status.PASS, MarkupHelper.createLabel("Promo code success message appeared", ExtentColor.GREEN));
                    checkPromoCode.log(Status.PASS, "Promo code success message appeared");
                    found=1;
                    break;
                    //sa.assertTrue(true);
                } else {
                    i++;
                }
            }
            if(found==0){
                failWithScreenshot("Promo code success message not appeared", resultDirectory, driver, extent, checkPromoCode);
                //sa.assertTrue(false, "Promo code success message not appeared");
            }
            //logger.log(Status.INFO, MarkupHelper.createLabel("Enter PromoCode", ExtentColor.BLUE));
            //checkPromoCode.log(Status.INFO, "Enter promo code");
            //Thread.sleep(1000);

            //checkPromoCode.log(Status.INFO, "Apply button clicked");
            //Thread.sleep(2000);

            // Verify promo code success text
            //if (!Brand.equals("DS")) {
                Thread.sleep(3000);
                String promoSuccessText = bkt.getPromoSuccessText(resultDirectory,checkPromoCode);
                if (promoSuccessText.contains("Code promo ajouté") ||
                        promoSuccessText.contains("Código promocional añadido") ||
                        promoSuccessText.contains("digo promocional a")||
                        promoSuccessText.contains("Code promotionnel ajouté")) {
                    //logger.log(Status.PASS, MarkupHelper.createLabel("Promo code success message appeared", ExtentColor.GREEN));
                    checkPromoCode.log(Status.PASS, "Promo code success message appeared");
                    //sa.assertTrue(true);
                } else {
                    failWithScreenshot("Promo code success message not appeared", resultDirectory, driver, extent, checkPromoCode);
                    //sa.assertTrue(false, "Promo code success message not appeared");
                }
            //}

            // Promo code content text
            //if (!Brand.equals("DS")) {
                System.out.println(promocodes.get(i));
                if (bkt.getPromoContentText(resultDirectory,checkPromoCode).contains(promocodes.get(i))) {
                    //logger.log(Status.PASS, MarkupHelper.createLabel("Promo code text appeared", ExtentColor.GREEN));
                    checkPromoCode.log(Status.PASS, "Promo code text appeared");
                    sa.assertTrue(true);
                    writeToProperties("PromoCode",promocodes.get(i));
                } else {
                    failWithScreenshot("Promo code text not appeared", resultDirectory, driver, extent, checkPromoCode);
                    sa.assertTrue(false, "Promo code text not appeared");
                }
            //}

            //Deduct price
            //if (!Brand.equals("DS")) {
            String promoDiscountPrice=bkt.getPromoDiscountPrice(resultDirectory,checkPromoCode);
                if (promoDiscountPrice.contains("1 000")
                        || promoDiscountPrice.contains("1 500")
                        || promoDiscountPrice.contains("500")
                        || promoDiscountPrice.contains("2 000")) {
                    checkPromoCode.log(Status.PASS, "Price deducted correctly after applying promo code");
                    sa.assertTrue(true);
                    writeToProperties("Discount",promoDiscountPrice);
                } else {
                    failWithScreenshot("Price did not deduct correctly after applying promo code", resultDirectory, driver, extent, checkPromoCode);
                    sa.assertTrue(false, "Price not deduct after applying promo code");
                    writeToProperties("Discount",null);
                }
            //}
            sa.assertAll();
        } catch (Exception e) {
            checkPromoCode.log(Status.FAIL, "Test Failed while verifying promo code");
            failWithScreenshot("Test Failed while verifying promo code", resultDirectory, driver, extent, checkPromoCode);
            checkPromoCode.log(Status.FAIL, String.valueOf(e.getStackTrace()));
        }
    }

}