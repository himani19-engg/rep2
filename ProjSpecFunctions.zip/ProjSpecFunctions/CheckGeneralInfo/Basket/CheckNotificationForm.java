package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.Utilities.UniversalMethods;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckNotificationForm extends UniversalMethods {

	@Test(description = "To fill notification form on Basket page")
	public static void fillNotificationFormOnBasket(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country, String postalCode, String emailId,
			String name, String phone, String address) throws Exception {
		
		ExtentTest notificationForm = extentBP.createNode("LeadForm", "Check Lead form");
		BasketPage basket = new BasketPage(driver);
		try {
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//Thread.sleep(5500);
			//basket.fillNotificationForm(brand, country, postalCode, emailId, name, phone, address,resultDirectory,notificationForm);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Notification Form filled", ExtentColor.BLUE));
			notificationForm.log(Status.INFO, "Lead form filled");

		} catch (Exception e) {
			failWithScreenshot("Test Failed while filling lead form on Basket page", resultDirectory, driver, extent, notificationForm);
			notificationForm.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
	}
}
