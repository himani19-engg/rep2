package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class BasketFooter extends UniversalMethods {

	public static ExtentTest footerCheck;

	@Test(description = "Checking Footers")
	public static void checkFooters(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Brand, String Country) throws Exception {
		int i;
		int j;
		int k;
		String brandText = null;
		footerCheck = extentBP.createNode("FooterCheck","Checking footer");
		HomePage HP = new HomePage(driver);
		try {
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

			// Open The footers
			HP.scrollToBottom(driver);
			int footerCount = HP.getFooterList(resultDirectory,footerCheck).size();
			System.out.println("<<<<<<>>>>>>" + footerCount);
			footerCheck.log(Status.INFO, "Testing Footers");
			//logger.log(Status.INFO, MarkupHelper.createLabel("Testing Footers", ExtentColor.BLUE));

			if(footerCount > 0) {
				for (i = 0; i < footerCount; i++) {
					HP.openFooter(i,resultDirectory,footerCheck);
					//footerCheck.log(Status.INFO, "The footer " + HP.getFooterList(resultDirectory,footerCheck).get(i).getText() + " is opened");
					//logger.log(Status.INFO, MarkupHelper.createLabel("The footer " + HP.getFooterList().get(i).getText() + " is opened", ExtentColor.BLUE));
					//Thread.sleep(2000);
					int subFooterCount = HP.getSubFooterList(i+1,resultDirectory,footerCheck).size();
					System.out.println("*******************" + subFooterCount);
					if(subFooterCount > 0) {
						for (j = 1; j < subFooterCount; j++) {
							System.out.println(i);
							System.out.println(j);
							HP.openSubFooters(i, j,resultDirectory,footerCheck);
							//Thread.sleep(500);
							HP.openSubFooters(i, j,resultDirectory,footerCheck);
						}
					}
					HP.openFooter(i,resultDirectory,footerCheck);
					System.out.println("Close the footer");
				}
				footerCheck.log(Status.INFO, "FAQ Footers are present");
			}else {
				//failWithScreenshot("Main footer list is not present", resultDirectory, driver, extent, footerCheck);
				footerCheck.log(Status.INFO,"Main footer list is not present");
			}

			// check all the footers with the Opened PDF
			if (HP.getFooter(resultDirectory,footerCheck) > 1) {
				if (HP.getFooterConditionList(resultDirectory,footerCheck).size() > 0) {
					for (k = 0; k <= 1; k++) {
						System.out.println("Value k :" + k);
						if ((Brand.equals("AC") || Brand.equals("DS")) && Country.equals("UK") && (k == 0)) {
						} else if (Brand.equals("VX") || Country.equals("UK") && k == 1) {
						} else if ((Brand.equals("AP") || Brand.equals("DS")) && Country.equals("ES")
								&& (k == 1 || k == 0)) {
						} else {
							HP.openFooterCondition(k,resultDirectory,footerCheck);
							ArrayList<String> tabs_windows = new ArrayList<String>(driver.getWindowHandles());
							ArrayList<String> tabs = new ArrayList<String>(tabs_windows);
							System.out.println("No. of tabs: " + tabs.size());
							footerCheck.log(Status.INFO, "No. of tabs: " + tabs.size());
							driver.switchTo().window(tabs_windows.get(1));
							footerCheck.log(Status.INFO, "Switched to new tab");
							Thread.sleep(1000);
							System.out.println(driver.getCurrentUrl());
							if (Brand.equals("VX") && Country.equals("UK") && (k == 0)) {
								waitForUrlContains("privacy-policy", driver, 60);
							} else {
								waitForUrlContains(".pdf", driver, 60);
							}
							driver.close();
							driver.switchTo().window(tabs_windows.get(0));
							footerCheck.log(Status.INFO, "Switched back to the old tab");
						}
					}
				}
				footerCheck.log(Status.INFO, "Condition Footers are correct");
				//logger.log(Status.INFO, MarkupHelper.createLabel("Condition Footers are correct", ExtentColor.BLUE));
			}

			// HP.OpenFooterCondition(HP.getFooterConditionList().size()-1);
			
			//HP.clickCookieFooter();
			//HP.acceptAllCookiesFooters();
			ArrayList<String> tabs_windows = new ArrayList<String>(driver.getWindowHandles());
			ArrayList<String> tabs = new ArrayList<String>(tabs_windows);
			if (tabs.size() == 2) {
				driver.switchTo().window(tabs_windows.get(1));
				footerCheck.log(Status.INFO, "Switched to the new tab");
				Thread.sleep(1000);
				driver.close();
				driver.switchTo().window(tabs_windows.get(0));
				footerCheck.log(Status.INFO, "Switched back to the old tab");
			}
			footerCheck.log(Status.INFO, "Cookies Footer is correct");
			//logger.log(Status.INFO, MarkupHelper.createLabel("Cookies Footer is correct", ExtentColor.BLUE));

			for (int s = 1; s <= 4; s++) {
				if (HP.footerIconPresent(s,resultDirectory,footerCheck)) {
					footerCheck.log(Status.PASS, "The footer Icone Exists");
				//	logger.log(Status.PASS, MarkupHelper.createLabel("The footer Icone Exists", ExtentColor.GREEN));
				} else {
					footerCheck.log(Status.FAIL,"The footer Icone doesn't Exist");
					failWithScreenshot("The footer Icone doesn't Exist", resultDirectory, driver, extent, footerCheck);
				}
			}
			
			brandText = Brand;
			if (brandText.equals("AP")) {
				brandText = "Peugeot";
			}
			if (brandText.equals("AC")) {
				brandText = "Citroën";
			}
			if (brandText.equals("DS")) {
				brandText = "DS";
			}
			String footerIconText = null;

			for (int l = 1; l <= 4; l++) {

				if (l == 1) {
					footerIconText = HP.getFooterIconText(l,resultDirectory,footerCheck);
					System.out.println("HOLLA " + footerIconText);
					System.out.println("BrandText : " + brandText);
					if (footerIconText.equalsIgnoreCase("Prix spécial " + brandText + " Store (1)")
							|| footerIconText.equalsIgnoreCase("CITROËN STORE PRICE")
							|| footerIconText.equalsIgnoreCase("DS Store Online Price")
							|| footerIconText.equalsIgnoreCase("PIDE COMPLETAMENTE ONLINE")
							|| footerIconText.equalsIgnoreCase("PIDA COMPLETAMENTE ONLINE")
							|| footerIconText.equalsIgnoreCase("Prix spécial " + brandText + " Store")
							|| footerIconText.equalsIgnoreCase("Offre exclusive Opel One")) {
						footerCheck.log(Status.PASS, "The first footer Icone text is correct - "+footerIconText);
					//	logger.log(Status.PASS,
					//			MarkupHelper.createLabel("The first footer Icone text is correct - "+footerIconText, ExtentColor.GREEN));
					} else {
						footerCheck.log(Status.FAIL,"The first footer Icone text is not correct - "+footerIconText);
						failWithScreenshot("The first footer Icone text is not correct - "+footerIconText, resultDirectory, driver,
								extent, footerCheck);
					}
				}

				if (l == 2) {
					footerIconText = HP.getFooterIconText(l,resultDirectory,footerCheck);
					if (footerIconText.equalsIgnoreCase("Garantie constructeur 24 mois")
							|| footerIconText.equalsIgnoreCase("Garantie constructeur 34 mois")
							|| footerIconText.equalsIgnoreCase("36-MONTH MANUFACTURER’S WARRANTY")
							|| footerIconText.equalsIgnoreCase("24 month manufacturer's warranty")
							|| footerIconText.equalsIgnoreCase("Free Vauxhall Care Package")
							|| footerIconText.equalsIgnoreCase("Garantía constructor 24 meses")
							|| footerIconText.equalsIgnoreCase("Garantie constructeur 24 mois")
							|| footerIconText.equalsIgnoreCase("Garantía constructor 36 meses")
							|| footerIconText.equalsIgnoreCase("Garantie constructeur")) {
						footerCheck.log(Status.PASS, "The second footer Icone text is correct - "+footerIconText);
						//logger.log(Status.PASS,
						//		MarkupHelper.createLabel("The second footer Icone text is correct - "+footerIconText, ExtentColor.GREEN));
					} else {
						footerCheck.log(Status.FAIL,"The second footer Icone text is not correct - "+footerIconText);
						failWithScreenshot("The second footer Icone text is not correct - "+footerIconText, resultDirectory, driver,
								extent, footerCheck);
					}
				}

				if (l == 3) {
					footerIconText = HP.getFooterIconText(l,resultDirectory,footerCheck);
					if (footerIconText.equalsIgnoreCase("Paiement en ligne sécurisé")
							|| footerIconText.equalsIgnoreCase("SAFE AND SECURE TRANSACTION")
							|| footerIconText.equalsIgnoreCase("Secure online payment")
							|| footerIconText.equalsIgnoreCase("ONLINE FINANCE DECISION")
							|| footerIconText.equalsIgnoreCase("Pago online seguro")
							|| footerIconText.equalsIgnoreCase("Pago seguro online")
							|| footerIconText.equalsIgnoreCase("Paiement en ligne sécurisé")
							|| footerIconText.equalsIgnoreCase("Livraison dans plus de 150 points de vente")) {
						footerCheck.log(Status.PASS, "The third footer Icone text is correct - "+footerIconText);
					//	logger.log(Status.PASS,
					//			MarkupHelper.createLabel("The Third footer Icone text is correct - "+footerIconText, ExtentColor.GREEN));
					} else {
						footerCheck.log(Status.FAIL,"The third footer Icone text is not correct - "+footerIconText);
						failWithScreenshot("The Third footer Icone text is not correct - "+footerIconText, resultDirectory, driver,
								extent, footerCheck);
					}
				}

				if (l == 4) {
					String text = HP.getFooterIconText(l,resultDirectory,footerCheck);
					if (HP.getFooterIconText(l,resultDirectory,footerCheck).equalsIgnoreCase("Support national de concessionnaires (+300)")
							|| text.equalsIgnoreCase("Support national de concessionnaires (+300)")
							|| text.equalsIgnoreCase("Un réseau exclusif de 167 DS STORE et DS SALON")
							|| text.equalsIgnoreCase("UK WIDE RETAILER SUPPORT")
							|| text.equalsIgnoreCase("Supported by our DS experts online and instore")
							|| text.equalsIgnoreCase("UK wide retailer support")
							|| text.equalsIgnoreCase("UN RÉSEAU DE PLUS DE 300 CONCESSIONNAIRES")
							|| text.equalsIgnoreCase("Una red con más de 100 concesionarios")
							|| text.equalsIgnoreCase("Antes de 14 días puede cambiar de opinión.")
							|| text.equalsIgnoreCase("Antes de 14 días puedes cambiar de opinión.")
							|| text.equalsIgnoreCase("Livraison en concession (+300 en France)")
							|| text.equalsIgnoreCase("Accompagnement par des experts Opel")) {
						footerCheck.log(Status.PASS, "The forth footer Icone text is correct - "+footerIconText);
					//	logger.log(Status.PASS,
					//			MarkupHelper.createLabel("The forth footer Icone text is correct - "+footerIconText, ExtentColor.GREEN));
					} else {
						//footerCheck.log(Status.FAIL,"The forth footer Icone text is not correct - "+footerIconText);
						failWithScreenshot("The forth footer Icone text is not correct - "+footerIconText, resultDirectory, driver,
								extent, footerCheck);
					}
				}
			}

			// scroll to the top
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//Thread.sleep(500);

		} catch (Exception e1) {
			footerCheck.log(Status.FAIL,"Test Failed in footer checks");
			failWithScreenshot("test Failed in footer checks", resultDirectory, driver, extent, footerCheck);
			extentBP.log(Status.FAIL, String.valueOf(e1.getStackTrace()));
		}
	}
}
