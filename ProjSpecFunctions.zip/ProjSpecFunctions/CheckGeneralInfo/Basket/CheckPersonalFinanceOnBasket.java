package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

//import static solRetailIHM.ProjSpecFunctions.CheckPage.CheckBasketPage.extentBP;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.Utilities.UniversalMethods;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckPersonalFinanceOnBasket extends UniversalMethods {

	@Test(description = "Check default Price")
	public static void validateDefaultPrice(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country) {
		SoftAssert sa = new SoftAssert();
		ExtentTest defaultPrice = extentBP.createNode("CheckDefaultPrice","Check default price on Personalize Finance popup");
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			BasketPage basket = new BasketPage(driver);
			String monthlyPrice = null;

			//PaymentMethodBasketPage.selectFinancePaymentOption(resultDirectory, driver, extent, logger, brand, country);
			//defaultPrice.log(Status.INFO, "Click on finance payment option");
			//Thread.sleep(4000);

			basket.clickOnPersonalizeFinanceButton(resultDirectory,defaultPrice);
			defaultPrice.log(Status.INFO, "Click on Personalize Finance button");
			//Thread.sleep(4000);

			String durationPrice = basket.getFinanceDurationPrice(resultDirectory,defaultPrice).replace(",",".").substring(0,6);
			
			monthlyPrice = basket.getFinanceContainerPriceAmount(resultDirectory,defaultPrice).substring(0,3);

			if ((Float.parseFloat(durationPrice)-Float.parseFloat(monthlyPrice))<=1) {
				defaultPrice.log(Status.PASS, "Default finance duration price "+durationPrice+" on calculator popup and Basket page matches");
				//sa.assertTrue(true);
			}else {
				failWithScreenshot("Default price "+durationPrice+" on calculator popup and Basket page "+monthlyPrice+" is not correct", resultDirectory, driver, extent, defaultPrice);
				//sa.assertTrue(false, "Default price on calculator popup and Basket page is not correct");
			}
			//Thread.sleep(5000);
			//sa.assertAll();
			basket.clickClosePopup(resultDirectory,defaultPrice);
			defaultPrice.log(Status.INFO, "Calculator popup closed");
			//Thread.sleep(4000);
		} catch (Exception e) {
			defaultPrice.log(Status.FAIL,"Test Failed while Checking default Price");
			failWithScreenshot("Test Failed while Checking default Price", resultDirectory, driver, extent, defaultPrice);
			defaultPrice.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
		//sa.assertAll();
	}

	@Test(description = "Check after change to default Price")
	public static void validateAfterChangeToDefaultPrice(String resultDirectory, WebDriver driver,
			ExtentReports extent, ExtentTest logger, String brand, String country) {
		SoftAssert sa = new SoftAssert();
		ExtentTest changeToDefaultPrice = extentBP.createNode("ChangeToDefaultPrice","Check change to default price on Personalize Finance popup");
		try {
			driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
			BasketPage basket = new BasketPage(driver);
			String monthlyPrice = "";

			basket.clickOnPersonalizeFinanceButton(resultDirectory,changeToDefaultPrice);
			//changeToDefaultPrice.log(Status.INFO, "Click on Personalize Finance button");
			Thread.sleep(4000);
			basket.clickFinanceDurationButton(resultDirectory,changeToDefaultPrice);
			//changeToDefaultPrice.log(Status.INFO, "Click on finance duration 36 option");
			Thread.sleep(4000);
			basket.selectEntradaRateRange(country,resultDirectory,changeToDefaultPrice);
			//changeToDefaultPrice.log(Status.INFO, "Select entrada rate range");
			//basket.selectAnnualMileageRange();
			Thread.sleep(3000);
			if(country.equals("FR")) {
				basket.selectAssuranceCheckbox(resultDirectory,changeToDefaultPrice);
				Thread.sleep(5000);
				basket.selectAssuranceConfirmCheckbox(resultDirectory,changeToDefaultPrice);
				//changeToDefaultPrice.log(Status.INFO, "Select assurance checkbox");
				//Thread.sleep(2000);
			}
			String calculatorDurationPrice = basket.getFinanceDurationPrice(resultDirectory,changeToDefaultPrice).replace(",",".").substring(0,6);
			//basket.clickOnContinueButton(resultDirectory,changeToDefaultPrice);
			//Thread.sleep(5000);
			monthlyPrice = basket.getFinanceContainerPriceAmount(resultDirectory,changeToDefaultPrice).replace(",",".").substring(0,6);

			if ((Float.parseFloat(monthlyPrice)-Float.parseFloat(calculatorDurationPrice)<=1)) {
				changeToDefaultPrice.log(Status.PASS, "After duration, rate and mileage change on Calculator, price "+calculatorDurationPrice+" on calculator popup and Basket page matches");
				//sa.assertTrue(true);
			}else {
				failWithScreenshot("After duration, rate and mileage change on Calculator popup, calculator price "+calculatorDurationPrice+" and basket page price "+monthlyPrice+" does not match", resultDirectory, driver, extent, changeToDefaultPrice);
				//sa.assertTrue(false, "After duration, rate and mileage change on Calculator popup, calculator price and basket page price does not match");
			}
			//sa.assertAll();
			Thread.sleep(1000);
			basket.clickClosePopup(resultDirectory,changeToDefaultPrice);
			changeToDefaultPrice.log(Status.INFO, "Calculator popup closed");
			basket.clickOnMonthlyPaymentButton(resultDirectory,changeToDefaultPrice,brand,country);
		} catch (Exception e) {
			changeToDefaultPrice.log(Status.FAIL,"Test Failed while Check after change to default Price");
			failWithScreenshot("Test Failed while Check after change to default Price", resultDirectory, driver, extent, changeToDefaultPrice);
			changeToDefaultPrice.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
		//sa.assertAll();
	}
}
