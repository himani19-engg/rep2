package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.ProjSpecFunctions.YopMailConfirmationMsg;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeUnit;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckShareEmailOnBasket extends UniversalMethods {
    static By saveYourProject=By.xpath("//*[@id='TESTING_SAVE_CAR_BOX']");
    public static ExtentTest shareEmail;
    @Test(description = "Share Email On Basket")
    public static void shareEmailOnBasket(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                          String brand, String country, String emailId) {
        shareEmail = extentBP.createNode("ShareEmail", "Check share email");
        BasketPage bkt = new BasketPage(driver);
        try {
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            //click on save your project button
            clickElement(driver,saveYourProject);
            //click on email link
            //bkt.clickOnShareEmailLink(resultDirectory,shareEmail);
            //shareEmail.log(Status.INFO, "Click on share email link");
            //Thread.sleep(2000);
            //enter email
            bkt.emailInTextBox(emailId,resultDirectory,shareEmail);

            //shareEmail.log(Status.INFO, "Entered email");
            //Thread.sleep(2000);
            //click on submit button
            bkt.clickOnSubmitButton(resultDirectory,shareEmail);
            //shareEmail.log(Status.INFO, "Click submit button");
            //Thread.sleep(3000);
            bkt.closeMailPopup(resultDirectory,shareEmail);
		/*	if(bkt.getShareEmailSuccessMsgText().contains("Su oferta ha sido enviada con éxito"))
				logger.log(Status.PASS, MarkupHelper.createLabel("Email sent success message is displayed", ExtentColor.GREEN));
			else
				logger.log(Status.WARNING, MarkupHelper.createLabel("Email sent success message is not displayed", ExtentColor.ORANGE));
		*/

            YopMailConfirmationMsg.checkBasketShareEmail(resultDirectory, driver, extent, shareEmail, brand, country, emailId);
            //SoftAssert sa=new SoftAssert();
            waitForUrlContains("/basket",driver,20);
            String url = driver.getCurrentUrl();
            System.out.println("Current URL is: "+url);
            if (url.contains("basket")) {
                //logger.log(Status.PASS, MarkupHelper.createLabel("Basket page is displayed", ExtentColor.GREEN));
                shareEmail.log(Status.PASS, "Basket page is displayed after Share email");
                //Assert.assertTrue(true);
                Assert.assertTrue(true);

            } else {
                failWithScreenshot("Basket page is not displayed after Share email", resultDirectory, driver, extent, shareEmail);
                //sa.assertTrue(false, "Basket page is not displayed");
                Assert.assertFalse(true);
            }

            //sa.assertAll();

        } catch (Exception e) {
            failWithScreenshot("Test Failed while Share Email On Basket", resultDirectory, driver, extent, shareEmail);
            shareEmail.log(Status.FAIL, String.valueOf(e.getStackTrace()));
        }
    }
}
