package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ImageView extends UniversalMethods{

	@Test(description="Basket Page Image Link")
	public static void configPageImageLink(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String Brand, String Country) throws Exception {
		ExtentTest imageCheck = extentBP.createNode("ImageCheckOnBasketPage", "Check image on Basket page");
		
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		ConfigPage CP = new ConfigPage(driver);

		// Click On Exterior image
		CP.scrollToTop(driver);
		CP.clickExteriorImage(resultDirectory,imageCheck);
		System.out.println("Here is the link title ::::");
		//logger.log(Status.INFO, MarkupHelper.createLabel("Exterior image link is clicked", ExtentColor.BLUE));
		imageCheck.log(Status.INFO, "Exterior image link is clicked");
		//logger.log(Status.INFO, "Exterior image link is clicked");
		//Thread.sleep(5000);
		for (int i = 1; i <= 3; i++) {
			CP.clickonNextSlideArrow(resultDirectory,imageCheck);
			Thread.sleep(1000);
		}

		System.out.println("click to slide arrow");
		imageCheck.log(Status.INFO, "Next slide arrow button clicked");

		/*
		 * //Count of exterior image int exteriorSize = CP.getImageList().size();
		 * System.out.println("<<<<<<>>>>>>" + exteriorSize);
		 * 
		 * for(int i=1;i<=exteriorSize;i++) { CP.clickImageLink(i); classValue =
		 * CP.getImageAttributeValue(i); if(classValue.contains("active")) {
		 * logger.log(Status.PASS,
		 * MarkupHelper.createLabel("Exterior image shown is correct",
		 * ExtentColor.GREEN)); }else { logger.log(Status.WARNING,
		 * MarkupHelper.createLabel("Exterior image shown is not correct",
		 * ExtentColor.ORANGE)); } }
		 */

		// Click on Interior image
		CP.clickInteriorImage(resultDirectory,imageCheck);
		System.out.println("Here is the interior link title ::::");
		imageCheck.log(Status.INFO, "Interior image link is clicked");
		Thread.sleep(5000);
		for (int i = 1; i <= 3; i++) {
			CP.clickonNextSlideArrow(resultDirectory,imageCheck);
			Thread.sleep(1000);
		}
		System.out.println("click to slide arrow");
		imageCheck.log(Status.INFO, "Next slide arrow button clicked");

		/*
		 * //Count of exterior image int interiorSize = CP.getImageList().size();
		 * System.out.println("<<<<<<>>>>>>" + interiorSize);
		 * 
		 * for(int i=1;i<=interiorSize;i++) { CP.clickImageLink(i); classValue =
		 * CP.getImageAttributeValue(i); if(classValue.contains("active")) {
		 * logger.log(Status.PASS,
		 * MarkupHelper.createLabel("Interior image shown is correct",
		 * ExtentColor.GREEN)); }else { logger.log(Status.WARNING,
		 * MarkupHelper.createLabel("Interior image shown is not correct",
		 * ExtentColor.ORANGE)); } }
		 */
	}catch(Exception e) {
		/*failWithScreenshot("Test Failed on Basket Page Image Link", resultDirectory, driver, extent, imageCheck);
		imageCheck.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
			catchFailDetails(resultDirectory, imageCheck,driver, "Test Failed on Basket Page Image Link",e);
	}
	}
}
