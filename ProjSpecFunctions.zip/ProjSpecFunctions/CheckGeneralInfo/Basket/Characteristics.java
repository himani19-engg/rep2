package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class Characteristics extends UniversalMethods {

    @Test(description = "Checking Charactristic Header")
    public static void checkCharactristicHeader(String resultDirectory,
                                                WebDriver driver,
                                                ExtentReports extent,
                                                ExtentTest logger,
                                                String brand,
                                                String country
    ) throws Exception {
        ExtentTest checkCharactristicHeader = extentBP.createNode("CheckCharactristicHeader", "Check charactrastic header");
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            ConfigPage CP = new ConfigPage(driver);
            SoftAssert sa = new SoftAssert();
            //Thread.sleep(2000);
            // Click On Charateristics
            CP.clickOnCharateristics(resultDirectory,checkCharactristicHeader);
            System.out.println("Here is the link title ::::");
            checkCharactristicHeader.log(Status.INFO, "Characteristics link is clicked");
            //   logger.log(Status.INFO, MarkupHelper.createLabel("Characteristics link is clicked", ExtentColor.BLUE));
            //Thread.sleep(1000);

            //Count characteristic
            int characteristicCount = CP.CharacteristicsLink(resultDirectory,checkCharactristicHeader).size();
            System.out.println("<<<<<<>>>>>>" + characteristicCount);
            // logger.log(Status.INFO, MarkupHelper.createLabel("Testing Characteristics", ExtentColor.BLUE));
            checkCharactristicHeader.log(Status.INFO, "Testing Characteristics");

            String energyText = CP.getEnergyText(resultDirectory,checkCharactristicHeader);
            String gearboxText = CP.getGearboxText(resultDirectory,checkCharactristicHeader);

            if (energyText.equalsIgnoreCase("Energía") ||
                    energyText.contains("Energ")||
                    (energyText.equalsIgnoreCase("Énergie") ||
                            energyText.contains("nergie")||
                            (energyText.equalsIgnoreCase("Energia") ||
                                    (energyText.equalsIgnoreCase("Energy"))))) {
                checkCharactristicHeader.log(Status.PASS, "Header text Energy is correct");
                //	logger.log(Status.PASS, MarkupHelper.createLabel("Header text Energy is correct", ExtentColor.GREEN));
                sa.assertTrue(true);
            } else {
                failWithScreenshot("Header text Energy is not correct", resultDirectory, driver, extent, checkCharactristicHeader);
                sa.assertTrue(false, "Header text Energy is not correct");
            }

            if (gearboxText.equalsIgnoreCase("Caja de cambios") ||
                    (gearboxText.equalsIgnoreCase("Boîte de vitesses") ||
                            (gearboxText.contains("te de vitesses") )||
                            (gearboxText.equalsIgnoreCase("Gearbox") ||
                                    (gearboxText.equalsIgnoreCase("Caja de cambio"))))) {
                checkCharactristicHeader.log(Status.PASS, "Header text GearBox is correct");
                //  logger.log(Status.PASS, MarkupHelper.createLabel("Header text GearBox is correct", ExtentColor.GREEN));
                sa.assertTrue(true);
            } else {
                failWithScreenshot("Header text GearBox is not correct", resultDirectory, driver, extent, checkCharactristicHeader);
                sa.assertTrue(false, "Header text GearBox is not correct");
            }


            String powerText = CP.CharacteristicsLinkCheck(characteristicCount-2,resultDirectory,checkCharactristicHeader);

            String totalCO2EmissionsText = CP.CharacteristicsLinkCheck(characteristicCount - 1,resultDirectory,checkCharactristicHeader);

            //Get and check the CharateristicsLink's Header text

            if (powerText.equalsIgnoreCase("Potencia") ||
                    (powerText.equalsIgnoreCase("Puissance") ||
                            (powerText.equalsIgnoreCase("Puissance électrique (kW)") ||
                                    (powerText.equalsIgnoreCase("Power") ||
                                            (powerText.equalsIgnoreCase("Potencia máxima en kW CEE / a rpm") ||
                                                    (powerText.equalsIgnoreCase("Autonomie (kms)") ||
                                                            (powerText.equalsIgnoreCase("Autonomie (km)") ||
                                                                    (powerText.equalsIgnoreCase("Electric range (kms)") ||
                                                                            (powerText.equalsIgnoreCase("Autonomía hasta (kms)") ||
                                                                                    (powerText.contains("Rango el")&& powerText.contains("ctrico (kms)") )||
                                                                                    (powerText.equalsIgnoreCase("Autonomía (kms)"))))))))))) {
                checkCharactristicHeader.log(Status.PASS, "Header text Power is correct");
                //   logger.log(Status.PASS, MarkupHelper.createLabel("Header text Power is correct", ExtentColor.GREEN));
                sa.assertTrue(true);
            } else {
                failWithScreenshot("Header text Power is not correct", resultDirectory, driver, extent, checkCharactristicHeader);
                sa.assertTrue(false, "Header text Power is not correct");
            }

            if (totalCO2EmissionsText.equalsIgnoreCase("Total emisiones de CO₂") ||
                    totalCO2EmissionsText.contains("Total emisiones de CO")||
                    (totalCO2EmissionsText.equalsIgnoreCase("Total émissions de CO₂") ||
                            (totalCO2EmissionsText.contains("missions de CO")) ||
                            (totalCO2EmissionsText.equalsIgnoreCase("Total émissions de CO2") ||
                                    (totalCO2EmissionsText.equalsIgnoreCase("Total Emisión CO2") ||
                                            (totalCO2EmissionsText.equalsIgnoreCase("Total CO₂ emissions")))))) {
                checkCharactristicHeader.log(Status.PASS, "Header text TotalCO2Emissions is  correct");
                sa.assertTrue(true);
            } else {
                failWithScreenshot("Header text TotalCO2Emissions is not correct", resultDirectory, driver, extent, checkCharactristicHeader);
                sa.assertTrue(false, "Header text TotalCO2Emissions is not correct");
            }
            //sa.assertAll();

            //scroll to the top
            //JavascriptExecutor js = (JavascriptExecutor) driver;
           // js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
            Thread.sleep(500);
        } catch (Exception e) {
            /*failWithScreenshot("Test Failed Test Failed while Checking Characteristic Header", resultDirectory, driver, extent, checkCharactristicHeader);
            extentBP.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            catchFailDetails(resultDirectory, extentBP,driver, "Test Failed Test Failed while Checking Characteristic Header",e);

        }
    }
}
