package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

//import static solRetailIHM.ProjSpecFunctions.CheckPage.CheckBasketPage.extentBP;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckBasket extends UniversalMethods {

	@Test(description = "Check Detailed Price")
	public static void checkAdditionalCosts(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String paymentMode) {
		SoftAssert sa = new SoftAssert();
		ExtentTest checkPrice = extentBP.createNode("CheckAdditionalCosts","Check additional costs");
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			BasketPage bkt = new BasketPage(driver);
			/*int vatIncludedPrice = 0;
			int cashPrice = extractNumericFromString(bkt.getCashPrice());
			if(paymentMode.equalsIgnoreCase("Finance")) {
				vatIncludedPrice = extractNumericFromString(bkt.getVATIncludedPrice());
			}*/
			List<WebElement> list = bkt.getAdditionalCostsList(resultDirectory,checkPrice);
			List<WebElement> stickyBarList = bkt.getStickyBarCostsList(resultDirectory,checkPrice);
			int size = list.size();
			int stickyBarSize = stickyBarList.size();
			int additionalCost = 0, totalAdditionalCost = 0;
			int stickyBarCost = 0, totalStickyBarCost = 0;
			
			for(int i = 0; i < size; i++) {
				additionalCost = extractNumericFromString(list.get(i).getText());
				totalAdditionalCost = totalAdditionalCost + additionalCost;
			}
			
			for(int i = 0; i < stickyBarSize; i++) {
				stickyBarCost = extractNumericFromString(stickyBarList.get(i).getText());
				totalStickyBarCost = totalStickyBarCost + stickyBarCost;
			}
			
			if(totalStickyBarCost == totalAdditionalCost) {
				checkPrice.log(Status.PASS, "Total of Additional cost matches with sticky bar costs "+totalAdditionalCost);
				sa.assertTrue(true);
			}
			else {
				failWithScreenshot("Total of Additional cost does not match with sticky bar costs "+totalAdditionalCost, resultDirectory, driver, extent, checkPrice);
				sa.assertTrue(false,"Total of Additional cost does not match with sticky bar costs");
			}
			
			/*if(paymentMode.equalsIgnoreCase("Finance")) {
				if((cashPrice + totalAdditionalCost) == vatIncludedPrice) {
					logger.log(Status.PASS, MarkupHelper.createLabel("VAT Included price is correct "+vatIncludedPrice, ExtentColor.GREEN));
					sa.assertTrue(true);
				}
				else {
					logger.log(Status.WARNING, MarkupHelper.createLabel("VAT Included price is not correct "+vatIncludedPrice, ExtentColor.ORANGE));
					sa.assertTrue(false,"VAT Included price is not correct");
				}
			}*/
			
			/*String basket_vehicleName = bkt.getVehicleNameOnBasket().toUpperCase();
			
			if(basket_vehicleName.contains(bkt.readFromProperties("VehicleName").toUpperCase()))
				logger.log(Status.PASS, MarkupHelper.createLabel("Vehicle name on basket page is correct", ExtentColor.GREEN));
			else {
				FailWithScreenshot("Vehicle name on basket page is not correct", resultDirectory, driver, extent, logger);
				driver.close();
			}*/
			//sa.assertAll();
		}catch(Exception e) {
			failWithScreenshot("Test failed while checking additional costs", resultDirectory, driver, extent, checkPrice);
			checkPrice.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
	}
	
	@Test(description = "Check additional service")
	public static void checkAdditionalServices(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String brand, String country) {
		BasketPage bkt = new BasketPage(driver);
		String serviceText = "";
		String servicePriceSectionText = "";
		SoftAssert sa = new SoftAssert();
		ExtentTest additionalServices = extentBP.createNode("AdditionalServices", "Check additional services");
		String additionalServicesTick = "";
		try {
//			if(!brand.equals("AC")) {
				serviceText = bkt.getFirstAdditionalServiceText(resultDirectory,additionalServices);
				bkt.selectFirstAdditionalService(resultDirectory,additionalServices);
				servicePriceSectionText = bkt.getFirstAdditionalServiceTextFromPriceSection(country,resultDirectory,additionalServices,brand);
				if(serviceText.contains("GRAVAGE (SEUL)")||serviceText.contains("E2E_Test")|| serviceText.contains("407-TEST")||serviceText.contains("Label 001")|| serviceText.contains("001")|| serviceText.contains("HORS PACK BATTERIE CHARGEE A PLUS DE 80%")
				|| serviceText.contains("Offert : Moulins Sel Poivre Peugeot")) {
					additionalServices.log(Status.PASS, "Additional Service is correctly selected : "+servicePriceSectionText);
					sa.assertTrue(true);
					writeToProperties("ServiceText",serviceText);
				}else {
					failWithScreenshot("Additional Service is not correctly selected : "+serviceText, resultDirectory, driver, extent, additionalServices);
					sa.assertTrue(false,"Additional Service is not correctly selected");
					writeToProperties("ServiceText",null);
				}
				if(serviceText.equalsIgnoreCase(servicePriceSectionText)){
					additionalServices.log(Status.PASS,"Additional service text is same in Complements and price section");
				} else{
					additionalServices.log(Status.FAIL,"Additional service text is not same in Complements and price section");
				}
				String priceInComplementsSection=bkt.getPriceInComplementsSectionText(resultDirectory,additionalServices);
				String priceinPriceSection=bkt.getPriceInPriceSection(resultDirectory,additionalServices,brand,country);
				if(priceInComplementsSection.equalsIgnoreCase(priceinPriceSection)){
					additionalServices.log(Status.PASS,"Additional service price is same in Complements and price section ");
					writeToProperties("FirstAdditionalServicePrice",priceInComplementsSection);
				} else{
					additionalServices.log(Status.FAIL,"Additional service price is not same in Complements and price section");
					writeToProperties("FirstAdditionalServicePrice",null);
				}
				additionalServicesTick = bkt.getAdditionalServicesTickAttribute("class",resultDirectory,additionalServices);
		        if(additionalServicesTick.contains("selected")) {
		        	additionalServices.log(Status.PASS, "Additional services option in header is ticked");
		        }else {
		        	additionalServices.log(Status.FAIL, "Additional services option in header is not ticked");
		        }
//			}
			//sa.assertAll();
		}catch(Exception e) {
			failWithScreenshot("Test failed while checking additional service", resultDirectory, driver, extent, additionalServices);
			additionalServices.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
	}
	
	public static void checkPrice(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String paymentMode) {
		ExtentTest checkPrice = extentBP.createNode("CheckPrice","Check price");
		BasketPage bkt = new BasketPage(driver);
		int cashPrice, financePrice, stickyCashPrice, stickyFinancePrice;
		try {
			if(paymentMode.equalsIgnoreCase("Cash")) {
				cashPrice = bkt.getPaymentCashPrice(resultDirectory,checkPrice);
				stickyCashPrice = bkt.getStickyBarCashPrice(resultDirectory,checkPrice);
				
				if(cashPrice == stickyCashPrice) {
					checkPrice.log(Status.PASS, "Cash price from Payment block "+ cashPrice +" matches with Stick bar price "+stickyCashPrice);
				}else {
					checkPrice.log(Status.FAIL, "Cash price from Payment block "+ cashPrice +" does not match with Stick bar price "+stickyCashPrice);
				}
			}
			
			if(paymentMode.equalsIgnoreCase("Finance")) {
				financePrice = bkt.getPaymentFinancePrice(resultDirectory,checkPrice);
				stickyFinancePrice = bkt.getStickyBarFinancePrice(resultDirectory,checkPrice);
				
				if(financePrice == stickyFinancePrice) {
					checkPrice.log(Status.PASS, "Finance price from Payment block "+ financePrice +" matches with Stick bar price "+stickyFinancePrice);
				}else {
					checkPrice.log(Status.FAIL, "Finance price from Payment block "+ financePrice +" does not match with Stick bar price "+stickyFinancePrice);
				}
			}
			
			
		}catch(Exception e) {
			failWithScreenshot("Test failed while checking checkPrice", resultDirectory, driver, extent, checkPrice);
			checkPrice.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
	}
	
	public static void checkCarteGrise(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String postalCode, String Brand) {
		ExtentTest checkCarteGrise = extentBP.createNode("CheckAdministrativeFees", "Check administrative/registration fees");
		BasketPage bkt = new BasketPage(driver);
		String carteGriseTick = null;
		try {
			bkt.selectYesReprise(resultDirectory,checkCarteGrise);
			bkt.fillCarteGrise(postalCode,resultDirectory,checkCarteGrise);
			//bkt.closeCGPriceCalculationErorPopup(resultDirectory,checkCarteGrise);
			Thread.sleep(6000);
			if(isElementPresent(driver,bkt.closeButton)){
				clickElement(driver,bkt.closeButton);
				clickElement(driver,bkt.noButton);
			} else{
			carteGriseTick = bkt.getCarteGriseTickAttribute("class",resultDirectory,checkCarteGrise);
            if(carteGriseTick.contains("selected")) {
				System.out.println("Carte Grise option in header is ticked");
            	checkCarteGrise.log(Status.PASS, "Carte Grise option in header is ticked");
            }else {
				System.err.println("Carte Grise option in header is ticked");
            	checkCarteGrise.log(Status.FAIL, "Carte Grise option in header is not ticked");
            }
			String carteGrisePrice=bkt.getCarteGrisePrice(resultDirectory,checkCarteGrise);
			String carteGrisePriceInPriceSection=bkt.getCarteGrisePriceInPriceSection(resultDirectory,checkCarteGrise);
		    Thread.sleep(5000);
			if(carteGrisePrice.contains(carteGrisePriceInPriceSection)){
				checkCarteGrise.log(Status.PASS,"Carte Grise price is displayed same in carte grise section and price section");
			    writeToProperties("CarteGrisePrice",carteGrisePrice);
			}else{
				checkCarteGrise.log(Status.FAIL,"Carte Grise price is displayed different in carte grise section and price section");
				writeToProperties("CarteGrisePrice",null);
			}
			String demarchesFees=bkt.getDemarchesFees(resultDirectory,checkCarteGrise, Brand);
			String demarchesFeesInPriceSection=bkt.getDemarchesFeesInPriceSection(resultDirectory,checkCarteGrise,Brand);
			Thread.sleep(3000);
			if(demarchesFees.equalsIgnoreCase(demarchesFeesInPriceSection)){
				checkCarteGrise.log(Status.PASS,"Demarches fees is displayed same in registration section and price section");
				writeToProperties("DemarchesFees",demarchesFees);
			} else{
				checkCarteGrise.log(Status.FAIL,"Demarches fees is displayed different in registration section and price section");
				writeToProperties("DemarchesFees",null);
			   }
		    }
		}catch(Exception e) {
			failWithScreenshot("Test failed while checking Carte Grise", resultDirectory, driver, extent, checkCarteGrise);
			checkCarteGrise.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
	}
	
	public static void	checkAssistedSalesPopin(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String email, String phone) {
		ExtentTest checkSalesPopin = extentBP.createNode("CheckAssistedSalesPopin", "Check assisted sales popin");
		BasketPage bkt = new BasketPage(driver);

		try {
			bkt.clickOnShareEmailLink(resultDirectory, checkSalesPopin);
			bkt.clickVendorModuleLink(resultDirectory, checkSalesPopin);
			bkt.selectDealer(resultDirectory, checkSalesPopin);
			bkt.fillOfferSection(resultDirectory, checkSalesPopin, email, phone);
			bkt.clickCopyLink(resultDirectory, checkSalesPopin);
			Thread.sleep(10000);
			bkt.acceptCookieUsingRobot(resultDirectory, checkSalesPopin);
			Thread.sleep(1000);
			bkt.openNewTab(driver);
			Thread.sleep(500);
			driver.close();
			Thread.sleep(2000);
			ArrayList<String> allTabs = new ArrayList<String>(driver.getWindowHandles());
			System.out.println("Switching to current tab");
			driver.switchTo().window(allTabs.get(0));
			Thread.sleep(5000);
			//https://psa-retail11-peugeot-preprod.summit-automotive.solutions/digital-api/redirect/basket/e74af93d-3389-4a6d-a1be-9bd0ae5a08d5
			bkt.clickPasteUsingRobot(resultDirectory, checkSalesPopin);
			waitForUrlContains("/basket",driver,15);
			String url = driver.getCurrentUrl();
            if (url.contains("/basket")) {
            	checkSalesPopin.log(Status.PASS, "Basket page is displayed after Sales popin");
            } else {
                failWithScreenshot("Basket page is not displayed after Sales popin", resultDirectory, driver, extent, checkSalesPopin);
            }
		}catch(Exception e) {
			failWithScreenshot("Test failed while checking Sales popin", resultDirectory, driver, extent, checkSalesPopin);
			checkSalesPopin.log(Status.FAIL, String.valueOf(e.getStackTrace()));
		}
	}
	public static void checkPxEnabledSwitch(String resultDirectory, WebDriver driver, ExtentReports extent,ExtentTest logger){
		ExtentTest CheckPxEnabledSwitch = extentBP.createNode("CheckPxEnabledSwitch", "Check PxEnabled Switch ");
		BasketPage bkt = new BasketPage(driver);
		try{
			bkt.clickOpenSwitches(resultDirectory,CheckPxEnabledSwitch);
			Thread.sleep(1000);
			String window= driver.getWindowHandle();
			driver.switchTo().window(window);
			Boolean b=bkt.checkPxEnabled(resultDirectory,CheckPxEnabledSwitch);
			if(b){
				CheckPxEnabledSwitch.log(Status.PASS,"pxEnabled switch is true");
			} else{
				CheckPxEnabledSwitch.log(Status.FAIL,"pxEnabled switch is false");
			}
			bkt.clickCloseButton(resultDirectory,CheckPxEnabledSwitch);
			window= driver.getWindowHandle();
			driver.switchTo().window(window);
		} catch (Exception e){
			e.printStackTrace();
		}
	}
}
