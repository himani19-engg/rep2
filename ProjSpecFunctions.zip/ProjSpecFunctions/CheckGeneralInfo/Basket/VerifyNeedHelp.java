package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class VerifyNeedHelp extends UniversalMethods {

	public static ExtentTest checkNeedHelpText;

	@Test(description = "Need Help Details")
	public static void needHelpDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String Country, String brand, String EmailId, String Name, String Phone, String Address)
			throws Exception {
		checkNeedHelpText = extentBP.createNode("CheckNeedHelpText","Checking need help details");
		HomePage HP = new HomePage(driver);
		SoftAssert sa = new SoftAssert();
		try {
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			// scroll to the top
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//Thread.sleep(500);

			System.out.println("Clicked on Need Help Button");
			HP.clickonNeedHelp(resultDirectory,checkNeedHelpText);
			String needHelpText = "";
			String faqText = "";
			checkNeedHelpText.log(Status.INFO,"Click on Need Help Button");
		//	logger.log(Status.INFO, MarkupHelper.createLabel("Click on Need Help Button", ExtentColor.BLUE));

			if (Country.equals("FR")) {
				needHelpText = HP.getNeedHelpText(resultDirectory,checkNeedHelpText);
				System.out.println("************************" + needHelpText);
				if (needHelpText.contains("Contactez-nous")
						|| needHelpText.contains("Besoin d'aide ?")) {
					checkNeedHelpText.log(Status.PASS,"Need Help Text Correct - "+needHelpText);
		//			logger.log(Status.PASS, MarkupHelper.createLabel("Need Help Text Correct - "+needHelpText, ExtentColor.GREEN));
				} else {
					failWithScreenshot("Need Help Text not Correct - "+needHelpText, resultDirectory, driver, extent, checkNeedHelpText);
					//driver.quit();
				}

				faqText = HP.getFAQText(Country,resultDirectory,checkNeedHelpText);
				if(!brand.equals("AP")) {
					if (faqText.equals("CONSULTEZ LA FAQ")
							|| faqText.equalsIgnoreCase("Consultez la FAQ")
							|| faqText.equalsIgnoreCase("Consult our FAQ")
							|| faqText.equals("PAR FORMULAIRE :")) {
						checkNeedHelpText.log(Status.PASS,"FAQ Text Correct - "+faqText);
						sa.assertTrue(true);
					} else {
						failWithScreenshot("FAQ Text not Correct - "+faqText, resultDirectory, driver, extent, checkNeedHelpText);
						sa.assertTrue(false, "FAQ Text not Correct");
					}
				}
			}

			else if (Country.equals("UK")) {

				System.out.println(">>>>>>>>" + HP.getNeedHelpText(resultDirectory,checkNeedHelpText));
				if (HP.getNeedHelpText(resultDirectory,checkNeedHelpText).equals("TESTING_NEED-HELP")
						|| HP.getNeedHelpText(resultDirectory,checkNeedHelpText).equalsIgnoreCase("NEED HELP")
						|| HP.getNeedHelpText(resultDirectory,checkNeedHelpText).equals("NEED HELP?")) {
					checkNeedHelpText.log(Status.PASS,"Need Help Text Correct");
		//			logger.log(Status.PASS, MarkupHelper.createLabel("Need Help Text Correct", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					failWithScreenshot("Need Help Text not Correct", resultDirectory, driver, extent, checkNeedHelpText);
					sa.assertTrue(false, "Need Help Text not Correct");
					//driver.quit();

				}
				System.out.println(">>>>>>>>" + HP.getFAQText(Country,resultDirectory,checkNeedHelpText));
				faqText = HP.getFAQText(Country,resultDirectory,checkNeedHelpText);
				if (faqText.equalsIgnoreCase("Check FAQS")
						|| faqText.equals("CONSULT THE FAQ")
						|| faqText.equals("SEE FAQ'S BELOW")
						|| faqText.equals("CONSULT THE FAQ"))

				{
					checkNeedHelpText.log(Status.PASS,"FAQ Text Correct -"+faqText);
		//			logger.log(Status.PASS, MarkupHelper.createLabel("FAQ Text Correct", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					failWithScreenshot("Need Help Text not Correct", resultDirectory, driver, extent, checkNeedHelpText);
					sa.assertTrue(false, "Need Help Text not Correct");
					//driver.quit();
				}
			} else if (Country.equals("ES")) {
				needHelpText = HP.getNeedHelpText(resultDirectory,checkNeedHelpText);
				System.out.println(">>>>>>>>" + needHelpText);
				if ((needHelpText.equalsIgnoreCase("¿Necesitas Ayuda?"))
						|| (needHelpText.equalsIgnoreCase("¿NECESITAS AYUDA?"))
						|| (needHelpText.equalsIgnoreCase("¿Necesita Ayuda?"))
						|| (needHelpText.equalsIgnoreCase("¿Necesitas Ayuda?"))
						|| (needHelpText.equalsIgnoreCase("¿NECESITA AYUDA?"))){
					checkNeedHelpText.log(Status.PASS,"Need Help text correct - "+needHelpText);
			//		logger.log(Status.PASS, MarkupHelper.createLabel("Need Help text correct - "+needHelpText, ExtentColor.GREEN));
					//sa.assertTrue(true);
				} else {
					failWithScreenshot("Need Help Text not Correct "+needHelpText, resultDirectory, driver, extent, checkNeedHelpText);
					//sa.assertTrue(false, "Need Help Text not Correct");
					//driver.quit();
				}
				
				faqText = HP.getFAQText(Country,resultDirectory,checkNeedHelpText);
				System.out.println(">>>>>>>>" + faqText);
				if (faqText.equals("Consulta nuestras preguntas frecuentes")
						|| faqText.equalsIgnoreCase("CONSULTA NUESTRAS PREGUNTAS FRECUENTES")
						|| faqText.equalsIgnoreCase("Consulte nuestras preguntas frecuentes")
						|| faqText.equalsIgnoreCase("CONSULTE NUESTRAS PREGUNTAS FRECUENTES")
						|| faqText.equalsIgnoreCase("Consulta las preguntas frecuentes")
						|| faqText.equalsIgnoreCase("Consulte las preguntas frecuentes")
						|| faqText.equalsIgnoreCase("Consulta Nuestras Preguntas Frecuentes")
						|| faqText.equalsIgnoreCase("Consult our FAQ"))
				{
					checkNeedHelpText.log(Status.PASS,"FAQ text correct - "+faqText);
		//			logger.log(Status.PASS, MarkupHelper.createLabel("FAQ text correct - "+faqText, ExtentColor.GREEN));
					//sa.assertTrue(true);
				} else {
					failWithScreenshot("FAQ text not correct - "+faqText, resultDirectory, driver, extent, checkNeedHelpText);
					//sa.assertTrue(false, "FAQ Text not Correct");
				}
			}

			System.out.println("Clicked on FAQ Button");
			checkNeedHelpText.log(Status.INFO,"Click on FAQ Button");
	//		logger.log(Status.INFO, MarkupHelper.createLabel("Click on FAQ Button", ExtentColor.BLUE));
			HP.clickonFAQButton(Country,resultDirectory,checkNeedHelpText);

			//System.out.println("URL contains FAQ");

			//waitForUrlContains("faqs", driver, 30);
			//System.out.println(driver.getCurrentUrl());

			/*if (driver.getCurrentUrl().contains("faqs")) {
				logger.log(Status.PASS, MarkupHelper.createLabel("URL is correct", ExtentColor.GREEN));
				sa.assertTrue(true);

			} else {
				failWithScreenshot("URL is not Correct", resultDirectory, driver, extent, logger);
				sa.assertTrue(false, "URL is not Correct");
			}*/
			//Thread.sleep(1000);
			sa.assertAll();
		} catch (Exception e1) {
			checkNeedHelpText.log(Status.FAIL,"Test Failed while verifying  Need Help Details");
			failWithScreenshot("Test Failed while verifying  Need Help Details", resultDirectory, driver, extent, checkNeedHelpText);
			//checkNeedHelpText.log(Status.FAIL, String.valueOf(e1.getStackTrace()));
		}
	}
}
