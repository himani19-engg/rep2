package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.TrimPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckNotificationForm extends UniversalMethods {
public static ExtentTest notificationForm;
	@Test(description = "To fill notification form on Trim page")
	public static void fillNotificationFormOnTrim(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country, String postalCode, String emailId,
			String name, String phone, String address) throws Exception {
		notificationForm = extentTP.createNode("CheckNotificationForm", "Check notification form");
		try {
			TrimPage trimPage = new TrimPage(driver);

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//Thread.sleep(5500);
			//trimPage.fillNotificationForm(brand, country, postalCode, emailId, name, phone, address);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Notification Form filled", ExtentColor.BLUE));
			notificationForm.log(Status.INFO, "Notification Form filled");

		} catch (Exception e) {
			/*failWithScreenshot("Test Failed Test Failed in notification form on Trim page", resultDirectory, driver, extent, notificationForm);
			notificationForm.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
			catchFailDetails(resultDirectory, notificationForm,driver, "Test Failed Test Failed in notification form on Trim page",e);
		}
	}
}
