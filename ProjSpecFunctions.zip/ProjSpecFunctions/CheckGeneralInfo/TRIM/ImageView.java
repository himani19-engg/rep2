package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.PageObjectModel.TrimPage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ImageView extends UniversalMethods {

    @Test(description = "Config Page Image Link")
    public static void trimPageImageLink(String resultDirectory, WebDriver driver, ExtentReports extent,
                                         ExtentTest logger, String Brand, String Country) throws Exception {
        ExtentTest imageCheckOnConfigPage = extentTP.createNode("ImageCheckOnTrimPage", "Check image on Trim page");
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            ConfigPage CP = new ConfigPage(driver);

            // Click On Exterior image
            CP.scrollToTop(driver);
            CP.clickExteriorImage(resultDirectory, imageCheckOnConfigPage);
            System.out.println("Here is the link title ::::");
            //logger.log(Status.INFO, MarkupHelper.createLabel("Exterior image link is clicked", ExtentColor.BLUE));
            //imageCheckOnConfigPage.log(Status.INFO, "Exterior image link is clicked");
            //logger.log(Status.INFO, "Exterior image link is clicked");
            Thread.sleep(1000);
            for (int i = 1; i <= 5; i++) {
                CP.clickonNextSlideArrow(resultDirectory, imageCheckOnConfigPage);
                Thread.sleep(1000);
            }

            System.out.println("click to slide arrow");
            imageCheckOnConfigPage.log(Status.INFO, "Next slide arrow button clicked");

            // Click on Interior image
            CP.clickInteriorImage(resultDirectory, imageCheckOnConfigPage);
            System.out.println("Here is the interior link title ::::");
            imageCheckOnConfigPage.log(Status.INFO, "Interior image link is clicked");
            //Thread.sleep(5000);
            for (int i = 1; i <= 5; i++) {
                CP.clickonNextSlideArrow(resultDirectory, imageCheckOnConfigPage);
                Thread.sleep(1000);
            }
            System.out.println("click to slide arrow");
            //imageCheckOnConfigPage.log(Status.INFO, "Next slide arrow button clicked");
            //new TrimPage(driver).clickLogoLink(resultDirectory, imageCheckOnConfigPage);

        } catch (Exception e) {
		/*failWithScreenshot("Test Failed", resultDirectory, driver, extent, imageCheckOnConfigPage);
		imageCheckOnConfigPage.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            catchFailDetails(resultDirectory, imageCheckOnConfigPage, driver, "Test failed- Config Page Image Link", e);
        }
    }
}
