package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.TrimPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class TrimPageChecks extends UniversalMethods {

	public boolean validateTrimFeatureSwitch(WebDriver driver,String resultDirectory)
			throws InterruptedException {
		ExtentTest checkTriminSwitch = extentTP.createNode("Check TrimPage Switch", "Checking Trim Page Switch");
		TrimPage trim=new TrimPage(driver);
		boolean bool=false;
		try {
			Thread.sleep(2000);
			trim.clickOpenFeatureSwitch(resultDirectory,checkTriminSwitch);
			Thread.sleep(5000);
			trim.waitForSwitch(resultDirectory,checkTriminSwitch);
			Thread.sleep(800);
			String window= driver.getWindowHandle();
			driver.switchTo().window(window);
			List<WebElement> allswitches = trim.listofAllFeatureSwitchElements(resultDirectory,checkTriminSwitch);
			for (WebElement ele : allswitches
			) {
				trim.waitForSwitch(resultDirectory,checkTriminSwitch);
				System.out.println("Current Text: " + ele.getText());
				if (ele.getText().contains("configurable trim page version")) {
					System.out.println("configurable trim page version label is present");
					checkTriminSwitch.log(Status.PASS, "configurable trim page version label is present");
						if (ele.getText().contains("v2")) {
							System.out.println("is configurable trim page version contains v2");
							checkTriminSwitch.log(Status.PASS, "is configurable trim page version contains v2");
							bool=true;
							break;
						}else{
							bool=false;
							System.err.println("is configurable trim page version does not contain v2");
							checkTriminSwitch.log(Status.FAIL, "is configurable trim page version does not contain v2");
						}
				}
			}
			trim.closeModelWindow(resultDirectory,checkTriminSwitch);
		} catch (Exception e) {
			e.printStackTrace();
			catchFailDetails(resultDirectory, checkTriminSwitch, driver, "Unable to verify Trim V2 switch", e);
		}
		return bool;
	}
	@Test(description = "Checking Trim Page Objects")
	public void checkPageObjects(String resultDirectory, WebDriver driver, ExtentReports extent, String Country, String Brand, String PaymentMode) throws Exception {
		ExtentTest checkTrimObjects = extentTP.createNode("Check_TrimPage_Objects", "Checking Trim Page Objects");
		TrimPage trim = new TrimPage(driver);
		float trimCashPrice = 0;
		float trimMonthlyPrice = 0;
		float stickyTrimCashPrice = 0;
		float stickyTrimMonthlyPrice = 0;
		trim.validateCatalogFromText(resultDirectory, checkTrimObjects);
		trim.validateTopContBtn(resultDirectory, checkTrimObjects);
		trim.validateContactSalesman(resultDirectory, checkTrimObjects, extent);
		trim.validateSubTitle(resultDirectory, checkTrimObjects, extent);
		trim.validateTrimTitle(resultDirectory, checkTrimObjects, extent);
		trim.verifyDefaultSelectedTrim(resultDirectory, checkTrimObjects, extent);
		trim.validateNoOfTrims(resultDirectory, checkTrimObjects, extent);
		int vehicleVersionFin = 0;
		for (int i = 1; i <= trim.getNoOfTrims(resultDirectory, checkTrimObjects); i++) {
			trim.validateIndividualTrimTitle(i-1, resultDirectory, checkTrimObjects, extent);
			trim.validateIndividualTrimContentTitle(i-1, resultDirectory, checkTrimObjects, extent);
			trim.validateIndividualTrimDescription(i-1, resultDirectory, checkTrimObjects, extent);
			trimCashPrice = trim.validateIndividualTrimCashPrice(i-1, resultDirectory, checkTrimObjects, extent, Country, Brand);
			if(PaymentMode.equalsIgnoreCase("Finance")){
				trimMonthlyPrice = trim.validateIndividualTrimMonthlyPrice(i-1, resultDirectory, checkTrimObjects, extent);
			}
			stickyTrimCashPrice = trim.validateStickyBarCashPrice(resultDirectory, checkTrimObjects, extent);
			if(PaymentMode.equalsIgnoreCase("Finance")){
				stickyTrimMonthlyPrice = trim.validateStickyBarMonthlyPrice(stickyTrimMonthlyPrice, resultDirectory, checkTrimObjects, extent);
			}
			trim.validateTrimCashPrice(resultDirectory, checkTrimObjects, stickyTrimCashPrice, trimCashPrice);
			if(PaymentMode.equalsIgnoreCase("Finance")){
				trim.validateTrimMonthlyPrice(resultDirectory, checkTrimObjects, stickyTrimMonthlyPrice, trimMonthlyPrice);
			}
		}
		trim.validateLinkSectionTitle(resultDirectory, checkTrimObjects, extent);
		//trim.validateLinkSectionElements(resultDirectory, checkTrimObjects, extent);
		trim.validateLinkSectionByPhone(resultDirectory, checkTrimObjects, extent);
		trim.validateContactYourAdvisor(resultDirectory, checkTrimObjects, extent);
		trim.validateOfferPaymentModelTexts(resultDirectory, checkTrimObjects, extent);
		trim.validateBottomContBtn(resultDirectory, checkTrimObjects);
	}

	@Test(description = "Checking main equipments")
	public void checkMainEquipments(String resultDirectory, WebDriver driver, ExtentReports extent) throws Exception {
		ExtentTest mainEquipments = extentTP.createNode("Check_TrimPage_MainEquipments", "Checking Main Equipments on Trim Page");
		TrimPage trim = new TrimPage(driver);
		trim.validateAndClickseeTheMainEquipmentLink(resultDirectory,mainEquipments);
		trim.validateModelHeader(resultDirectory,mainEquipments);
		trim.validateModelTitle(resultDirectory,mainEquipments);
		trim.validateKeyTitle(resultDirectory,mainEquipments);
		trim.validateCategories(resultDirectory,mainEquipments);
		trim.validateEngineLabel(resultDirectory,mainEquipments);
		trim.validateEngineConfiguration(resultDirectory,mainEquipments);
		trim.validateMainEquipmentLabel(resultDirectory,mainEquipments);
		trim.validateMainEquipmentConfiguration(resultDirectory,mainEquipments);
		trim.validateColorsLabel(resultDirectory,mainEquipments);
		trim.validateColorsConfiguration(resultDirectory,mainEquipments);
		trim.validateInteriorLabel(resultDirectory,mainEquipments);
		trim.validateInteriorConfiguration(resultDirectory,mainEquipments);

	}

	@Test(description = "Checking standard equipments")
	public void checkStandardEquipments(String resultDirectory, WebDriver driver, ExtentReports extent) throws Exception {
		ExtentTest mainEquipments = extentTP.createNode("Check_TrimPage_StandardEquipments", "Checking Standard Equipments on Trim Page");
		TrimPage trim = new TrimPage(driver);
		trim.validateStandardEquipmentTitle(resultDirectory,mainEquipments);
		trim.validateStandardEquipmentDescription(resultDirectory,mainEquipments);
		trim.validateStandardEquipmentCategories(resultDirectory,mainEquipments);
		trim.validateComfortLabel(resultDirectory,mainEquipments);
		trim.validateComfortConfiguration(resultDirectory,mainEquipments);
		trim.validatesecurityLabel(resultDirectory,mainEquipments);
		trim.validateSecurityConfiguration(resultDirectory,mainEquipments);
		trim.validateAestheticLabel(resultDirectory,mainEquipments);
		trim.validateAestheticConfiguration(resultDirectory,mainEquipments);
		trim.validateAudioCommunicationLabel(resultDirectory,mainEquipments);
		trim.validateAudioCommunicationConfiguration(resultDirectory,mainEquipments);
		trim.validateRimsLabel(resultDirectory,mainEquipments);
		trim.validateRimsConfiguration(resultDirectory,mainEquipments);
		trim.closeModel(resultDirectory,mainEquipments);
	}

	@Test(description = "Checking Range")
	public static void verifySetRange(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String country, String brand) throws Exception {
		ExtentTest checkRange = extentTP.createNode("Check_TrimPage_Budget", "Checking Price Range");
		try {
			driver.manage().timeouts().implicitlyWait(7,TimeUnit.SECONDS) ;
			TrimPage trim = new TrimPage(driver);
			Thread.sleep(3000);
			//trim.clickFilter(resultDirectory,checkRange);
			trim.clickFilterButton(resultDirectory,checkRange);
			//Thread.sleep(2000);
			trim.adjustRange(resultDirectory,checkRange);
			//Thread.sleep(3000);
			Float startPrice = trim.getRangeStartPrice(resultDirectory,checkRange);
			Float endPrice = trim.getRangeEndPrice(resultDirectory,checkRange);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Start range price is " + startPrice, ExtentColor.BLUE));
			//checkRange.log(Status.INFO, "Start range price is " + startPrice);
			//logger.log(Status.INFO, MarkupHelper.createLabel("End range price is " + endPrice, ExtentColor.BLUE));
			//checkRange.log(Status.INFO, "End range price is " + endPrice);
			trim.clickValidate(resultDirectory,checkRange);
			//Thread.sleep(2000);
			System.out.println("StartPrice : "+startPrice);
			System.out.println("EndPrice : "+endPrice);
			//Long cashPrice = (long) extractNumericFromString(trim.getCashPrice(resultDirectory,checkRange));
			String cashPriceOnTrimPage=trim.getCashPrice(resultDirectory,checkRange).replace(",",".");
			Float cashPrice = extractFloatFromString(cashPriceOnTrimPage);

			if (cashPrice <= endPrice && cashPrice >= startPrice) {
				checkRange.log(Status.PASS, "Cash price "+cashPrice+" is displayed correctly");
			}else {
				checkRange.log(Status.FAIL, "Cash price "+cashPrice+" is not displayed correctly ");
				failWithScreenshot("Cash price "+cashPrice+" is not displayed correctly", resultDirectory, driver, extent, checkRange);
			}
			//trim.clickFilter(resultDirectory,checkRange);
			trim.clickFilterButton(resultDirectory,checkRange);
			Thread.sleep(2000);
			trim.clickReset(resultDirectory,checkRange);
			Thread.sleep(3000);
			//checkRange.log(Status.INFO, "Price range is reset");
		} catch (Exception e1) {
			e1.printStackTrace();
			catchFailDetails(resultDirectory, checkRange,driver, "Test Failed in Trim page set range",e1);
		}

	}
	
	/*public static void checkRetourButton(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String country, String brand) throws Exception {
		TrimPage trim = new TrimPage(driver);
		HomePage homePage = new HomePage(driver);
		try {
			trim.clickRetourBtn();
			logger.log(Status.INFO, MarkupHelper.createLabel("Clicked Retour button", ExtentColor.BLUE));
			if(homePage.checkHomePageIsDisplayed()) {
				logger.log(Status.PASS, MarkupHelper.createLabel("Homepage is displayed after clicking Retour button", ExtentColor.GREEN));
			}else {
				logger.log(Status.FAIL, MarkupHelper.createLabel("Homepage is not displayed after clicking Retour button", ExtentColor.GREEN));
				failWithScreenshot("Homepage is not displayed after clicking Retour button", resultDirectory, driver, extent, logger);
			}
			ChooseCarCashNonEc41.chooseCarModel(resultDirectory, driver, extent, logger, brand, country);
		}catch (Exception e1) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Error with Retour Button", ExtentColor.BLUE));
			e1.printStackTrace();
		}
		
	}*/
	
	public static void checkLegalText(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String country, String brand) throws Exception {
		TrimPage trim = new TrimPage(driver);
		String text = null;
		ExtentTest legal = extentTP.createNode("CheckLegalText","Check legal text");
		try {
			text = trim.getLegalText(resultDirectory,legal);
			if(text.contains("Prix internet conseill")) {
				legal.log(Status.PASS, "Legal text is displayed on Trim page");
			}else {
				failWithScreenshot("Legal text is not displayed on Trim page. It is showing as: "+text, resultDirectory, driver, extent, legal);
			}
		}catch (Exception e1) {
			catchFailDetails(resultDirectory, legal,driver, "Error with Legal text on Trim page",e1);
		}
		
	}
	public  static  void validatePrices(String resultDirectory, WebDriver driver, ExtentReports extent, String Country, String Brand, String PaymentMode){
		ExtentTest checkTrimPagePrice = extentTP.createNode("Compare TrimPage Prices and Home Page Prices", "Checking Trim Page Switch");
		try{
			float homePageCashPrice=Float.parseFloat(readFromProperties("currentCashPrice"));
			float trimPageCashPrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_SELECTOR_CASH_PRICE']/span[1]")).replace(",","."));
			if (trimPageCashPrice-homePageCashPrice<1){
				checkTrimPagePrice.log(Status.PASS,"Home Page cash price "+homePageCashPrice+" is same as Trim Page cash price");
			} else{
				checkTrimPagePrice.log(Status.FAIL,"Home Page cash price "+homePageCashPrice+" is not same as Trim Page cash price "+trimPageCashPrice);
			}
			if(PaymentMode.equalsIgnoreCase("Finance")){
				float homePageFinancePrice=Float.parseFloat(readFromProperties("currentFinanceprice"));
				float trimPageFinancePrice=extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_SELECTOR_FINANCE_PRICE']/span[1]/span[1]")).replace(",","."));
				if(trimPageFinancePrice-homePageFinancePrice<1){
					checkTrimPagePrice.log(Status.PASS,"Home Page finance price "+homePageFinancePrice+" is same as Trim Page finanace price");
				} else{
					checkTrimPagePrice.log(Status.FAIL,"Home Page finance price "+homePageFinancePrice+" is not same as Trim Page finance price");
				}
			}
		} catch (Exception e){
			e.printStackTrace();
		}
	}
}