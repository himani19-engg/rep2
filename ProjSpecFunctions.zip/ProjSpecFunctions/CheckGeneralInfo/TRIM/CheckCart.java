package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckCart extends UniversalMethods {
	
	public static ExtentTest cartCheck;

	@Test(description = "Cart Details")
	public static void checkCartDetails(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Country, String EmailId, String Name, String Phone, String Address) throws Exception {
		SoftAssert sa = new SoftAssert();
		try {
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS) ;
			cartCheck = extentTP.createNode("CartCheck", "Checking cart");
			// scroll to the top
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//Thread.sleep(1000);

			HomePage HP = new HomePage(driver);

			HP.clickonCartIcon(Country,resultDirectory,cartCheck);
			//cartCheck.log(Status.INFO, "Click on Cart Icon");

			if (Country.equals("FR")) {
				System.out.println("************************" + HP.GetCartEmptyText(Country,resultDirectory,cartCheck));
				if (HP.GetCartEmptyText(Country,resultDirectory,cartCheck).contains("Votre panier est vide")) {
					cartCheck.log(Status.PASS, "The cart empty message is correct");
					//logger.log(Status.PASS, MarkupHelper.createLabel("The cart empty message is correct", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					cartCheck.log(Status.FAIL, "The cart empty message is not correct");
					//failWithScreenshot("The cart empty message is not correct", resultDirectory, driver, extent, logger);
					sa.assertTrue(false, "The cart empty message is not correct");
				}
			}

			else if (Country.equals("UK")) {

				System.out.println(">>>>>>>>" + HP.GetCartEmptyText(Country,resultDirectory,cartCheck));
				if (HP.GetCartEmptyText(Country,resultDirectory,cartCheck).equals("Your basket is empty")) {
					cartCheck.log(Status.PASS, "The cart empty message is correct");
					//logger.log(Status.PASS, MarkupHelper.createLabel("The cart empty message is correct", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					cartCheck.log(Status.FAIL, "The cart empty message is not correct");
					//failWithScreenshot("The cart empty message is not correct", resultDirectory, driver, extent, logger);
					sa.assertTrue(false, "The cart empty message is not correct");
				}
			}

			else if (Country.equals("ES")) {

				System.out.println(">>>>>>>>" + HP.GetCartEmptyText(Country,resultDirectory,cartCheck));
				if ((HP.GetCartEmptyText(Country,resultDirectory,cartCheck).equals("Tu cesta esta vacia"))
						|| (HP.GetCartEmptyText(Country,resultDirectory,cartCheck).equals("Su cesta esta vacía"))) {
					cartCheck.log(Status.PASS, "The cart empty message is correct");
					//logger.log(Status.PASS, MarkupHelper.createLabel("The cart empty message is correct", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					cartCheck.log(Status.FAIL, "The cart empty message is not correct");
					//failWithScreenshot("The cart empty message is not correct", resultDirectory, driver, extent, logger);
					sa.assertTrue(false, "The cart empty message is not correct");
				}
			}

			HP.clickonChooseMycar(Country,resultDirectory,cartCheck);
			//cartCheck.log(Status.INFO, "Click on choose car Button");
			//Thread.sleep(2000);
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>" + driver.getCurrentUrl());
			waitForUrlContains("configurable", driver, 20);
			cartCheck.log(Status.INFO, "Home page has appeared");
			//sa.assertAll();
		} catch (Exception e1) {
			cartCheck.log(Status.FAIL,"Issue with Cart");
			failWithScreenshot("Issue with Cart", resultDirectory, driver, extent, cartCheck);
			cartCheck.log(Status.FAIL, String.valueOf(e1.getStackTrace()));
		}
	}

}
