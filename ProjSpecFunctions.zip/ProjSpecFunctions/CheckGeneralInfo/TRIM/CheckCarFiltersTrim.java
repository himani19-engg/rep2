package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;

import java.net.URLDecoder;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.TrimPage;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckCarFilters;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckCarFiltersTrim extends UniversalMethods {

    @Test(description = "Filter Check")
    public static void FilterCheck(String resultDirectory,
                                   WebDriver driver,
                                   ExtentReports extent,
                                   ExtentTest logger,
                                   String Brand, String country) throws Exception {

        CheckCarFilters.filterCheck(resultDirectory, driver, extent, logger, Brand, country);
    }

    public static void checkEnergyFilter(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                         String Brand, String country) throws Exception {
        String energy ;
        String url;
        ExtentTest checkFilter = extentTP.createNode("Check Energy filter", "Checking energy filter");
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS) ;
            TrimPage trimPage = new TrimPage(driver);
            // trimPage.clickFilter(resultDirectory,checkFilter);
            trimPage.clickFilterButton(resultDirectory,checkFilter);
            energy = trimPage.getEnergyText(resultDirectory,checkFilter);
            System.out.println("Energy :" + energy);
            trimPage.selectEnergyFilter(resultDirectory,checkFilter);
            trimPage.clickValidate(resultDirectory,checkFilter);
            checkFilter.log(Status.INFO, "Select energy filter and click Validate");
            Thread.sleep(2000);
            //url = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8").replaceAll(" ", "+");
            url = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8");
            System.out.println("URL : " + url);
            Thread.sleep(3000);
            if ((url.toLowerCase()).contains(energy.toLowerCase())) {
                checkFilter.log(Status.PASS, "The URL contains energy filter " + energy);
                Assert.assertTrue(true);
            } else {
                failWithScreenshot("The URL doesn't contain energy filter " + energy + "", resultDirectory, driver, extent,
                        checkFilter);
            }

            //trimPage.clickFilter(resultDirectory,checkFilter);
            trimPage.clickFilterButton(resultDirectory,checkFilter);
            trimPage.clickReset(resultDirectory,checkFilter);
            trimPage.clickValidate(resultDirectory,checkFilter);
            waitForUrlNotContains("?", driver, 20);

            if (!driver.getCurrentUrl().contains("?")) {
                checkFilter.log(Status.PASS, "The URL doesn't contain any filter value after reset");
                Assert.assertTrue(true);
            } else {
                checkFilter.log(Status.FAIL, "The URL contains any filter value after reset");
                failWithScreenshot("The URL contains filter value after reset", resultDirectory, driver, extent, checkFilter);
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, checkFilter,driver, "Test Failed in energy filter on Trim page",e);
        }
    }

    public static void checkGearboxFilter(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                          String Brand, String country) throws Exception {
        String gearBox = null;
        String url = null;
        ExtentTest checkFilter = extentTP.createNode("Check GearBox filter", "Checking gearbox filter");
        try {
            driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
            TrimPage trimPage = new TrimPage(driver);
           // trimPage.clickFilter(resultDirectory,checkFilter);
            trimPage.clickFilterButton(resultDirectory,checkFilter);
            gearBox = trimPage.getGearText(resultDirectory,checkFilter);
            System.out.println("Gear :" + gearBox);
            trimPage.selectGearFilter(resultDirectory,checkFilter);
            trimPage.clickValidate(resultDirectory,checkFilter);
            checkFilter.log(Status.INFO, "Select gearBox filter and click Validate");
            Thread.sleep(5000);

            //url = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8").replaceAll(" ", "+");
            //waitForUrlContains("-es-sol.psa-testing.drivvn.tech/",driver,10);
            //waitForUrlContains(gearBox.toLowerCase().substring(0,3),driver,10);
            url = URLDecoder.decode(driver.getCurrentUrl(), "UTF-8");
            //url = driver.getCurrentUrl();
            System.out.println("URL : " + url);
            //.substring(0,3)
            if ((url.toLowerCase()).contains(gearBox.toLowerCase())) {
                checkFilter.log(Status.PASS, "The URL contains gearBox filter " + gearBox);
                Assert.assertTrue(true);
            } else {
                //checkFilter.log(Status.FAIL, "The URL doesn't contain gearBox filter" + gearBox + "");
                failWithScreenshot("The URL doesn't contain gearBox filter " + gearBox + "", resultDirectory, driver,
                        checkFilter);
                //Assert.assertTrue(false, "The URL doesn't contain gearBox filter" + gearBox);
            }

            //trimPage.clickFilter(resultDirectory,checkFilter);
            trimPage.clickFilterButton(resultDirectory,checkFilter);
            trimPage.clickReset(resultDirectory,checkFilter);
            trimPage.clickValidate(resultDirectory,checkFilter);
            //Thread.sleep(3000);
            waitForUrlNotContains("?", driver, 60);

            //driver.navigate().refresh();
            //Thread.sleep(3000);
        } catch (Exception e) {
            /*failWithScreenshot("Test Failed in gearBox filter on Trim page", resultDirectory, driver, extent, checkFilter);
            checkFilter.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            catchFailDetails(resultDirectory, checkFilter,driver, "Test Failed in gearBox filter on Trim page",e);
        }
    }

    public static void checkVehicleAsPerFilter(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                               String brand, String country, String filter) throws Exception {
        TrimPage trimPage = new TrimPage(driver);
        String vehicleSubtitle = "";
        String vehicleState = "";
        int noOfVehicles = 0;
        try {
            noOfVehicles = trimPage.getNoOfVehicles(resultDirectory,logger);
            System.out.println("Vehicles : " + noOfVehicles);
            System.out.println("filter : " + filter);
            for (int i = 1; i <= noOfVehicles; i++) {
                if (i > 3) {
                    trimPage.clickOnNext();
                    Thread.sleep(500);
                }
                System.out.println("Value of i " + i);
                vehicleSubtitle = trimPage.getVehicleSubtitle(i,resultDirectory,logger).toLowerCase();
                System.out.println("vehicleSubtitle : " + vehicleSubtitle);
                vehicleState = trimPage.getVehicleEnabledOrDisabled(i,resultDirectory,logger).toLowerCase();
                if (vehicleSubtitle.contains(filter)) {
                    if (vehicleState.contains("enabled")) {
                        logger.log(Status.PASS,
                                MarkupHelper.createLabel("Vehicle is enabled for filter : " + filter + "", ExtentColor.GREEN));
                    } else {
                        failWithScreenshot("Vehicle is disabled for filter : " + filter + "", resultDirectory, driver, extent, logger);
                    }
                } else {
                    if (vehicleState.contains("disabled")) {
                        logger.log(Status.PASS,
                                MarkupHelper.createLabel("Vehicle is disabled for filter : " + filter + "", ExtentColor.GREEN));
                    } else {
                        failWithScreenshot("Vehicle is enabled for filter : " + filter + "", resultDirectory, driver, extent, logger);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
