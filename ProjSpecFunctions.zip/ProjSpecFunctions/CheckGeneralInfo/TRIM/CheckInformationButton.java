package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.TrimPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckInformationButton extends UniversalMethods {
public static ExtentTest checkInfo;
    @Test(description = "Checking Info")
    public static void CheckInfo(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                 String Brand, String Country) {
        String financialPrice = null;
        String financialPriceInfoPage = null;
        SoftAssert sa = new SoftAssert();
        checkInfo = extentTP.createNode("CheckInfo","Checking Information");
        try {

            TrimPage TP = new TrimPage(driver);
            String cashPrice = "";
            String entradaPrice = "";
            String promotionalText = "";
            String cashPriceInfoPopup = "";
            String entradaPriceInfoPopup = "";
            String TAEInfoPopup = "";
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            int size = TP.getCarsList(Country,resultDirectory, checkInfo).size();
            System.out.println("*************<<<<<<<>>>>>>>" + size);

            int cpt = 0;
            for (int i = 1; i < size; i++) {
                //System.out.println("Car price ::::::::::" + TP.getPriceText(i + 1));

                if (i > 3) {
                    //TP.clickOnNext();
                    Thread.sleep(2000);
                    break;
                }

                if (!Country.equals("UK")) {

                    if (TP.getPriceText(i,resultDirectory,checkInfo).contains("/mois") || TP.getPriceText(i,resultDirectory,checkInfo).contains("/MOIS")
                            || TP.getPriceText(i,resultDirectory,checkInfo).contains("/MES") || TP.getPriceText(i,resultDirectory,checkInfo).contains("/mes")) {
                        financialPrice = TP.getFinantialPriceTrim(i - cpt,resultDirectory,checkInfo).replaceAll(" ", "");
                        System.out.println("the Financial price is:" + financialPrice);
                        cashPrice = TP.getCashPrice(i,resultDirectory,checkInfo);
                        entradaPrice = TP.getEntradaPrice(i,resultDirectory, checkInfo);
                        if (Country.equals("ES")) {
                            promotionalText = TP.getPromotionalText(i,resultDirectory,checkInfo);
                        }
                        financialPriceInfoPage = "";
                        financialPriceInfoPage = TP.getFinantialPriceTrimInfoPage(i - cpt, Country,resultDirectory, checkInfo).replaceAll(" ", "");
                        System.out.println("the Financial price info Page is:" + financialPriceInfoPage);
                        //Thread.sleep(2000);
                        Integer financialPriceInfo = extractNumericFromString(financialPriceInfoPage);
                        cashPriceInfoPopup = TP.getCashPriceOnInfoPopup(resultDirectory,checkInfo);

                        if (Country.equals("UK")) {
                            entradaPriceInfoPopup = TP.getEntradaPriceOnInfoPopup(Country,resultDirectory,checkInfo);
                            TAEInfoPopup = TP.getTAEOnInfoPopup(resultDirectory,checkInfo);
                        }

                        TP.closeInfoPopup(resultDirectory, checkInfo);
                        //Thread.sleep(2000);

                        if (Country.equals("FR")) {
                            financialPriceInfo = Math.round((financialPriceInfo + 99) / 100 * 100);
                            String Str = financialPriceInfo.toString();
                            String Res = Str.toString().substring(0, Str.toString().length() - 2);
                            financialPriceInfo = Integer.parseInt(Res);
                        }

                        System.out.println("FinancialPrice1 : " + extractNumericFromString(financialPrice));
                        System.out.println("FinancialPrice2 : " + financialPriceInfo);

                        if (extractNumericFromString(financialPrice) == financialPriceInfo) {
                            checkInfo.log(Status.PASS, "The Monthly Price on Trim page info popup is correct");
                            sa.assertTrue(true);
                        } else {
                            checkInfo.log(Status.FAIL, "Monthly Price on Trim page info popup Not correct or not existing. Monthly Price :" + extractNumericFromString(financialPrice) + ", MonthlyPrice Info popup :" + financialPriceInfo);
                            failWithScreenshot("Monthly Price on Trim page info popup Not correct or not existing. Monthly Price :" + extractNumericFromString(financialPrice) + ", MonthlyPrice Info popup :" + financialPriceInfo, resultDirectory, driver, extent, logger);
                            sa.assertTrue(false, "Monthly Price Not correct or not existing");
                        }

                        if (cashPrice.equalsIgnoreCase(cashPriceInfoPopup)) {
                            checkInfo.log(Status.PASS, "Cash price on Trim page info popup is correct");
                            //logger.log(Status.PASS,
                                    //MarkupHelper.createLabel("Cash price on Trim page info popup is correct", ExtentColor.GREEN));
                            sa.assertTrue(true);
                        } else {
                            checkInfo.log(Status.FAIL, "Cash price on Trim page info popup is not correct. Cash Price :" + cashPrice + ", CashPrice Info popup :" + cashPriceInfoPopup);
                            failWithScreenshot("Cash price on Trim page info popup is not correct. Cash Price :" + cashPrice + ", CashPrice Info popup :" + cashPriceInfoPopup, resultDirectory, driver, extent, logger);
                            sa.assertTrue(false, "Cash price is not correct");
                        }

                        if (Country.equals("UK")) {
                            if (extractNumericFromString(entradaPrice) == extractNumericFromString(entradaPriceInfoPopup)) {
                                checkInfo.log(Status.PASS, "Entrada price is correct");
                                sa.assertTrue(true);
                            } else {
                                checkInfo.log(Status.FAIL, "Entrada price is not correct");
                                sa.assertTrue(false, "Entrada price is not correct");
                            }

                            if (promotionalText.contains(TAEInfoPopup.split("%")[0])) {
                                checkInfo.log(Status.PASS, "TAE info is correct");
                                sa.assertTrue(true);
                            } else {
                                checkInfo.log(Status.FAIL, "TAE info is not correct");
                                /*logger.log(Status.WARNING,
                                        MarkupHelper.createLabel("TAE info is not correct", ExtentColor.ORANGE));*/
                                sa.assertTrue(false, "TAE info is not correct");
                            }
                        }
                    }
                }
				/*else {
				TP.clickonFinantialInformation(i);
				logger.log(Status.PASS,
						MarkupHelper.createLabel("Finantial information clicked", ExtentColor.BLUE));
				sa.assertTrue(true);
			}*/
            }
            //sa.assertAll();
        } catch (Exception e1) {
            /*logger.log(Status.FAIL,
                    MarkupHelper.createLabel("Issue with Checking Info", ExtentColor.BLUE));
            e1.printStackTrace();*/
            catchFailDetails(resultDirectory, checkInfo,driver, "Issue with Checking Info",e1);
        }
    }

    @Test(description = "Checking Info popup")
    public static void checkInfoPopup(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                      String Brand, String Country) {
        TrimPage trimPage = new TrimPage(driver);
        float prixCataloguePrice;
        int promotionalAmount = 0;
        float monthlyPrice;
        int prixCatalogueInfoPopup = 0;
        float monthlyPriceInfoPopup = 0;
        int promotionalAmountInfoPopup = 0;
        ExtentTest infoPopup = extentTP.createNode("InfoPopup", "Checking info popup");
        try {
            driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
            if(isElementPresent(driver,TrimPage.financeVehicle,10)) {
                trimPage.selectFinanceVehicle(resultDirectory, infoPopup);
                //prixCataloguePrice = Float.parseFloat(trimPage.getPrixCatalogPrice(Country, Brand, resultDirectory, infoPopup).replace(" ","").replace(",",".").substring(0,5));
                prixCataloguePrice=extractFloatFromString(trimPage.getPrixCatalogPrice(Country, Brand, resultDirectory, infoPopup));
                System.out.println("prixCataloguePrice is: "+prixCataloguePrice);
                String monthlyP=trimPage.getMonthlyPrice(resultDirectory, infoPopup).replace(" ","").replace(",",".");
                monthlyPrice = Float.parseFloat(monthlyP.substring(0,monthlyP.length()-1));
                System.out.println("monthlyPrice is: "+monthlyPrice);
                if (Country.equalsIgnoreCase("FR")) {
                    promotionalAmount = extractNumericFromString(trimPage.getPromotionalAmount(resultDirectory, infoPopup).substring(0,2));
                    System.out.println("promotionalAmount is: "+promotionalAmount);
                }
                trimPage.clickInfoPopupBtn(Country, resultDirectory, infoPopup);
                if (!trimPage.validateInfoPopup(resultDirectory, infoPopup) == true) {
                    if (Country.equalsIgnoreCase("FR")) {
                        prixCatalogueInfoPopup = extractNumericFromString(trimPage.getPrixCataloguePrice_InfoPopup(resultDirectory, infoPopup));
                        System.out.println("prixCatalogueInfoPopup is: "+monthlyPrice);
                        promotionalAmountInfoPopup = extractNumericFromString(trimPage.getPromotionalAmount_InfoPopup(resultDirectory, infoPopup));
                        System.out.println("promotionalAmountInfoPopup is: "+promotionalAmountInfoPopup);
                    }
                    if (Country.equalsIgnoreCase("ES")) {
                        //monthlyPriceInfoPopup = extractNumericFromString(trimPage.getMonthlyPrice_InfoPopup(resultDirectory, infoPopup).substring(0,2));
                        String monthlyPriceInfo=trimPage.getMonthlyPrice_InfoPopup(resultDirectory, infoPopup).replace(" ","").replace(",",".");
                        monthlyPriceInfoPopup = Float.parseFloat(monthlyPriceInfo.substring(0,monthlyPriceInfo.length()));
                        System.out.println("promotionalAmountInfoPopup is: "+monthlyPriceInfoPopup);
                    }

                    trimPage.closeInfoPopup(resultDirectory, infoPopup);
                    if (Country.equalsIgnoreCase("FR")) {
                        if (Float.parseFloat(String.valueOf(prixCataloguePrice))-Float.parseFloat(String.valueOf(prixCatalogueInfoPopup))<1) {
                            infoPopup.log(Status.PASS, "Prix Catalogue price: " + prixCataloguePrice + " on Trim page matches with Info popup price: " + prixCatalogueInfoPopup);
                        } else {
                            infoPopup.log(Status.FAIL, "Prix Catalogue price: " + prixCataloguePrice + " on Trim page did not match with Info popup price: " + prixCatalogueInfoPopup);
                            failWithScreenshot("Prix Catalogue price: " + prixCataloguePrice + " on Trim page does not match with Info popup price: " + prixCatalogueInfoPopup, resultDirectory, driver, extent, infoPopup);
                        }
                        if (Float.parseFloat(String.valueOf(promotionalAmount))-Float.parseFloat(String.valueOf(promotionalAmountInfoPopup))<1) {
                            infoPopup.log(Status.PASS, "Promotional Amount: " + promotionalAmount + " on Trim page matches with Info popup price: " + promotionalAmountInfoPopup);
                        } else {
                            infoPopup.log(Status.FAIL, "Promotional Amount: " + promotionalAmount + " on Trim page did not match with Info popup price: " + promotionalAmountInfoPopup);
                            failWithScreenshot("Promotional Amount: " + promotionalAmount + " on Trim page does not match with Info popup price: " + promotionalAmountInfoPopup, resultDirectory, driver, extent, infoPopup);
                        }
                    }

                    if (Country.equalsIgnoreCase("ES")) {
                        if (monthlyPrice == monthlyPriceInfoPopup) {
                            infoPopup.log(Status.PASS, "Monthly Price: " + monthlyPrice + " on Trim page matches with Info popup price: " + monthlyPriceInfoPopup);
                        } else {
                            infoPopup.log(Status.FAIL,"Monthly Price: " + monthlyPrice + " on Trim page does not match with Info popup price: " + monthlyPriceInfoPopup);
                            failWithScreenshot("Monthly price: " + monthlyPrice + " on Trim page does not match with Info popup price: " + monthlyPriceInfoPopup, resultDirectory, driver, extent, infoPopup);
                        }
                    }
                } else {
                    infoPopup.log(Status.WARNING, "Error Info Popup Present");
                    failWithScreenshot("Error Info Popup Present", resultDirectory, driver, extent, infoPopup);
                    trimPage.closeInfoPopup(resultDirectory,infoPopup);
                }

            }else{
                infoPopup.log(Status.INFO,"Finance Vehicle is not present as Info Popup is not present");
            }

        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, infoPopup, driver, "Error while checking Info Pop-up", e);

        }
    }

}
