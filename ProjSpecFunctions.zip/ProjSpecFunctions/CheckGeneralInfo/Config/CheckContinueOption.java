package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckContinueOption extends UniversalMethods {

	@Test(description="clicking Continue Btn And Back To Config Page")
	public static void clickContinueBtnAndBackToConfigPage(String resultDirectory, WebDriver driver,
			ExtentReports extent, ExtentTest logger, String brand, String country) throws Exception {
		try {
			ConfigPage CP = new ConfigPage(driver);
			//Thread.sleep(5000);
			CP.clickContinueButtonOnStickyBar(resultDirectory,logger);
			/*logger.log(Status.INFO,
					MarkupHelper.createLabel("Continue button is clicked on stickybar", ExtentColor.BLUE));*/
			Thread.sleep(10000);
			driver.navigate().back();
			//Thread.sleep(4000);
		} catch (Exception e) {
			logger.log(Status.FAIL,
					MarkupHelper.createLabel("issue with clicking on Continue Button And Back To Config Page", ExtentColor.BLUE));
			e.printStackTrace();
		}
	}
}