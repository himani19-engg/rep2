package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

public class CheckConfigPageDetails extends UniversalMethods {
public static ExtentTest checkForm;
	public static void verifyNotificationFormOnStickyBar(String resultDirectory, WebDriver driver,
			ExtentReports extent, ExtentTest logger, String brand, String country) throws Exception {
		
		ConfigPage CP = new ConfigPage(driver);
		String text = "";
		checkForm = extentCP.createNode("NotificationFormOnStickyBar","Checking notification form on stickybar");
		try {
			CP.clickNotificationFormOnStickyBar(resultDirectory,checkForm);
			CP.clickOnMakeRequest(resultDirectory,checkForm);
			text = CP.getNotificationFormHeader(resultDirectory,checkForm);
			if (text.contains("Vous avez")
					|| text.equalsIgnoreCase("CONTACTEZ-NOUS")
					|| text.equalsIgnoreCase("Contactez-nous")
					|| text.equalsIgnoreCase("¿Necesitas más información?")
					|| text.equalsIgnoreCase("¿Necesita más información?")
					|| (text.contains("Necesitas m")&&text.contains("s informaci") ) ){
				checkForm.log(Status.PASS, "Notification form on Config page sticky bar is displayed");
			} else {

				failWithScreenshot("Notification form on Config page sticky bar is not displayed", resultDirectory, driver, extent, checkForm);
			}
			CP.clickCloseFormPopup(resultDirectory,checkForm);

		} catch (Exception e) {
			failWithScreenshot("Notification form on Config page is failed", resultDirectory, driver, extent, checkForm);
			e.printStackTrace();
		}
	}
	
	@Test(description = "Checking Delivery Text On Config")
	public static void checkDeliveryTextOnConfig(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country) throws Exception {

		ConfigPage CP = new ConfigPage(driver);
		SoftAssert sa = new SoftAssert();
		String deliveryText;
		ExtentTest checkingDeliveryTextOnConfigPage = extentCP.createNode("CheckingDeliveryTextOnConfigPage","Checking delivery text on config page");
		try {
			CP.scrollToTop(driver);
			deliveryText= CP.getDeliveryText(resultDirectory,checkingDeliveryTextOnConfigPage);
			if (deliveryText != null) {
				if (deliveryText.contains("Disponible")) {
					checkingDeliveryTextOnConfigPage.log(Status.PASS, "Delivery text on Config page is displayed");
					sa.assertTrue(true);
				} else {
					failWithScreenshot("Delivery text on Config page is not correctly displayed", resultDirectory, driver, extent, checkingDeliveryTextOnConfigPage);
					sa.assertTrue(false, "Delivery text on Config page is not correctly displayed");
				}

			}
		} catch (Exception e) {
			failWithScreenshot("Test failed while checking Delivery Text On Config", resultDirectory, driver, extent, checkingDeliveryTextOnConfigPage);
			checkingDeliveryTextOnConfigPage.log(Status.FAIL, String.valueOf(e.getStackTrace()));
			
		}
	}
	
	public static void checkLegalTextOnConfig(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country) throws Exception {

		ConfigPage CP = new ConfigPage(driver);
		SoftAssert sa = new SoftAssert();
		String text;
		ExtentTest legalText = extentCP.createNode("CheckLegalText","Checking delivery text on config page");
		try {
			CP.scrollToTop(driver);
			text= CP.getLegalText(resultDirectory,legalText);
				if (text.contains("Prix")
						|| text.contains("crédit")) {
					legalText.log(Status.PASS, "Legal text on Config page is displayed");
					sa.assertTrue(true);
				} else {
					//failWithScreenshot("Legal text on Config page is not correctly displayed", resultDirectory, driver, extent, legalText);
					legalText.log(Status.INFO, "Legal text on Config page does not contain words Prix and crédit ");
					sa.assertTrue(true, "Legal text on Config page does not contain words Prix and crédit ");
				}
		} catch (Exception e) {
			failWithScreenshot("Test failed while checking Legal Text On Config", resultDirectory, driver, extent, legalText);
			legalText.log(Status.FAIL, String.valueOf(e.getStackTrace()));
			
		}
	}
}
