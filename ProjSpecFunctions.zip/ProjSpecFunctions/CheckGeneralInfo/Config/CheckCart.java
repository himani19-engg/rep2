package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.testng.asserts.SoftAssert;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

@Test(description = "Checking Cart")
public class CheckCart extends UniversalMethods {

	public static void CheckCartConfig(String resultDirectory, WebDriver driver, ExtentReports extent,
									   ExtentTest logger, String brand, String country, String paymentMode) throws Exception {
		ExtentTest checkingCartOnConfigPage = extentCP.createNode("CheckingCartOnConfigPage", "Check cart on config page");
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			HomePage HP = new HomePage(driver);
			// scroll to the top of the page
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//SoftAssert sa=new SoftAssert();

			HP.clickonCartIcon(country, resultDirectory, checkingCartOnConfigPage);
			//waitForUrlContains("peugeot-preprod", driver, 20);
			if(driver.getCurrentUrl().contains("/summary")){
				waitForPageToLoad(driver, 15);
				clickElement(driver, By.xpath("(//*[@id='TESTING_TO_BASKET_BOX_INTERESTEDBOX'])[2]"));
				//cyp.clickConfigcontinue(resultDirectory, navigateToDealerStepBeforeBasketAndValidation, Brand,Country);
			}
			Thread.sleep(10000);
			String currentURL=driver.getCurrentUrl();
			// Get and check the basket text in URL

			if (currentURL.contains("basket")) {
				checkingCartOnConfigPage.log(Status.PASS, "URL contains basket text i.e. Basket Page has appeared");
				//sa.assertTrue(true);
			} else if (currentURL.contains("dealers")) {
				checkingCartOnConfigPage.log(Status.PASS, "URL contains dealers text i.e. Dealer Page Before Basket has appeared");
				//sa.assertTrue(true);
			} else {
				checkingCartOnConfigPage.log(Status.FAIL, "URL does not contains dealers/basket text");
				failWithScreenshot("URL does not contains dealers text", resultDirectory, driver, extent, checkingCartOnConfigPage);
				//sa.assertTrue(false, "URL does not contains dealers/basket text");
			}
			//sa.assertAll();
			Thread.sleep(2000);
			if(!((brand.equalsIgnoreCase("OV"))&&(paymentMode.equalsIgnoreCase("Finance")))){
				driver.navigate().back();
			}
			driver.navigate().refresh();
			checkingCartOnConfigPage.log(Status.INFO, "Returned from Basket Page");
			//Thread.sleep(2000);

		} catch (Exception e1) {
			failWithScreenshot("Test Failed while Checking Cart", resultDirectory, driver, extent, checkingCartOnConfigPage);
			checkingCartOnConfigPage.log(Status.FAIL, String.valueOf(e1.getStackTrace()));
		}
	}

}
