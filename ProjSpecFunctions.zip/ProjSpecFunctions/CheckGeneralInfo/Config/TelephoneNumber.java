package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class TelephoneNumber extends UniversalMethods {

	@Test(description="Clicking TelephoneNumber Link")
	public static void clickTelephoneNumberLink(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country) throws Exception {
		ExtentTest telephoneNumberLink = extentCP.createNode("TelephoneNumberLink","Check Telephone number link");
		try {
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			ConfigPage CP = new ConfigPage(driver);
			//Thread.sleep(2000);
			CP.clickOnTelephoneNumberLink(resultDirectory,telephoneNumberLink);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Telephone number link is clicked", ExtentColor.BLUE));
			//telephoneNumberLink.log(Status.INFO, "Telephone number link is clicked");


			CP.clickEnterUsingRobot(resultDirectory,telephoneNumberLink);
			
		} catch (Exception e) {
			/*failWithScreenshot("Test Failed while Clicking TelephoneNumber Link", resultDirectory, driver, extent, telephoneNumberLink);
			telephoneNumberLink.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
			catchFailDetails(resultDirectory, telephoneNumberLink,driver, "Error with Clicking TelephoneNumber Link",e);
		}
	}
}