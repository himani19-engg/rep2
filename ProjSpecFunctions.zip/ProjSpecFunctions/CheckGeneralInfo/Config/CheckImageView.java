package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckImageView extends UniversalMethods {

    @Test(description = "Config Page Image Link")
    public static void configPageImageLink(String resultDirectory, WebDriver driver, ExtentReports extent,
                                           ExtentTest logger, String Brand, String Country) throws Exception {
        ExtentTest imageCheckOnConfigPage = extentCP.createNode("ImageCheckOnConfigPage", "Check image on config page");
        try {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            ConfigPage CP = new ConfigPage(driver);

            // Click On Exterior image
            CP.scrollToTop(driver);
            CP.clickExteriorImage(resultDirectory,imageCheckOnConfigPage);
            System.out.println("Here is the link title ::::");
            //logger.log(Status.INFO, MarkupHelper.createLabel("Exterior image link is clicked", ExtentColor.BLUE));
            //imageCheckOnConfigPage.log(Status.INFO, "Exterior image link is clicked");
            //logger.log(Status.INFO, "Exterior image link is clicked");
            //Thread.sleep(5000);
            for (int i = 1; i <= 3; i++) {
                CP.clickonNextSlideArrow(resultDirectory,imageCheckOnConfigPage);
                //Thread.sleep(1000);
            }

            System.out.println("click to slide arrow");
            imageCheckOnConfigPage.log(Status.INFO, "Next slide arrow button clicked");

            /*
             * //Count of exterior image int exteriorSize = CP.getImageList().size();
             * System.out.println("<<<<<<>>>>>>" + exteriorSize);
             *
             * for(int i=1;i<=exteriorSize;i++) { CP.clickImageLink(i); classValue =
             * CP.getImageAttributeValue(i); if(classValue.contains("active")) {
             * logger.log(Status.PASS,
             * MarkupHelper.createLabel("Exterior image shown is correct",
             * ExtentColor.GREEN)); }else { logger.log(Status.WARNING,
             * MarkupHelper.createLabel("Exterior image shown is not correct",
             * ExtentColor.ORANGE)); } }
             */

            // Click on Interior image
            CP.clickInteriorImage(resultDirectory,imageCheckOnConfigPage);
            System.out.println("Here is the interior link title ::::");
            //imageCheckOnConfigPage.log(Status.INFO, "Interior image link is clicked");
            //Thread.sleep(5000);
            for (int i = 1; i <= 3; i++) {
                CP.clickonNextSlideArrow(resultDirectory,imageCheckOnConfigPage);
                //Thread.sleep(1000);
            }
            System.out.println("click to slide arrow");
            //imageCheckOnConfigPage.log(Status.INFO, "Next slide arrow button clicked");

            /*
             * //Count of exterior image int interiorSize = CP.getImageList().size();
             * System.out.println("<<<<<<>>>>>>" + interiorSize);
             *
             * for(int i=1;i<=interiorSize;i++) { CP.clickImageLink(i); classValue =
             * CP.getImageAttributeValue(i); if(classValue.contains("active")) {
             * logger.log(Status.PASS,
             * MarkupHelper.createLabel("Interior image shown is correct",
             * ExtentColor.GREEN)); }else { logger.log(Status.WARNING,
             * MarkupHelper.createLabel("Interior image shown is not correct",
             * ExtentColor.ORANGE)); } }
             */
        } catch (Exception e) {
            /*imageCheckOnConfigPage.log(Status.FAIL, "Test Failed. Issue with Config Page Image Link");
            failWithScreenshot("Test Failed. Issue with Config Page Image Link", resultDirectory, driver, extent, imageCheckOnConfigPage);
            imageCheckOnConfigPage.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            catchFailDetails(resultDirectory, imageCheckOnConfigPage,driver, "Image is not present on Home Page",e);

        }
    }
}
