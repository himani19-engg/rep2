package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)
public class CheckInformationForm extends UniversalMethods {

	@Test(description = "Fill Confirmation Page")
	public static void FillConfirmationPage(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String Brand, String Country, String PostalCode, String EmailId, String Password,
			String Name, String Phone, String Address) throws Exception {
		ExtentTest notificationForm = extentCP.createNode("NotificationForm","Check Notification form");
		try {
			driver.manage().timeouts().implicitlyWait(6, TimeUnit.SECONDS);
			ConfigPage CP = new ConfigPage(driver);

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//Thread.sleep(5000);
			//CP.fillNotificationForm(Brand, Country, PostalCode, EmailId, Name, Phone, Address,resultDirectory,notificationForm);
			//notificationForm.log(Status.INFO, "Notification Form filled");

		} catch (Exception e) {
			/*notificationForm.log(Status.FAIL,"Test Failed in notification form on Config page");
			failWithScreenshot("Test Failed Test Failed in notification form on Config page", resultDirectory, driver, extent, notificationForm);
			notificationForm.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, notificationForm,driver, "Test Failed in notification form on Config page",e);
		}
	}

}
