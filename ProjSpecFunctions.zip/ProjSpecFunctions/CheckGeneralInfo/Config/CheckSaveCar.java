package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.LoginUserPage;
import solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckSaveCar extends UniversalMethods {


	@Test(description = "Checking Save Car Button")
	public static void CheckSaveCarButton(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String Country, String vehicleChoice, String EmailId, String Password, String PaymentMode)
			throws Exception {

		try {

			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);

			ConfigPage CP = new ConfigPage(driver);
			LoginUserPage LUP = new LoginUserPage(driver);
			HomePage HP1 = new HomePage(driver);
			SoftAssert sa = new SoftAssert();
			// scroll to the top of the page
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			//Thread.sleep(2000);

			System.out.println("Here is the button title :::::::" + CP.getSaveButtonText(resultDirectory,logger));
			// Get and check the save button text

			if (CP.getSaveButtonText(resultDirectory,logger).equalsIgnoreCase("SAUVEGARDEZ")
					|| CP.getSaveButtonText(resultDirectory,logger).equalsIgnoreCase("SAVE")
					|| CP.getSaveButtonText(resultDirectory,logger).equalsIgnoreCase("SAUVEGARDER")
					|| CP.getSaveButtonText(resultDirectory,logger).equalsIgnoreCase("GUARDAR"))

			{
				logger.log(Status.PASS, "Save button text is correct");
				//logger.log(Status.PASS, MarkupHelper.createLabel("Save button text is correct", ExtentColor.GREEN));
				sa.assertTrue(true);
			} else {
				failWithScreenshot("Save button text is not correct", resultDirectory, driver, extent, logger);

				sa.assertTrue(false, "Vehicle name on basket page is not correct");
				//driver.close();
			}

			// click on save car Button
			CP.clickOnSaveButton(resultDirectory,logger);
			//Thread.sleep(1500);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Save Button Clicked", ExtentColor.BLUE));
			//Thread.sleep(1000);
			System.out.println("Here is the button title after clicking  :::::::" + CP.getSaveButtonTextAfterClicking(resultDirectory,logger));
			//Thread.sleep(1000);

			// Get and check the save button text after clicking
			if (CP.getSaveButtonTextAfterClicking(resultDirectory,logger).equalsIgnoreCase("Vehículo guardado")
					|| (CP.getSaveButtonTextAfterClicking(resultDirectory,logger).equalsIgnoreCase("Véhicule sauvegardé"))
					|| (CP.getSaveButtonTextAfterClicking(resultDirectory,logger).equalsIgnoreCase("Vehicle saved"))
					|| (CP.getSaveButtonTextAfterClicking(resultDirectory,logger).equalsIgnoreCase("Configuración Guardada")))

			{
				logger.log(Status.PASS, "Save button text after clicking is correct");
				/*logger.log(Status.PASS,
						MarkupHelper.createLabel("Save button text after clicking is correct", ExtentColor.GREEN));*/
				sa.assertTrue(true);
			} else {
				failWithScreenshot("Save button text after clicking is not correct", resultDirectory, driver, extent, logger);
				/*logger.log(Status.WARNING,
						MarkupHelper.createLabel("Save button text after clicking is not correct", ExtentColor.ORANGE));*/
				sa.assertTrue(false, "Save button text after clicking is not correct");

			}

			// Login
			//Thread.sleep(2000);
			CP.clickOnLoginButton(resultDirectory,logger);
			//Thread.sleep(1000);
			LUP.enterEmail(EmailId,resultDirectory,logger);
			//Thread.sleep(1000);
			LUP.enterPassword(Password,resultDirectory,logger);
			//Thread.sleep(1000);
			LUP.validate(resultDirectory,logger);
			//Thread.sleep(4000);
			logger.log(Status.INFO, MarkupHelper.createLabel("The user is logged succesfully", ExtentColor.BLUE));
			//Thread.sleep(1500);

			// CP.clickOnSaveButton();

			/*
			 * System.out.println("Here is the button title after clicking  :::::::"+
			 * CP.getSaveButtonTextAfterClicking()); Thread.sleep(1000);
			 * 
			 * //Get and check the save button text after clicking if
			 * (CP.getSaveButtonTextAfterClicking().equalsIgnoreCase("Vehículo guardado")||
			 * (CP.getSaveButtonTextAfterClicking().equalsIgnoreCase("Véhicule sauvegardé"))
			 * || (CP.getSaveButtonTextAfterClicking().equalsIgnoreCase("Vehicle saved"))||
			 * (CP.getSaveButtonTextAfterClicking().
			 * equalsIgnoreCase("Configuración Guardada")))
			 * 
			 * { logger.log(Status.PASS,
			 * MarkupHelper.createLabel("Save button text after clicking is correct",
			 * ExtentColor.GREEN)); } else {
			 * FailWithScreenshot("Save button text after clicking is not correct",
			 * resultDirectory, driver, extent, logger); driver.quit(); }
			 * 
			 * // scroll to the top of the page JavascriptExecutor js2 =
			 * (JavascriptExecutor) driver;
			 * js2.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
			 * Thread.sleep(2000);
			 * 
			 * 
			 * 
			 * HP1.clickonMyOrderVehicles(); logger.log(Status.INFO,
			 * MarkupHelper.createLabel("Click on My Order Vehicles button",
			 * ExtentColor.BLUE)); Thread.sleep(1000);
			 * 
			 * // delete offer HP1.deleteOffer(); logger.log(Status.INFO,
			 * MarkupHelper.createLabel("Click on Delete Offer", ExtentColor.BLUE));
			 * Thread.sleep(1000);
			 * 
			 * //delete order HP1.deleteOrderConfirm(); logger.log(Status.INFO,
			 * MarkupHelper.createLabel("Click on Delete Order", ExtentColor.BLUE));
			 * Thread.sleep(3000);
			 */

			// Click account
			HP1.clickonAccountButton(resultDirectory,logger);
			logger.log(Status.INFO, MarkupHelper.createLabel("Click on Account button", ExtentColor.BLUE));
			//Thread.sleep(2000);

			HP1.clickonAccountCreation(resultDirectory,logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Click on Account Creation button", ExtentColor.BLUE));
			//Thread.sleep(1000);

			HP1.clickonMyOrderVehicles(resultDirectory,logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Click on My Order Vehicles button", ExtentColor.BLUE));
			//Thread.sleep(1000);

			// delete offer
			HP1.deleteOffer(resultDirectory,logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Click on Delete Offer", ExtentColor.BLUE));
			//Thread.sleep(1000);

			// delete order
			HP1.deleteOrderConfirm(resultDirectory,logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Click on Delete Order", ExtentColor.BLUE));
			//Thread.sleep(3000);

			// Click on logout
			LUP.clickAccountkLink(resultDirectory,logger);
			//Thread.sleep(2000);
			LUP.clickLogout(resultDirectory,logger,Country);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Click on Logout", ExtentColor.BLUE));

			ChooseCarCashNonEc41.chooseCarModel(resultDirectory, driver, extent, logger, brand, Country,PaymentMode);
			//ChooseCarCashNonEc41.chooseCarType(resultDirectory, driver, extent, logger, brand, Country, vehicleChoice);
			sa.assertAll();
		} catch (Exception e1) {
			/*logger.log(Status.FAIL, MarkupHelper.createLabel("Unable to Check Save Car Button", ExtentColor.BLUE));
			e1.printStackTrace();*/
			catchFailDetails(resultDirectory, logger,driver, "Unable to Check Save Car Button",e1);

		}
	}

}
