package solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CompareAllPrice extends UniversalMethods {

	@Test(description = "Comparing Price On Trim And Config")
	public static void comparePriceOnTAEPopupAndConfigPage(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country) throws Exception {

		String cashPriceOnConfig;
		String cashPriceOnTAEConfig;
		String financePriceOnConfig;
		String financePriceOnTAEConfig;
		String entradaPriceOnConfigpage = null;
		String entradaPriceOnConfigTAEPopUp = null;

		ConfigPage CP = new ConfigPage(driver);
		SoftAssert sa = new SoftAssert();
		//Thread.sleep(2000);
		ExtentTest comparingPriceOnTrimAndConfigPage = extentCP.createNode("ComparingPriceOnTrimAndConfigPage","comparing Price On Trim And Config page");
	try{
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		CP.clickOnTAEPopupLink(country,resultDirectory,comparingPriceOnTrimAndConfigPage);
		//comparingPriceOnTrimAndConfigPage.log(Status.INFO, "Click on TAE popup link on Config page");
		//Thread.sleep(1000);

		cashPriceOnConfig = CP.getCashPriceOnConfigpage(resultDirectory,comparingPriceOnTrimAndConfigPage);
		cashPriceOnTAEConfig = CP.getCashPriceOnConfigTAEPopUp(resultDirectory,comparingPriceOnTrimAndConfigPage);
		financePriceOnConfig = CP.getFinancePriceOnConfigpage(resultDirectory,comparingPriceOnTrimAndConfigPage);
		financePriceOnTAEConfig = CP.getFinancePriceOnConfigTAEPopUp(country,resultDirectory,comparingPriceOnTrimAndConfigPage);
		//entradaPriceOnConfigpage = CP.getEntradaPriceOnConfigpage();
		//entradaPriceOnConfigTAEPopUp = CP.getEntradaPriceOnConfigTAEPopUp(); 

		if ((Float.parseFloat(cashPriceOnConfig)-(Float.parseFloat(cashPriceOnTAEConfig))<=1)) {
			comparingPriceOnTrimAndConfigPage.log(Status.PASS, "Cash price on config page and TAE popup is correct");
		} else {
			failWithScreenshot("Cash price on config page " + cashPriceOnConfig + " and TAE popup " + cashPriceOnTAEConfig + " is not correct", resultDirectory, driver, extent, comparingPriceOnTrimAndConfigPage);
		}

			if ((Float.parseFloat(financePriceOnConfig)-Float.parseFloat(financePriceOnTAEConfig))<=1) {
				comparingPriceOnTrimAndConfigPage.log(Status.PASS, "finance price on config page and TAE popup is correct");
				//sa.assertTrue(true);
			} else {
				failWithScreenshot("finance price on config page "+extractNumericFromString(financePriceOnConfig)+" and TAE popup "+extractNumericFromString(financePriceOnTAEConfig)+" is not correct", resultDirectory, driver, extent, comparingPriceOnTrimAndConfigPage);
				//sa.assertTrue(false, "finance price on config page and TAE popup is not correct");
			}
			//sa.assertAll();
			/*System.out
					.println("Entrada Price from TAE popup= " + extractNumericFromString(entradaPriceOnConfigTAEPopUp));

			System.out.println("Entrada Price from Config Page= " + extractNumericFromString(entradaPriceOnConfigpage));

			if (extractNumericFromString(entradaPriceOnConfigpage) == extractNumericFromString(
					entradaPriceOnConfigTAEPopUp)) {
				logger.log(Status.PASS, MarkupHelper
						.createLabel("Entrada price on config page and TAE popup is correct", ExtentColor.GREEN));
				sa.assertTrue(true);
			} else {
				logger.log(Status.WARNING, MarkupHelper
						.createLabel("Entrada price on config page and TAE popup is not correct", ExtentColor.ORANGE));
				sa.assertTrue(false, "Entrada price on config page and TAE popup is not correct");
			} */

		//Thread.sleep(1000);
		CP.clickOnTCloseTAEPopupLink(resultDirectory,comparingPriceOnTrimAndConfigPage);
		//comparingPriceOnTrimAndConfigPage.log(Status.INFO, "Close TAE popup link on config page");
		//Thread.sleep(1000);

		//sa.assertAll();
		} catch (Exception e) {
			/*comparingPriceOnTrimAndConfigPage.log(Status.FAIL,"Test Failed while Comparing Price On Trim And Config");
			failWithScreenshot("Test Failed while Comparing Price On Trim And Config", resultDirectory, driver, extent, comparingPriceOnTrimAndConfigPage);
			comparingPriceOnTrimAndConfigPage.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
		catchFailDetails(resultDirectory, comparingPriceOnTrimAndConfigPage,driver, "Test Failed while Comparing Price On Trim And Config",e);
		}

	}

}
