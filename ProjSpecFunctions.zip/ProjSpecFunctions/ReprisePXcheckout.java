package solRetailIHM.ProjSpecFunctions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.FullParkExchangePage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.PageObjectModel.ReprisePage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.PageObjectModel.HomePage.getHomePageVahicleName;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.MonthlyTotalBasketCash;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.getbasketPgVehicleName;
import static solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash.*;
import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.vehicleName;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ReprisePXcheckout extends UniversalMethods {

    public static ExtentTest fillRepriseCheckout;
    public static ExtentTest PriceCompare;

    public static ExtentTest threeIcons;

    public static Float MonthlyTotalCashRepriseFloat;
    public static Float FinanceCashRepriseFloat;

    public static String rightPanel_reprise;

    @Test(description = "Fill Reprise for Cash")
    public static void FillReprise(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                   String Country, String PaymentMode, String VehicleChoice, String Brand, String Plate, String PXConfigPage,
                                   String PXCheckoutPage) throws Exception {
        fillRepriseCheckout = logger.createNode("Reprise", "Checking Reprise");
        try {
            driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
            FullParkExchangePage fpe = new FullParkExchangePage(driver);
            //SoftAssert sa = new SoftAssert();
            Thread.sleep(6000);

            // Checking the check box if mode is Cash
            if (PaymentMode.equalsIgnoreCase("Cash")) {
                if ((PXCheckoutPage.equals("yes")) || (PXConfigPage.equals("yes"))) {

                    if (PXConfigPage.equals("yes")) {
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.GoToReprise();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.GoToRepriseValidate();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);

                    } else {
                        System.out.println("We choose Yes for Reprise");
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.ClickRepriseYes();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        logger.log(Status.PASS, MarkupHelper.createLabel("Clicked On Reprise Yes", ExtentColor.BLUE));
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.ClickConfirmRepriseButton();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        logger.log(Status.PASS,
                                MarkupHelper.createLabel("Clicked On Confirmation Reprise Yes", ExtentColor.BLUE));
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.ClickOnContinueRepriseButton();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    }

                    if (Brand.equals("AP") || Brand.equals("DS")) {
                        fpe.FillImmatriculation(Plate);
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        fpe.ClickOnContinueOfferRepriseButton();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        fpe.ClickOnNextConfirmButton();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        fpe.ChooseTheFirstVehicleFromRepriseList();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        logger.log(Status.PASS, MarkupHelper.createLabel("Fill Immatriculation", ExtentColor.BLUE));
                    } else if (Brand.equals("AC")) {
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.ChooseBrandAC(PXCheckoutPage);
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.ChooseCarOptionsAC();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.ChooseVersionAC(PXConfigPage);
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        Thread.sleep(2000);
                        logger.log(Status.PASS, MarkupHelper.createLabel("Fill Immatriculation", ExtentColor.BLUE));
                    }
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.EnterMileageInfo();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Enter Mileage", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckOwnerYes();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Check Owner Yes", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckCarGageNo();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Gage No", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckCarCanDriveYes();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Car Can Drive Yes", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckCarWreckedNo();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Car Wreaked No", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckCarImportedNo();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Car Import NO", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckTechnicalControlYes();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Technical Control Yes", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckVehicleStatus();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Vehicle Status Entered", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckMaintenaceSatus();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Maintenance Status Checked", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckInternalStatus();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Inter Status Checked", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckTireStatus();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Check Tire Yes", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
//					fpe.CheckNodamage();
//					//LogWithScreenshot("", resultDirectory, driver, extent, logger);
//					Thread.sleep(2000);
//					logger.log(Status.PASS,
//							MarkupHelper.createLabel("No Dommage Yes", ExtentColor.BLUE));
                    fpe.ClickExternalDamages();
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("No External Dommage", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.CheckStatusSummary();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.ConfirmOffer();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Confirm Offer Done", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.AttacheFiles();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    if (Brand.equals("DS") || Brand.equals("AC")) {
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                        fpe.ContinueToAttacheFile();
                        // LogWithScreenshot("", resultDirectory, driver, extent, logger);

                    }
                    Thread.sleep(5000);
                    fpe.ProvideAttachedFiles();
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Attached Files Added", ExtentColor.BLUE));
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                    fpe.FinalisePayment();
                    Thread.sleep(2000);
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);

                    fpe.MovetoNextStep("", resultDirectory, driver, extent, logger);
                    // LogWithScreenshot("", resultDirectory, driver, extent, logger);
                }

                if ((PXCheckoutPage.equals("no")) && (!PXConfigPage.equals("yes"))) {
                    System.out.println("We choose No for Reprise");
                    fpe.ClickRepriseNo();
                    Thread.sleep(2000);
                    logger.log(Status.PASS, MarkupHelper.createLabel("Clicked On Reprise No", ExtentColor.BLUE));
                    fpe.ClickConfirmRepriseButton();
                    Thread.sleep(2000);
                    logger.log(Status.PASS,
                            MarkupHelper.createLabel("Clicked On Confirmation Reprise No", ExtentColor.BLUE));

                }

                waitForUrlContains("/order-summary", driver, 240);
                // fpe.CobfirmOfferWithPaymentObligation();
                if (fpe.checkConfirmationMessage()) {
                    logger.log(Status.PASS,
                            MarkupHelper.createLabel("Confirmation Message Received", ExtentColor.GREEN));
                    //sa.assertTrue(true);
                } else {
                    failWithScreenshot("Confirmation Message not Received", resultDirectory, driver, extent, logger);
                    //sa.assertTrue(false, "Confirmation Message not Received");
                    //driver.close();

                }

            }

            //sa.assertAll();

        } catch (Exception e) {
			/*fillRepriseCheckout.log(Status.FAIL,"Test Failed while Filling Reprise for Cash");
            failWithScreenshot("test Failed", resultDirectory, driver, extent, logger);
			fillRepriseCheckout.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
            catchFailDetails(resultDirectory, fillRepriseCheckout,driver, "Test Failed while Filling Reprise for Cash",e);
        }
    }

    public static void validateRepriseMonthlyPricewithIdentificationPrice(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                                      String country) {
        LoginUser LogincashPr=new LoginUser();
        ReprisePage ReprisecashPr=new ReprisePage(driver);
        Float RepCashPrc;
        try {
            if (country.equals("FR")) {
                RepCashPrc= Float.valueOf(ReprisecashPr.getRepriseCashPrice());
                System.out.println("Monthly Price on Reprise Screen is: "+RepCashPrc);
                if((RepCashPrc-LogincashPr.cashPriceOnPersonalInfo)<=1) {
                    logger.log(Status.PASS, "Cash Price on Identification Page is same as on Reprise Page");
                }else{
                    logger.log(Status.FAIL, "Cash Price on Identification Page is not same as on Reprise Page");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            catchFailDetails(resultDirectory, logger,driver, "Test Failed while comparing monthly Price on Reprise screen with Identification Screen",e);
        }
    }

    public static void selectNoRepriseOptionAndSubmit(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                                      String country, String PersoV, String PaymentMode, String EmailId, String PostalCode, String City, String Phone, String Brand, String Name) {
        if(driver!=null) {
            ReprisePage reprise = new ReprisePage(driver);
            ReprisePXcheckout reprisePrice = new ReprisePXcheckout();
            fillRepriseCheckout = logger.createNode("Reprise", "Checking Reprise");
            try {
                CheckPersonnalInfoCash.validateRetailerAddress(resultDirectory,driver,extent,fillRepriseCheckout,Brand, country);
                CheckPersonnalInfoCash.validatePersonalInfo(resultDirectory,driver,extent,fillRepriseCheckout,Brand, country,EmailId,PostalCode,City,Phone,Name);
                CheckPersonnalInfoCash.validateRefundableFeeAmount(resultDirectory,driver,extent,fillRepriseCheckout,Brand, country,PaymentMode);
                PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, fillRepriseCheckout, getbasketPgVehicleName, "Reprise Page", By.xpath("//*[@class='versionLabel']"));
                PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, fillRepriseCheckout, country);

                if (PersoV.equalsIgnoreCase("yes")) {
                    reprisePrice.validateRepriseMonthlyPricewithIdentificationPrice(resultDirectory, driver, extent, fillRepriseCheckout, country);
                } else {
                    if (country.equals("FR")) {
                        rightPanel_reprise = getAnyText(driver, By.xpath("//div[@class='bloc-recap-detail']"), 10);
                        fillRepriseCheckout.log(Status.INFO, "<=====Right Side Panel Context of Reprise Screen Starts here=====>");
                        fillRepriseCheckout.log(Status.INFO, rightPanel_reprise);
                        fillRepriseCheckout.log(Status.INFO, "<=====Right Side Panel Context of Reprise Screen Ends here=====>");
                        String diffInText = differenceInText(rightPanel_personalInfo, rightPanel_reprise);
                        System.out.println("Similarity is: " + findSimilarity(rightPanel_personalInfo, rightPanel_reprise));
                        if (findSimilarity(rightPanel_personalInfo, rightPanel_reprise) == 1.0 || diffInText == "") {
                            fillRepriseCheckout.log(Status.PASS, "Right Side Panel Context of Personal Info Page is same as of Reprise Screen");
                        } else {
                            fillRepriseCheckout.log(Status.FAIL, "Right Side Panel Context of Personal Info Page is not same as of Reprise Screen and the difference in context is: " + diffInText);
                        }
                        if(Brand.equalsIgnoreCase("AC")){
                        if(isElementPresent(driver,By.xpath("(//*[contains(@class,\"btn-valider\")])[1]"))) {
                            clickElement(driver, By.xpath("(//*[contains(@class,\"btn-valider\")])[1]"));
                            waitForElementPresent(driver, By.xpath("//*[@class=\"reprise-ferme\"]"), 50);
                            clickElement(driver, By.xpath("//*[contains(@class,\"btn-next\")]"));
                            waitForElementPresent(driver, By.xpath("//*[contains(@class,\"btn-next\")]"), 50);
                            clickElement(driver, By.xpath("//*[contains(@class,\"btn-next\")]"));
                            waitForElementPresent(driver, By.xpath("//*[contains(@class,\"btn-next\")]"), 50);
                            clickElement(driver, By.xpath("//*[contains(@class,\"btn-next\")]"));
                            enterData(driver, By.xpath("//*[@name=\"annualMileage\"]"), "25");
                            waitForElementPresent(driver, By.xpath("//*[contains(@class,\"btn-next\")]"), 50);
                            clickElement(driver, By.xpath("//*[contains(@class,\"btn-next\")]"));
                            waitForElementPresent(driver, By.xpath("//*[contains(@class,\"btn-next\")]"), 50);
                            clickElement(driver,By.xpath("(//*[contains(@class,\"btn-to-custom-focus\")])[2]"));
                            clickElement(driver, By.xpath("//*[contains(@class,\"btn-next\")]"));
                            waitForElementPresent(driver, By.xpath("//*[contains(@class,\"btn-next\")]"), 50);
                            clickElement(driver, By.xpath("//*[contains(@class,\"btn-next\")]"));

                        }else{
                            reprise.selectNoOption();
                        }
                        }else {
                            reprise.selectNoOption();
                        }
                        String MonthlyTotalCashReprise = getAnyText(driver, By.xpath("//span[contains(@class,'price-total-price')]")).replaceAll(" ", "").replaceAll(",", ".");
                        MonthlyTotalCashRepriseFloat = extractFloatFromString(MonthlyTotalCashReprise);
                        //(MonthlyTotalCashRepriseFloat - totalMonthlyPriceIdentificationFloat) <= 1) ||
                        if (((MonthlyTotalCashRepriseFloat - MonthlyTotalBasketCash) <= 1)) {
                            fillRepriseCheckout.log(Status.PASS, "Monthly Total Basket Cash, Monthly Total Cash Reprise and total Monthly Price Identification/Personal Info all are same which is: " + totalMonthlyPriceIdentificationFloat);
                        } else {
                            fillRepriseCheckout.log(Status.FAIL, "Monthly Total Basket Cash, Monthly Total Cash Reprise and total Monthly Price Identification/Personal Info all are not same");
                        }
                        writeToProperties("currentCashPrice",String.valueOf(MonthlyTotalCashRepriseFloat));

                        if (PaymentMode.equalsIgnoreCase("Finance")) {
                            FinanceCashRepriseFloat = extractFloatFromString(getAnyText(driver, By.xpath("//p[@class='prix_mois']"),10).replace(" ", "").replace(",", "."));
                            if ((financePriceOnIdentificationPage - FinanceCashRepriseFloat) <= 1) {
                                fillRepriseCheckout.log(Status.PASS, "finance Price On Identification Page " + financePriceOnIdentificationPage + " is same as Finance Cash Reprise " + FinanceCashRepriseFloat);
                            } else {
                                fillRepriseCheckout.log(Status.FAIL, "finance Price On Identification Page " + financePriceOnIdentificationPage + " is not same as Finance Cash Reprise " + FinanceCashRepriseFloat);
                            }
                            writeToProperties("currentFinanceprice",String.valueOf(FinanceCashRepriseFloat));
                        }

                        String userAddress = getAnyText(driver, By.xpath("(//section[contains(@class,'recap-aside-seller')])[2]"));
                        System.out.println(userAddress);
                        if(userAddress!=null) {
                            if (userAddress.contains(EmailId)
                                    || userAddress.contains(PostalCode)
                                    && userAddress.contains(City)
                                    && userAddress.contains(Phone)
                                    && userAddress.contains(Name)
                                    && userAddress.contains("Test")
                                    && userAddress.contains("France")
                            ) {
                                fillRepriseCheckout.log(Status.PASS, "Mini Side Bar: User's Address is matched with the information we have which is: Email id, City, Phone Number, User's Name, User's Country");
                            } else {
                                fillRepriseCheckout.log(Status.FAIL, "Mini Side Bar: User's Address is not matched");
                            }
                        }else{
                            fillRepriseCheckout.log(Status.FAIL, "Mini Side Bar: User's Address is not Found");
                        }
                        repriseValidateThreeicons(resultDirectory, driver, extent, fillRepriseCheckout, country);
                        reprise.clickSubmit();
                        fillRepriseCheckout.log(Status.INFO, "Selected No option and submit");
                    }
                }
            } catch (Exception e) {
			/*fillRepriseCheckout.log(Status.FAIL,"Test Failed while selecting No Reprise option");
            failWithScreenshot("Test Failed while selecting No Reprise option", resultDirectory, driver, extent, fillRepriseCheckout);
			fillRepriseCheckout.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                e.printStackTrace();
                catchFailDetails(resultDirectory, fillRepriseCheckout, driver, "Test Failed while selecting No Reprise option", e);
            }
        }
    }

    public static void repriseValidateThreeicons(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                                  String country) {
        if(driver!=null) {
            ReprisePage reprise = new ReprisePage(driver);
            threeIcons = fillRepriseCheckout.createNode("validate3Icons", "Validating Three icons");
            try {
                if (country.equals("FR")) {
                    if(reprise.checkThreeIconsPresent(driver)){
                        threeIcons.log(Status.PASS, "3 Icons are present which are: ");
                        threeIcons.log(Status.INFO, reprise.threeIconContext(driver));
                    }else{
                        threeIcons.log(Status.FAIL, "3 Icons are not present");
                    }

                }
            } catch (Exception e) {
			/*fillRepriseCheckout.log(Status.FAIL,"Test Failed while Reprise Done and Go to Next Step");
			failWithScreenshot("Test Failed while Reprise Done and Go to Next Step", resultDirectory, driver, extent, fillRepriseCheckout);
			fillRepriseCheckout.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, fillRepriseCheckout, driver, "Test Failed while validating three icons on Reprise Screen", e);
            }
        }
    }

    public static void repriseDoneAndGoToNextStep(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                                  String country, String PaymentMode) {
        if(driver!=null) {
            ReprisePage reprise = new ReprisePage(driver);
            fillRepriseCheckout = logger.createNode("Reprise", "Checking Reprise");
            try {
                if (country.equals("FR")) {
                    reprise.clickGoToNextStep();
                    fillRepriseCheckout.log(Status.INFO, "Click Go to Next step");
                }
            } catch (Exception e) {
			/*fillRepriseCheckout.log(Status.FAIL,"Test Failed while Reprise Done and Go to Next Step");
			failWithScreenshot("Test Failed while Reprise Done and Go to Next Step", resultDirectory, driver, extent, fillRepriseCheckout);
			fillRepriseCheckout.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, fillRepriseCheckout, driver, "Test Failed while Reprise Done and Go to Next Step", e);
            }
        }
    }


    public static void repriseDoneAndSelectNoTradeInOffer(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                                          String country, String PersoV, String Brand, String PaymentMode) {
        if(driver!=null) {
            ReprisePage reprise = new ReprisePage(driver);
            fillRepriseCheckout = logger.createNode("Reprise", "Checking Reprise");

            try {

                CheckPersonnalInfoCash.validateRetailerAddress(resultDirectory,driver,extent,fillRepriseCheckout,Brand, country);
                CheckPersonnalInfoCash.validateRefundableFeeAmount(resultDirectory,driver,extent,fillRepriseCheckout,Brand, country, PaymentMode);
                PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, fillRepriseCheckout, getbasketPgVehicleName, "Reprise Page", By.xpath("//*[@class='versionLabel']"));
                PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, fillRepriseCheckout, country);

                if (PersoV.equalsIgnoreCase("yes")) {
                    reprise.clickValidateButton(driver,country,Brand);
                    reprise.clickYesButton(driver);
                } else {
                    if (country.equals("FR")) {
                        reprise.clickToConfirmNoTradeInOffer();
                        fillRepriseCheckout.log(Status.INFO, "Click to confirm No Trade In offer");
                    }
                }

            } catch (Exception e) {
			/*fillRepriseCheckout.log(Status.FAIL,"Test Failed while Clicking to confirm No Trade In offer");
            failWithScreenshot("Test Failed while Clicking to confirm No Trade In offer", resultDirectory, driver, extent, fillRepriseCheckout);
			fillRepriseCheckout.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, fillRepriseCheckout, driver, "Test Failed while Clicking to confirm No Trade In offer", e);
            }
        }
    }

    public static void repriseFullPartExchangeStep(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                                  String country) {
        if(driver!=null) {
            ReprisePage reprise = new ReprisePage(driver);
            fillRepriseCheckout = logger.createNode("Full Part Exchange order summary", "Checking Reprise");

            try {
                if (country.equals("FR")) {
                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'Demander une offre de reprise ferme')]"))) {
                        fillRepriseCheckout.log(Status.PASS, "Request a firm trade-in offer button is present");
                        clickElement(driver, By.xpath("//*[contains(text(),'Demander une offre de reprise ferme')]"));
                        driver.navigate().refresh();
                        waitForElementPresent(driver, By.xpath("//*[contains(text(),'Demander une offre de reprise ferme')]"), 90);
                        clickElement(driver, By.xpath("//*[contains(text(),'Demander une offre de reprise ferme')]"));
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
                    fillRepriseCheckout.log(Status.PASS, "Obtain a firm trade-in price is present");
                    //*[contains(text(),'Obtenez un prix de reprise ferme ')]
                    reprise.clickSubmit();
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
                    //V�rifiez les informations
                    reprise.clickSubmit();
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'Quelle est la')]"))) {
                        //*[contains(text(),'Quelle est la version de votre v�hicule ?')]
                        fillRepriseCheckout.log(Status.PASS, "Select the version of your vehicle");
                        clickElement(driver, By.xpath("//select[contains(@class,'custom-select')]"));
                        //option[contains(text(),'GENERATION-I 1.6 BLUEHDI 120 ACTIVE BUSINESS START-STOP')]
                        clickElement(driver, By.xpath("//option[contains(text(),'GENERATION')]"));
                        reprise.clickSubmit();
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
                    //*[contains(text(),'Quel est le kilom�trage actuel de votre v�hicule ?')]
                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'Quel est le kilom')]"))) {
                        fillRepriseCheckout.log(Status.PASS, "Entered current mileage and average annual mileage do you cover with your vehicle");
                        enterData(driver, By.xpath("//*[contains(@name,'overallMileage')]"), "25000");
                        //*[contains(text(),'Quel kilom�trage annuel moyen parcourez-vous avec votre v�hicule ?')]
                        enterData(driver, By.xpath("//*[contains(@name,'annualMileage')]"), "250");
                        reprise.clickSubmit();
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
//*[contains(text(),'�tes-vous le propri�taire de votre v�hicule ?')]
                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'tes-vous le')]"))) {
                        fillRepriseCheckout.log(Status.PASS, "Answered as yes regarding ownership of your vehicle");
                        reprise.clickRepriseYesButton();
                        reprise.clickSubmit();
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
//*[contains(text(),'Votre v�hicule est-il gag� ?')]
                    //*[contains(text(),'Votre véhicule')]
                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'Votre')]"))) {
                        fillRepriseCheckout.log(Status.PASS, "Answered as No regarding details of vehicle damaged");
                        reprise.clickRepriseNoButton();
                        reprise.clickSubmit();
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);

                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'Votre')]"))) {
                        fillRepriseCheckout.log(Status.PASS, "Answered as Yes regarding Is your vehicle roadworthy?");
                        reprise.clickRepriseYesButton();
                        reprise.clickSubmit();
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
                    //*[contains(text(),'Votre v�hicule a-t-il d�j� �t� accident� ?')]

                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'Votre')]"))) {
                        fillRepriseCheckout.log(Status.PASS, "Answered as No regarding Has your vehicle ever been in an accident?");
                        reprise.clickRepriseNoButton();
                        reprise.clickSubmit();
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,reprise.submitBtn,90);
//*[contains(text(),'Votre v�hicule a-t-il �t� import� ?')]
                    if(isElementPresent(driver,By.xpath("//*[contains(text(),'Votre')]"))) {
                        fillRepriseCheckout.log(Status.PASS, "Answered as Yes regarding Was your vehicle imported?");
                        reprise.clickRepriseYesButton();
                        reprise.clickSubmit();
                    }
                    Thread.sleep(10000);
                    waitForElementPresent(driver,By.xpath("//*[contains(text(),'Continuez sans reprise')]"),90);
                    //*[contains(text(),'Votre v�hicule n�cessite une expertise aupr�s')]
                    isElementPresent(driver,By.xpath("//*[contains(text(),'Votre')]"));
                    fillRepriseCheckout.log(Status.PASS, "Continue without Restart button is present");
                    clickElement(driver,By.xpath("//*[contains(text(),'Continuez sans reprise')] | //*[contains(text(),'Continuer sans reprise')]"));

                }
            } catch (Exception e) {
			/*fillRepriseCheckout.log(Status.FAIL,"Test Failed while Reprise Done and Go to Next Step");
			failWithScreenshot("Test Failed while Reprise Done and Go to Next Step", resultDirectory, driver, extent, fillRepriseCheckout);
			fillRepriseCheckout.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, fillRepriseCheckout, driver, "Test Failed while Reprise Done and Go to Next Step", e);
            }
        }
    }


}
