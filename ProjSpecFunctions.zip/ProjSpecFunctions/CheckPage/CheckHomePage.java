package solRetailIHM.ProjSpecFunctions.CheckPage;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckAccount;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckCarFilters;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckCart;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckFooter;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckImage;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckInfoButton;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckNeedHelp;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckPrice;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckRange;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckHomePage extends UniversalMethods {
	
	@Test(description = "Home Page Details")
	public static void HomePageDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
									   ExtentTest logger, String Country, String EmailId, String Name, String Phone, String Address,
									   String Password, String Brand, String PaymentMode) throws Exception {

		try {
			if(driver!=null) {
				if (!Brand.equalsIgnoreCase("AC")) {
					CheckImage.imageCheckOnHP(resultDirectory, driver, extent, logger);
				}

				CheckNeedHelp.needHelpDetails(resultDirectory, driver, extent, logger, Country, Brand, EmailId, Name, Phone, Address);

				//CheckAccount.checkAccountDetails(resultDirectory, driver, extent, logger, Country, EmailId, Name, Phone, Address, Password, Brand,PaymentMode);

				//CheckCart.checkCartDetails(resultDirectory, driver, extent, logger, Country, EmailId, Name, Phone, Address);

				CheckRange.setRange(resultDirectory, driver, extent, logger, Country, Brand);

				if (Country.equalsIgnoreCase("ES") && (!Brand.equals("OV"))) {
					CheckInfoButton.checkInfo(resultDirectory, driver, extent, logger, Brand, Country);
				}

				CheckPrice.verifyCashPrice(resultDirectory, driver, extent, logger, Brand,PaymentMode);
				CheckCarFilters.checkFilterOrder(resultDirectory, driver, extent, logger, Brand, Country);
				CheckCarFilters.checkEnergyFilter(resultDirectory, driver, extent, logger, Brand, Country);
				CheckCarFilters.checkGearboxFilter(resultDirectory, driver, extent, logger, Brand, Country);

				//if(!Brand.equals("AP")) {
				CheckFooter.checkFooters(resultDirectory, driver, extent, logger, Brand, Country);
				//}
			}

		} catch (Exception e1) {
			/*extentHP.log(Status.FAIL,"Error in details of the Homepage validations");
			failWithScreenshot("Error in details of the Homepage validations", resultDirectory, driver, extent, extentHP);
			extentHP.log(Status.FAIL, String.valueOf(e1.getStackTrace()));*/
			catchFailDetails(resultDirectory, extentHP,driver, "Error in details of the Homepage validations",e1);
		}
	}
}
