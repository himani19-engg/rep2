package solRetailIHM.ProjSpecFunctions.CheckPage;

import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.ProjSpecFunctions.CheckCalculatorOnConfigPage;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config.CheckCart;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config.CheckCharacteristics;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config.CheckConfigPageDetails;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config.CheckImageView;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config.CheckInformationForm;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config.CompareAllPrice;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Config.TelephoneNumber;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckConfigPage extends UniversalMethods {
		
	@Test(description = "Config Page Details")
	public static void ConfigPageDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String Brand, String Country, String VehicleChoice, String PostalCode, String EmailId,
			String Password, String Name, String Phone, String Address, String paymentMode) throws InterruptedException {
			ConfigPage err=new ConfigPage(driver);
		if(driver!=null) {
			try {
				//CheckContinueOption.clickContinueBtnAndBackToConfigPage(resultDirectory, driver, extent, logger, Brand, Country);

				CheckInformationForm.FillConfirmationPage(resultDirectory, driver, extent, logger, Brand, Country, PostalCode, EmailId, Password, Name, Phone, Address);

				CheckConfigPageDetails.checkLegalTextOnConfig(resultDirectory, driver, extent, logger, Brand, Country);

				CheckConfigPageDetails.checkDeliveryTextOnConfig(resultDirectory, driver, extent, logger, Brand, Country);

				CheckConfigPageDetails.verifyNotificationFormOnStickyBar(resultDirectory, driver, extent, logger, Brand, Country);

				TelephoneNumber.clickTelephoneNumberLink(resultDirectory, driver, extent, logger, Brand, Country);

				CheckCharacteristics.checkCharactristicHeader(resultDirectory, driver, extent, logger, Brand, Country);

				CheckImageView.configPageImageLink(resultDirectory, driver, extent, logger, Brand, Country);

				if (paymentMode.equalsIgnoreCase("Finance")) {
					CheckCalculatorOnConfigPage.validateDefaultCalculatorPrice(resultDirectory, driver, extent, logger, Brand, Country, paymentMode);
					if ((err.techProblemError(resultDirectory, logger) == null) || (!err.techProblemError(resultDirectory, logger).contains("SE HA PRODUCIDO UN ERROR") == true)) {
						CheckCalculatorOnConfigPage.validateAfterDefaultCalculatorPrice(resultDirectory, driver, extent, logger, Brand, Country, paymentMode);
						if (paymentMode.equalsIgnoreCase("Finance")) {
							CompareAllPrice.comparePriceOnTAEPopupAndConfigPage(resultDirectory, driver, extent, logger, Brand, Country);
						}
					} else {
						err.clickClosePopup(resultDirectory, logger);
					}
				}

				CheckCart.CheckCartConfig(resultDirectory, driver, extent, logger, Brand, Country,paymentMode);

			} catch (Exception e1) {
				failWithScreenshot("Error in Config Page Details", resultDirectory, driver, extent, extentCP);
				extentCP.log(Status.FAIL, String.valueOf(e1.getStackTrace()));
			}
		}
	}
}
