package solRetailIHM.ProjSpecFunctions.CheckPage;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.CheckCarFiltersTrim;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.CheckInformationButton;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.CheckNotificationForm;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.ImageView;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.TrimFooter;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.TrimPageChecks;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.TRIM.VerifyNeedHelp;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)
public class CheckTrimPage extends UniversalMethods {

	@Test(description="Trim Page Check")
	public static void TrimPageCheck(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Brand, String Country, String PostalCode, String EmailId, String Name, String Phone, String Address, String PaymentMode) {

		if(driver!=null) {
			try {

				TrimPageChecks trim = new TrimPageChecks();
				trim.validatePrices(resultDirectory, driver, extent, Country, Brand, PaymentMode);
				if (trim.validateTrimFeatureSwitch(driver, resultDirectory) == true) {
					trim.checkPageObjects(resultDirectory, driver, extent, Country, Brand,PaymentMode);
					trim.checkMainEquipments(resultDirectory, driver, extent);
					trim.checkStandardEquipments(resultDirectory, driver, extent);

					if (!Country.equals("FR")) {
						TrimFooter.checkFooters(resultDirectory, driver, extent, logger, Brand, Country);
					}

					if (!Brand.equals("OV")) {
						CheckInformationButton.checkInfoPopup(resultDirectory, driver, extent, logger, Brand, Country);
					}

					TrimPageChecks.verifySetRange(resultDirectory, driver, extent, logger, Country, Brand);

					// Check Trim car filters
					CheckCarFiltersTrim.checkEnergyFilter(resultDirectory, driver, extent, logger, Brand, Country);
					CheckCarFiltersTrim.checkGearboxFilter(resultDirectory, driver, extent, logger, Brand, Country);

					TrimPageChecks.checkLegalText(resultDirectory, driver, extent, logger, Country, Brand);

					//CheckNotificationForm.fillNotificationFormOnTrim(resultDirectory, driver, extent, logger, Brand, Country, PostalCode, EmailId, Name, Phone, Address);

					// Need help and FAQ
					VerifyNeedHelp.needHelpDetails(resultDirectory, driver, extent, logger, Country, Brand, Country, resultDirectory, Brand, Country);

					ImageView.trimPageImageLink(resultDirectory, driver, extent, logger, Brand, Country);
				}

			} catch (Exception e) {
			/*extentTP.log(Status.FAIL,"Error with Trim Page Check");
			failWithScreenshot("Error with Trim Page Check", resultDirectory, driver, extent, extentTP);
			extentTP.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				e.printStackTrace();
				catchFailDetails(resultDirectory, extentTP, driver, "Error with Trim Page Check", e);
			}
		}
	}

}
