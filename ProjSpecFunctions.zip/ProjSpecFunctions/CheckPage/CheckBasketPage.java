package solRetailIHM.ProjSpecFunctions.CheckPage;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;
import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import solRetailIHM.ProjSpecFunctions.ReprisePXconfig;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.BasketFooter;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.Characteristics;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.CheckBasket;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.CheckNotificationForm;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.CheckPersonalFinanceOnBasket;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.CheckShareEmailOnBasket;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.ImageView;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.VerifyNeedHelp;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckBasketPage extends UniversalMethods {

	public static ExtentTest navigatetobasketpagepricevalidation;

	@Test(description = "Basket page checks")
	public static void basketPageCheck(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String Brand, String Country, String PaymentMode, String VehicleChoice,
			String PostalCode, String EmailId, String Password, String Name, String Phone, String Address, String Plate,
			String PromoCode, String PersoV) throws Exception {
		navigatetobasketpagepricevalidation = extentCP.createNode("Navigate To price validations of dealer and basket page", "Navigating To Basket Page");
		if(driver!=null) {
		try {
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			if(!PersoV.equalsIgnoreCase("yes")){
				BasketFooter.checkFooters(resultDirectory, driver, extent, logger, Brand, Country);

				// Check need help
				VerifyNeedHelp.needHelpDetails(resultDirectory, driver, extent, logger, Country, Brand, EmailId, VehicleChoice, EmailId, Password);

				// Check interior exterior view
				ImageView.configPageImageLink(resultDirectory, driver, extent, logger, Brand, Country);
			}


//		public void navigatetobasketpagepricevalidation(String resultDirectory, ExtentTest , String PaymentMode) {
//				this.resultDirectory = resultDirectory;
//				nodeORSubNode = NodeORSubNode;
//				paymentMode = PaymentMode;
//				Float dealerPageCashPrice = null;
				//				writeToProperties("currentCashPrice", String.valueOf(dealerPageCashPrice));
			if(Country.equalsIgnoreCase("FR"))
				try {
					Float dealerpageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
					Thread.sleep(2000);
					Float basketPageCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//div[@data-testid='TESTING_TOTAL_CASH_PRICE']")));
					if (dealerpageCashPrice - basketPageCashPrice < 1) {
						Thread.sleep(2000);
						navigatetobasketpagepricevalidation.log(Status.PASS, "dealer page Cash price " + dealerpageCashPrice + "is same as basket page cash price");
					} else {
						Thread.sleep(2000);
						navigatetobasketpagepricevalidation.log(Status.FAIL, "dealer Page Cash Price" + dealerpageCashPrice + "is not same as basket page cash price");
					}

//					if (PaymentMode.equalsIgnoreCase("Finance")) {
//						Float dealerPageFinancePrice = Float.parseFloat(readFromProperties("currentFinanceprice"));
//						Float basketPageFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@data-testid='TESTING_TOTAL_MONTHLY_PRICE']")));
//						if (dealerPageFinancePrice - basketPageFinancePrice < 1) {
//							navigatetobasketpagepricevalidation.log(Status.PASS, "dealer page Finance price " + dealerPageFinancePrice + "is same as basket page finance price");
//						} else {
//							navigatetobasketpagepricevalidation.log(Status.FAIL, "dealer Page Finance Price" + dealerPageFinancePrice + "is not same as basket page finance price");
//						}
//					}

				} catch (Exception e) {
					catchFailDetails(resultDirectory, navigatetobasketpagepricevalidation, driver, "Unable to validate prices of delaer and basket", e);
				}
			// Form for more info
			CheckNotificationForm.fillNotificationFormOnBasket(resultDirectory, driver, extent, logger, Brand, Country, PostalCode, EmailId, Name, Phone, Address);

			if(PersoV.equalsIgnoreCase("yes")){
				// Check additional costs
				if(Country.equals("ES")){
					CheckBasket.checkAdditionalCosts(resultDirectory, driver, extent, logger, PaymentMode);
				}
				CheckBasket.checkPxEnabledSwitch(resultDirectory, driver, extent, logger);

			}
			CheckBasket.checkPrice(resultDirectory, driver, extent, logger, PaymentMode);

			// share email on basket
			//CheckShareEmailOnBasket.shareEmailOnBasket(resultDirectory, driver, extent, logger, Brand, Country, EmailId);

			Characteristics.checkCharactristicHeader(resultDirectory, driver, extent, logger, Brand, Country);

			if(PersoV.equalsIgnoreCase("yes")){
				//if(!(Country.equals("FR") && Brand.equals("DS"))) {
				CheckBasket.checkAdditionalServices(resultDirectory, driver, extent, logger, Brand, Country);
				//}
			}

			// Change Payment method
			if (PaymentMode.equalsIgnoreCase("Finance")) {
				PaymentMethodBasketPage.verifyChangePaymentOption(resultDirectory, driver, extent, logger, Brand, Country);
			}

			if (PaymentMode.equalsIgnoreCase("Finance")) {
				if(!Brand.equals("OV")){
					CheckPersonalFinanceOnBasket.validateDefaultPrice(resultDirectory, driver, extent, logger, Brand, Country);
					CheckPersonalFinanceOnBasket.validateAfterChangeToDefaultPrice(resultDirectory, driver, extent, logger, Brand, Country);
				}
			}

			// Part exchange
			if(!Brand.equals("OV")&&PersoV.equalsIgnoreCase("yes")){
				ReprisePXconfig.FillReprise(resultDirectory, driver, extent, logger, Brand, Country, PaymentMode, PostalCode, EmailId, Name, Phone, Plate);
			}

			if(PersoV.equalsIgnoreCase("yes")){
				// Validate promoCode
				//if(Brand.equals("AP")){
				PaymentMethodBasketPage.verifyPromoCode(resultDirectory, driver, extent, logger, Brand, Country, PaymentMode, PromoCode);
				//}
				if(Country.equals("FR")){
					//CheckBasket.checkAssistedSalesPopin(resultDirectory, driver, extent, logger, EmailId, Phone);
				}
				//if ((Country.equalsIgnoreCase("FR")) && (!driver.getCurrentUrl().contains("opel"))) {
				if(Country.equalsIgnoreCase("FR")&&!Brand.equalsIgnoreCase("AC")){
					CheckBasket.checkCarteGrise(resultDirectory, driver, extent, logger, PostalCode, Brand);
				}
				//}

			}
		} catch (Exception e1) {
			failWithScreenshot("Error with Basket page checks", resultDirectory, driver, extent, extentBP);
			e1.printStackTrace();
		}
	}
}
}
