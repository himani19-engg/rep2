package solRetailIHM.ProjSpecFunctions.LoginApplications;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solRetailIHM.PageObjectModel.Digital1.Vauxhall_UK;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class LoginApplicationD1_VX_UK extends UniversalMethods {

	@Test(description = "Login into application VX_UK")
	public static void login(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Digital1, String Brand, String Country) {

		Vauxhall_UK vxuk = new Vauxhall_UK(driver);

		try {
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS) ;
			driver.get(Digital1);
			//Thread.sleep(1000);

			// Log and handle cookie popup
			logger.log(Status.INFO, MarkupHelper.createLabel("Accepting cookie", ExtentColor.BLUE));
			vxuk.clickContAccepter(resultDirectory,logger);

			// Case 1 : direct link
			vxuk.goToVauxhallStore();
			logger.log(Status.INFO,
					MarkupHelper.createLabel("Digital 1 : Clicked on Vauxhall Store Link", ExtentColor.BLUE));

			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));

			waitForUrlContains("https://preprod.vauxhall-uk-sol.psa-testing.summit-automotive.solutions/configurable/",
					driver, 20);
			logger.log(Status.INFO, MarkupHelper.createLabel("Vauxhall Store has opened", ExtentColor.GREEN));

			driver.close();
			driver.switchTo().window(tabs.get(0));

			// Case 2 : order online link
			vxuk.orderOnline();
			logger.log(Status.INFO,
					MarkupHelper.createLabel("Digital 1 : Clicked on Order Online Link", ExtentColor.BLUE));
			//Thread.sleep(2000);

			vxuk.goToVauxhallWebStore();
			logger.log(Status.INFO,
					MarkupHelper.createLabel("Digital 1 : Clicked on GO to Vauxhall Store Link", ExtentColor.BLUE));

			ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(0));
			driver.close();
			driver.switchTo().window(tabs2.get(1));

			waitForUrlContains("https://preprod.vauxhall-uk-sol.psa-testing.summit-automotive.solutions/configurable/",
					driver, 20);
			logger.log(Status.INFO, MarkupHelper.createLabel("Vauxhall Store has opened", ExtentColor.GREEN));

		} catch (Exception e) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Error while Login into application VX_UK", ExtentColor.BLUE));
			failWithScreenshot("Error while Login into application VX_UK", resultDirectory, driver, extent, logger);
		//	driver.close();
			e.printStackTrace();
		}
	}

}
