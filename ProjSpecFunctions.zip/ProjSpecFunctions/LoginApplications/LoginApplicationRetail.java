package solRetailIHM.ProjSpecFunctions.LoginApplications;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.CookieAccepter;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.ProjSpecFunctions.CheckPersonnalInfoCash;
import solRetailIHM.Utilities.UniversalMethods;

import static solo2c.Utilities.UniversalMethods.FailWithScreenshot;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class LoginApplicationRetail extends UniversalMethods {

	public static ExtentTest extentHP;
	public static ExtentTest extentTP;
	
	@Test(description="Login into Application_Retail")
	public static void login(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Digital1, String Digital1Flag, String URL, String Brand, String Country) {
		if(driver!=null) {
			ExtentTest extent3 = logger.createNode("LoginPage", "Login into Application_Retail");
			CookieAccepter accept = new CookieAccepter(driver);
			HomePage hmpg = new HomePage(driver);
			SoftAssert sa = new SoftAssert();
			PersonnalInfoPage pn = new PersonnalInfoPage(driver);
		//	pn.dateValidations(resultDirectory, driver, extent, logger, Country);


			try {
				driver.manage().deleteAllCookies();
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				if (Digital1Flag.equals("yes")) {
					if ((Brand.equals("VX")) && (Country.equals("UK"))) {
						extent3.log(Status.PASS, "We are into Login window of UK and Brand of VX");
						LoginApplicationD1_VX_UK.login(resultDirectory, driver, extent, extent3, Digital1, Brand, Country);
					}

					if ((Brand.equals("AP")) && (Country.equals("FR"))) {
						extent3.log(Status.PASS, "We are into Login window of FR and Brand of AP");
						LoginApplicationD1_AP_FR.login(resultDirectory, driver, extent, extent3, Digital1, Brand, Country);
					}

					if ((Brand.equals("AC")) && (Country.equals("UK"))) {
						extent3.log(Status.PASS, "We are into Login window of UK and Brand of AC");
						LoginApplicationD1_AC_UK.login(resultDirectory, driver, extent, extent3, Digital1, Brand, Country);
					}
				}

				if (Digital1Flag.equals("no")) {
					driver.get(URL);
					driver.navigate().refresh();
				}
				//if(Country.equalsIgnoreCase("ES")){
					/*By emailId= By.xpath("//*[@name='loginfmt']");
					enterData(driver,emailId,"himani.himani@capgemini.com");
					By nextButton =By.xpath("//*[@type='submit']");
					clickElement(driver,nextButton);
					Thread.sleep(5000);
					By noButton=By.xpath("//*[@id='idBtn_Back']");
					clickElement(driver,noButton);
					Thread.sleep(5000);*/
					By emailId= By.xpath("//*[@name='loginfmt']");
					enterData(driver,emailId,"himani.h@external.stellantis.com");
					By nextButton =By.xpath("//*[@type='submit']");
					clickElement(driver,nextButton);
					Thread.sleep(5000);
					enterData(driver,By.xpath("//input[@name=\"UserName\"]"),"SE20443");
                    enterData(driver,By.xpath("//input[@name=\"Password\"]"),"KUMa2007");
					clickElement(driver,By.xpath("//*[@class=\"submit\"]"));
					By noButton=By.xpath("//*[@id='idBtn_Back']");
					clickElement(driver,noButton);
					Thread.sleep(5000);
					//FailWithScreenshot("Home page launched or not", resultDirectory, driver, extent, logger);

				waitForUrlContains("configurable", driver, 10);
				if (driver.getCurrentUrl().contains("configurable")) {
					extent3.log(Status.PASS, "URL launched successfully");
					//	logger.log(Status.PASS, MarkupHelper.createLabel("URL launched successfully", ExtentColor.GREEN));
					//sa.assertTrue(true);
				} else {
					extent3.log(Status.FAIL, "URL could not be launched");
					failWithScreenshot("URL could not be launched", resultDirectory, driver, extent, extent3);
					//sa.assertTrue(false, "URL could not be launched");
				}

				//Thread.sleep(2000);

				// Log and handle cookie popup
				//extent3.log(Status.INFO,"Accepting cookie");
				//accept.clickContAccepter(resultDirectory, extent3);
				accept.clickContRejecter(resultDirectory,extent3);
				accept.saveMySettings(resultDirectory,extent3);
				// checks vehicule on home page

				if (hmpg.getBrand_HomePage(resultDirectory, extent3) != null) {
					extent3.log(Status.PASS, "vehicle name has appeared");
					//		logger.log(Status.PASS, MarkupHelper.createLabel("vehicle name has appeared", ExtentColor.GREEN));
					//sa.assertTrue(true);
				} else {
					failWithScreenshot("vehicle name has not appeared", resultDirectory, driver, extent, extent3);
					//sa.assertTrue(false, "vehicle name has not appeared");
				}
				if (Country.equalsIgnoreCase("FR")) {
					hmpg.getPrice_HomePage_FR(resultDirectory, extent3);
					if (hmpg.getPrice_HomePage_FR(resultDirectory, extent3) != null) {
						extent3.log(Status.PASS, "vehicle Price has appeared");
						//		logger.log(Status.PASS, MarkupHelper.createLabel("vehicle Price has appeared", ExtentColor.GREEN));
						//sa.assertTrue(true);
					} else {
						extent3.log(Status.FAIL, "vehicle Price has not appeared");
						failWithScreenshot("vehicle Price has not appeared", resultDirectory, driver, extent, extent3);
						//sa.assertTrue(false, "vehicle Price has not appeared");
					}
				}
				if (Country.equalsIgnoreCase("UK")) {
					hmpg.getPrice_HomePage_UK(resultDirectory, extent3);
				/*if (hmpg.getPrice_HomePage_UK() != null) {
					extent3.log(Status.PASS,"vehicle Price has appeared");
					sa.assertTrue(true);
				} else {
					extent3.log(Status.FAIL,"vehicle Price has not appeared");
					failWithScreenshot("vehicle Price has not appeared", resultDirectory, driver, extent, extent3);
					sa.assertTrue(false, "vehicle Price has not appeared");
				//	driver.close();
				}*/

				}
				// Close book a test drive
				if ((Country.equalsIgnoreCase("UK")) && (Brand.equalsIgnoreCase("DS"))) {
					hmpg.CloseBookTestDrive(resultDirectory, extent3);
					//extent3.log(Status.INFO,"Closed book a test drive");
				}
				//sa.assertAll();
				//sa.assertAll();
			} catch (Exception e) {
			/*extent3.log(Status.FAIL,"Error while Login into Application_Retail");
			failWithScreenshot("Error while Login into Application_Retail", resultDirectory, driver, extent, extent3);
			extent3.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/

				catchFailDetails(resultDirectory, extent3, driver, "Error while Login into Application_Retail", e);
			} finally {
				extentHP = logger.createNode("HomePage", "Checking details on HomePage");
				extentTP = logger.createNode("TrimPage", "Checking details on TrimPage");
			}
		}
	}

}
