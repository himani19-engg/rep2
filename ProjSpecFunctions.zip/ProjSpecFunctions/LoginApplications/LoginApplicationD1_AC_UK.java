package solRetailIHM.ProjSpecFunctions.LoginApplications;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solRetailIHM.PageObjectModel.Digital1.Citroen_UK;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class LoginApplicationD1_AC_UK  extends UniversalMethods {

	@Test(description="Login into application AC_UK")
	public static void login(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Digital1, String Brand, String Country) {

		Citroen_UK cuk = new Citroen_UK(driver);

		try {
			driver.manage().deleteAllCookies();

			driver.get(Digital1);
			//Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS) ;
			// Log and handle cookie popup
			logger.log(Status.INFO, MarkupHelper.createLabel("Accepting cookie", ExtentColor.BLUE));
			cuk.clickContAccepter(resultDirectory,logger);
			//Thread.sleep(3000);

			// Case 1 : direct link A : Models
			cuk.ClickModels();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Go to models list", ExtentColor.BLUE));
			//Thread.sleep(2000);

			cuk.GoToWebStore();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Go to web store", ExtentColor.BLUE));

			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));

			waitForUrlContains("https://preprod.citroen-uk-sol.psa-testing.summit-automotive.solutions/configurable",
					driver, 30);
			logger.log(Status.INFO, MarkupHelper.createLabel(" Store has opened", ExtentColor.GREEN));

			driver.close();
			driver.switchTo().window(tabs.get(0));

			// Case 2 : direct link B
			cuk.ClickHome();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Go back to Home Page", ExtentColor.BLUE));

			cuk.GoToWebstoreLink();
			logger.log(Status.INFO,
					MarkupHelper.createLabel("Digital 1 : Clicked on Citroen Store Link", ExtentColor.BLUE));

			ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));

			waitForUrlContains("https://preprod.citroen-uk-sol.psa-testing.summit-automotive.solutions/configurable",
					driver, 30);
			logger.log(Status.INFO, MarkupHelper.createLabel(" Store has opened", ExtentColor.GREEN));

			driver.close();
			driver.switchTo().window(tabs2.get(0));

			// Case 2 : direct link C :
			cuk.ClickBuyMenu();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Open Buy Menu", ExtentColor.BLUE));
			//Thread.sleep(2000);

			cuk.SeeOffers();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : See offers", ExtentColor.BLUE));

			cuk.GoToWebstoreLink();
			logger.log(Status.INFO,
					MarkupHelper.createLabel("Digital 1 : Clicked on Citroen Store Link", ExtentColor.BLUE));

			ArrayList<String> tabs3 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs3.get(1));

			waitForUrlContains("https://preprod.citroen-uk-sol.psa-testing.summit-automotive.solutions/configurable",
					driver, 30);
			logger.log(Status.PASS, MarkupHelper.createLabel(" Store has opened", ExtentColor.GREEN));

			driver.switchTo().window(tabs3.get(0));
			driver.close();
			driver.switchTo().window(tabs3.get(1));

		} catch (Exception e) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Error while Login into application AC_UK", ExtentColor.BLUE));
			failWithScreenshot("Error while Login into application AC_UK", resultDirectory, driver, extent, logger);
			//driver.close();
			e.printStackTrace();
		}
	}

}
