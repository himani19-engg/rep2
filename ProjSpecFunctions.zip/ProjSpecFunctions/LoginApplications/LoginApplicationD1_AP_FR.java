package solRetailIHM.ProjSpecFunctions.LoginApplications;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solRetailIHM.PageObjectModel.Digital1.Peugeot_FR;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class LoginApplicationD1_AP_FR  extends UniversalMethods {

	@Test(description="Login into application AP_FR")
	public static void login(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Digital1, String Brand, String Country) {

		Peugeot_FR pfr = new Peugeot_FR(driver);

		try {
			driver.manage().deleteAllCookies();

			driver.get(Digital1);
			//Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS) ;
			// Log and handle cookie popup
			logger.log(Status.INFO, MarkupHelper.createLabel("Accepting cookie", ExtentColor.BLUE));
			pfr.clickContAccepter(resultDirectory,logger);

			// Case 1 : direct link A
			pfr.closeFormPopup();

			pfr.OpenMenu();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Open Menu", ExtentColor.BLUE));

			pfr.ClickBuyMenu();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Open Buy Menu", ExtentColor.BLUE));

			pfr.ClickGoToWebstoreMenu();
			logger.log(Status.INFO,
					MarkupHelper.createLabel("Digital 1 : Clicked on Peugeot Store Link", ExtentColor.BLUE));

			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));

			waitForUrlContains("https://psa-retail11-peugeot-preprod.summit-automotive.solutions/configurable/", driver,
					30);
			logger.log(Status.INFO, MarkupHelper.createLabel(" Store has opened", ExtentColor.GREEN));

			driver.close();
			driver.switchTo().window(tabs.get(0));

			// Case 2 : direct link B
			pfr.ClickHome();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Go back to Home Page", ExtentColor.BLUE));

			pfr.ClickCommandOnline();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Command Online", ExtentColor.BLUE));

			ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));

			waitForUrlContains("https://psa-retail11-peugeot-preprod.summit-automotive.solutions/configurable/", driver,
					30);
			logger.log(Status.INFO, MarkupHelper.createLabel(" Store has opened", ExtentColor.GREEN));

			driver.close();
			driver.switchTo().window(tabs2.get(0));

			// Case 2 : direct link C
			pfr.OpenMenu();
			logger.log(Status.INFO, MarkupHelper.createLabel("Digital 1 : Open Menu", ExtentColor.BLUE));
			//Thread.sleep(1000);

			pfr.GoToWebstoreLink();
			logger.log(Status.INFO,
					MarkupHelper.createLabel("Digital 1 : Clicked on Peugeot Store Link", ExtentColor.BLUE));

			waitForUrlContains("https://psa-retail11-peugeot-preprod.summit-automotive.solutions/configurable/", driver,
					30);
			logger.log(Status.INFO, MarkupHelper.createLabel(" Store has opened", ExtentColor.GREEN));

		} catch (Exception e) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Error while Login into application AP_FR", ExtentColor.BLUE));
			failWithScreenshot("Error while Login into application AP_FR", resultDirectory, driver, extent, logger);
			driver.close();
			e.printStackTrace();
		}
	}

}
