package solRetailIHM.ProjSpecFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.ChooseDealerPage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import static solRetailIHM.PageObjectModel.HomePage.getHomePageVahicleName;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.MonthlyTotalBasketCash;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.getbasketPgVehicleName;
import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;
import static solRetailIHM.ProjSpecFunctions.ChooseDealerCash.*;
import static solRetailIHM.ProjSpecFunctions.GoToBasket.selectedDealerCleanAddress_BP;
import static solRetailIHM.ProjSpecFunctions.ValidateBasket.financePriceOnBasketPage;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckPersonnalInfoCash extends UniversalMethods {

    public static ExtentTest checkAndModifyPersonalDetails;
    public static ExtentTest registerUserPersonalDetails;

    public static ExtentTest retailerDetails;
    public static ExtentTest personalInfoDetails;
    public static ExtentTest PriceValidations;
    public static ExtentTest threeIcons;
    public static ExtentTest PersonnalInfoPg;
    public static ExtentTest validateRefundableAmount;
    public static Float totalMonthlyPriceIdentificationFloat;

    public static Float financePriceOnIdentificationPage;

    public static String rightPanel_personalInfo;

    @Test(description = "Entering personal Details")
    public static void personalDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
                                       ExtentTest logger, String Country, String VehicleChoice, String PostalCode, String City, String NIF,
                                       String EmailId, String Name, String Phone, String Address, String brand) throws Exception {
       // PriceValidations=logger.createNode("PriceValidations","Validate prices on Basket and Personnalinfo page");
        try {
            PersonnalInfoPage pi = new PersonnalInfoPage(driver);
            ChooseDealerPage dea = new ChooseDealerPage(driver);
            //SoftAssert sa = new SoftAssert();

            if (VehicleChoice.equals("ec41")) {

                // enter email
                pi.EmailCash(EmailId);
                logger.log(Status.INFO, MarkupHelper.createLabel("Email is entered", ExtentColor.BLUE));

                // continue login
                pi.ContinueButtonClick();
                waitForPageToLoad(driver, 5);
                pi.ContinueButtonLogin(brand, Country);

                /*// continue
                pi.ContinueButtonClick();*/

            }
            if (!VehicleChoice.equals("ec41")) {

                // click on modify button
                Thread.sleep(3000);
                pi.ClickOnModifyLink();
                logger.log(Status.PASS, MarkupHelper.createLabel("Modify button is clicked", ExtentColor.GREEN));
                Thread.sleep(3000);
                // Check Address
                System.out.println(Address);
                System.out.println(pi.getadressCash());
                if (pi.getadressCash().equals(Address)) {
                    logger.log(Status.PASS, MarkupHelper.createLabel("Address is OK", ExtentColor.GREEN));
                    //sa.assertTrue(true);
                } else {
                    logger.log(Status.WARNING, MarkupHelper.createLabel("Address is not OK", ExtentColor.ORANGE));
                    //sa.assertTrue(false, "Address is not OK");
                }

                // Check Name
                if (pi.getnameCash().equals(Name)) {
                    logger.log(Status.PASS, MarkupHelper.createLabel("Name is OK", ExtentColor.GREEN));
                    //sa.assertTrue(true);
                } else {
                    logger.log(Status.WARNING, MarkupHelper.createLabel("Name is not OK", ExtentColor.ORANGE));
                    //sa.assertTrue(false, "Name is not OK");

                }
                // Check Phone
                if (pi.getphoneCash().equals(Phone)) {
                    logger.log(Status.PASS, MarkupHelper.createLabel("Phone is OK", ExtentColor.GREEN));
                    //sa.assertTrue(true);
                } else {
                    logger.log(Status.WARNING, MarkupHelper.createLabel("Phone is not OK", ExtentColor.ORANGE));
                    //sa.assertTrue(false, "Phone is not OK");
                }
                // Check Email
                if (pi.getemailCash().equals(EmailId)) {
                    logger.log(Status.PASS, MarkupHelper.createLabel("Email is OK", ExtentColor.GREEN));
                    //sa.assertTrue(true);
                } else {
                    logger.log(Status.WARNING, MarkupHelper.createLabel("Email is not OK", ExtentColor.ORANGE));
                    //sa.assertTrue(false, "Email is not OK");
                }

                // NIF has been entered
                if (Country.equals("ES")) {
                    pi.NIF(NIF);
                    logger.log(Status.INFO, MarkupHelper.createLabel("NIF is entered", ExtentColor.BLUE));
                }

                // Validate
                pi.clickValidate();
                logger.log(Status.INFO, MarkupHelper.createLabel("Validate personnal info", ExtentColor.BLUE));

                // check arrival on choose dealer page
                if (Country.equals("FR")) {
                    waitForUrlContains("reprise", driver, 320);
                }

                if ((dea.getDealerHeader().contains("Reprise"))
                        || (dea.getDealerHeader().contains("REPRISE"))) {
                    logger.log(Status.PASS,
                            MarkupHelper.createLabel("Reprise PAGE page has appeared", ExtentColor.GREEN));
                    //sa.assertTrue(true);
                } else {
                    failWithScreenshot("Reprise PAGE page has not appeared", resultDirectory, driver, extent, logger);
                    //sa.assertTrue(false, "Reprise PAGE page has not appeared");
                    //driver.close();

                }

            }
            //sa.assertAll();
        } catch (Exception e) {

            /*e.printStackTrace();
            failWithScreenshot("test Failed", resultDirectory, driver, extent, logger);*/
            catchFailDetails(resultDirectory, logger,driver, "Test Failed while Entering personal Details",e);
            //	driver.close();

        }
    }

    @Test(description = "Check And Modify Personal Details")

    public static void checkAndModifyPersonalDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                     ExtentTest logger, String brand, String Country, String VehicleChoice, String PostalCode, String City, String NIF,
                                                     String EmailId, String Name, String Phone, String Address, String PersoV, String PaymentMode) throws Exception {
        if(driver!=null) {
            checkAndModifyPersonalDetails = logger.createNode("PersonnalInfo", "Checking Personal Info page");
            try {
                PersonnalInfoPage pi = new PersonnalInfoPage(driver);
                ChooseDealerPage dea = new ChooseDealerPage(driver);
                waitForPageToLoad(driver, 10);
                if(!brand.equalsIgnoreCase("OV")){
                    System.out.println(getbasketPgVehicleName);
                    PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, checkAndModifyPersonalDetails, getbasketPgVehicleName, "IdentificationPage", By.xpath("//*[@class='versionLabel']"));
                    PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, checkAndModifyPersonalDetails,Country);
                }

                if (!VehicleChoice.equals("ec41")) {
                    // Modify info
                    if (Country.equals("ES")) {
                        //Thread.sleep(2000);
                        if (brand.equalsIgnoreCase("AP") != true && Country.equalsIgnoreCase("AP") != true) {
                            pi.ClickOnModifyLink();
                        }
                        waitForPageToLoad(driver, 20);
                        Thread.sleep(10000);
                        checkAndModifyPersonalDetails.log(Status.INFO, "Click on modify link");
                        pi.selectCivility(brand);
                        String[] name = Name.split(" ");

                        pi.enterFirstName(name[0], brand);
                        Thread.sleep(1000);
                        checkAndModifyPersonalDetails.log(Status.INFO, "First name entered");

                        pi.enterLastName(name[1], brand);
                        Thread.sleep(1000);
                        checkAndModifyPersonalDetails.log(Status.INFO, "Last name entered");

                        pi.enterPhone_OV(Phone);
                        pi.enterAddress_OV(Address);
                        pi.enterCity_OV(City);
                        pi.enterPostalCode_OV(PostalCode);
                        // NIF has been entered
                        pi.NIF(NIF);
                        checkAndModifyPersonalDetails.log(Status.INFO, "NIF is entered");

                        /*if(brand.equalsIgnoreCase("OV")){
                            enterData(driver,By.xpath("//input[@id='field_companyName']"), "XYZ Company");
                        } else {
                            enterData(driver,By.xpath("//input[@id='field_companyName']"), "XYZ Company");
                        }

                        if(brand.equalsIgnoreCase("OV")){
                            enterData(driver,By.xpath("//input[@id='field_siretNumber']"), "1234567891234");
                        } else {
                            enterData(driver,By.xpath("//input[@id='field_siretNumber']"), "1234567891234");
                        }*/
                        if (!PersoV.equalsIgnoreCase("yes")) {
                          //  pi.validateRetailerAddress(driver, checkAndModifyPersonalDetails);
                        }
                        // Validate
                        //Thread.sleep(1000);
                        pi.clickValidate();
                        waitForPageToLoad(driver, 10);
                        //Thread.sleep(8000);
                        checkAndModifyPersonalDetails.log(Status.INFO, "Validate personnal info");
                    }

                    if (Country.equals("FR")) {
                        if (brand.equals("OV")) {
                            pi.enterEmail_OV(EmailId);
                            pi.enterConfirmEmail_OV(EmailId);
                            pi.enterFirstName_OV("Telly");
                            pi.enterLastName_OV("Talker");
                            pi.enterPhone_OV(Phone);
                            pi.enterAddress_OV(Address);
                            pi.enterCity_OV(City);
                            pi.enterPostalCode_OV(PostalCode);
                            pi.agreeToTermsAndConditions();
                            pi.clickSubmitBtn_OV();
                            checkAndModifyPersonalDetails.log(Status.INFO, "Validate button clicked");
                        } else {
                            //Thread.sleep(3000);
                            String totalMonthlyPriceIdentification=getAnyText(driver,By.xpath("//span[contains(@class,'price-total-price')]")).replace(" ","").replace(",",".");
                            totalMonthlyPriceIdentificationFloat=extractFloatFromString(totalMonthlyPriceIdentification);
                            if((MonthlyTotalBasketCash-totalMonthlyPriceIdentificationFloat)<=1){
                                checkAndModifyPersonalDetails.log(Status.PASS, "Monthly Total Basket Cash Price is same as on Identification/Personal Info Screen");
                            }else{
                                checkAndModifyPersonalDetails.log(Status.FAIL, "Monthly Total Basket Cash Price is not same as on Identification/Personal Info Screen");
                            }
                            if (PaymentMode.equalsIgnoreCase("Finance")) {
                                financePriceOnIdentificationPage = extractFloatFromString(getAnyText(driver, By.xpath("//p[@class='prix_mois']")).replace(" ", "").replace(",", "."));

                                if ((financePriceOnBasketPage - financePriceOnIdentificationPage) <= 1) {
                                    checkAndModifyPersonalDetails.log(Status.PASS, "finance Price On Basket Page " + financePriceOnBasketPage + " is same as finance Price On Identification Page " + financePriceOnIdentificationPage);
                                } else {
                                    checkAndModifyPersonalDetails.log(Status.PASS, "finance Price On Basket Page " + financePriceOnBasketPage + " is not same as finance Price On Identification Page " + financePriceOnIdentificationPage);
                                }
                            }

                            pi.clickValidate_FR();
                            checkAndModifyPersonalDetails.log(Status.INFO, "Validate button clicked");
                         if(Country.equalsIgnoreCase("FR")) {
                                try {
                                    Float basketPageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
                                    //   waitForElementPresent(driver, By.xpath("//span[@class='price-total-price']"), 50);
                                    Float PersonalinfoCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@class='price-total-price']")).replace(" ", "").replace(",", "."));
                                    Thread.sleep(2000);
                                    if (basketPageCashPrice - PersonalinfoCashPrice < 1) {
                                        Thread.sleep(2000);
                                       logger.log(Status.PASS, "Basket page Cash price " + basketPageCashPrice + "is same as Personalinfopage cash price");
                                    } else {
                                        Thread.sleep(2000);
                                       logger.log(Status.FAIL, "Basket Page Cash Price" + basketPageCashPrice + "is not same as Personalinfopage cash price");
                                    }
                                    if(PaymentMode.equalsIgnoreCase("Finance")){
                                        Float basketPageFinancePrice = Float.parseFloat(readFromProperties("currentCashPrice"));
                                        //   waitForElementPresent(driver, By.xpath("//span[@class='price-total-price']"), 50);
                                        Float PersonalinfoFinancePrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@class='span1 ng-star-inserted']")).replace(" ", "").replace(",", "."));
                                        Thread.sleep(2000);
                                        if (basketPageFinancePrice - PersonalinfoFinancePrice < 1) {
                                            Thread.sleep(2000);
                                            logger.log(Status.PASS, "Basket page Finance price " + basketPageFinancePrice + "is same as Personalinfopage Finance price");
                                        } else {
                                            Thread.sleep(2000);
                                            logger.log(Status.FAIL, "Basket Page Finance Price" + basketPageFinancePrice + "is not same as Personalinfopage Finance price");
                                        }
                                    }
                                    // }


                                } catch (Exception e) {
                                    catchFailDetails(resultDirectory, logger, driver, "Unable to validate the prices", e);
                                    e.printStackTrace();
                                }
                            }
                        }
                    }

                }
            } catch (Exception e) {
            /*checkAndModifyPersonalDetails.log(Status.FAIL, "Test Failed with Check And Modify Personal Details");
            failWithScreenshot("Test Failed Check And Modify Personal Details", resultDirectory, driver, extent, checkAndModifyPersonalDetails);
			checkAndModifyPersonalDetails.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, checkAndModifyPersonalDetails, driver, "Test Failed Check And Modify Personal Details", e);
            }
        }
    }

    @Test(description = "Validate Retailer's Address on Personal Info./Identification Page")
    public  static void validateRetailerAddress(String resultDirectory,WebDriver driver, ExtentReports extent, ExtentTest logger,String brand, String Country){

        retailerDetails = logger.createNode("RetailerAdressDetails", "Validate Retailer's Address on Personal Info Page");
       // retailerDetails = logger.createNode("PersonnalInfo", "Validate Retailer's Address on Personal Info Page");
        PersonnalInfoPage pi=new PersonnalInfoPage(driver);
        try{
            //driver.navigate().refresh();
            String retailerAddressOnPersonalInfoPage=pi.getRetailerAddress(driver).replace("  "," ");
            retailerDetails.log(Status.INFO, "Mini Side Bar: Retailer's Address on Identification/Personal Info page : " +retailerAddressOnPersonalInfoPage );
            if(brand.equalsIgnoreCase("OV")!=true) {
              //  if(Country.equalsIgnoreCase("FR")) {
                    for (int i = 0; i < selectedDealerCleanAddress_BP.length; i++) {
                        System.out.println(selectedDealerCleanAddress_BP[i]);
                        System.out.println(retailerAddressOnPersonalInfoPage);
                        if (retailerAddressOnPersonalInfoPage.toUpperCase().contains(selectedDealerCleanAddress_BP[i].toUpperCase())) {
                            retailerDetails.log(Status.PASS, "Mini Side Bar: Line No. " + (i + 1) + " of Retailer's Address on Identification/Personal Info page : " + selectedDealerCleanAddress_BP[i] + " is matching with the basket page: ");
                        } else {
                            retailerDetails.log(Status.FAIL, "Mini Side Bar: Line No. " + (i + 1) + " of Retailer's Address on Identification/Personal Info page : " + selectedDealerCleanAddress_BP[i] + " is not matching with the basket page");
                        }
                    }
                }
                //}

            rightPanel_personalInfo=getAnyText(driver,By.xpath("//div[@class='bloc-recap-detail']"));
            retailerDetails.log(Status.INFO, "<=====Right Side Panel of Personal Info Page/Identification Page Starts here=====>");
            retailerDetails.log(Status.INFO,rightPanel_personalInfo );
            retailerDetails.log(Status.INFO, "<=====Right Side Panel of Personal Info Page/Identification Page Ends here=====>");
            validatePersonalInfoThreeIcons(resultDirectory,driver, extent, retailerDetails,brand, Country);
        }catch (Exception e){
            catchFailDetails(resultDirectory, retailerDetails,driver, "Mini Side Bar: Unable to validate Retailer's Address on Identification/Personal Info page As compared with Basket Page",e);
        }
    }

//    @Test(description = "Validate price validations of Basket and Personalinfo page")
//   public static void validationforpriceinBasketAndPersonalinfo(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger, String brand, String Country) {
//     validationforpriceinBasketAndPersonalinfo   = logger.createNode("PriceValidations", "Validate prices on Basket and Personnalinfo page");
//       validationforpriceinBasketAndPersonalinfo=extentCP.createNode("PriceValidations","Validate prices on Basket and Personnalinfo page");
//        PersonnalInfoPage pi = new PersonnalInfoPage(driver);
//        try {
//          //  if (brand.equalsIgnoreCase("AP") && (Country.equalsIgnoreCase("FR"))) {
//                Float basketPageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
//                Float PersonalinfoCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@class='price-total-price']")));
//                if (basketPageCashPrice - PersonalinfoCashPrice < 1) {
//                    PriceValidations.log(Status.PASS, "Basket page Cash price " + basketPageCashPrice + "is same as Personalinfopage cash price");
//                } else {
//                    PriceValidations.log(Status.FAIL, "Basket Page Cash Price" + basketPageCashPrice + "is not same as Personalinfopage cash price");
//                }
//           // }
//        } catch (Exception e) {
//            catchFailDetails(resultDirectory, PriceValidations, driver, "Unable to validate the prices", e);
//        }
//    }

    @Test(description = "Validate personal Information on OrderValidation Page")
    public  static void validatePersonalInfo(String resultDirectory,WebDriver driver, ExtentReports extent, ExtentTest logger,String brand, String Country,String EmailId, String PostalCode, String City, String Phone, String Name){

        personalInfoDetails = logger.createNode("PersonalInfoDetails", "Validate Personal Information on Order Validation Page");
        // retailerDetails = logger.createNode("PersonnalInfo", "Validate Retailer's Address on Personal Info Page");
        PersonnalInfoPage pi=new PersonnalInfoPage(driver);
        try{
            if(brand.equalsIgnoreCase("OV")!=true) {

                waitForElementPresent(driver, By.xpath("//app-recap-personal-info//*[contains(@class,\"recap-aside-seller\")]"), 50);
                String userAddress = getAnyText(driver, By.xpath("//app-recap-personal-info//*[contains(@class,\"recap-aside-seller\")]"));

                System.out.println(userAddress);
                if (userAddress != null) {
                    if (userAddress.contains(EmailId)
                            || userAddress.contains(PostalCode)
                            && userAddress.contains(City)
                            && userAddress.contains(Phone)
                            && userAddress.contains(Name)
                            && userAddress.contains("Test")
                            &&(userAddress.contains("France")
                            || userAddress.contains("España"))
                    ) {
                        if(Country.equalsIgnoreCase("FR")) {
                            personalInfoDetails.log(Status.PASS, "Mini Side Bar: User's Address is matched with the information we have which is: Email id :" + EmailId + ", City :" + City + ", Phone Number :" + Phone + ", User's Name :" + Name + ", User's Country :France");
                        }else{
                            personalInfoDetails.log(Status.PASS, "Mini Side Bar: User's Address is matched with the information we have which is: Email id :" + EmailId + ", City :" + City + ", Phone Number :" + Phone + ", User's Name :" + Name + ", User's Country :Espa�a");
                        }
                    } else {
                        personalInfoDetails.log(Status.FAIL, "Mini Side Bar: User's Address is not matched");
                    }
                } else {
                    personalInfoDetails.log(Status.FAIL, "Mini Side Bar: User's Address is not Found");
                }

            }

        } catch(Exception e){
            catchFailDetails(resultDirectory, personalInfoDetails,driver, "Mini Side Bar: Unable to validate Retailer's Address on Identification/Personal Info page As compared with Basket Page",e);
        }
    }


    @Test(description = "Validate 3 icons on Personal Info./Identification Page")
    public  static void validatePersonalInfoThreeIcons(String resultDirectory,WebDriver driver, ExtentReports extent, ExtentTest logger,String brand, String Country) {
        //threeIcons = logger.createNode("PersonnalInfo", "Validate 3 icons on Personal Info Page");
        PersonnalInfoPage pi = new PersonnalInfoPage(driver);
        try {
            if (brand.equalsIgnoreCase("OV") != true && Country.equalsIgnoreCase("FR")) {

                if (pi.validateThreeicons(driver)) {
                    logger.log(Status.PASS, "3 icons on Identification/Personal Info page is present and those are: ");
                    logger.log(Status.INFO, pi.contextOfThreeicons(driver));
                } else {
                    logger.log(Status.FAIL, "3 icons on Identification/Personal Info page is not present");
                }
            }

        }catch (Exception e){
            catchFailDetails(resultDirectory, logger,driver, "Unable to validate 3 icons on Identification/Personal Info page",e);
        }
    }


//        if (brand.equalsIgnoreCase("AP") && (Country.equalsIgnoreCase("FR"))) {
//            try {
//                Float basketPageCashPrice = Float.parseFloat(readFromProperties("currentCashPrice"));
//             //   waitForElementPresent(driver, By.xpath("//span[@class='price-total-price']"), 50);
//                Float PersonalinfoCashPrice = extractFloatFromString(getAnyText(driver, By.xpath("//span[@class='price-total-price']")).replace(" ", "").replace(",", "."));
//                Thread.sleep(2000);
//                if (basketPageCashPrice - PersonalinfoCashPrice < 1) {
//                    Thread.sleep(2000);
//                    logger.log(Status.PASS, "Basket page Cash price " + basketPageCashPrice + "is same as Personalinfopage cash price");
//                } else {
//                    Thread.sleep(2000);
//                    logger.log(Status.FAIL, "Basket Page Cash Price" + basketPageCashPrice + "is not same as Personalinfopage cash price");
//                }
//                // }
//
//
//            } catch (Exception e) {
//                catchFailDetails(resultDirectory, logger, driver, "Unable to validate the prices", e);
//                e.printStackTrace();
//            }
 //       }



 //   }

    @Test(description = "Validate Refundable fee amount on Personal Info./Identification Page")
    public  static void validateRefundableFeeAmount(String resultDirectory,WebDriver driver, ExtentReports extent, ExtentTest logger,String brand, String Country, String PaymentMode){
        PersonnalInfoPage pi=new PersonnalInfoPage(driver);
        try{
            if(PaymentMode.equals("Cash") && driver!=null) {
                float actualAmount;
                if (isElementPresent(driver, By.xpath("//p[contains(@class,'ng-star-inserted')]//span"))) {
                    validateRefundableAmount = logger.createNode("Refundable fee Amount details", "Validate Refundable Fee Amount on Personal Info Page");
                    String totalAmount = getAnyText(driver, By.xpath("//*[contains(@class,'price-total-price')]")).replace(",", ".").trim().toString();
                    String refundableFeeAmount = getAnyText(driver, By.xpath("//*[contains(@class,'payment-type-price')]")).trim().toString();
                    String expectedAmount = getAnyText(driver, By.xpath("//p[contains(@class,'ng-star-inserted')]//span")).replace(",", ".").trim().toString();
                    System.out.println(totalAmount + " " + refundableFeeAmount + " " + expectedAmount);
                    int length = totalAmount.length();
                    totalAmount = totalAmount.substring(0, length - 1).trim();
                    refundableFeeAmount = refundableFeeAmount.substring(0, refundableFeeAmount.length() - 1).trim();
                    expectedAmount = expectedAmount.substring(0, expectedAmount.length() - 1).trim();
                    System.out.println(totalAmount + " " + refundableFeeAmount + " " + expectedAmount);
                    actualAmount = extractFloatFromString(totalAmount) - Float.parseFloat(refundableFeeAmount);

                    System.out.println(actualAmount);
                    if (actualAmount == extractFloatFromString(expectedAmount)) {
                        validateRefundableAmount.log(Status.PASS, "After substract refeundable fee amount " + refundableFeeAmount + " from total amount " + totalAmount + " then remaining amount is matched with actual amount and Amount will be " + actualAmount);
                    } else {
                        validateRefundableAmount.log(Status.FAIL, "After substract refeundable fee amount " + refundableFeeAmount + " from total amount " + totalAmount + " then remaining amount is matched with actual amount and Amount will be " + actualAmount);
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            catchFailDetails(resultDirectory, retailerDetails,driver, "Mini Side Bar: Unable to validate Retailer's Address on Identification/Personal Info page As compared with Basket Page",e);
        }
    }

    @Test(description = "Register User Personal Details")
    public static void registerUserPersonalDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                   ExtentTest logger, String country, String vehicleChoice, String postalCode, String city, String NIF,
                                                   String emailId, String phone, String address,String Brand, String PersoV) throws Exception {
        if(driver!=null) {
            registerUserPersonalDetails = logger.createNode("PersonnalInfo", "Checking Personal Info page");
            try {
                PersonnalInfoPage pi = new PersonnalInfoPage(driver);

                /*
                 * pi.enterConfirmEmail(emailId); Thread.sleep(1000); logger.log(Status.INFO,
                 * MarkupHelper.createLabel("Confirm email id", ExtentColor.BLUE));
                 */
                //Thread.sleep(8000);
                pi.selectCivility(Brand);
                Thread.sleep(1000);
                registerUserPersonalDetails.log(Status.INFO, "Check civility box");

                pi.Address(address, Brand);
                Thread.sleep(1000);
                registerUserPersonalDetails.log(Status.INFO, "Address entered");

                pi.ZipCode(postalCode, Brand);
                Thread.sleep(1000);
                registerUserPersonalDetails.log(Status.INFO, "Postal code entered");

                pi.City(city, Brand);
                Thread.sleep(1000);
                registerUserPersonalDetails.log(Status.INFO, "City entered");

                pi.enterFirstName("Talker", Brand);
                Thread.sleep(1000);
                registerUserPersonalDetails.log(Status.INFO, "First name entered");

                pi.enterLastName("Telly", Brand);
                Thread.sleep(1000);
                registerUserPersonalDetails.log(Status.INFO, "Last name entered");

                pi.enterPhone(phone, Brand);
                Thread.sleep(1000);
                registerUserPersonalDetails.log(Status.INFO, "Phone number entered");

                if (country.equals("ES")) {
                    pi.NIF(NIF);
                    Thread.sleep(1000);
                    registerUserPersonalDetails.log(Status.INFO, "NIF entered");
                }
				 if(!PersoV.equalsIgnoreCase("yes")){
                        pi.validateRetailerAddress(driver,checkAndModifyPersonalDetails);
                    }
                pi.clickValidate();
                Thread.sleep(8000);
                registerUserPersonalDetails.log(Status.INFO, "Validate button clicked");

            } catch (Exception e) {
            /*registerUserPersonalDetails.log(Status.FAIL, "Test Failed with Register User Personal Details");
            failWithScreenshot("Test Failed with Register User Personal Details", resultDirectory, driver, extent, registerUserPersonalDetails);
			registerUserPersonalDetails.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, registerUserPersonalDetails, driver, "Test Failed with Register User Personal Details", e);
            }
        }
    }
    @Test(description = "Personal Info page Details")
    public static void PersonalInfoPgDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                   ExtentTest logger, String brand, String Country, String PaymentMode) throws Exception {
        PersonnalInfoPg = logger.createNode("PersonnalInfo", "Checking details on Personal Info Page");


        CheckPersonnalInfoCash.validateRetailerAddress(resultDirectory,driver,extent,PersonnalInfoPg,brand, Country);
        CheckPersonnalInfoCash.validateRefundableFeeAmount(resultDirectory,driver,extent,PersonnalInfoPg,brand, Country,PaymentMode);
        PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, PersonnalInfoPg, getbasketPgVehicleName, "PersonalInfo Page", By.xpath("//*[@class='versionLabel']"));
        PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, PersonnalInfoPg, Country);


    }

    }
