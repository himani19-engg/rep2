package solRetailIHM.ProjSpecFunctions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.OrderPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class FinaliseOrderFinance extends UniversalMethods {

	@Test(description = "Validating Order")
	public static void orderValidation(WebDriver driver, ExtentReports extent, String resultDirectory, ExtentTest logger, String Brand,
			String Country) throws Exception {

		try {

			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			OrderPage or = new OrderPage(driver);
			HomePage hmpg = new HomePage(driver);
			//SoftAssert sa = new SoftAssert();

			// Close book a test drive
			if ((Country.equalsIgnoreCase("UK")) && (Brand.equalsIgnoreCase("DS"))) {
				hmpg.CloseBookTestDrive(resultDirectory,logger);
			}

			// click on terms and condition checkbox
			or.TCCheckbox(driver);
			logger.log(Status.INFO, MarkupHelper.createLabel("Clicked terms and condition checkbox", ExtentColor.BLUE));

			// click on terms and condition checkbox
			or.DCheckbox();
			logger.log(Status.INFO, MarkupHelper.createLabel("Clicked delivery checkbox", ExtentColor.BLUE));

			// Validate order
			or.Validate();
			logger.log(Status.INFO, MarkupHelper.createLabel("Order validation", ExtentColor.BLUE));

			waitForUrlContains("/checkout/confirmation", driver, 240);

			// Validate arriving on order page
			if (Country.equalsIgnoreCase("UK")) {
				if (or.OrderConfirmation().equalsIgnoreCase("Your vehicle is ordered")) {
					logger.log(Status.PASS,"YOUR VEHICULE IS ORDERED");
					//sa.assertTrue(true);
				} else {
					logger.log(Status.FAIL,"YOUR VEHICULE IS NOT ORDERED");
					//sa.assertTrue(false, "YOUR VEHICULE IS NOT ORDERED");
					//driver.quit();
					//org.testng.Assert.fail();
				}
			}

			if (Country.equalsIgnoreCase("FR")) {
				if (or.OrderConfirmation().equalsIgnoreCase("Votre véhicule est commandé")) {
					logger.log(Status.PASS,"YOUR VEHICULE IS ORDERED");
					//sa.assertTrue(true);
				} else {
					logger.log(Status.FAIL,"YOUR VEHICULE IS NOT ORDERED");
					//sa.assertTrue(false, "YOUR VEHICULE IS NOT ORDERED");
				//	driver.quit();
					// org.testng.Assert.fail();
				}
			}
			//sa.assertAll();
		} catch (Exception e1) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Error with Validating Order", ExtentColor.RED));
			e1.printStackTrace();

		}
	}

}
