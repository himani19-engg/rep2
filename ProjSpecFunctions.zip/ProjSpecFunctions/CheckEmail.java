package solRetailIHM.ProjSpecFunctions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.OrderEmailPage;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckAccount;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class CheckEmail extends UniversalMethods {

    public static void validateEmail(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                     String Country, String emailId, String MopValidation) {
        try {
            driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
            OrderEmailPage emailOrder = new OrderEmailPage(driver);
            SoftAssert sa = new SoftAssert();
            /*
             * //Check Email if (MopValidation.equals("yes")) {
             * waitForUrlContains("payment/confirmation", driver, 120); if
             * (emailOrder.goToYopmailAndActivateTheAccount(Country)){
             *
             * logger.log(Status.PASS, MarkupHelper.createLabel("Email has been validated",
             * ExtentColor.GREEN)); } else {
             * FailWithScreenshot("Email has not been validated", resultDirectory, driver,
             * extent, logger); driver.quit(); } }}
             */
            if (MopValidation.equals("yes")) {
                waitForUrlContains("payment/confirmation", driver, 60);
                emailOrder.openNewTab(driver);
                ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                emailOrder.openYOPEmail(resultDirectory,logger,logger);
                //logger.log(Status.INFO, MarkupHelper.createLabel("Open YOP email", ExtentColor.BLUE));
                emailOrder.enterEmailId(emailId,resultDirectory,logger);
                //logger.log(Status.INFO, MarkupHelper.createLabel("Enter email Id", ExtentColor.BLUE));
                emailOrder.confirmEmail(resultDirectory,logger);
                //logger.log(Status.INFO, MarkupHelper.createLabel("Confirm email Id", ExtentColor.BLUE));
                emailOrder.clickRefresh(resultDirectory,logger);
                //logger.log(Status.INFO, MarkupHelper.createLabel("Refresh email", ExtentColor.BLUE));
                Thread.sleep(500);
                emailOrder.switchToMailFrame();
                System.out.println("switch frame");

                /*
                 * if(emailOrder.verifyEmailText(Country)) logger.log(Status.PASS,
                 * MarkupHelper.createLabel("Email text is present", ExtentColor.GREEN)); else
                 * logger.log(Status.WARNING,
                 * MarkupHelper.createLabel("Email text is not present", ExtentColor.ORANGE));
                 */
                String fromEmailText = emailOrder.getFromEmailText(resultDirectory, CheckAccount.accountCheck);
                if (fromEmailText.contains("Citroën") || fromEmailText.contains("DS")
                        || fromEmailText.contains("Peugeot")) {
                    logger.log(Status.PASS,"Brand text is present in email address");
                    //sa.assertTrue(true);
                } else {
                    logger.log(Status.FAIL,"Brand text is not present in email address");
                    //sa.assertTrue(false, "Brand text is not present in email address");
                }

//				emailOrder.deleteEmail();
//				logger.log(Status.PASS, MarkupHelper.createLabel("Delete email", ExtentColor.BLUE));

                driver.switchTo().defaultContent();
                Thread.sleep(2000);
                // Close Tab
                driver.close();
                Thread.sleep(2000);
                // Switch to mainTab
                driver.switchTo().window(tabs.get(0));
                logger.log(Status.INFO,"Switch to main tab");
                System.out.println("URL : " + driver.getCurrentUrl());
                Thread.sleep(1000);
            }
            sa.assertAll();
        } catch (Exception e) {
            /*logger.log(Status.INFO, MarkupHelper.createLabel("Error with Validating Email", ExtentColor.RED));
            failWithScreenshot("test Failed", resultDirectory, driver, extent, logger);
            e.printStackTrace();*/
            catchFailDetails(resultDirectory, logger,driver, "Error with Validating Email",e);
            //	driver.close();
        }

    }
}
