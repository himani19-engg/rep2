package solRetailIHM.ProjSpecFunctions;

import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.LoginUserPage;
import solRetailIHM.PageObjectModel.RegistrationPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class UserRegistration extends UniversalMethods {
	public static ExtentTest registerUser;
	@Test(description = "Registration")
	public static void registration(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String brand, String country) {
		if(driver!=null) {
			RegistrationPage RP = new RegistrationPage(driver);
			HomePage homePage = new HomePage(driver);
			registerUser = logger.createNode("RegisterUserPage", "Register user");
			try {
				driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				homePage.clickonAccountButton(resultDirectory, registerUser);
				//registerUser.log(Status.INFO, "Click on Account Icon");
				//Thread.sleep(4000);
				RP.clickOnAccountRegisterButton(resultDirectory, registerUser);
				//Thread.sleep(4000);
				String userEmail = RP.fillRegistrationForm(country, brand, resultDirectory, extent, registerUser);
				registerUser.log(Status.INFO, "User registration form has been filled: " + userEmail);
				Thread.sleep(500);
				if (RP.getHeaderMessage(resultDirectory, registerUser).equalsIgnoreCase("ACTIVAR TU CUENTA")
						|| RP.getHeaderMessage(resultDirectory, registerUser).equalsIgnoreCase("ACTIVER MON COMPTE")
						|| RP.getHeaderMessage(resultDirectory, registerUser).equalsIgnoreCase("ACTIVEZ VOTRE COMPTE")) {
					registerUser.log(Status.PASS, "Page header is validated and correct");
					//Assert.assertTrue(true);
				} else {
					//registerUser.log(Status.FAIL, "Page header is not correct");
					failWithScreenshot("Page header is not correct", resultDirectory, driver, extent, registerUser);
					//Assert.assertTrue(false, "Page header is not correct");
				}
				Thread.sleep(500);
				RP.clickOnContinueButton(resultDirectory, registerUser);
				//registerUser.log(Status.INFO, "Click on continue button");
				Thread.sleep(3000);
				RP.openNewTab(driver);
				//Thread.sleep(1000);
				driver.close();
				ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(0));
				//Thread.sleep(500);
			} catch (Exception e) {
				e.printStackTrace();
				catchFailDetails(resultDirectory, registerUser, driver, "Test Failed while Registering User", e);
			}
		}
	}

	@Test(description = "Login and Logout")
	public static void login(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Brand, String country, String email, String password, String PaymentMode) {
		if(driver!=null) {
			HomePage homePage = new HomePage(driver);
			LoginUserPage loginPage = new LoginUserPage(driver);
			ExtentTest validateLogin = logger.createNode("ValidateLogin", "Validate Login");

			try {
				driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
				homePage.clickonAccountButton(resultDirectory,validateLogin);
				homePage.clickonConnexionButton(country, resultDirectory, validateLogin,PaymentMode,Brand);
				//validateLogin.log(Status.INFO, "Click on Connexion button");

				loginPage.enterEmail(email, resultDirectory, validateLogin);
				//validateLogin.log(Status.INFO, "Entered email");
				//Thread.sleep(500);
				loginPage.enterPassword(password, resultDirectory, validateLogin);
				validateLogin.log(Status.INFO, "Entered password");
				//Thread.sleep(500);
				loginPage.validate(resultDirectory, validateLogin);
				//logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Validate button", ExtentColor.BLUE));
				validateLogin.log(Status.INFO, "Clicked on Validate button");
				waitForUrlContains("my-account", driver, 60);
				validateLogin.log(Status.INFO, "The account page has appeared");
				//Thread.sleep(500);
				if (loginPage.checkLogoutLink(country)) {
					validateLogin.log(Status.PASS, "New user is activated and successfully logged in");
				} else {
					failWithScreenshot("Not able to login with new user", resultDirectory, driver, extent, validateLogin);
				}
				homePage.clickonLogout(resultDirectory, validateLogin);
				//validateLogin.log(Status.INFO, "Click on Logout link");
				//Thread.sleep(1000);
				if (homePage.checkHomePageIsDisplayed(resultDirectory, validateLogin)) {
					validateLogin.log(Status.PASS, "Homepage is displayed after Logout");
				} else {
					validateLogin.log(Status.FAIL, "Homepage is not displayed after Logout");
				}
				System.out.println("Title new: " + driver.getTitle());
				System.out.println(driver.getCurrentUrl());
				//Thread.sleep(1000);
			} catch (Exception e) {
			/*validateLogin.log(Status.FAIL,"Test failed while validating login");
			failWithScreenshot("Test failed while validating login", resultDirectory, driver, extent, validateLogin);
			validateLogin.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, validateLogin, driver, "Test failed while validating login", e);
			}
		}
	}
	
	public static void checkExistingUserEmail(String resultDirectory, WebDriver driver, ExtentTest logger, String url,
			String brand, String country, String emailId) 
	
	{
		if(driver!=null) {
			ExtentTest existingUserEmail = extentHP.createNode("CheckExistingUser", "Check existing user email");

			RegistrationPage registerPage = new RegistrationPage(driver);
			HomePage homePage = new HomePage(driver);
			String errorMsg = "";
			try {
				homePage.clickonAccountButton(resultDirectory, existingUserEmail);

				//existingUserEmail.log(Status.INFO, "Click on Account Icon");
				// Thread.sleep(5000);
				registerPage.clickOnAccountRegisterButton(resultDirectory, existingUserEmail);
				existingUserEmail.log(Status.INFO, "User register button is clicked");
				Thread.sleep(10000);
				driver.navigate().refresh();
				String curUrl= URLDecoder.decode(driver.getCurrentUrl(), "UTF-8");
				if(curUrl.contains("Timestamp")){
					driver.navigate().back();
					driver.navigate().back();
					registerPage.clickOnAccountRegisterButton(resultDirectory, existingUserEmail);
				}
				errorMsg = registerPage.getExistingUserEmailErrorMessage(emailId);
				if(errorMsg==null){
					driver.navigate().back();
					registerPage.clickOnAccountRegisterButton(resultDirectory,existingUserEmail);
					errorMsg = registerPage.getExistingUserEmailErrorMessage(emailId);
				}
				if (errorMsg.contains("Cette adresse email est déjà associée à un compte")
						|| errorMsg.contains("Este email")
						|| errorMsg.contains("email saisie")
						|| errorMsg.contains("We already have an account for you")
						|| (errorMsg.contains("El correo electr")&& errorMsg.contains("nico ya existe"))
						//|| errorMsg.contains("L'adresse e-mail existe déjà"))
						|| errorMsg.contains("adresse e-mail existe")) {
					existingUserEmail.log(Status.PASS, "Error message displayed for existing user email while creating account");
				} else {
					failWithScreenshot("Error message not displayed for existing user email while creating account", resultDirectory, driver, existingUserEmail);
				}
				driver.navigate().to(url);
				Thread.sleep(1000);
			} catch (Exception e) {
			/*failWithScreenshot("Failed test case while checking existing user email on Registration page", resultDirectory, driver, existingUserEmail);
			e.printStackTrace();*/
				catchFailDetails(resultDirectory, existingUserEmail, driver, "Failed test case while checking existing user email on Registration page", e);
			}
		}
	}
}