package solRetailIHM.ProjSpecFunctions;

import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.extentCP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.BasketPage;
import solRetailIHM.PageObjectModel.ChooseDealerPage;
import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.PageObjectModel.DealerStepBeforeBasketPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)


@Test(description = "Navigate To Basket and Validations")
public class GoToBasket extends UniversalMethods {
	public static Float monthlyTotalPriceDealer;
	public static ExtentTest navigateToBasketAndValidation;
	public static Float FinancePriceDealerBeforeBasket;
	public static String[] selectedDealerCleanAddress_BP;

	public static void goToBasket(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Country, String PaymentMode, String VehicleChoice, String DealerPage, String Brand, String ScenarioName) throws Exception {
		if (driver != null) {
			navigateToBasketAndValidation = extentCP.createNode("NavigateToBasketPage", "Navigating to Basket page");
			try {
				driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				ConfigPage cyp = new ConfigPage(driver);
				BasketPage bkt = new BasketPage(driver);
				ChooseDealerPage dea = new ChooseDealerPage(driver);
				waitForUrlContains("preprod", driver, 10);
				if (Country.equalsIgnoreCase("FR") && !Brand.equalsIgnoreCase("OV")) {
					if ((Brand.equalsIgnoreCase("AP")) && (Country.equalsIgnoreCase("FR"))) {
						driver.navigate().back();
					}

					String defaultSelectedDealer = getAnyText(driver, By.xpath("//*[@id='dealerList']//button[contains(@class, 'selected')]"));
					System.out.println("Default Selected Dealer's Unclean Address: ");
					Thread.sleep(2000);
					System.out.println(defaultSelectedDealer);
					Thread.sleep(2000);
					selectedDealerCleanAddress_BP = defaultSelectedDealer.split("[\\r\\n]+");
					selectedDealerCleanAddress_BP = removeStringFromStringArray(selectedDealerCleanAddress_BP, 1);
					selectedDealerCleanAddress_BP = removeStringFromStringArray(selectedDealerCleanAddress_BP, 1);
					selectedDealerCleanAddress_BP = removeStringFromStringArray(selectedDealerCleanAddress_BP, 3);
					System.out.println("Default Selected Dealer's Clean Address: ");
					navigateToBasketAndValidation.log(Status.INFO, "Default Selected Dealer's Clean Address: ");
					for(int i=0;i<selectedDealerCleanAddress_BP.length;i++) {
						System.out.println(selectedDealerCleanAddress_BP[i]);
						navigateToBasketAndValidation.log(Status.INFO, selectedDealerCleanAddress_BP[i]);
					}
					//}
					if (PaymentMode.equalsIgnoreCase("Finance") != true) {
						if (!Brand.equalsIgnoreCase("OV") || !(ScenarioName.contains("Retail"))) {
							System.out.println("Country is: " + Country);
							cyp.clickConfigcontinue(resultDirectory, navigateToBasketAndValidation, Brand, Country);
						}
					} else {
						//monthlyTotalPriceDealer=extractFloatFromString(getAnyText(driver, By.xpath("//div[contains(@class,'totalPrice_cashPrice')]")).replace(" ","").replace(",","."));
						if (PaymentMode.equalsIgnoreCase("Finance") && Country.equalsIgnoreCase("FR")) {
							try {
								FinancePriceDealerBeforeBasket = extractFloatFromString(getAnyText(driver, By.xpath("//span[contains(@class,'totalPrice_monthlyPrice_price')]")).replace(" ", "").replace(",", "."));
							} catch (Exception e) {

							}
						}
						cyp.clickConfigcontinue(resultDirectory, navigateToBasketAndValidation, Brand, Country);
						monthlyTotalPriceDealer = extractFloatFromString(getAnyText(driver, By.xpath("//div[contains(@class,'totalPrice_cashPrice')]"), 10).replace(" ", "").replace(",", "."));
						if (VehicleChoice.equalsIgnoreCase("non-ec41")) {

							// checks arriving on basketPage
							if (Country.equalsIgnoreCase("FR")) {
								if (bkt.getPaymentHeaderText(resultDirectory, navigateToBasketAndValidation).contains("PAIEMENT")
										|| bkt.getPaymentHeaderText(resultDirectory, navigateToBasketAndValidation).contains("Paiement")) {
									navigateToBasketAndValidation.log(Status.PASS, "Basket page is displayed");
								} else {
									failWithScreenshot("Basket page is not displayed", resultDirectory, driver, extent, navigateToBasketAndValidation);
								}
							}
						}
					}
					if(Brand.equalsIgnoreCase("AC")&&Country.equalsIgnoreCase("FR")){
						driver.navigate().back();
					}
					cyp.clickConfigcontinue(resultDirectory, navigateToBasketAndValidation, Brand, Country);
					monthlyTotalPriceDealer=extractFloatFromString(getAnyText(driver, By.xpath("//div[contains(@class,'totalPrice_cashPrice')]"),10).replace(" ","").replace(",","."));
					if (VehicleChoice.equalsIgnoreCase("non-ec41")) {

						// checks arriving on basketPage
						if (Country.equalsIgnoreCase("FR")) {
							if (bkt.getPaymentHeaderText(resultDirectory, navigateToBasketAndValidation).contains("PAIEMENT")
									|| bkt.getPaymentHeaderText(resultDirectory, navigateToBasketAndValidation).contains("Paiement")) {
								navigateToBasketAndValidation.log(Status.PASS, "Basket page is displayed");
							} else {
								failWithScreenshot("Basket page is not displayed", resultDirectory, driver, extent, navigateToBasketAndValidation);
							}
						}
					}

					if (VehicleChoice.equalsIgnoreCase("ec41")) {
						//Thread.sleep(1000);
						cyp.clickCommercialOffer(resultDirectory, navigateToBasketAndValidation);
						//navigateToBasketAndValidation.log(Status.INFO,"Choose commercial offer is clicked");

						waitForUrlContains("/offers/dealers", driver, 120);
						//Thread.sleep(1000);
						cyp.clickCommercialOffer(resultDirectory, navigateToBasketAndValidation);
						//navigateToBasketAndValidation.log(Status.INFO,"Choose commercial offer is clicked");

						waitForUrlContains("/offers/dealers", driver, 120);

						if (dea.getEC41DealerTitle()) {
							navigateToBasketAndValidation.log(Status.PASS, "Choose your dealer page has appeared");
							//sa.assertTrue(true);
						} else {
							failWithScreenshot("Choose your dealer page has not appeared", resultDirectory, driver, extent, navigateToBasketAndValidation);
							//sa.assertTrue(false, "Choose your dealer page has appeared");
						}
					}
				}
				else{
					cyp.clickConfigcontinue(resultDirectory, navigateToBasketAndValidation, Brand, Country);
				}
				//sa.assertAll();
			} catch (Exception e) {
				e.printStackTrace();
			/*failWithScreenshot("Test Failed while Navigating To Basket and Validations", resultDirectory, driver, extent, navigateToBasketAndValidation);
			navigateToBasketAndValidation.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, navigateToBasketAndValidation, driver, "Test Failed while Navigating To Basket and Validations", e);
				ConfigPage cyp = new ConfigPage(driver);
				cyp.clickConfigcontinue(resultDirectory, navigateToBasketAndValidation, Brand, Country);
			}
		}
	}
}
