package solRetailIHM.ProjSpecFunctions;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.ParkExchangePage;
import solRetailIHM.Utilities.UniversalMethods;
import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ReprisePXconfig extends UniversalMethods {
	public static By returnToVehicleSheet= By.xpath("//*[text()='REVENIR SUR LA FICHE VÉHICULE'] | //*[text()='VOLVER A LA HOJA DEL VEHÍCULO']");

	public static String PXPrice;
	public String MarkPXconfig;
	public String ModelPXconfig;
	public static String PlatePXconfig;
	public static String PricePXconfig;
	public static String makeAndModel;
	public static String repriseTick = "";

	@Test(description = "Fill Reprise for Finance")
	public static void FillReprise(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Brand, String Country, String PaymentMode, String PostalCode, String EmailId, String Name,
			String Phone, String Plate) throws Exception {

		Object[] PXinfo;
		/*String PXPrice;
		String MarkPXconfig;
		String ModelPXconfig;
		String PlatePXconfig;
		String PricePXconfig;
		String makeAndModel;
		String repriseTick = "";*/
		
		ExtentTest reprise = extentBP.createNode("CheckReprise", "Check Reprise");

		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			ParkExchangePage pe = new ParkExchangePage(driver);
			SoftAssert sa = new SoftAssert();
			//Thread.sleep(3000);

			System.out.println("We choose Yes for Reprise");
			pe.clickOnRepriseYes();
			reprise.log(Status.INFO, "Click on Reprise Yes option");

			PXinfo = pe.FillCarImmatriculationAndMileage(Brand, Plate);
			reprise.log(Status.INFO, "Enter Immatriculation");
			System.out.println("---- " + PXinfo[0]);
			System.out.println("---- " + PXinfo[1]);
			System.out.println("---- " + PXinfo[2]);

			if(isElementPresent(driver,returnToVehicleSheet)){
				clickElement(driver,returnToVehicleSheet);
				writeToProperties("Reprise",null);
				reprise.log(Status.INFO,"Reprise price not applicable");
			} else {
				pe.ChooseCarVersion();
				reprise.log(Status.INFO, "Choose Version");

				/*pe.clickSubmitButton();
				reprise.log(Status.INFO, "Clicked on submit button");*/

				Thread.sleep(40000);
				if (isElementPresent(driver, returnToVehicleSheet)) {
					clickElement(driver, returnToVehicleSheet);
					writeToProperties("Reprise", null);
					reprise.log(Status.INFO,"Reprise price not applicable");
				} else {
					if ((Country.equals("FR")) && ((Brand.equals("AP") || Brand.equals("AC")))) {
						pe.FeelPersonalInformation(Brand, Country, PaymentMode, PostalCode, EmailId, Name, Phone, Plate);
						reprise.log(Status.INFO, "Fill Personal Info");
					}

					Thread.sleep(10000);
					PXPrice = pe.PricePX();
					System.out.println("---- " + PXPrice);

					pe.ClickOnConfirmEstimation();
					reprise.log(Status.INFO, "Click on confirm estimation");
					Thread.sleep(10000);
					// MarkPXconfig = pe.MarkPXconfig();
					// ModelPXconfig = pe.ModelPXconfig();
					makeAndModel = pe.getMakeAndModel();
					PlatePXconfig = pe.PlatePXconfig();
					PricePXconfig = pe.PricePXconfig();

					// checks Mark
					if (makeAndModel.contains(PXinfo[0].toString())) {
						reprise.log(Status.PASS, "Part Exchange car brand is OK");
						//sa.assertTrue(true);
					} else {
						failWithScreenshot("Part Exchange car brand is not OK", resultDirectory, driver, extent, reprise);
						//sa.assertTrue(false, "Part Exchange car brand is not OK");
					}

					// checks Model
					if (makeAndModel.contains(PXinfo[1].toString())) {
						reprise.log(Status.PASS, "Part Exchange car model is OK");
						//sa.assertTrue(true);
					} else {
						failWithScreenshot("Part Exchange car model is not OK", resultDirectory, driver, extent, reprise);
						//sa.assertTrue(false, "Part Exchange car model is not OK");
					}

					// checks Plate
					if (PlatePXconfig.trim().contains(PXinfo[2].toString().trim())) {
						reprise.log(Status.PASS, "Part Exchange car plate is OK");
						//sa.assertTrue(true);
					} else {
						failWithScreenshot("Part Exchange car plate is not OK", resultDirectory, driver, extent, reprise);
						//sa.assertTrue(false, "Part Exchange car plate is not OK");
						//driver.close();
						// org.testng.Assert.fail();
					}
					writeToProperties("Reprise", PricePXconfig);
					// checks Price
					if (PricePXconfig.contains(PXPrice.toString())) {
						reprise.log(Status.PASS, "Part Exchange car price is OK");
						writeToProperties("Reprise", PricePXconfig);
						//sa.assertTrue(true);
					} else {
						failWithScreenshot("Part Exchange car price is not OK", resultDirectory, driver, extent, reprise);
						//sa.assertTrue(false, "Part Exchange car plate is not OK");
					}
  					Thread.sleep(5000);
					repriseTick = pe.getRepriseTickAttribute("class");
					if (repriseTick.contains("selected")) {
						reprise.log(Status.PASS, "Reprise option in header is ticked");
					} else {
						reprise.log(Status.FAIL, "Reprise option in header is not ticked");
					}
				}
			}
			//sa.assertAll();
		} catch (Exception e) {
			/*failWithScreenshot("Test Failed while Fill Reprise for Finance", resultDirectory, driver, extent, reprise);
			reprise.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
			e.printStackTrace();
			catchFailDetails(resultDirectory, reprise,driver, "Test Failed while Fill Reprise for Finance",e);
		}

	}
}
