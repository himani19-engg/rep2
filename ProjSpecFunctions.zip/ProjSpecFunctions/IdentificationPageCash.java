package solRetailIHM.ProjSpecFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.ChooseDealerPage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.ProjSpecFunctions.ChooseDealerCash.searchingAndSelectingRetailer;
import static solRetailIHM.ProjSpecFunctions.GoToBasket.selectedDealerCleanAddress_BP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class IdentificationPageCash extends UniversalMethods {
	public static ExtentTest identificationPage;
    public static String ServiceText=readFromProperties("ServiceText");
	public static String FirstAdditionalServicePrice=readFromProperties("FirstAdditionalServicePrice");
	public static String DemarchesFees=readFromProperties("DemarchesFees");
	public static String CarteGrisePrice=readFromProperties("CarteGrisePrice");
	//public static String PromoCodeText=readFromProperties("PromoCode");
	public static String promoCodeVal=readFromProperties("Discount");

	public static String Reprise=readFromProperties("Reprise");
	static By firstAdditionalServiceText=By.xpath("//*[text()='"+ServiceText+"']");
	static By firstAdditionalServicePrice=By.xpath("//*[text()='"+ServiceText+"']/parent::div/following-sibling::div | (//*[@class='paragraph'])[9]/span[2]/span/span");
	static By firstAdditionalServicePrice_OV=By.xpath("//*[text()='"+ServiceText+"']/parent::p/span[2]");
	static By demarchesFees=By.xpath("//*[text()='Démarches  d´immatriculation' or text()=\"Démarches d'immatriculation\"]/parent::div/following-sibling::div | (//*[@class='paragraph'])[8]/span[2]/span/span");
	static By demarchesFees_OV=By.xpath("//*[text()='Démarches  d´immatriculation' or text()=\"Démarches d'immatriculation\" or text()=\"Demarches immatriculation\"]/parent::p/span[2]");
	static By carteGrisePrice=By.xpath("//*[contains(text(),'Carte grise')]/parent::div/following-sibling::div | //*[contains(text(),'Carte grise')]/parent::p/span[2]/span/span");
	//static By promoCodeText=By.xpath("//*[text()='"+PromoCodeText+"']");
	static By promoCodeText=By.xpath("//*[contains(text(),'DONT SUSPSEND OR ARCHIEVE THIS CODE')]");
	//static By PromoCodeValue=By.xpath("//*[text()='"+PromoCodeText+"']/parent::div/following-sibling::div | //*[text()='"+PromoCodeText+"']/parent::div/span[2]");
	static By PromoCodeValue=By.xpath("//*[contains(text(),'DONT SUSPSEND OR ARCHIEVE THIS CODE')]/parent::div/following-sibling::div | //*[contains(text(),'DONT SUSPSEND OR ARCHIEVE THIS CODE')]/parent::div/span[2]");

	@Test(description="filling Email Cash")
	public static String fillEmailCash(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String Country, String VehicleChoice, String PostalCode, String City, String NIF, String EmailId,
			String Name, String Phone, String Address, String Brand, String PaymentMode) throws Exception {
		String email = null;
		if(driver!=null) {
			identificationPage = logger.createNode("Identification", "Checking Identification page");

			try {
				if(Brand.equalsIgnoreCase("OV")!=true) {
					CheckPersonnalInfoCash.PersonalInfoPgDetails(resultDirectory, driver, extent, identificationPage, Brand, Country, PaymentMode);
				}
				PersonnalInfoPage pi = new PersonnalInfoPage(driver);
				int randomNo = generateRandomNumber();
				System.out.println(Country + Brand + randomNo);
				email = "testretail" + Country.toLowerCase() + Brand.toLowerCase() + randomNo + "@yopmail.com";
				pi.enterEmail(email, Brand);
				identificationPage.log(Status.INFO, "Entered email id on identification page");
				if(isElementPresent(driver, By.xpath("//*[contains(text(),'Continuer')] | //button[contains(text(),'Continuar')]")))
				{
					clickElement(driver, By.xpath("//*[contains(text(),'Continuer')] | //button[contains(text(),'Continuar')]"));
				}

				if (pi.enterEmailError(resultDirectory, driver, extent, identificationPage) == true) {
					identificationPage.log(Status.FAIL, "Error message appeared for the email entered: " + driver.findElement(By.id("field_email_error")).getText());
					failWithScreenshot("Error message appeared for the email entered: " + driver.findElement(By.id("field_email_error")).getText(), resultDirectory, driver, extent, logger);
					driver.close();
				} else {
					identificationPage.log(Status.PASS, "Entered email is accepted by the field");
				}
				if(Brand.equalsIgnoreCase("OV")!=true) {
					pi.ContinueAsGuestButtonClick();
					identificationPage.log(Status.INFO, "Clicked on continue as guest button");
				}
			} catch (Exception e) {
			/*identificationPage.log(Status.FAIL,"Test Failed while filling Email Cash");
			failWithScreenshot("Test Failed while filling Email Cash", resultDirectory, driver, extent, identificationPage);
			identificationPage.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, identificationPage, driver, "Test Failed while filling Email Cash", e);
			}

		}
		return email.toLowerCase();
	}
	public static ExtentTest registerUserPersonalDetails;
	@Test(description="Register User Personal Details")
	public static void registerUserPersonalDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String country, String vehicleChoice, String postalCode, String city, String NIF,
			String email, String phone, String address, String Brand, String Name) throws Exception {
		if(driver!=null) {
			registerUserPersonalDetails = logger.createNode("PersonalInfo", "Checking Identification page");
			try {
				PersonnalInfoPage pi = new PersonnalInfoPage(driver);

				pi.enterConfirmEmail(email, Brand);
				System.out.println("Emailid " + email);
				Thread.sleep(3000);
				registerUserPersonalDetails.log(Status.INFO, "Confirm email id");

				pi.selectCivility(Brand);
				Thread.sleep(1000);
				registerUserPersonalDetails.log(Status.INFO, "Check civility box");

				String[] name = Name.split(" ");

				pi.enterFirstName(name[0], Brand);
				Thread.sleep(1000);
				registerUserPersonalDetails.log(Status.INFO, "First name entered");

				pi.enterLastName(name[1], Brand);
				Thread.sleep(1000);
				registerUserPersonalDetails.log(Status.INFO, "Last name entered");

				pi.enterPhone(phone, Brand);
				Thread.sleep(1000);
				registerUserPersonalDetails.log(Status.INFO, "Phone number entered");

				pi.Address(address, Brand);
				Thread.sleep(1000);
				registerUserPersonalDetails.log(Status.INFO, "Address entered");

				pi.ZipCode(postalCode, Brand);
				Thread.sleep(1000);
				registerUserPersonalDetails.log(Status.INFO, "Postal code entered");

				pi.City(city, Brand);
				Thread.sleep(1000);
				registerUserPersonalDetails.log(Status.INFO, "City entered");

				if (country.equalsIgnoreCase("ES")) {
					pi.NIF(NIF);
					Thread.sleep(1000);
					registerUserPersonalDetails.log(Status.INFO, "NIF entered");

					if(Brand.equalsIgnoreCase("OV")){
						enterData(driver,By.xpath("//input[@id='field_companyName']"), "XYZ Company");
					} else {
						enterData(driver,By.xpath("//input[@id='field_companyName']"), "XYZ Company");
					}

					if(Brand.equalsIgnoreCase("OV")){
						enterData(driver,By.xpath("//input[@id='field_siretNumber']"), "1234567891234");
					} else {
						enterData(driver,By.xpath("//input[@id='field_siretNumber']"), "1234567891234");
					}
				}
				if(Brand.equalsIgnoreCase("OV")==true)
				{
					if(isElementPresent(driver,By.xpath("//*[contains(@id,'toggle-1-not_agree')]")))
					{
						clickElement(driver,By.xpath("//*[contains(@id,'toggle-1-not_agree')]"));
					}
					if(isElementPresent(driver,By.xpath("//*[contains(@id,'toggle-2-not_agree')]")))
					{
						clickElement(driver,By.xpath("//*[contains(@id,'toggle-2-not_agree')]"));
					}
					if(isElementPresent(driver,By.xpath("//*[contains(@id,'toggle-3-not_agree')]")))
					{
						clickElement(driver,By.xpath("//*[contains(@id,'toggle-3-not_agree')]"));
					}
				}
				pi.guestUser_ValidateCash(Brand);
				Thread.sleep(8000);
				registerUserPersonalDetails.log(Status.INFO, "Validate button clicked");

				clickElement(driver, By.xpath("//*[text()='Continuer']"));

			} catch (Exception e) {
			/*registerUserPersonalDetails.log(Status.FAIL,"Test Failed while Registering User Personal Details");
			failWithScreenshot("Test Failed while Registering User Personal Details", resultDirectory, driver, extent, registerUserPersonalDetails);
			registerUserPersonalDetails.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, registerUserPersonalDetails, driver, "Test Failed while Registering User Personal Details", e);
			}
		}
	}

	public static ExtentTest sideBarText;
	@Test(description="validating Side Bar Text")
	public static void validateSideBarText(String resultDirectory, WebDriver driver, ExtentReports extent,
												 ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage)
			throws Exception {
		sideBarText = searchingAndSelectingRetailer.createNode("SideBarText", "Checking Side Bar Identification Panel Text");
		String strIdentification;
		//Validate R.H.S. List of Identification Page with Point of Sale Page
		strIdentification = getAnyText(driver, By.className("bloc-recap-detail"));
		System.out.println("<==========================R.H.S. Identification======================>");
		System.out.println(strIdentification);
		System.out.println("<==========================R.H.S. Identification======================>");
		double percentMatch=findSimilarity(strIdentification,ChooseDealerCash.StrPOSPV);
		if (percentMatch>=0.90){
			System.out.println("R.H.S. Matched");
			sideBarText.log(Status.PASS, "Identification Panel Text is matched with Point de vente");
		} else {
			System.out.println("R.H.S. Not Matched");
			sideBarText.log(Status.FAIL, "Identification Panel Text could not be matched with Point de vente and the similarities between the two texts are: "+ percentMatch);
			sideBarText.log(Status.INFO, "The unmatched Texts lies somewhere here: "+ differenceInText(strIdentification,ChooseDealerCash.StrPOSPV));
		}
	}

	public static ExtentTest identificationTab;
	@Test(description="validating Identification Tab")
	public static void validateIdentificationTab(String resultDirectory, WebDriver driver, ExtentReports extent,
												 ExtentTest logger, String Brand, String Country, String VehicleChoice, String Retailer, String PaymentMode, String DealerPage)
			throws Exception {
		identificationTab = searchingAndSelectingRetailer.createNode("IdentificationTab", "Checking Identification");

		try{
			ChooseDealerPage dea = new ChooseDealerPage(driver);
			PersonnalInfoPage pi = new PersonnalInfoPage(driver);
			// Validate arriving on reprise page
			if (Country.equals("FR")) {
				if (Brand.equals("OV")) {
					waitForUrlContains("/my-details", driver, 240);
				} else {
					waitForUrlContains("/personnal-information", driver, 240);
				}

				String identificationHeader = "";
				if (Brand.equals("OV"))
					identificationHeader = dea.getIdentificationHeader_OV();
				else if (Brand.equals("AC"))
					identificationHeader = pi.getCashIdentification_AC();
				else
					identificationHeader = pi.getCashIdentification(Country);

				if ((identificationHeader.contains("Identification"))
						|| (identificationHeader.contains("IDENTIFICATION"))) {
					identificationTab.log(Status.PASS, "Identification PAGE page has appeared");
					//sa.assertTrue(true);
				} else {
					failWithScreenshot("Identification PAGE page has not appeared", resultDirectory, driver, extent, logger);
					//sa.assertTrue(false,"Identification PAGE page has not appeared");
				}
			}

			if ((Country.equals("ES")) && (!(Brand.equalsIgnoreCase("DS")) || Brand.equalsIgnoreCase("AP") || Brand.equalsIgnoreCase("AC")) && (!PaymentMode.equalsIgnoreCase("Finance"))) {
				String identificationHeader = "";
				waitForPageToLoad(driver,10);
				//waitForUrlContains("/personnal-information", driver, 50);
				Thread.sleep(5000);
				if (Brand.equals("AC")) {
					identificationHeader = pi.getCashIdentification_AC();
				}
				else {
					identificationHeader = pi.getCashIdentification(Country);
				}

				if ((identificationHeader.contains("RECAPITULATIVO"))
						|| (identificationHeader.contains("Identificación"))
						|| (identificationHeader.contains("Identificaci"))
						|| (identificationHeader.contains("Recapitulativo"))){
					identificationTab.log(Status.PASS, "Current PAGE page has appeared as " + identificationHeader);
				}else{
					failWithScreenshot("ORDER confirm PAGE page has not appeared", resultDirectory, driver, extent, identificationTab);
					driver.quit();
					//sa.assertTrue(false,"ORDER confirm PAGE page has not appeared");
				}
			}
			validateSideBarText(resultDirectory, driver, extent,
					logger, Brand, Country, VehicleChoice, Retailer, PaymentMode, DealerPage);
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	public  static String getServiceText(String resultDirectory, ExtentTest NodeORSubNode, WebDriver driver,String Page){
		String str=null;
		try{
			str=getAnyText(driver, firstAdditionalServiceText,1);
			NodeORSubNode.log(Status.INFO, "Got First Additional Service Text on "+Page+" page : "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get First Additional Service Text on "+Page+" page : "+str,e);
		}
		return str;
	}
	public static String getServicePrice(String resultDirectory, ExtentTest NodeORSubNode, WebDriver driver, String Brand,String Page){
		String str=null;
		try{
			if(Brand.equalsIgnoreCase("OV")){
				str=getAnyText(driver,firstAdditionalServicePrice_OV,1);
			} else{
				str=getAnyText(driver, firstAdditionalServicePrice,1);
			}
			NodeORSubNode.log(Status.INFO, "Got First Additional Service Price on "+Page+" page : "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get First Additional Service Price on "+Page+" page : "+str,e);
		}
		return str;
	}
	public static String getDemarchesPrice(String resultDirectory, ExtentTest NodeORSubNode, WebDriver driver,String Brand, String Page){
		String str=null;
		try{
			if(Brand.equalsIgnoreCase("OV")){
				str=getAnyText(driver, demarchesFees_OV,1);
			} else{
				str=getAnyText(driver, demarchesFees,1);
			}
			NodeORSubNode.log(Status.INFO, "Got Demarches Price on "+Page+" page : "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Demarches Price on "+Page+" page : "+str,e);
		}
		return str;
	}
	public static String getCarteGrisePrice(String resultDirectory, ExtentTest NodeORSubNode, WebDriver driver, String Page){
		String str=null;
		try{
			str=getAnyText(driver, carteGrisePrice,1);
			NodeORSubNode.log(Status.INFO, "Got Carte Grise Price on "+Page+" page : "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Carte Grise Price on "+Page+" page : "+str,e);
		}
		return str;
	}
	public  static String getPromoCodeText(String resultDirectory, ExtentTest NodeORSubNode, WebDriver driver, String Page){
		String str=null;
		try{
			str=getAnyText(driver, promoCodeText,1);
			NodeORSubNode.log(Status.INFO, "Got Promo Code Text on "+Page+" page : "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Promo Code Text on "+Page+" page : "+str,e);
		}
		return str;
	}
	public  static String getPromoCodeValue(String resultDirectory, ExtentTest NodeORSubNode, WebDriver driver, String Page){
		String str=null;
		try{
			str=getAnyText(driver,PromoCodeValue,1);
			NodeORSubNode.log(Status.INFO, "Got Promo Code Value on "+Page+" page : "+str);
		}catch (Exception e){
			catchFailDetails(resultDirectory, NodeORSubNode,driver, "Unable to get Promo Code Value on "+Page+" page : "+str,e);
		}
		return str;
	}
}
