package solRetailIHM.ProjSpecFunctions.ChooseCar;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.ChooseVehicleVersion;
import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ChooseCarModelEc41 extends UniversalMethods {

	@Test(description = "Selecting Car Model Ec41")
	public static Object[] validateBrandAndPrice(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger) {

		float CashPriceNum = 0;
		float CashPrice = 0;

		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			ChooseVehicleVersion btn = new ChooseVehicleVersion(driver);
			ConfigPage cyp = new ConfigPage(driver);
			HomePage hmpg = new HomePage(driver);

			CashPrice = hmpg.getCashPrice_HomePage(resultDirectory,logger);
			CashPriceNum = hmpg.getCashPriceNum_HomePage(resultDirectory,logger);

			// choose vehicule

			System.out.println(hmpg.numberOfOffers(resultDirectory,logger));

			hmpg.clickSelectEC41Offer(resultDirectory, driver, extent, logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on View Vehicle Button", ExtentColor.BLUE));
			btn.clickViewVehicleType(resultDirectory,logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Personnalizes Button", ExtentColor.BLUE));

			// checks arriving on config page

			if (cyp.getCustomizeYourProjectText_FR(resultDirectory,logger).contains("PERSONNALISEZ VOTRE PROJET")) {
				logger.log(Status.PASS,
						MarkupHelper.createLabel("PERSONNALISEZ VOTRE PROJET page has appeared", ExtentColor.GREEN));
				Assert.assertTrue(true);
			} else {
				failWithScreenshot("PERSONNALISEZ VOTRE PROJET page has not appeared", resultDirectory, driver, extent,
						logger);
				Assert.assertTrue(false, "PERSONNALISEZ VOTRE PROJET page has not appeared");
				driver.close();
				// org.testng.Assert.fail();
			}

		} catch (Exception e) {
			logger.log(Status.FAIL,
					MarkupHelper.createLabel("Error while Selection of Car Model Ec41", ExtentColor.BLUE));
			failWithScreenshot("Error while Selection of Car Model Ec41", resultDirectory, driver, extent, logger);
			e.printStackTrace();
			driver.close();
		}
		Object[] prices = new Object[2];
		prices[0] = CashPrice;
		prices[1] = CashPriceNum;
		return prices;

	}
}
