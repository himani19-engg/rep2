package solRetailIHM.ProjSpecFunctions.ChooseCar;

import static solRetailIHM.PageObjectModel.HomePage.getHomePageVahicleName;
import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentTP;
import static solRetailIHM.ProjSpecFunctions.LoginApplications.LoginApplicationRetail.extentHP;
import static solRetailIHM.ScenarioMainClass.ScenarioMain_FR.driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.performance.Performance;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import solRetailIHM.PageObjectModel.ChooseVehicleVersion;
import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.TrimPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.Optional;

@Listeners(solRetailIHM.Runner.ListenerTest.class)
public class ChooseCarCashNonEc41 extends UniversalMethods {
    public static ExtentTest chooseCarCash;
    public static ExtentTest selectingCarType;

    public static ExtentTest extentCP;
    public static String vehicleName;
    static SoftAssert sa;

    public static By homeButton=By.xpath("//*[@href='/']");
    public static By error=By.xpath("//*[@class='errorPage__title']");
    @Test(description = "validation of Brand And Price_Cash")

    public static Object[] validateBrandAndPrice_Cash(String resultDirectory, WebDriver driver, ExtentReports extent,
                                                      ExtentTest logger, String Country, String VehicleChoice) {

        float CashPriceNum = 0;
        float CashPrice = 0;
        sa = new SoftAssert();

        try {
            // driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
            ChooseVehicleVersion btn = new ChooseVehicleVersion(driver);
            ConfigPage cyp = new ConfigPage(driver);
            HomePage hmpg = new HomePage(driver);

            CashPrice = hmpg.getCashPrice_HomePage(resultDirectory,logger);
            CashPriceNum = hmpg.getCashPriceNum_HomePage(resultDirectory,logger);

            // choose vehicule

            System.out.println(hmpg.numberOfOffers(resultDirectory,logger));

            if (Country.equalsIgnoreCase("non-ec41")) {
                hmpg.clickViewVehicle(resultDirectory,logger);
                //logger.log(Status.PASS, "Clicked on View Vehicle Button");
                //logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on View Vehicle Button", ExtentColor.BLUE));
            } else {
                hmpg.clickViewVehicleACnoEC41(resultDirectory,logger);
                //logger.log(Status.PASS, MarkupHelper.createLabel("Clicked on View Vehicle Button", ExtentColor.BLUE));
            }

            btn.clickViewVehicleType(resultDirectory,logger);
            //logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Personnalizes Button", ExtentColor.BLUE));

            // checks arriving on config page
            if (Country.equalsIgnoreCase("FR")) {
                if (cyp.getCustomizeYourProjectText_FR(resultDirectory,logger).contains("PERSONNALISEZ VOTRE PROJET")) {
                    logger.log(Status.PASS, "PERSONNALISEZ VOTRE PROJET page has appeared");
                   /* logger.log(Status.PASS, MarkupHelper.createLabel("PERSONNALISEZ VOTRE PROJET page has appeared",
                            ExtentColor.GREEN));*/
                    sa.assertTrue(true);
                } else {
                    logger.log(Status.FAIL, "PERSONNALISEZ VOTRE PROJET page has not appeared");
                    failWithScreenshot("PERSONNALISEZ VOTRE PROJET page has not appeared", resultDirectory, driver,
                            extent, logger);
                    sa.assertTrue(false, "PERSONNALISEZ VOTRE PROJET page has not appeared");
                    //driver.close();
                    // org.testng.Assert.fail();
                }
            }
            if (Country.equalsIgnoreCase("UK")) {
                if ((!driver.getCurrentUrl().contains("citroen")) && (!driver.getCurrentUrl().contains("ds"))) {
                    if (cyp.getCustomizeYourProjectText_UK_VX(resultDirectory,selectingCarType).contains("PERSONALISE YOUR OFFER")) {
                        logger.log(Status.PASS, "PERSONALISE YOUR OFFER page has appeared");
                        /*logger.log(Status.PASS, MarkupHelper.createLabel("PERSONALISE YOUR OFFER page has appeared",
                                ExtentColor.GREEN));*/
                        sa.assertTrue(true);
                    } else {
                        logger.log(Status.FAIL, "PERSONALISE YOUR OFFER page has not appeared");
                        failWithScreenshot("PERSONALISE YOUR OFFER page has not appeared", resultDirectory, driver,
                                extent, logger);
                        sa.assertTrue(false, "PERSONALISE YOUR OFFER page has not appeared");
                        //driver.close();
                        // org.testng.Assert.fail();
                    }
                } else {
                    if (cyp.getCustomizeYourProjectText_UK(resultDirectory,logger).contains("PERSONALISE YOUR VEHICLE")) {
                        logger.log(Status.PASS, "PERSONALISE YOUR VEHICLE page has appeared");
                        /*logger.log(Status.PASS, MarkupHelper.createLabel("PERSONALISE YOUR VEHICLE page has appeared",
                                ExtentColor.GREEN));*/
                        sa.assertTrue(true);
                    } else {
                        logger.log(Status.FAIL, "PERSONALISE YOUR VEHICLE page has not appeared");
                        failWithScreenshot("PERSONALISE YOUR VEHICLE page has not appeared", resultDirectory, driver,
                                extent, logger);
                        sa.assertTrue(false, "PERSONALISE YOUR VEHICLE page has not appeared");
                        //driver.close();
                        // org.testng.Assert.fail();
                    }
                }
            }

            if (Country.equalsIgnoreCase("ES")) {
                if (driver.getCurrentUrl().contains("peugeot") || driver.getCurrentUrl().contains("citroen")) {
                    if (cyp.getCustomizeYourProjectText_ES(resultDirectory,logger).contains("PERSONALIZA TU COMPRA")) {
                        logger.log(Status.PASS, "PERSONALIZA TU COMPRA page has appeared");
                        /*logger.log(Status.PASS,
                                MarkupHelper.createLabel("PERSONALIZA TU COMPRA page has appeared", ExtentColor.GREEN));*/
                        sa.assertTrue(true);
                    } else {
                        logger.log(Status.FAIL, "PERSONALIZA TU COMPRA page has not appeared");
                        failWithScreenshot("PERSONALIZA TU COMPRA page has not appeared", resultDirectory, driver,
                                extent, logger);
                        sa.assertTrue(false, "PERSONALIZA TU COMPRA page has not appeared");
                        //driver.close();
                        // org.testng.Assert.fail();
                    }
                } else {
                    if (cyp.getCustomizeYourProjectText_ES_DS(resultDirectory,logger).contains("PERSONALICE SU COMPRA")) {
                        logger.log(Status.PASS, "PERSONALICE SU COMPRA page has appeared");
                        /*logger.log(Status.PASS,
                                MarkupHelper.createLabel("PERSONALICE SU COMPRA page has appeared", ExtentColor.GREEN));*/
                        sa.assertTrue(true);
                    } else {
                        logger.log(Status.FAIL, "PERSONALICE SU COMPRA page has not appeared");
                        failWithScreenshot("PERSONALICE SU COMPRA page has not appeared", resultDirectory, driver,
                                extent, logger);

                        sa.assertTrue(false, "PERSONALICE SU COMPRA page has not appeared");
                        //driver.close();
                        // org.testng.Assert.fail();
                    }
                }
            }
            sa.assertAll();
        } catch (Exception e) {
            /*logger.log(Status.FAIL, MarkupHelper.createLabel("Error with validation of Brand And Price_Cash", ExtentColor.BLUE));
            failWithScreenshot("test Failed", resultDirectory, driver, extent, logger);
            e.printStackTrace();*/

            catchFailDetails(resultDirectory, logger,driver, "Error with validation of Brand And Price_Cash",e);
        }
        Object[] prices = new Object[2];
        prices[0] = CashPrice;
        prices[1] = CashPriceNum;
        return prices;

    }

    @Test(description = "Selecting Car Model")
    public static Object[] chooseCarModel(String resultDirectory, WebDriver driver, ExtentReports extent,
                                          ExtentTest logger, String brand, String Country, String PaymentMode) {
        Object[] prices = new Object[2];
        if(driver!=null) {
            float CashPriceNum = 0;
            float CashPrice = 0;
            //vehicleName = null;
            chooseCarCash = extentHP.createNode("ChooseCarModel", "Choosing vehicle on Home page");
            try {
                // driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
                HomePage hmpg = new HomePage(driver);
                //HomePage hmpg1 = new HomePage(driver);
                TrimPage trimPage = new TrimPage(driver);

                CashPrice = hmpg.getCashPrice_HomePage(resultDirectory, chooseCarCash);
                CashPriceNum = hmpg.getCashPriceNum_HomePage(resultDirectory, chooseCarCash);
                SoftAssert sa = new SoftAssert();
                // choose vehicle

                int noOfOffers = hmpg.numberOfOffers(resultDirectory, chooseCarCash);
                System.out.println("Total Number of Offers along with Need a Help Box: "+noOfOffers);
                int financeVehiclesSize = 0;
                financeVehiclesSize = hmpg.getVehiclesList(resultDirectory, chooseCarCash, brand, PaymentMode).size();
                if (financeVehiclesSize == 0 && driver!=null) {
                    //Clicking on Diesel Filter
                    clickElement(driver, By.xpath("//div[@data-testid='TESTING_FILTER_fuel']/button[@id='TESTING_DIESEL']"), 5);
                    //Thread.sleep(5000);
                    financeVehiclesSize = hmpg.getVehiclesList(resultDirectory, chooseCarCash, brand, PaymentMode).size();
                }
                if (financeVehiclesSize == 0 && driver!=null) {
                    //Clicking on Electric Filter
                    clickElement(driver, By.xpath("//div[@data-testid='TESTING_FILTER_fuel']/button[2]/div[@class='disp-inline']"), 5);
                    Thread.sleep(5000);
                    financeVehiclesSize = hmpg.getVehiclesList(resultDirectory, chooseCarCash, brand, PaymentMode).size();
                }
                if (financeVehiclesSize == 0 && driver!=null) {
                    //Clicking on Essence Filter
                    clickElement(driver, By.xpath("//div[@data-testid='TESTING_FILTER_fuel']/button[@id='TESTING_ESSENCE']"), 5);
                    Thread.sleep(5000);
                    financeVehiclesSize = hmpg.getVehiclesList(resultDirectory, chooseCarCash, brand, PaymentMode).size();
                }
                hmpg.writeToProperties("financeVehiclesSize", String.valueOf(financeVehiclesSize));

                if (noOfOffers == 1 && driver!=null) {
                    vehicleName = hmpg.getFirstVehicleName(resultDirectory, chooseCarCash);
                    hmpg.writeToProperties("VehicleName", vehicleName);
                    hmpg.clickViewVehicle(resultDirectory, chooseCarCash);

                } else if (financeVehiclesSize > 0 && driver!=null) {
                    //vehicleName = hmpg.getFinanceVehicleName(resultDirectory, chooseCarCash,brand);
                    if(isElementPresent(driver, hmpg.closeButton))
                    {
                        clickElement(driver, hmpg.closeButton);
                    }
                    vehicleName = hmpg.getModelVehicle(resultDirectory, chooseCarCash, PaymentMode, brand);
                    hmpg.writeToProperties("VehicleName", vehicleName);
                    //chooseCarCash.log(Status.INFO,"Vehicle name is: " + vehicleName);

                    //logger.log(Status.INFO, MarkupHelper.createLabel("Vehicle name is: " + vehicleName, ExtentColor.BLUE));
                    hmpg.clickViewVehicle(resultDirectory, chooseCarCash, PaymentMode,brand,Country);
                    //chooseCarCash.log(Status.INFO,"Clicked on Finance View Vehicle Button");

                    //logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Finance View Vehicle Button", ExtentColor.BLUE));
                } else {
                    if(driver!=null) {
                        vehicleName = hmpg.getFirstVehicleName(resultDirectory, chooseCarCash);
                        hmpg.writeToProperties("VehicleName", vehicleName);
                        hmpg.clickViewVehicleACnoEC41(resultDirectory, chooseCarCash);
                        //waitForUrlContains("trim",driver,5);
                        waitForPageToLoad(driver, 5);
                    }
                    // chooseCarCash.log(Status.INFO, "Clicked on View Vehicle Button");

                    //logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on View Vehicle Button", ExtentColor.BLUE));
                }
                // Thread.sleep(9000);
            /*
            // Verify trim page appeared
            if (Country.equalsIgnoreCase("ES")) {
				if(!brand.equalsIgnoreCase("AP")) {
					if (trimPage.getTrimPageHeaderText().contains("ELIGE SU ACABADO")
							|| trimPage.getTrimPageHeaderText().contains("ELIGE EL ACABADO")
							|| trimPage.getTrimPageHeaderText().contains("ELIJA SU ACABADO")) {

						chooseCarCash.log(Status.PASS,"Trim page has appeared");
						logger.log(Status.PASS, MarkupHelper.createLabel("Trim page has appeared", ExtentColor.GREEN));
						sa.assertTrue(true);
					} else {
						chooseCarCash.log(Status.FAIL,"Trim page has not appeared");
						logger.log(Status.WARNING,
								MarkupHelper.createLabel("Trim page has not appeared", ExtentColor.BROWN));
						sa.assertTrue(false, "Trim page has not appeared");
					}
					System.out.println("CashPrice :" + trimPage.getCashPrice());
					trimPage.writeToProperties("CashPrice",
							String.valueOf(extractNumericFromString(trimPage.getCashPrice())));

					String trimPage_vehicleName = trimPage.getVehicleName().toUpperCase();

					if (trimPage_vehicleName.contains(trimPage.readFromProperties("VehicleName").toUpperCase())) {
						chooseCarCash.log(Status.PASS,"Vehicle name on Trim page is correct");
						logger.log(Status.PASS,
								MarkupHelper.createLabel("Vehicle name on Trim page is correct", ExtentColor.GREEN));
						sa.assertTrue(true);
					} else {
						chooseCarCash.log(Status.FAIL,"Vehicle name on Trim page is not correct");
						logger.log(Status.WARNING,
								MarkupHelper.createLabel("Vehicle name on Trim page is not correct", ExtentColor.ORANGE));
						sa.assertTrue(false, "Vehicle name on Trim page is not correct");
					}
				}
            }
			String text = "";
			if (Country.equalsIgnoreCase("FR")) {
				text = trimPage.getTrimPageHeaderText();
				if (text.contains("CHOISISSEZ VOTRE VERSION")
						|| text.contains("CHOISISSEZ VOTRE FINITION")) {
					chooseCarCash.log(Status.PASS,"Trim page has appeared");
					logger.log(Status.PASS, MarkupHelper.createLabel("Trim page has appeared", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					chooseCarCash.log(Status.PASS,"Trim page has not appeared");
					failWithScreenshot("Trim page has not appeared", resultDirectory, driver, extent, logger);
					sa.assertTrue(false, "Trim page has not appeared");
				}

				String trimPage_vehicleName = trimPage.getVehicleName().toUpperCase();

				if (trimPage_vehicleName.contains(trimPage.readFromProperties("VehicleName").toUpperCase())) {

					chooseCarCash.log(Status.PASS,"Vehicle name on Trim page is correct");
					logger.log(Status.PASS,
							MarkupHelper.createLabel("Vehicle name on Trim page is correct", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					chooseCarCash.log(Status.FAIL,"Vehicle name on Trim page is not correct");
					logger.log(Status.WARNING,
							MarkupHelper.createLabel("Vehicle name on Trim page is not correct", ExtentColor.ORANGE));
					sa.assertTrue(false, "Vehicle name on Trim page is not correct");
				}
			}
*/
                if (Country.equalsIgnoreCase("UK") && driver!=null) {
                    if (trimPage.getTrimPageHeaderText(resultDirectory, chooseCarCash).contains("CHOOSE YOUR TRIM")) {
                        chooseCarCash.log(Status.PASS, "Trim page has appeared");
                        //logger.log(Status.PASS, MarkupHelper.createLabel("Trim page has appeared", ExtentColor.GREEN));
                        sa.assertTrue(true);
                    } else {
                        chooseCarCash.log(Status.FAIL, "Trim page has not appeared");
                        failWithScreenshot("Trim page has not appeared", resultDirectory, driver, extent, chooseCarCash);
                        sa.assertTrue(false, "Trim page has not appeared");
                    }
                }
                //sa.assertAll();
            } catch (Exception e) {
            /*chooseCarCash.log(Status.FAIL, "Error with Selecting Car Model");
            failWithScreenshot("Error with Selecting Car Model", resultDirectory, driver, extent, chooseCarCash);
            chooseCarCash.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                catchFailDetails(resultDirectory, chooseCarCash, driver, "Error with Selecting Car Model", e);
            }
            prices[0] = CashPrice;
            prices[1] = CashPriceNum;
        }
        return prices;
    }

    @Test(description = "Selecting Car Type")
    public static void chooseCarType(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
                                     String brand, String Country, String VehicleChoice, String paymentMode) {
        selectingCarType = extentTP.createNode("ChooseCarType", "Choosing Car Type on Trim page");
        if(driver!=null) {
            try {
                ChooseVehicleVersion btn = new ChooseVehicleVersion(driver);
                TrimPage trimPage = new TrimPage(driver);
                ConfigPage cyp = new ConfigPage(driver);
                //SoftAssert sa = new SoftAssert();

                //	if(Country.equals("ES") && brand.equals("AP")) {
                trimPage.scrollToTop(driver);
                //driver.navigate().refresh();
                //Thread.sleep(10000);
                if (paymentMode.equalsIgnoreCase("Finance")) {
                    selectingCarType.log(Status.INFO, "Payment Mode is Finance");
                    trimPage.selectFinanceVehicle(resultDirectory, selectingCarType);
                    writeToProperties("currentFinanceprice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_SELECTOR_FINANCE_PRICE']/span[1]/span[1]")).replace(",","."))));
                }
                writeToProperties("currentCashPrice",String.valueOf(extractFloatFromString(getAnyText(driver,By.xpath("//*[@data-testid='TESTING_SELECTOR_CASH_PRICE']/span[1]")).replace(",","."))));
                Thread.sleep(3000);
                btn.navigateToConfigPage(resultDirectory, selectingCarType);
                Thread.sleep(3000);
                //selectingCarType.log(Status.INFO, "Clicked on Continue button on Trim page");
                btn.validateTrimAndConfigPagePrices(resultDirectory,selectingCarType,paymentMode);
                // checks arriving on config page
                if (Country.equalsIgnoreCase("FR")) {
                    if (cyp.getMotorLabelText(resultDirectory, selectingCarType).contains("Motor") || cyp.getMotorLabelText(resultDirectory, selectingCarType).contains("moteur")) {
                        selectingCarType.log(Status.PASS, "Config page has appeared");
                        //logger.log(Status.PASS, MarkupHelper.createLabel("Config page has appeared", ExtentColor.GREEN));
                        //sa.assertTrue(true);
                    } else {
                        //selectingCarType.log(Status.FAIL, "Config page has not appeared");
                        failWithScreenshot("Config page has not appeared", resultDirectory, driver, extent, selectingCarType);
                        //sa.assertTrue(false, "Config page has not appeared");
                    }
                }
                if (Country.equalsIgnoreCase("UK")) {
                    if ((!driver.getCurrentUrl().contains("citroen")) && (!driver.getCurrentUrl().contains("ds"))) {
                        if (cyp.getCustomizeYourProjectText_UK_VX(resultDirectory, selectingCarType).contains("PERSONNALISEZ VOTRE PROJET")) {
                            selectingCarType.log(Status.PASS, "PERSONALISE page has appeared");
                            //sa.assertTrue(true);
                        } else {
                            //selectingCarType.log(Status.FAIL, "PERSONALISE page has not appeared");
                            failWithScreenshot("PERSONALISE YOUR OFFER page has not appeared", resultDirectory, driver, extent, selectingCarType);
                            //sa.assertTrue(false, "PERSONALISE YOUR OFFER page has not appeared");
                        }
                    } else {
                        if (cyp.getCustomizeYourProjectText_UK(resultDirectory, selectingCarType).contains("PERSONALISE YOUR VEHICLE")) {
                            selectingCarType.log(Status.PASS, "PERSONALISE YOUR VEHICLE page has appeared");
                            //sa.assertTrue(true);
                        } else {
                            //selectingCarType.log(Status.FAIL, "PERSONALISE YOUR VEHICLE page has not appeared");
                            failWithScreenshot("PERSONALISE YOUR VEHICLE page has not appeared", resultDirectory, driver, extent, selectingCarType);
                            //sa.assertTrue(false, "PERSONALISE YOUR VEHICLE page has not appeared");
                        }
                    }
                }

                if (Country.equalsIgnoreCase("ES")) {
                    if (cyp.getMotorLabelText(resultDirectory, selectingCarType).contains("Motor")) {
                        selectingCarType.log(Status.PASS, "Config page has appeared");
                        //sa.assertTrue(true);
                    } else {
                        //selectingCarType.log(Status.FAIL, "Config page has not appeared");
                        failWithScreenshot("Config page has not appeared", resultDirectory, driver, extent, selectingCarType);
                        //sa.assertTrue(false, "Config page has not appeared");
                    }
                }

                extentCP = logger.createNode("ConfigPage", "Checking details on ConfigPage");
                //sa.assertAll();
            } catch (Exception e) {
            /*selectingCarType.log(Status.FAIL, "Test Failed due to error in Selection of Car Type");
            failWithScreenshot("Test Failed due to error in Selection of Car Type", resultDirectory, driver, extent, selectingCarType);
            selectingCarType.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
                e.printStackTrace();
                catchFailDetails(resultDirectory, selectingCarType, driver, "Test Failed due to error in Selection of Car Type", e);
            }
        }
    }
}
