package solRetailIHM.ProjSpecFunctions.ChooseCar;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import solRetailIHM.PageObjectModel.ChooseVehicleVersion;
import solRetailIHM.PageObjectModel.ConfigPage;
import solRetailIHM.PageObjectModel.HomePage;
import solRetailIHM.PageObjectModel.TrimPage;
import solRetailIHM.Utilities.UniversalMethods;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class ChooseCarFinanceNonEc41 extends UniversalMethods {

	@Test(description = "Selecting Car Finance NonEc41")
	public static Object[] validateBrandAndPrice_Finance_Model(String resultDirectory, WebDriver driver,
			ExtentReports extent, ExtentTest logger, String Brand, String Country, String VehicleChoice) {

		int MonthlyPriceFinanceNum = 0;
		String MonthlyPriceFinance = null;

		try {
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			ChooseVehicleVersion btn = new ChooseVehicleVersion(driver);
			ConfigPage cyp = new ConfigPage(driver);
			TrimPage trimPage = new TrimPage(driver);
			HomePage hmpg = new HomePage(driver);
			SoftAssert sa = new SoftAssert();

			// checks finance vehicule is present

			if (Country.equalsIgnoreCase("FR")) {
				MonthlyPriceFinance = hmpg.getMonthlyPriceFinance_HomePage_FR(resultDirectory,logger);
				if (MonthlyPriceFinance != null) {
					MonthlyPriceFinanceNum = hmpg.getPriceMonthlyNum_HomePage_FR(resultDirectory,logger);
				}
			}

			if (Country.equalsIgnoreCase("UK")) {
				MonthlyPriceFinance = hmpg.getMonthlyPriceFinance_HomePage_UK(resultDirectory,logger);
				if (MonthlyPriceFinance != null) {
					MonthlyPriceFinanceNum = hmpg.getPriceMonthlyNum_HomePage_UK(resultDirectory,logger);
				}
			}

			sa.assertTrue(true);
			if (MonthlyPriceFinance != null) {
				logger.log(Status.PASS, "vehicle finance Price has appeared");
				sa.assertTrue(true);
			} else {
				logger.log(Status.FAIL, "vehicle finance Price has not appeared");
				failWithScreenshot("vehicle finance has not appeared", resultDirectory, driver, extent, logger);
				sa.assertTrue(false, "vehicle finance has not appeared");
			//	driver.quit();

			}

			// choose vehicule

			System.out.println(hmpg.numberOfOffers(resultDirectory,logger));

			hmpg.clickSelectFinanceOffer(resultDirectory,logger);
			//hmpg.clickSelectFinanceOffer(Brand, Country, VehicleChoice);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on View Vehicle Button", ExtentColor.BLUE));

			// Verify trim page appeared
			if (Country.equalsIgnoreCase("ES")) {
				if (trimPage.getTrimPageHeaderText(resultDirectory,logger).contains("ELIGE SU ACABADO")
						|| trimPage.getTrimPageHeaderText(resultDirectory,logger).contains("ELIGE EL ACABADO")
						|| trimPage.getTrimPageHeaderText(resultDirectory,logger).contains("ELIJA SU ACABADO")) {
					logger.log(Status.PASS, MarkupHelper.createLabel("Trim page has appeared", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					failWithScreenshot("Trim page has not appeared", resultDirectory, driver, extent, logger);
					sa.assertTrue(false, "Trim page has not appeared");
				//	driver.close();
				}
			}

			if (Country.equalsIgnoreCase("FR")) {
				if (trimPage.getTrimPageHeaderText(resultDirectory,logger).contains("CHOISISSEZ VOTRE VERSION")) {
					logger.log(Status.PASS, MarkupHelper.createLabel("Trim page has appeared", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					failWithScreenshot("Trim page has not appeared", resultDirectory, driver, extent, logger);
					sa.assertTrue(false, "Trim page has not appeared");
				//	driver.close();
				}
			}

			if (Country.equalsIgnoreCase("UK")) {
				if (trimPage.getTrimPageHeaderText(resultDirectory,logger).contains("CHOOSE YOUR TRIM")) {
					logger.log(Status.PASS, MarkupHelper.createLabel("Trim page has appeared", ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					failWithScreenshot("Trim page has not appeared", resultDirectory, driver, extent, logger);
					sa.assertTrue(false, "Trim page has not appeared");
				//	driver.close();
				}
			}

			sa.assertAll();
		} catch (Exception e) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Error with Selection of Car Finance NonEc41", ExtentColor.BLUE));
			failWithScreenshot("Error with Selection of Car Finance NonEc41", resultDirectory, driver, extent, logger);
			e.printStackTrace();
		}
		Object[] prices = new Object[2];
		prices[0] = MonthlyPriceFinance;
		prices[1] = MonthlyPriceFinanceNum;
		return prices;

	}

	@Test(description = "Validating Brand And Price_Finance_Type")
	public static void validateBrandAndPrice_Finance_Type(String resultDirectory, WebDriver driver,
			ExtentReports extent, ExtentTest logger, String Brand, String Country, String VehicleChoice) {

		try {
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			ChooseVehicleVersion btn = new ChooseVehicleVersion(driver);
			ConfigPage cyp = new ConfigPage(driver);
			HomePage hmpg = new HomePage(driver);
			SoftAssert sa = new SoftAssert();
			// checks finance veicule is present

			btn.clickSelectFinanceOfferType(Country, logger);
			logger.log(Status.INFO, MarkupHelper.createLabel("Clicked on Personnalizes Button", ExtentColor.BLUE));

			// checks arriving on config page
			if (Country.equalsIgnoreCase("FR")) {
				if (cyp.getCustomizeYourProjectText_FR(resultDirectory,logger).contains("PERSONNALISEZ VOTRE PROJET")) {
					logger.log(Status.PASS, MarkupHelper.createLabel("PERSONNALISEZ VOTRE PROJET page has appeared",
							ExtentColor.GREEN));
					sa.assertTrue(true);
				} else {
					failWithScreenshot("PERSONNALISEZ VOTRE PROJET page has not appeared", resultDirectory, driver,
							extent, logger);
					sa.assertTrue(false, "PERSONNALISEZ VOTRE PROJET page has not appeared");
					driver.quit();

				}
			}
			if (Country.equalsIgnoreCase("UK")) {
				if (driver.getCurrentUrl().contains("vauxhall")) {
					if (cyp.getCustomizeYourProjectText_UK_VX(resultDirectory,logger).contains("PERSONNALISEZ VOTRE PROJET")) {
						logger.log(Status.PASS, MarkupHelper.createLabel("PERSONALISE YOUR OFFER page has appeared",
								ExtentColor.GREEN));
						sa.assertTrue(true);
					} else {
						failWithScreenshot("PERSONALISE YOUR OFFER page has not appeared", resultDirectory, driver,
								extent, logger);
						sa.assertTrue(false, "PERSONALISE YOUR OFFER page has not appeared");
						driver.quit();

					}
				} else {
					if (cyp.getCustomizeYourProjectText_UK(resultDirectory,logger).contains("PERSONALISE YOUR VEHICLE")) {
						logger.log(Status.PASS, MarkupHelper.createLabel("PERSONALISE YOUR VEHICLE page has appeared",
								ExtentColor.GREEN));
						sa.assertTrue(true);
					} else {
						failWithScreenshot("PERSONALISE YOUR VEHICLE page has not appeared", resultDirectory, driver,
								extent, logger);
						sa.assertTrue(false, "PERSONALISE YOUR VEHICLE page has not appeared");

						driver.quit();

					}
				}
			}
			sa.assertAll();
		} catch (Exception e) {
			logger.log(Status.PASS, MarkupHelper.createLabel("Error while Validating Brand And Price_Finance_Type",
					ExtentColor.BLUE));
			failWithScreenshot("Error while Validating Brand And Price_Finance_Type", resultDirectory, driver,
					extent, logger);
			e.printStackTrace();
		}

	}
}
