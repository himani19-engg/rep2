package solRetailIHM.ProjSpecFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import solRetailIHM.PageObjectModel.PaymentCashPage;
import solRetailIHM.PageObjectModel.PersonnalInfoPage;
import solRetailIHM.Utilities.UniversalMethods;

import static solRetailIHM.PageObjectModel.HomePage.getHomePageVahicleName;
import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.getbasketPgVehicleName;
import static solRetailIHM.ProjSpecFunctions.ChooseCar.ChooseCarCashNonEc41.vehicleName;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

@Test(description = "Payment Transaction along with validation")
public class PaymentCash extends UniversalMethods {
	public static ExtentTest paymentTransactionAlongWithValidation;
	public static ExtentTest paymentDetails;
	public static void Payment(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String brand, String country,String MopValidation, String CarNumber, String CarDate, String CVC, String PaymentMode,String EmailId,String PostalCode,String City,String Phone,String Name) {
		if(driver!=null) {

			paymentTransactionAlongWithValidation = logger.createNode("Payment", "Check Payment page");
			paymentDetails = paymentTransactionAlongWithValidation.createNode("Payment Informations", "Payment details");

			try {
				PaymentCashPage pay = new PaymentCashPage(driver);
				//SoftAssert sa = new SoftAssert();
				//Thread.sleep(2000);
				//  card number
				pay.EnterCardNumber(CarNumber);
				paymentDetails.log(Status.INFO, "Credit card number has been entered");

				// card Name
				pay.EnterCardName();
				paymentDetails.log(Status.INFO, "Credit card name has been entered");

				// card expirydate
				pay.EnterExpiryDate(CarDate);
				paymentDetails.log(Status.INFO, "Credit card expiry date has been entered");

				// card CVC
				pay.EnterCVC(CVC);
				paymentDetails.log(Status.INFO, "Credit card CVC has been entered");

				// validate
				Thread.sleep(1000);
				pay.Validate();
				if (MopValidation.equals("yes")) {
					// waitForUrlContains("mpi-v1-simulation.test.v-psp.com", driver, 240);
					pay.confirm();
				}

				// Check order
				if (MopValidation.equals("yes")) {
					try {
						PaymentPgDetails(resultDirectory,driver,extent,paymentTransactionAlongWithValidation,brand, country, PaymentMode, EmailId,PostalCode,City,Phone,Name);

						if (brand.equals("OV")) {
							waitForUrlContains("checkout/order-review", driver, 20);
						} else {
							waitForUrlContains("payment/confirmation", driver, 20);
						}
						if (pay.getOrderValidTitle(country, brand)) {
							paymentDetails.log(Status.PASS, "Order has been validated");
							//sa.assertTrue(true);
						} else {
							failWithScreenshot("Error at order payment", resultDirectory, driver, extent, paymentTransactionAlongWithValidation);
							//sa.assertTrue(false, "Error at order payment");
						}
					} catch (org.openqa.selenium.TimeoutException e2) {
						e2.printStackTrace();
						driver.close();
					} catch (Exception e) {
						e.printStackTrace();
					}

				}
				boolean check = false;
				if (MopValidation.equals("no")) {
					if (brand.equals("OV")) {
						waitForUrlContains("checkout/pre-order", driver, 20);
					} else {
						waitForUrlContains("/order-summary", driver, 20);
					}

					if (brand.equals("OV")) {
						WebDriverWait wait = new WebDriverWait(driver,50);
						wait.until(ExpectedConditions.urlContains("/pre-order"));
						if (driver.getCurrentUrl().contains("/pre-order")) {
							paymentDetails.log(Status.PASS, "Landed on Pre-order Page");
						} else {
							paymentDetails.log(Status.FAIL, "Could not Land on Pre-order Page");
						}
					} else {
						//Thread.sleep(9000);
						WebDriverWait wait = new WebDriverWait(driver,50);
						wait.until(ExpectedConditions.urlContains("/order-summary"));
						if (driver.getCurrentUrl().contains("/order-summary")) {
							paymentDetails.log(Status.PASS, "Landed on order-summary Page");
						} else {
							paymentDetails.log(Status.FAIL, "Could not Land on order-summary Page");
						}
					}

					if (pay.getOrderInvalidTitle() == true) {
						paymentDetails.log(Status.PASS, "Order has been refused");
					} else {
						failWithScreenshot("Error at order refusal", resultDirectory, driver, extent, paymentDetails);
					}
				}

				//sa.assertAll();
			} catch (Exception e) {
			/*paymentTransactionAlongWithValidation.log(Status.FAIL,"Test Failed while doing Payment Transaction along with validation");
			failWithScreenshot("Test Failed while doing Payment Transaction along with validation", resultDirectory, driver, extent, paymentTransactionAlongWithValidation);
			paymentTransactionAlongWithValidation.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, paymentDetails, driver, "Test Failed while doing Payment Transaction along with validation", e);
			}
		}


	}
	@Test(description = "Payment page Details")
	public static void PaymentPgDetails(String resultDirectory, WebDriver driver, ExtentReports extent,
										ExtentTest logger, String brand, String Country, String PaymentMode,String EmailId,String PostalCode,String City,String Phone,String Name) throws Exception {

		if(!brand.equalsIgnoreCase("OV")){
		CheckPersonnalInfoCash.validateRetailerAddress(resultDirectory,driver,extent,paymentTransactionAlongWithValidation,brand, Country);
		CheckPersonnalInfoCash.validateRefundableFeeAmount(resultDirectory,driver,extent,paymentTransactionAlongWithValidation,brand, Country, PaymentMode);
		PersonnalInfoPage.compareVehicaleName(resultDirectory, driver, extent, paymentTransactionAlongWithValidation, getbasketPgVehicleName, "PaymentPage", By.xpath("//*[@class='versionLabel']"));
		PersonnalInfoPage.dateValidations(resultDirectory, driver, extent, paymentTransactionAlongWithValidation, Country);
		CheckPersonnalInfoCash.validatePersonalInfo(resultDirectory,driver,extent,paymentTransactionAlongWithValidation,brand, Country,EmailId,PostalCode,City,Phone,Name);
		}


	}

}
