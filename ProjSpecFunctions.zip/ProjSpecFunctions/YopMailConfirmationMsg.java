package solRetailIHM.ProjSpecFunctions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.OrderEmailPage;
import solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.HOME.CheckAccount;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import static solRetailIHM.ProjSpecFunctions.CheckGeneralInfo.Basket.PaymentMethodBasketPage.extentBP;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

public class YopMailConfirmationMsg extends UniversalMethods {
	public static ExtentTest validateEmail;
	@Test(description = "Validating Email")
	public static void validateEmail(String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger,
			String brand, String Country) {
		validateEmail= logger.createNode("ValidateEmailPage","Validate Email");
		if(driver!=null) {
			try {
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				OrderEmailPage emailPage = new OrderEmailPage(driver);

				// emailPage.openNewTab(driver);
				// ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
				// driver.switchTo().window(tabs.get(1));
				emailPage.openYOPEmail(resultDirectory, validateEmail, logger);
				// emailPage.AcceptCookies();
				//Thread.sleep(2000);
				emailPage.enterEmailId(emailPage.readFromProperties("RegisterEmail"), resultDirectory, validateEmail);
				// Thread.sleep(3000);
				emailPage.confirmEmail(resultDirectory, validateEmail);
				//validateEmail.log(Status.INFO, "Confirm email Id");
				//Thread.sleep(3000);
				//if(brand.equals("DS")) {
				//		Thread.sleep(10000);
				//}
				emailPage.clickRefresh(resultDirectory, validateEmail);
				//logger.log(Status.INFO, MarkupHelper.createLabel("Refresh email", ExtentColor.BLUE));
				//validateEmail.log(Status.INFO, "Refresh email");
				Thread.sleep(5000);
				emailPage.switchToMailFrame();
				System.out.println("switch frame");
				String fromEmailText = emailPage.getFromEmailText(resultDirectory, validateEmail);
				if (fromEmailText.contains("Citroën") || fromEmailText.contains("DS")
						|| fromEmailText.contains("Peugeot") || fromEmailText.contains("CITROËN")
						|| fromEmailText.contains("Opel")) {
					validateEmail.log(Status.PASS, "Brand text is present in email address");
					//Assert.assertTrue(true);
				} else {
					failWithScreenshot("Brand text is not present in email address", resultDirectory, driver, extent, validateEmail);
					//Assert.assertTrue(false, "Brand text is not present in email address");
				}
				// click on activation button
				Thread.sleep(2000);
				activateUserAccout(resultDirectory, driver, extent, validateEmail, Country);
				//Thread.sleep(2000);
				// Close Tab
				driver.close();
				validateEmail.log(Status.INFO, "Closed Tab after activating user account");
				ArrayList<String> allTabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(allTabs.get(0));
				validateEmail.log(Status.INFO, "Switched to Current Tab");
				//Thread.sleep(2000);
				System.out.println("Title: " + driver.getTitle());
				validateEmail.log(Status.INFO, "Title of the page is: " + driver.getTitle());
				emailPage.clickActivateContinueButton(resultDirectory, validateEmail);
				//Thread.sleep(5000);
				waitForUrlContains("/login", driver, 5);
				System.out.println("Current url is: " + driver.getCurrentUrl());
				validateEmail.log(Status.INFO, "Current url is: " + driver.getCurrentUrl());
				if (driver.getCurrentUrl().contains("/login")) {
					validateEmail.log(Status.PASS, "Redirected to Login Page after Activation of account successfully");
					passWithScreenshot("Test PASSED", resultDirectory, driver, validateEmail);
				} else {
					//validateEmail.log(Status.FAIL, "Unable to redirected to Login Page after Activation of account");
					failWithScreenshot("Unable to redirected to Login Page after Activation of account", resultDirectory, driver, validateEmail);
				}

				//Thread.sleep(2000);
				// Switch to mainTab
				// driver.switchTo().window(tabs.get(0));
				// logger.log(Status.PASS, MarkupHelper.createLabel("Switch to main tab",
				// ExtentColor.BLUE));

			} catch (Exception e) {
			/*validateEmail.log(Status.FAIL,"Test failed while validating email");
			failWithScreenshot("Test failed while validating email", resultDirectory, driver, extent, validateEmail);
			validateEmail.log(Status.FAIL, String.valueOf(e.getStackTrace()));*/
				catchFailDetails(resultDirectory, validateEmail, driver, "Test failed while validating email", e);
				//driver.close();
			}
		}
	}

	@Test(description = "Activating User Account")
	public static void activateUserAccout(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String Country) {

		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			OrderEmailPage emailPage = new OrderEmailPage(driver);

			emailPage.clickOnActivationButton(Country,resultDirectory,validateEmail);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Click on activate button in yopmail", ExtentColor.BLUE));
			//logger.log(Status.INFO, "Click on activate button in yopmail");
			//Thread.sleep(3000);
		}
		catch (Exception e) {
			/*failWithScreenshot("Test Failed while Activating User Account", resultDirectory, driver, extent, logger);
			e.printStackTrace();*/
			catchFailDetails(resultDirectory, logger,driver, "Test Failed while Activating User Account",e);
			//driver.close();
		}
	}

	@Test(description = "Checking Basket Share Email")
	public static void checkBasketShareEmail(String resultDirectory, WebDriver driver, ExtentReports extent,
			ExtentTest logger, String brand, String country, String emailId) {
		OrderEmailPage emailPage = new OrderEmailPage(driver);
		try {
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			// Open yopmail
			emailPage.openYOPEmail(resultDirectory, logger,logger);
			// enter email in yopmail
			emailPage.enterEmailId(emailId,resultDirectory, logger);
			// click on arrow
			emailPage.clickOnArrow();
			//Thread.sleep(2000);
			// refresh email
			//Thread.sleep(10000);
			//Thread.sleep(14000);
			emailPage.clickRefresh(resultDirectory,logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Refresh email", ExtentColor.BLUE));
			logger.log(Status.INFO, "Refresh email");
			Thread.sleep(5000);
			emailPage.switchToMailFrame();
			System.out.println("switch frame");
			//Thread.sleep(2000);
			// Setting button click
			emailPage.clickMySettingsButton(brand);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Click setting button", ExtentColor.BLUE));
			logger.log(Status.INFO, "Click setting button");
			Thread.sleep(5000);
			driver.close();
			ArrayList<String> allTabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(allTabs.get(0));
			//Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			/*
			failWithScreenshot("Test Failed while checking share basket mail in mailbox", resultDirectory, driver, extent, logger);
			Assert.assertTrue(false,"Element not found");*/
			catchFailDetails(resultDirectory, logger,driver, "Test Failed while checking share basket mail in mailbox",e);
			//driver.close();
		}
	}
	
	public static void checkForgotPasswordEmail(String resultDirectory, WebDriver driver, ExtentTest logger,
			String country, String brand, String emailId) throws Exception {
		OrderEmailPage emailPage = new OrderEmailPage(driver);
		String text = null;
		try {
			emailPage.openYOPEmail(resultDirectory,CheckAccount.accountCheck,logger);
			//logger.log(Status.PASS, MarkupHelper.createLabel("Open YOP email", ExtentColor.BLUE));
			//logger.log(Status.INFO, "Open YOP email");
			//Thread.sleep(2000);
			emailPage.enterEmailId(emailId, resultDirectory,CheckAccount.accountCheck);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Enter email Id", ExtentColor.BLUE));
			//logger.log(Status.INFO, "Enter email Id");
			emailPage.confirmEmail(resultDirectory,CheckAccount.accountCheck);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Confirm email Id", ExtentColor.BLUE));
			//logger.log(Status.INFO, "Confirm email Id");
			//Thread.sleep(3000);
			emailPage.clickRefresh(resultDirectory,logger);
			//logger.log(Status.INFO, MarkupHelper.createLabel("Refresh email", ExtentColor.BLUE));
			//logger.log(Status.INFO, "Refresh email");
			Thread.sleep(1000);
			emailPage.switchToMailFrame();
			System.out.println("switch frame");
			text = emailPage.getEmailSubject();
			if(text.contains("Changez votre mot de passe")
					|| text.contains("Mot de passe oublié")
					|| text.contains("renouvelez votre mot de passe")
					|| text.contains("Vous avez demandé de changer votre mot de passe pour myOpel") 
					|| text.contains("Restablecer tu contraseña")
					|| text.contains("Contraseña olvidada")) {
				logger.log(Status.PASS, "Forgot password email is present");
			}else {
				failWithScreenshot("Forgot password email is not present", resultDirectory, driver, logger);
			}
			
		}catch (Exception e) {
			/*logger.log(Status.FAIL,"Test failed in forgot password email");
			failWithScreenshot("Test failed in forgot password email", resultDirectory, driver, logger);
			e.printStackTrace();*/
			e.printStackTrace();
			catchFailDetails(resultDirectory, logger,driver, "Test failed in forgot password email",e);
		}
	}
}
