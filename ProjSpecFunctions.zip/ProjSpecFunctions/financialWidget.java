package solRetailIHM.ProjSpecFunctions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import solRetailIHM.PageObjectModel.FinancialWidgetPage;
import solRetailIHM.Utilities.UniversalMethods;

import java.util.concurrent.TimeUnit;

@Listeners(solRetailIHM.Runner.ListenerTest.class)

@Test(description = "Selection of financial Widget")
public class financialWidget extends UniversalMethods {

	public static void ModifyFinancialInfo(WebDriver driver, ExtentReports extent, ExtentTest logger, String Country,
			String PaymentMode, String VehicleChoice, String Brand) throws Exception

	{

		try {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			FinancialWidgetPage fwp = new FinancialWidgetPage(driver);
			Thread.sleep(5000);
			System.out.println("We start Finance Widget Change");
			fwp.ClickOnFinantialButton();

			if (Brand.equals("AP") || Brand.equals("AC") || Brand.equals("DS")) {
				fwp.ChooseMonthPeriod();
				System.out.println("We choose the month period");
				logger.log(Status.INFO, MarkupHelper.createLabel("We choose the month period", ExtentColor.BLUE));
				fwp.ChooseAnnualMileage();
				System.out.println("We choose the annual mileage");
				logger.log(Status.INFO, MarkupHelper.createLabel("We choose the annual mileager", ExtentColor.BLUE));
				if (Country.equals("FR")) {
					fwp.SubscribeAssurance();
					System.out.println("We choose no assurace offer");
					logger.log(Status.INFO, MarkupHelper.createLabel("We choose no assurance offer", ExtentColor.BLUE));

				}
			}

			fwp.ClickOnContinue(Brand);

		} catch (Exception e1) {
			logger.log(Status.FAIL, MarkupHelper.createLabel("Error in Selection of financial Widget", ExtentColor.RED));
			e1.printStackTrace();

		}

	}
}
