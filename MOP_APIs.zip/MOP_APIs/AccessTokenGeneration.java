package solRetailIHM.MOP_APIs;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.codehaus.jettison.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static solRetailIHM.MOP_APIs.MOPAPIs.mopAPIValidation;
import static solRetailIHM.ProjSpecFunctions.ValidateOrderFinance.checkPayment;

import io.restassured.specification.RequestSpecification;
import org.testng.asserts.SoftAssert;

public class AccessTokenGeneration {
	public static ExtentTest AccessTokenGeneration;
	/* private static String requestBody = "{\n" +
			//"  \"client_id\": \"summitdev\",\n" +
			//"  \"client_secret\": \"NL47vYHE34t\",\n" +
			 "  \"client_id\": \"mdesoc01\",\n" +
			"  \"client_secret\": \"desmsoc0\",\n" +
			"  \"grant_type\": \"client_credentials\" \n}";*/
		

	    @BeforeClass
	    public void setup() {
	    	
	    	RestAssured.config = RestAssured.config().sslConfig(CertHelper.getSslConfig());
	        RestAssured.baseURI = "https://monprojet-api-staging.sol.awsmpsa.com/oauth";
	    
	      
	    	
	    }

	    @Test
	    public String postRequest(String MopValidation) {
			AccessTokenGeneration = mopAPIValidation.createNode("AccessTokenGeneration_postRequest", "Checking Status Code and Response Code for MOP API");
	        Response response = given()
	        		.header("Content-type", "application/json")
	                .and()
	                //.body(requestBody)
					.queryParam("client_id","mdesoc01")
					.queryParam("client_secret","desmsoc0")
					.queryParam("grant_type","client_credentials")
					.when()
	                .post("/v2/token")
	                .then()
	                .extract().response();
	        System.out.println("Token generation status code is: "+response.getStatusCode());
			AccessTokenGeneration.log(Status.INFO, "Token generation status code is: "+response.getStatusCode());
	        String Response = response.body().asString();
			AccessTokenGeneration.log(Status.INFO, "Response is: "+Response);
			System.out.println("Response is: "+Response);
			String[] Response1 = Response.split(",");
	       // System.out.println(Response1[0]);
	        String[] Response2 =  Response1[0].split(":");
	       // System.out.println(Response2[1]);
	       
	        String AccessToken = Response2[1].substring(1, Response2[1].length()-1);
	        System.out.println("Access Token is: "+AccessToken);
			AccessTokenGeneration.log(Status.INFO, "Access Token is: "+AccessToken);
	        System.out.println("The response is: " +response.body().asString());
			AccessTokenGeneration.log(Status.INFO, "The response is: " +response.body().asString());
	        /*System.out.println("The request body is: " +requestBody);
			AccessTokenGeneration.log(Status.INFO, "The request body is: " +requestBody);*/
			System.out.println("The response code in Run time is: " +response.statusCode());
			AccessTokenGeneration.log(Status.INFO, "The response code in Run time is: " +response.statusCode());
			if(MopValidation.equalsIgnoreCase("yes")) {
				if(response.statusCode()==200) {
					AccessTokenGeneration.log(Status.PASS, "Status Code is validated successfully as: " +200);
				}else{
					AccessTokenGeneration.log(Status.FAIL, "Status Code could not be validated successfully as Status code which we get is: " +response.statusCode());
				}
			}
	        System.out.println("Access Token: "+AccessToken);
			AccessTokenGeneration.log(Status.INFO, "Access Token: "+AccessToken);
	        return AccessToken;
			
	        	       
	    }
}
