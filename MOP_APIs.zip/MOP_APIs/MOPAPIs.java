package solRetailIHM.MOP_APIs;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jettison.json.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static solRetailIHM.ProjSpecFunctions.ValidateOrderFinance.checkPayment;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import io.restassured.specification.RequestSpecification;

import solRetailIHM.MOP_APIs.AccessTokenGeneration;


public class MOPAPIs {

	public static ExtentTest mopAPIValidation;
	   	AccessTokenGeneration TokenObj = new AccessTokenGeneration();
	
	    @BeforeClass
	    public void setup() {
	    	
	    	RestAssured.config = RestAssured.config().sslConfig(CertHelper.getSslConfig());
	        RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
	        //RestAssured.baseURI = "https://monprojet-api-staging.sol.awsmpsa.com";
            }

	    public void postRequestAccept(String Country, String MOPID, String Brand, String MopValidation) {
			mopAPIValidation = checkPayment.createNode("postRequestAccept", "Checking Status Code and Response Code for MOP API");
			//Get MOP ID
			String CountryM = null;
			String BrandM = null;
			try {

				if (Country.equals("UK")) {
					CountryM = "GB";
				}

				if (Country.equals("FR")) {
					CountryM = "FR";
				}

				if (Country.equals("ES")) {
					CountryM = "ES";
				}

				if (Brand.equals("VX")) {
					BrandM = "OV";
				} else {
					BrandM = Brand;
				}
				TokenObj.setup();
				String Token = TokenObj.postRequest(MopValidation);
				System.out.println("Token Value is " + Token);
				mopAPIValidation.log(Status.INFO, "Token Value is " + Token);
				RestAssured.baseURI = "https://monprojet-api-staging.sol.awsmpsa.com";
				System.out.println(Brand);
				System.out.println(Country);
				System.out.println(MOPID);
				mopAPIValidation.log(Status.INFO, "Brand, Country and MOPID are respectively " + Brand + " ," + Country + " , " + MOPID);
				String requestBody = "{\n" +
						"  \"sourceName\": \"SUMMIT\",\n" +
						"  \"mopId\": \"" + MOPID + "\",\n" +
						"  \"brand\": \"" + BrandM + "\",\n" +
						"  \"country\": \"" + CountryM + "\",\n" +
						"  \"financeFile\": {\n" +
						"   	\"status\": \"Acceptation Definitive\",\n" +
						"   	\"statusId\": \"4\",\n" +
						"   	\"preScore\": \"vert\"" +
						"}\n}";
				mopAPIValidation.log(Status.INFO, "Request Body is:-------------->  ");
				mopAPIValidation.log(Status.INFO, requestBody);
				Response response = given().auth().oauth2(Token)
						.contentType(ContentType.JSON)
						//.header("Content-type", "application/json")
						//.header("Authorization", Token)
						.and()
						.body(requestBody)
						.when()
						.post("/api/mop/update")
						.then()
						.extract().response();

				System.out.println("request " + requestBody);
				System.out.println("Mop validation status code is: " + response.getStatusCode());
				mopAPIValidation.log(Status.INFO, "Mop validation status code is: " + response.getStatusCode());
				String Response = response.body().asString();
				System.out.println("Mop validation response is: " + Response);
				mopAPIValidation.log(Status.INFO, "Mop validation response is: " + Response);
			} catch (Exception e1) {
				//throw (e1);
				e1.printStackTrace();
			}

		}
	    
      public void postRequestRefused(String Country, String MOPID, String Brand, String MopValidation) {
		  mopAPIValidation = checkPayment.createNode("postRequestRefused", "Checking Status Code and Response Code for MOP API");
	    	//Get MOP ID
    	    String CountryM = null;
    	    String BrandM = null;
    	    
	    	try {
				
	    		if (Country.equals("UK")) {
	    			CountryM = "GB";
	    		}
	    		
	    		if (Country.equals("FR")) {
	    			CountryM = "FR";
	    		}
	    		if (Country.equals("ES")) {
	    			CountryM = "ES";
	    		}
	    		
	    		if (Brand.equals("VX")) {
	    			BrandM = "OV";
	    		}
	    		else 
	    		{
	    			BrandM = Brand;
	    		}
	    		
				TokenObj.setup();
				String Token =  TokenObj.postRequest(MopValidation);
				System.out.println("Token Value is " + Token);
				mopAPIValidation.log(Status.INFO, "Token Value is " + Token);
				RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
				System.out.println(Brand);
				System.out.println(Country);
				System.out.println(MOPID);
				mopAPIValidation.log(Status.INFO, "Brand, Country and MOPID are respectively " + Brand + " ," + Country + " , " + MOPID);
				String requestBody = "{\n" +
						"  \"sourceName\": \"SUMMIT\",\n" +
						"  \"mopId\": \""+MOPID+"\",\n" +
						"  \"brand\": \""+BrandM+"\",\n" +
						"  \"country\": \""+CountryM+"\",\n" +
						"  \"financeFile\": {\n" +
						//"   	\"status\": \"Refus Definitif\",\n" +
						"   	\"statusId\": \"5\",\n" +
						"   	\"preScore\": \"vert\"}\n}" ;
				
				System.out.println("request "+requestBody);
				mopAPIValidation.log(Status.INFO, "Request Body "+requestBody);
				Response response = given().auth().oauth2(Token)
						.contentType(ContentType.JSON)
		        		//.header("Content-type", "application/json")
		        		//.header("Authorization", "Bearer "+Token+"")
		                .and()
		                .body(requestBody)
		                .when()
		                .post("/api/mop/update")
		                .then()
		                .extract().response();
				
				//System.out.println("request "+requestBody);
				
				System.out.println("Mop validation status code is: "+response.getStatusCode());
				mopAPIValidation.log(Status.INFO, "Mop validation status code is: "+response.getStatusCode());
		        String Response = response.body().asString();
		        System.out.println("Mop validation response is: "+Response);
				mopAPIValidation.log(Status.INFO, "Mop validation response is: "+Response);
			}  catch (Exception e1)  { 

				throw (e1); 

				} 
	    	
	    }
	    
	    public void getRequest(WebDriver driver, String Country, String MOPID, String Brand, String MopValidation) {
			mopAPIValidation = checkPayment.createNode("getRequest", "Checking Status Code and Response Code for MOP API");
 	    	//Get MOP ID
	    	 String CountryM = null;
	    	 String BrandM = null;
		    	try {
					
		    		if (Country.equals("UK")) {
		    			CountryM = "GB";
		    		}
		    		
		    		if (Country.equals("FR")) {
		    			CountryM = "FR";
		    		}
		    		
		    		if (Country.equals("ES")) {
		    			CountryM = "ES";
		    		}
		    		
		    		if (Brand.equals("VX")) {
		    			BrandM = "OV";
		    		}
		    		else
		    		{
		    			BrandM = Brand; 
		    		}
		    		
 	    	
 				TokenObj.setup();
 				String Token =  TokenObj.postRequest(MopValidation);
 				System.out.println("Token Value is " + Token);
 				//RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
 				RestAssured.baseURI = "https://monprojet-api-staging.sol.awsmpsa.com";
 				
 				Response response = //given()
 						given().auth().oauth2(Token)
						.contentType(ContentType.JSON)
 		        		.header("Content-type", "application/json")
 		        		.header("Authorization", "Bearer "+Token+"")
 		                .get("/api/mop/"+BrandM+"/"+CountryM+"/mopId/"+MOPID+"")
 		                .then()
 		                .extract().response();
 				
 				 		        
 		        String Response = response.body().asString();
 		        System.out.println("Mop validation response is: "+Response);
				 mopAPIValidation.log(Status.INFO, "Mop validation response is: "+Response);
 		       String[] Response1 = Response.split("callBackUrl");
 		      // System.out.println(Response1[0]);
					String[] Response2 = new String[0];
					if(Response1[1].contains(",")) {
						 Response2 = Response1[1].split(",");
					}
 		       System.out.println(Response2[0]);
 		       
 		       String callBackURL = Response2[0].substring(3, Response2[0].length()-1).replaceAll("\\/", "");
 		       System.out.println("Call Back URL is: "+callBackURL);
				mopAPIValidation.log(Status.INFO, "Call Back URL is: "+callBackURL);
 		      
 		       
 		      ((JavascriptExecutor)driver).executeScript("window.open()");
				ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
			    driver.switchTo().window(tabs.get(1)); //switches to new tab
				driver.get(callBackURL);
				
				
 		       						
 			} catch (Exception e) {
 				
 				e.printStackTrace(); 
 			}

       
    }
	    	
	    	 
}
