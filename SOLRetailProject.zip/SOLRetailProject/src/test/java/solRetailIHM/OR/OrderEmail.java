package solRetailIHM.OR;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.By;

public class OrderEmail {
	public static HashMap<String, By> hm;
	
	public OrderEmail() {
		hm = new HashMap<String, By>();
		hm.put("AcceptCookies", By.id("accept"));
		hm.put("YopmailEmailField", By.className("ycptinput"));
		hm.put("For geeks", By.id("accept3"));
	}

	// Main driver method
	public static By OrderEmail_Loc(String Key) {
		
		return hm.get(Key);
	}

}
