package solo2c.Utilities;

import org.openqa.selenium.WebDriver;

public class BaseClass {
	static WebDriver driver=null;
	public void projectSetup() {
	String projectPath=System.getProperty("user.home");
	System.setProperty("webdriver.chrome.driver", projectPath+"/drivers/chromedriver.exe");
	}
}
