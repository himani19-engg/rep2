package solo2c.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;


public class UniversalMethods {
	// private static WebDriver driver=null;
	public static Properties prop;
	public static Properties config;
	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	public static String value;
	public static String Detectedlanguage;
	int colNum;
	int rowNum;

	public static Properties LoadConfig() throws IOException {

		config = new Properties();
		InputStream input = null;
		input = new FileInputStream("config.properties");
		// System.out.println("The input is: "+input);
		config.load(input);
		return config;
	}

	public UniversalMethods() {
		try {
			LoadConfig();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void scroling(WebDriver driver, By by) throws InterruptedException {
        for (int i = 0; i < 10; i++) {
            try {
                driver.findElement(by).click();
            	break;
            	}
             catch (ElementClickInterceptedException e) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollBy(0,50)");
                Thread.sleep(500);
            }
        }
		
	}
	
	public void clickUsingJS(WebDriver driver, By by) throws InterruptedException {
        try {
        	WebElement element = driver.findElement(by);
        	JavascriptExecutor executor = (JavascriptExecutor)driver;
        	executor.executeScript("arguments[0].click();", element);
        }catch(Exception e) {
        	
        }
		
	}
	
	public static String getScreenShot(WebDriver driver, String screenshotName) throws IOException {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		// after execution, you could see a folder "FailedTestsScreenshots" under src
		// folder
		String destination = System.getProperty("user.dir") + "/Screenshots/" + screenshotName + dateName + ".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}

	public String ReadCellData(int vRow, int vColumn, String ExcelSheetName, int SheetIndex) throws Exception {
		// getRowAndColumn(ExcelSheetName);
		value = null; // variable for storing the cell value
		HSSFWorkbook wb = null; // initialize Workbook null
		try {
			InputStream ins = getClass().getResourceAsStream("/com/" + ExcelSheetName + ".xls");
			wb = new HSSFWorkbook(ins);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		HSSFSheet sheet = wb.getSheetAt(SheetIndex); // getting the XSSFSheet object at given index
		HSSFRow row1 = sheet.getRow(0);
		colNum = row1.getLastCellNum();
		// System.out.println("Total Number of Columns in the excel is : " + colNum);
		rowNum = sheet.getLastRowNum() + 1;
		// System.out.println("Total Number of Rows in the excel is : " + rowNum);
		Row row = sheet.getRow(vRow);// returns the logical row
		Cell cell = row.getCell(vColumn); // getting the cell representing the given column
		if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
			value = cell.getStringCellValue();// getting cell value
			System.out.println("Value in excel sheet is: " + value);
		} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			value = String.valueOf(cell.getNumericCellValue());// getting cell value
			System.out.println("Value in excel sheet is: " + value);
		}
		return value;
	}

	public void getColRowNum(String ExcelSheetName, int SheetIndex) throws Exception {
		// getRowAndColumn(ExcelSheetName);
		value = null; // variable for storing the cell value
		HSSFWorkbook wb = null; // initialize Workbook null
		try {
			InputStream ins = getClass().getResourceAsStream("/com/" + ExcelSheetName + ".xls");
			wb = new HSSFWorkbook(ins);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		HSSFSheet sheet = wb.getSheetAt(SheetIndex); // getting the XSSFSheet object at given index
		HSSFRow row1 = sheet.getRow(0);
		colNum = row1.getLastCellNum();
		// System.out.println("Total Number of Columns in the excel is : " + colNum);
		rowNum = sheet.getLastRowNum() + 1;
		// System.out.println("Total Number of Rows in the excel is : " + rowNum);
	}

	public static void getRowAndColumn(String ExcelSheetName) throws Exception {
		FileInputStream fis = (FileInputStream) Class.class.getClassLoader()
				.getResourceAsStream("/com/" + ExcelSheetName + ".xls");
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheet("Sheet");
		HSSFRow row = sheet.getRow(0);
		int colNum = row.getLastCellNum();
		System.out.println("Total Number of Columns in the excel is : " + colNum);
		int rowNum = sheet.getLastRowNum() + 1;
		System.out.println("Total Number of Rows in the excel is : " + rowNum);
	}

	public static boolean isElementPresent(WebDriver driver, By by) throws InterruptedException {

		for (int k = 0; k <= 3; k++) {
			if (driver.findElements(by).size() == 0) {
				Thread.sleep(500);
				System.out.println("Waiting for element to be present...");
			} else {
				System.out.println("awaited element is found");
				return true;
			}
		}
		return false;
	}

	public static boolean isElementPresent(WebDriver driver, List<WebElement> allEle) throws InterruptedException {

		for (int k = 0; k <= 3; k++) {
			if (allEle.size() == 0) {
				Thread.sleep(500);
				System.out.println("Waiting for element to be present...");
			} else {
				System.out.println("awaited element is found");
				return true;
			}
		}
		return false;
	}

	public static boolean isElementPresentWithoutWait(WebDriver driver, By by) throws InterruptedException {
		if (driver.findElements(by).size() == 0) {
			System.out.println("Element is not present...");
			return false;
		} else {
			System.out.println("Element is present...");
			return true;
		}
	}

	public static boolean isElementPresentShort(WebDriver driver, By by) throws InterruptedException {

		for (int k = 0; k <= 2; k++) {
			if (driver.findElements(by).size() == 0) {
				Thread.sleep(200);
				System.out.println("Waiting for element to be present...");
			} else {
				System.out.println("awaited element is found");
				return true;
			}
		}
		return false;
	}

	

	public static void waitForElementPresent(WebDriver driver, By by) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	public static void waitForElementPresent(WebDriver driver, By by, int time) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	public static void waitForVisibilityofTextPresent(WebDriver driver, By by, int time, String text)
			throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(by), text));
	}

	public void waitForInvisibilityofElementsLocated(WebDriver driver, By by) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}

	public void waitForElementClickable(WebDriver driver, By by) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, 200);
		wait.until(ExpectedConditions.elementToBeClickable(by));
	}

	public void waitUntilElementIsInvisible(WebDriver driver, By by) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}

	public void clickElement(WebDriver driver, By by) throws InterruptedException {
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			if (isElementPresent(driver, by)) {
				driver.findElement(by).click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getAnyText(WebDriver driver, By by) {
		String text = null;
		try {
			// waitForElementPresent(driver, by);
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			if (isElementPresent(driver, by)) {
				text = driver.findElement(by).getText();
				System.out.println("Run time text is: " + text);
			} else {
				System.out.println("Required element is not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}
	
	public String getInnerHML(WebDriver driver, By by) {
		String text = null;
		try {
			// waitForElementPresent(driver, by);
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			if (isElementPresent(driver, by)) {
				text = driver.findElement(by).getAttribute("innerHTML");
				System.out.println("Run time text is: " + text);
			} else {
				System.out.println("Required element is not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}
	
	public String getInnerText(WebDriver driver, By by) {
		String text = null;
		try {
			// waitForElementPresent(driver, by);
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			if (isElementPresent(driver, by)) {
				text = driver.findElement(by).getAttribute("innerText");
				System.out.println("Run time text is: " + text);
			} else {
				System.out.println("Required element is not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}
	
	public String getClassValue(WebDriver driver, By by) {
		String classText = null;
		try {
			// waitForElementPresent(driver, by);
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			if (isElementPresent(driver, by)) {
				classText = driver.findElement(by).getAttribute("class");
				System.out.println("Run time Class is: " + classText);
				
			} else {
				System.out.println("Required element is not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return classText;
	}

	public static int extractNumericFromString(String str) {
		// String str = "abc d 1234567890pqr 54897";
		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			if (Character.isDigit(str.charAt(i))) {
				myNumbers.append(str.charAt(i));
				// System.out.println(str.charAt(i) + " is a digit.");
			} else {
				// System.out.println(str.charAt(i) + " not a digit.");
			}
		}
		System.out.println("Your numbers: " + myNumbers.toString());
		return Integer.parseInt(myNumbers.toString());
	}

	public void verifyIfTextpresent(WebDriver driver, By by, String expectedString) throws InterruptedException {
		try {
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
			SoftAssert sa = new SoftAssert();
			sa.assertEquals(getAnyText(driver, by).contains(expectedString), true);
			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterData(WebDriver driver, By by, String string) throws InterruptedException {
		try {
			if (isElementPresentShort(driver, by)) {
				driver.findElement(by).clear();
				driver.findElement(by).sendKeys(string);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isElementEnabled(WebDriver driver, By by) throws InterruptedException {
		if (driver.findElement(by).isEnabled() == true) {
			return true;
		} else {
			return false;
		}
	}

	public static String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	public void waitForElementTobeVisible(WebDriver driver, By by) {
		System.out.println("Waiting For Element To be Visible...");
		WebDriverWait some_element = new WebDriverWait(driver, 10);
		some_element.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	public void navigateBack(WebDriver driver) {
		System.out.println("Navigating Back...");
		driver.navigate().back();
	}

	public int NumberOfElements(WebDriver driver, By by) {
		System.out.println("Getting Number of elements");
		List<WebElement> allElements = driver.findElements(by);
		return allElements.size();
	}

	public void clickElementFromList(WebDriver driver, By by, String str) {
		System.out.println("Getting Number of elements");
		List<WebElement> allElements = driver.findElements(by);
		for (int i = 0; i <= allElements.size(); i++) {
			if (allElements.get(i).getText().contains(str)) {
				allElements.get(i).click();
			}

		}
	}

//Get method name using StackTraceElement.getMethodName()
	public static void getMethodNameUsingStackTraceElement() {
		StackTraceElement stackTraceElements[] = (new Throwable()).getStackTrace();
		System.out.println(
				"Current Method Execution Name Using StackTraceElement - " + stackTraceElements[0].getMethodName());
	}

//Get method name using Thread.currentThread().getStackTrace()
	public static void getMethodNameUsingCurrentThread() {
		System.out.println("Current Method Execution Name using Current Thread - "
				+ Thread.currentThread().getStackTrace()[1].getMethodName());
	}
	
	public static void waitForUrlContains(String expectedString, WebDriver driver, int specifiedTimeout) {
		   WebDriverWait wait = new WebDriverWait(driver, specifiedTimeout);
		   ExpectedCondition<Boolean> urlIsCorrect = arg0 ->    driver.getCurrentUrl().contains(expectedString);
		   wait.until(urlIsCorrect);
		   
		}
	
	//driver and screenshotName
	public static String getScreenshot(WebDriver driver, String resultDirectory, String screenshotName) {
	                //below line is just to append the date format with the screenshot name to avoid duplicate names		
	                String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
	                //after execution, you could see a folder "FailedTestsScreenshots" under src folder
			String destination = resultDirectory + "/FailedTestsScreenshots/"+screenshotName+dateName+".png";
			File finalDestination = new File(destination);
			try {
				FileUtils.copyFile(source, finalDestination);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	                //Returns the captured file path
			String ImagePath = "./FailedTestsScreenshots/"+screenshotName+dateName+".png";
			return ImagePath;
	}
	
	//Fail with screenshot
	public static void FailWithScreenshot(String text, String resultDirectory, WebDriver driver, ExtentReports extent, ExtentTest logger) {
	logger.log(Status.FAIL,"Failed test case");
	String screenshotPath = UniversalMethods.getScreenshot(driver, resultDirectory, "getCarTitle");
	System.out.println(screenshotPath);
	
	try {
		logger.log(Status.FAIL, text ,MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
