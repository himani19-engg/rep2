package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.MOP_APIs.MOPAPIs;
import solo2c.PageObjectModel.PaymentCashPage;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;

public class PaymentFinance extends UniversalMethods {

    public static void Payment(String resultDirectory,
                               String ScenarioName,
                               WebDriver driver,
                               ExtentReports extent,
                               ExtentTest logger,
                               String Country,
                               String Brand,
                               String PaymentMode,
                               String MOPID) {

        String CallBackURL = null;
        PaymentCashPage pay = new PaymentCashPage(driver);

        try {

            if (PaymentMode.equals("Valid")) {
                //Validate MOP
                MOPAPIs.postRequestAccept(Country, MOPID);

                //Complementary call for Italy
                if (Country.equals("IT")) {
                    MOPAPIs.postRequestITA(MOPID);
                }
            }

            if (PaymentMode.equals("Refusal")) {

                MOPAPIs.postRequestRefused(Country, MOPID);
            }

            //Get callBack URL
            CallBackURL = MOPAPIs.getRequest(Country, MOPID);

            ((JavascriptExecutor) driver).executeScript("window.open()");
            ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs.get(1)); //switches to new tab
            driver.get(CallBackURL);

            //Check order
            if (PaymentMode.equals("Valid")) {
                if (Country.equals("FR")) {
                    waitForUrlContains("ami/commande/confirmation", driver, 540);
                }
                if (Country.equals("IT")) {
                    waitForUrlContains("ami/order/confirmation", driver, 540);
                }

                if (pay.getOrderValidTitleFinance(Country)) {

                    logger.log(Status.PASS, "Order has been validated");
                } else {
                    FailWithScreenshot("Error at order payment", resultDirectory, driver, extent, logger);
                    driver.quit();
                }

            }
            if (PaymentMode.equals("Refusal")) {

                waitForUrlContains("preprod.summit-automotive.solutions/ami", driver, 540);
                logger.log(Status.PASS, "Order has been refused");

            }


        } catch (Exception e) {
            /*e.printStackTrace();
            FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
			catchFailDetails(resultDirectory, logger,driver, "Error with Payment Finance",e);

        }

    }


}
