package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.BasketPage;
import solo2c.PageObjectModel.HomePage;

import static solRetailIHM.Utilities.UniversalMethods.waitForPageToLoad;


public class BasketValidation extends UniversalMethods {

    public static Object[] Basket(String resultDirectory,
                                  Object[] prices,
                                  WebDriver driver,
                                  ExtentReports extent,
                                  ExtentTest logger,
                                  String Brand,
                                  String Country,
                                  String ScenarioMode,
                                  String Product,
                                  String Service) {


        BasketPage bkt = new BasketPage(driver);


        try {

            bkt.CheckBasketData(resultDirectory, extent, logger, Brand, ScenarioMode, Product, Service);

            bkt.CheckBasketDataPrices(resultDirectory, extent, prices, logger, Country, ScenarioMode);


            //Validate Basket
            bkt.Validate();
            //Thread.sleep(1000);
            waitForPageToLoad(driver,5);
            logger.log(Status.INFO, "Basket is validated");


        } catch (Exception e) {
            e.printStackTrace();
            FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);


        }

        return prices;

    }


}
