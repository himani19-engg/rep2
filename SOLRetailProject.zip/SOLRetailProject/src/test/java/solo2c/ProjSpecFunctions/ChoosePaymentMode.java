package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.CookieAccepter;
import solo2c.PageObjectModel.HomePage;

import solo2c.ProjSpecFunctions.MenuVehicle;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;
import static solRetailIHM.Utilities.UniversalMethods.waitForPageToLoad;


public class ChoosePaymentMode extends UniversalMethods {

    public static void ChoosePayment(String resultDirectory,
                                     WebDriver driver,
                                     ExtentReports extent,
                                     ExtentTest logger,
                                     String Country, String
                                             ScenarioMode) {

        HomePage hmpg = new HomePage(driver);

        try {
            Screen s = new Screen();
            String url = driver.getCurrentUrl();

            //String ImagePath = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\PaymentFR.png";
            String ImagePath = Paths.get(System.getProperty("user.dir"), "src", "test", "java", "solo2c", "Utilities", "Pictures", "PaymentFR.png").toString();
            Pattern PaymentFR = new Pattern(ImagePath);

            //String ImagePath2 = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\PaymentIT.png";
            String ImagePath2 = Paths.get(System.getProperty("user.dir"), "src", "test", "java", "solo2c", "Utilities", "Pictures", "PaymentIT.png").toString();
            Pattern PaymentIT = new Pattern(ImagePath2);

            //Case cash
            if ((ScenarioMode.equals("B2B")) || (ScenarioMode.equals("B2CC"))) {

                if (Country.equals("FR")) {
                    if (url.contains("journey=finance")) {
                        s.click(PaymentFR);
                        //Thread.sleep(500);
                        waitForPageToLoad(driver,1);
                    }
                }
                if (Country.equals("IT")) {
                    if (url.contains("journey=loa")) {
                        s.click(PaymentIT);
                        //Thread.sleep(500);
                        waitForPageToLoad(driver,1);
                    }
                }

                // checks page is opened in cash mode
                if (hmpg.checkCash()) {
                    logger.log(Status.PASS, "Cash mode has been choosen");
                } else {
                    FailWithScreenshot("Cash mode has not been choosen", resultDirectory, driver, extent, logger);
                    driver.quit();

                }
            }
            //Case finance
            if (ScenarioMode.equals("B2CF")) {
                if (url.contains("journey=cash")) {
                    if (Country.equals("FR")) {
                        s.click(PaymentFR);
                        //Thread.sleep(500);
                        waitForPageToLoad(driver,1);
                    }
                    if (Country.equals("IT")) {
                        s.click(PaymentIT);
                        //Thread.sleep(500);
                        waitForPageToLoad(driver,1);
                    }
                }
                // checks page is opened in finance mode
                if (hmpg.checkFinance()) {
                    logger.log(Status.PASS, "Finance mode has been choosen");
                } else {
                    FailWithScreenshot("Finance mode has not been choosen", resultDirectory, driver, extent, logger);
                    driver.quit();

                }
            }


        } catch (Exception e) {
            /*e.printStackTrace();
            FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
			catchFailDetails(resultDirectory, logger,driver, "Test Case Failed while choosing Payment",e);

        }
    }


}
