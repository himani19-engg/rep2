package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.ImatriculationPage;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;


public class Imatriculation extends UniversalMethods {

    public static void Imat(String resultDirectory,
                            WebDriver driver,
                            ExtentReports extent,
                            ExtentTest logger,
                            String Country,
                            String ScenarioMode,
                            String Imat) {

        ImatriculationPage imat = new ImatriculationPage(driver);

        try {
            Thread.sleep(2000);

            // scroll to the top of the page
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
            Thread.sleep(3000);

            //Case Country FR
            if ((Country.equals("FR")) && (!ScenarioMode.equals("B2CF"))) {
                // Case imat PSA
                if (Imat.equals("PSA")) {
                    imat.PSAImmat();
                    logger.log(Status.INFO, "PSA Imatriculation has been choosen");
                }
                //Case imat client
                if (Imat.equals("Client")) {
                    imat.ClientImmat();
                    ;
                    logger.log(Status.INFO, "Client Imatriculation has been choosen");
                }
                Thread.sleep(1000);
                //validate imat
                imat.ValidateImmat();
                Thread.sleep(500);
                logger.log(Status.INFO, "Imatriculation has been validated");


                //confirm imat
                if (Imat.equals("Client")) {
                    imat.ConfirmImmat();
                }

                waitForUrlContains("ami/commande", driver, 240);
                Thread.sleep(500);
                logger.log(Status.INFO, "Imatriculation has been confirmed");

            } else if ((Country.equals("FR")) && (ScenarioMode.equals("B2CF"))) {

                //validate imat
                imat.ValidateImmat();
                waitForUrlContains("ami/commande", driver, 240);
                Thread.sleep(500);
                logger.log(Status.INFO, "Imatriculation has been validated");

            }
            //Case Country IT
            else if (Country.equals("IT")) {

                //validate imat
                imat.ValidateImmat();

                waitForUrlContains("ami/order", driver, 240);
                Thread.sleep(2000);
                logger.log(Status.INFO, "Imatriculation has been validated");
            }


        } catch (Exception e) {
		/*e.printStackTrace();
		FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
            catchFailDetails(resultDirectory, logger, driver, "Test case failed while checking Imatriculation", e);


        }
    }


}
