package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.CookieAccepter;
import solo2c.PageObjectModel.HomePage;

import solo2c.ProjSpecFunctions.MenuVehicle;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;


public class LoginApplication extends UniversalMethods {

	public static void login(String resultDirectory, 
			                 WebDriver driver, 
			                 ExtentReports extent, 
			                 ExtentTest logger, 
			                 String Brand,
			                 String Country,
			                 String URL,
			                 String Dealer,
			                 String ScenarioMode) {
	
	
	
	CookieAccepter accept=new CookieAccepter(driver);
	HomePage hmpg=new HomePage(driver);	
		
	try {
		driver.manage().deleteAllCookies();
		driver.get(URL);
		Thread.sleep(2000);
		driver.manage().deleteAllCookies();
		driver.navigate().to(driver.getCurrentUrl());
		Thread.sleep(500);
		driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
		
		//handle cookie popup
		logger.log(Status.INFO,"Accepting cookie");
		Thread.sleep(500);
		accept.clickContAccepter();
		accept.clickCookiesAccept();
		Thread.sleep(500);
		
		//choosing mode B2B ou B2C 
		if (ScenarioMode.equals("B2B")) {
			if (Country.equals("IT")) {
				hmpg.clickB2BLinkIT();
				Thread.sleep(3000);
			}
			if (Country.equals("FR")) {
				hmpg.clickB2BLinkFR();
				Thread.sleep(3000);
			}
			
			waitForUrlContains("/pro/", driver, 120);
			
			logger.log(Status.INFO,"B2B mode has been choosen");
			
//			Screen s =new Screen();
//						
//			//String ImagePath = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\B2BImage.png";
//			String ImagePath = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities","Pictures", "B2BImage.png").toString();
//			Pattern B2BImage = new Pattern(ImagePath);
//			if (s.find(B2BImage)!=null) {
//				logger.log(Status.PASS,
//						MarkupHelper.createLabel("B2B mode has been choosen", ExtentColor.GREEN));
//			}
//			else {
//				FailWithScreenshot("B2B mode has not been choosen", resultDirectory, driver, extent, logger);
//			    driver.quit();
//			}		
		}
		else {
			if (Country.equals("IT")) {
				hmpg.clickB2CLinkIT();
				Thread.sleep(3000);
			}
			if (Country.equals("FR")) {
				hmpg.clickB2CLinkFR();
				Thread.sleep(3000);
			}
			
			logger.log(Status.INFO,"B2C mode has been choosen");
			
//			Screen s =new Screen();
//			
//			//String ImagePath = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\B2CImage.png";
//			String ImagePath = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities", "Pictures", "B2CImage.png").toString();
//			Pattern B2CImage = new Pattern(ImagePath);
//			if (s.find(B2CImage)!=null) {
//				logger.log(Status.PASS,
//						MarkupHelper.createLabel("B2C mode has been choosen", ExtentColor.GREEN));
//			}
//			else {
//				FailWithScreenshot("B2C mode has not been choosen", resultDirectory, driver, extent, logger);
//				driver.quit();
//			}		
				
		}
		
		//choose car 
		String InitURL = driver.getCurrentUrl();
	    System.out.println(InitURL);
	    String [] InitURL1 = InitURL.split("/");
	    String InitURL2 = ""; 
	    for (int i=0; i < InitURL1.length-1; i++) {
	    	InitURL2 = InitURL2 + "/" + InitURL1[i];
	    }
	    System.out.println(InitURL2);
	    if (Country.equals("FR")) {
	    	if ((ScenarioMode.equals("B2B"))||(ScenarioMode.equals("B2CC")))
		        {
			         if (Dealer.equals("FreeDealer")) {InitURL = InitURL2.substring(1) + "/" +  Brand + "?salesman=020200G-BASTIA&journey=cash"; }
			         else {InitURL = InitURL2.substring(1) + "/" +  Brand + "?journey=cash";}
			         logger.log(Status.INFO, "Cash mode has been choosen");
		        }
	        if (ScenarioMode.equals("B2CF"))
		        {
	        	     if (Dealer.equals("FreeDealer")) {InitURL = InitURL2.substring(1) + "/" +  Brand + "?salesman=020200G-BASTIA&journey=finance"; }
		             else {InitURL = InitURL2.substring(1) + "/" +  Brand + "?journey=finance";}
	        	     logger.log(Status.INFO,"Finance mode has been choosen");
		        }
	    }
        if (Country.equals("IT")) {
        	if ((ScenarioMode.equals("B2B"))||(ScenarioMode.equals("B2CC")))
	        {
        		 if (Dealer.equals("FreeDealer")) {InitURL = InitURL2.substring(1) + "/" +  Brand + "?salesman=216681E&journey=cash&isScrappageSelected=false"; }
	             else {InitURL = InitURL2.substring(1) + "/" +  Brand + "?journey=cash&isScrappageSelected=false";}
        		 
		         logger.log(Status.INFO,"Cash mode has been choosen");
	        }
        if (ScenarioMode.equals("B2CF"))
	        {
        	      if (Dealer.equals("FreeDealer")) {InitURL = InitURL2.substring(1) + "/" +  Brand + "?salesman=216681E&journey=loa&isScrappageSelected=false"; }
                  else {InitURL = InitURL2.substring(1) + "/" +  Brand + "?journey=loa&isScrappageSelected=false";} 
        	
		         logger.log(Status.INFO, "Finance mode has been choosen");
	        }
        	
	    }
	    System.out.println(InitURL);
	    driver.navigate().to(InitURL);
	    
		Thread.sleep(1000);	
		
		
		
//		//chose car 
//		MenuVehicle.Menu(null, Brand, driver);
//		Thread.sleep(500);
//		if (!hmpg.getCarTitle().equalsIgnoreCase(Brand)) {
//			MenuVehicle.Menu(null, Brand, driver);
//			Thread.sleep(500);
//		}
		
		//check right vehicule has been choosen
		if (hmpg.getCarTitle().equalsIgnoreCase(Brand.replaceAll("-",  " ")))
		{
			logger.log(Status.PASS,"Vehicle "+ Brand + " has been choosen");
		}
		else {
			FailWithScreenshot("Vehicle "+ Brand + " has not been choosen", resultDirectory, driver, extent, logger);
			driver.quit();
			
			//org.testng.Assert.fail();
		}
		
	}catch(Exception e) {
		/*e.printStackTrace();
		FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
		catchFailDetails(resultDirectory, logger,driver, "Test Case Failed on Login Page",e);
		
	}
	}


}
