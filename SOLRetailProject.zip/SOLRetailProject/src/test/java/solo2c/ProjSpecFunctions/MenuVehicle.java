package solo2c.ProjSpecFunctions;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.nio.file.Paths;
import java.util.Iterator;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen; 


public class MenuVehicle {
	//public static Screen s;
	public static void Menu(String arg[], String Brand, WebDriver driver) throws InterruptedException, FindFailed, AWTException {
	
	Screen s =new Screen();
	Robot robot = new Robot();
	
	//String ImagePath = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\OpenMenu.png";
	String ImagePath = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities", "Pictures", "OpenMenu.png").toString();
	Pattern OpenMenu = new Pattern(ImagePath);
	Thread.sleep(500);
	s.click(OpenMenu);
	Thread.sleep(500);
	
	//String ImagePath2 = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\AMIAMI.png";
	String ImagePath2 = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities", "Pictures", "AMIAMI.png").toString();
	Pattern AMIAMILogo = new Pattern(ImagePath2);
	
	//String ImagePath3 = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\AMIVIBE.png";
	String ImagePath3 = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities", "Pictures", "AMIVIBE.png").toString();
	Pattern AMIVIBELogo = new Pattern(ImagePath3);
	
	//String ImagePath4 = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\AMIColor.png";
	String ImagePath4 = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities", "Pictures", "AMIColor.png").toString();
	Pattern AMIColorLogo = new Pattern(ImagePath4);
	
	Thread.sleep(500);
	
	if (Brand.equals("ami ami")) {
		
		s.click(AMIAMILogo);
		//Thread.sleep(2000);
		
	}
	
	else if (Brand.equals("my ami vibe")) {
			
			s.click(AMIVIBELogo);
			//Thread.sleep(2000);
			
		}
	
	else if (!Brand.equals("my ami orange"))  {
		
		//s.mouseMove(AMIColorLogo);
		s.mouseMove(-100, 0);
		s.mouseMove(0, 60);
		//robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
 	    //robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		Thread.sleep(500);
		
		if (Brand.equals("my ami khaki")) {

			    s.mouseMove(150, 0);
			    Thread.sleep(500);
			    s.mouseMove(0, 15);
			    Thread.sleep(500);
		 	    robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		 	    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		    	
		    }
		    
	        if (Brand.equals("my ami grey")) {
	 	        
	        	s.mouseMove(300, 0);
	    	    Thread.sleep(500);
	        	s.mouseMove(0, 70);
	        	Thread.sleep(500);
		 	    robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		 	    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		    	
		    }
		    
	        if (Brand.equals("my ami blue")) {
	        
	    	    s.mouseMove(300, 0);
	    	    Thread.sleep(500);
	        	s.mouseMove(0, 100);
	        	Thread.sleep(500);
		 	    robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		 	    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		    	
		    }
		      
		}
		
		
	}
	

	}
	
	 
	
