package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.PaymentCashPage;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;


public class PaymentCash extends UniversalMethods {

	public static void Payment ( String resultDirectory, 
						            String ScenarioName, 
						            WebDriver driver, 
						            ExtentReports extent, 
						            ExtentTest logger,
						            String Country,
						            String ScenarioMode,
						            String PaymentMode,
            						String CarNumber,
            						String CarDate,
            						String CVC ) {
	
	
		PaymentCashPage pay = new PaymentCashPage(driver); 
	
	
	try {
		Thread.sleep(3000);
		//Saisie carte bleue
		pay.EnterCardNumber(CarNumber);
		logger.log(Status.INFO,"Credit card number has been entered");
		//Saisie date 
		pay.EnterExpiryDate(CarDate);
		logger.log(Status.INFO,"Credit card expiry date has been entered");
		//Siasie CVC 
		pay.EnterCVC(CVC);
		logger.log(Status.INFO,"Credit card CVC has been entered");
		
		//validate
		pay.Validate();
		if (PaymentMode.equals("Valid")) 
		{ 
			waitForUrlContains("mpi-v1-simulation.test.v-psp.com", driver, 540);
			pay.Confirm();
		}
		Thread.sleep(10000);
		
		driver.navigate().to(driver.getCurrentUrl());
		
		//Check order 
		if (PaymentMode.equals("Valid"))
		{
			if (Country.equals("FR")){
				waitForUrlContains("ami/commande/confirmation", driver, 540);
			}
			if (Country.equals("IT")) {
				waitForUrlContains("ami/order/confirmation", driver, 540);
			}
			
			if (pay.getOrderValidTitle(Country, ScenarioMode)){
					
						logger.log(Status.PASS,"Order has been validated");
					}		
						else {
							FailWithScreenshot("Error at order payment", resultDirectory, driver, extent, logger);
								driver.quit();
				    }
				  
			}
		if (PaymentMode.equals("Refusal"))
		{
			if (Country.equals("FR")){
				waitForUrlContains("ami/commande/paiement?status=declined", driver, 540);
			}
			if (Country.equals("IT")) {
				waitForUrlContains("/ami/order/payment?status=declined", driver, 540);
			}
			
			if (pay.getOrderRefuseTitle(Country)){
					
						logger.log(Status.PASS,"Order has been refused");
					}		
						else {
							FailWithScreenshot("Error at order refusal", resultDirectory, driver, extent, logger);
								driver.quit();
				    }
				  
			}
		

	} catch(Exception e) {
		/*e.printStackTrace();
		FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
		catchFailDetails(resultDirectory, logger,driver, "Error with Payment Cash",e);
		
	}
	
	}


}
