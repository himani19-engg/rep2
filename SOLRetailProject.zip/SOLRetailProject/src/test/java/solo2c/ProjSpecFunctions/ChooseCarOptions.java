package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.BasketPage;
import solo2c.PageObjectModel.HomePage;


public class ChooseCarOptions extends UniversalMethods {

    public static Object[] ChooseOptions(String resultDirectory,
                                         WebDriver driver,
                                         ExtentReports extent,
                                         ExtentTest logger,
                                         String Country,
                                         String ScenarioMode) {

        HomePage hmpg = new HomePage(driver);
        BasketPage bkt = new BasketPage(driver);

        String TotalPrice = null;
        String LoanPrice = null;
        String FirstLoanPrice = null;
        Object[] prices = new Object[2];


        try {

            //Chhose bonus 10% for IT country
            if ((Country.equals("IT")) && (!ScenarioMode.equals("B2B"))) {

                hmpg.ClickITRemmiseLink();
                Thread.sleep(500);
                hmpg.ClickITRemiseValidation();
                Thread.sleep(500);
                logger.log(Status.INFO, "10% BONUS ROTTAMAZIONE INCLUSO has been activated");

            }

            //Scroll to top of page
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
            Thread.sleep(500);

//		 //add product kit main libre
//		 hmpg.SelectAdditionnalProduct();
//		 
//		 if (Country.equals("FR"))
//		 {
//			 hmpg.AddAdditionnalProductFR();
//		 }
//			 
//		 if (Country.equals("IT"))
//		 {
//			 hmpg.AddAdditionnalProductIT();
//		 }
//	    Thread.sleep(500);  
//		hmpg.ValidateProduct();
//		Thread.sleep(500);  
//		logger.log(Status.INFO, MarkupHelper.createLabel("KIT MAINS-LIBRES NOMADE POUR SMARTPHONE has been choosen", ExtentColor.BLUE));
//		
            //add service my AMI care 3 years
            if ((ScenarioMode.equals("B2B")) || (ScenarioMode.equals("B2CC"))) {
                hmpg.SelectAdditionnalService();

                if (Country.equals("FR")) {
                    hmpg.AddAdditionnalServiceFR();
                }

                if (Country.equals("IT")) {
                    hmpg.AddAdditionnalServiceIT();
                }
                Thread.sleep(2000);
                hmpg.ValidateProduct();
                logger.log(Status.INFO, "MY AMI CARE 3 YEARS has been choosen");
            }

            //get prices for car
            if ((ScenarioMode.equals("B2B")) || (ScenarioMode.equals("B2CC"))) {

                TotalPrice = hmpg.getCarTotalPrice();
                System.out.println("TotalPrice : " + TotalPrice);
                prices[0] = TotalPrice;


            }

            if (ScenarioMode.equals("B2CF")) {
                LoanPrice = hmpg.getCarLoanPrice();
                System.out.println("LoanPrice : " + LoanPrice);
                prices[0] = LoanPrice;

                if (Country.equals("FR")) {
                    FirstLoanPrice = hmpg.getFirstLoanPriceFR();
                    System.out.println("FirstLoanPrice : " + FirstLoanPrice);
                    prices[1] = FirstLoanPrice;
                }
                if (Country.equals("IT")) {
                    FirstLoanPrice = hmpg.getFirstLoanPriceIT();
                    System.out.println("FirstLoanPrice : " + FirstLoanPrice);
                    prices[1] = FirstLoanPrice;
                }

            }

            //Validate services and options
            hmpg.Validate();
            Thread.sleep(500);

            //Validate arriving on basket page


            if (Country.equals("FR")) {
                waitForUrlContains("/ami/panier", driver, 240);
                if (bkt.checkBasketTitleFR()) {
                    logger.log(Status.PASS, "BASKET page has appeared");
                } else {
                    FailWithScreenshot("BASKET page has not appeared", resultDirectory, driver, extent, logger);
                    driver.quit();

                }
            }
            if (Country.equals("IT")) {
                waitForUrlContains("/ami/basket", driver, 240);
                if (bkt.checkBasketTitleIT()) {
                    logger.log(Status.PASS, "BASKET page has appeared");
                } else {
                    FailWithScreenshot("BASKET page has not appeared", resultDirectory, driver, extent, logger);
                    driver.quit();

                }
            }


        } catch (Exception e) {
            e.printStackTrace();
            FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);

        }

        return prices;

    }


}
