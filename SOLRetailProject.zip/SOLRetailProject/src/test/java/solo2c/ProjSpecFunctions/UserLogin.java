package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;


import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.LoginPage;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;

public class UserLogin extends UniversalMethods {

    public static void Login(String resultDirectory,
                             WebDriver driver,
                             ExtentReports extent,
                             ExtentTest logger,
                             String Country,
                             String ScenarioMode,
                             String Email,
                             String Password,
                             String ConnectMode,
                             String Coordinates,
                             String DeliveryAdress) {


        LoginPage log = new LoginPage(driver);


        try {

            //Go to login Page
            log.GoToLoginPage();
            waitForUrlContains("/login?", driver, 60);
            driver.get(driver.getCurrentUrl());
            Thread.sleep(2000);
            logger.log(Status.INFO, "Login button has been clicked");

            //Enter Email
            log.enterEmail(Email);
            logger.log(Status.INFO, "Email has been entered");

            Thread.sleep(10000);
            //Enter Password
            log.enterPassword(Password);
            logger.log(Status.INFO, "Password has been entered");


            Thread.sleep(10000);
            //Validate login
            log.validateLogin();
            waitForUrlContains("summit-automotive.solutions", driver, 240);
            logger.log(Status.INFO, "Login has been validated");

            if (Country.equals("IT")) {
                log.ScrollItaly(Country);
            }

            if (Country.equals("FR")) {
                log.ScrollFrance(Country);
            }

            Thread.sleep(3000);

            //check adress
            log.CheckAdressData(resultDirectory, extent, logger, Country, Coordinates, DeliveryAdress);

            //validate personal information
            log.PersonnalInfoValidate();
            Thread.sleep(500);


        } catch (Exception e) {
		/*e.printStackTrace();
		FailWithScreenshot("Test Case is Failed", resultDirectory, driver, extent, logger);*/
            catchFailDetails(resultDirectory, logger, driver, "Test Case Failed while user Login", e);

        }


    }


}
