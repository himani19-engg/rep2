package solo2c.ProjSpecFunctions;

import java.nio.file.Paths;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.PageObjectModel.FinancialWidgetPage;
import solo2c.Utilities.UniversalMethods;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;


public class FinancialWidget extends UniversalMethods {

    public static void Finance(String resultDirectory,
                               WebDriver driver,
                               ExtentReports extent,
                               ExtentTest logger,
                               String Country) {

        FinancialWidgetPage fwp = new FinancialWidgetPage(driver);
        String MounthlyPrice = null;
        String FirstLoanPrice = null;
        String Duration = null;

        if (Country.equals("FR")) {
            Duration = "24Mois";
        } else if (Country.equals("IT")) {
            Duration = "24mesi";
        }

        try {
            //Click on finantial Icon
//		Screen s =new Screen();
//		
//		//String ImagePath = "\\src\\test\\java\\solo2c\\Utilities\\Pictures\\Widget.png";
//		String ImagePath = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities","Pictures", "Widget.png").toString();
//		Pattern Finacebutton = new Pattern(ImagePath);
//		System.out.println("here is the test before");
//			
//		
//		s.click(Finacebutton);

            fwp.ClickFinanceWidgetButton();
            logger.log(Status.INFO, "Financial Widget opened");
            Thread.sleep(5000);

            //Click on LLA + Ami Car
            fwp.ClickOnLLAAndAmiCare();
            logger.log(Status.INFO, "LLA + Ami Car has been Choosen");
            Thread.sleep(500);

            //Choose 24 mounths
            fwp.Choose24mounths();
            logger.log(Status.INFO, "24 Month duration has been Choosen");
            Thread.sleep(500);

            //Get Monthly Price
            MounthlyPrice = fwp.GetMounthlyPrice();
            System.out.println("******* " + fwp.GetTableMounthlyPrice(Country));


            //Get First Loan Price
            FirstLoanPrice = fwp.GetFirstLoanPrice();
            System.out.println("******* " + fwp.GetTableFirstLoanPrice(Country));


            //Check Table Mounthly Price
            if (fwp.GetTableMounthlyPrice(Country).contains(MounthlyPrice)) {
                logger.log(Status.PASS, "Widget Mountly Price is correct");
            } else {
                FailWithScreenshot("Widget Mountly Price is not correct", resultDirectory, driver, extent, logger);
                driver.quit();

            }

            //Check Table Fisrt Loan Price
            if (fwp.GetTableFirstLoanPrice(Country).equals(FirstLoanPrice)) {
                logger.log(Status.PASS, "Widget First Loan Price is correct");
            } else {
                FailWithScreenshot("Widget First Loan Price is not correct", resultDirectory, driver, extent, logger);
                driver.quit();

            }

            System.out.println("The duration is" + Duration);
            System.out.println(fwp.GetTableDuration(Country));

            //Check Table Duration
            if (fwp.GetTableDuration(Country).equals(Duration)) {
                logger.log(Status.PASS, "Widget Duration is correct");
            } else {
                FailWithScreenshot("\"Widget Duration is not correct\"", resultDirectory, driver, extent, logger);
                driver.quit();

            }


            //Click on Confirmation Button

            fwp.Confirm();
            Thread.sleep(500);
            logger.log(Status.INFO, "Financial Widget Closed");


        } catch (Exception e) {
		/*e.printStackTrace();
		FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
            catchFailDetails(resultDirectory, logger, driver, "Unable to get value of finance Widget CheckBox", e);

        }
    }


}
	

