package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.BasketPage;
import solo2c.PageObjectModel.DeliveryOptionsPage;
import solo2c.PageObjectModel.LoginPage;
import solo2c.PageObjectModel.OrderPage;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;
import static solRetailIHM.Utilities.UniversalMethods.waitForPageToLoad;


public class OrderValidation extends UniversalMethods {

	public static String Order( String resultDirectory,
			                  String DeliveryDate,
			                  WebDriver driver, 
			                  ExtentReports extent, 
			                  ExtentTest logger,
			                  String Brand, 
			                  String Country,
			                  String Dealer,
			                  String ScenarioMode,
			                  String Product, 
			                  String Service,
			                  String DealerName,
			                  String DeliveryAdress,
			                  String OrderCoordinates,
			                  String ImatText,
			                  String ordercheck) {
	
	
	BasketPage bkt = new BasketPage(driver); 
	DeliveryOptionsPage del = new DeliveryOptionsPage(driver);
	LoginPage log = new LoginPage(driver);
	OrderPage or = new OrderPage(driver);
	String MOPID = null;
	
	try {
		//Thread.sleep(2000);
		waitForPageToLoad(driver,5);
		//Basket validation
		bkt.ScrollBasket(Country, ordercheck);
		//Thread.sleep(500);
        bkt.CheckBasketData(resultDirectory,extent, logger, Brand, ScenarioMode, Product,Service);
		waitForPageToLoad(driver,5);
        bkt.ScrollBasket(Country, ordercheck);
        //Thread.sleep(500);
		waitForPageToLoad(driver,5);
		
		
		//Delivery validation
		del.ScrollDelivery(Country);
		//Thread.sleep(500);
		waitForPageToLoad(driver,5);
		del.CheckDeliveryData(resultDirectory, extent, logger, Dealer, ScenarioMode, DealerName);
		
		if (del.getDeliveryDate().equals(DeliveryDate))
		{
			logger.log(Status.PASS, "Delivery Date is OK");
		}		
			else {
				FailWithScreenshot("Delivery Date is not OK", resultDirectory, driver, extent, logger);
					driver.quit();
							
		}
		//Thread.sleep(500);
		waitForPageToLoad(driver,5);
		del.ScrollDelivery(Country);
		//Thread.sleep(500);
		waitForPageToLoad(driver,5);
		
		//Adress validation
		log.ScrollAdress(Country, ordercheck);
		//Thread.sleep(500);
		waitForPageToLoad(driver,5);
		or.CheckAdressData(resultDirectory, extent, logger, Country,ScenarioMode, DeliveryAdress, OrderCoordinates);
		//Thread.sleep(500);
		waitForPageToLoad(driver,5);
		log.ScrollAdress(Country, ordercheck);
		//Thread.sleep(500);
		waitForPageToLoad(driver,5);
		
		//Imat Validation
		if (Country.equals("FR")) {
			or.clickImatTitle();
			//Thread.sleep(500);
			waitForPageToLoad(driver,5);
			 if (or.getImat().equals(ImatText))
				{
					logger.log(Status.PASS, "Immatriculation is OK");
				}		
					else {
						FailWithScreenshot("Immatriculation is not OK", resultDirectory, driver, extent, logger);
							driver.quit();
			    }
			 //Thread.sleep(500);
			waitForPageToLoad(driver,5);
			 or.clickImatTitle();
			 //Thread.sleep(500);
			waitForPageToLoad(driver,5);
		}
		
		if (ordercheck.equals("confirmation")) {
			//get Mop ID 
			MOPID = or.getMOP();
			logger.log(Status.INFO, "MOP ID has been found " + MOPID);
		
			
			//Validate order for payment 
			if ((ScenarioMode.equals("B2B")) || (ScenarioMode.equals("B2CC"))) {
				or.clickConditionConsent();
				//Thread.sleep(2000);
				waitForPageToLoad(driver,5);
				or.clickServiceConsent();
				//Thread.sleep(2000);
				waitForPageToLoad(driver,5);
			}
			if (ScenarioMode.equals("B2CF")) {
				or.clickFinanceGuarantee();
			
			}
			
			or.clickPaymentConsent();
			//Thread.sleep(500);
			waitForPageToLoad(driver,5);
			or.ValidateOrderforPayment();
			
			//Validate ariving on payment page 
			if (Country.equals("FR")) {
				if (ScenarioMode.equals("B2B")) {
				    waitForUrlContains("/ami/commande/confirmation?", driver, 240);
				    
				    if (or.getOrderConfirmTitleB2B())
					{
						logger.log(Status.PASS,"Order has been confirmed");
					}		
						else {
							FailWithScreenshot("Order has not been confirmed", resultDirectory, driver, extent, logger);
								driver.quit();
				    }
				  }
				  if (ScenarioMode.equals("B2CC")) {
					  waitForUrlContains("stage-secure-gateway.hipay-tpp.com/", driver, 240);
					  logger.log(Status.INFO,"Payment page has appeared");
				  }
				  if (ScenarioMode.equals("B2CF")) {waitForUrlContains("uat-psa-finance", driver, 380);}
				    
			}
			if (Country.equals("IT")) {
				if ((ScenarioMode.equals("B2B")) || (ScenarioMode.equals("B2CC"))) {
				   waitForUrlContains("stage-secure-gateway.hipay-tpp.com/", driver, 360);
				   logger.log(Status.INFO,"Payment page has appeared");
				}
				  if (ScenarioMode.equals("B2CF")) {waitForUrlContains("ami.siscowebcrm.it", driver, 380);}
				    
			}
		}
		

	} catch(Exception e) {
		/*e.printStackTrace();
		FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
		catchFailDetails(resultDirectory, logger,driver, "Test Failed while order validation",e);
		
	}
	
	return MOPID; 
	
	}


}
