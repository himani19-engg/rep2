package solo2c.ProjSpecFunctions;

import java.awt.Robot;
import java.io.FileInputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;
import solo2c.PageObjectModel.DeliveryOptionsPage;


public class ChooseDeliveryOptions extends UniversalMethods {

    public static String Delivery(String resultDirectory,
                                  WebDriver driver,
                                  ExtentReports extent,
                                  ExtentTest logger,
                                  String Country,
                                  String ScenarioMode,
                                  String Dealer,
                                  String DealerName,
                                  String DeliverySearch) {


        DeliveryOptionsPage del = new DeliveryOptionsPage(driver);
        String DeliveryDate = null;

        try {

            Thread.sleep(3000);

            // scroll to the top of the page
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
            Thread.sleep(2000);

            if (!ScenarioMode.equals("B2B")) {
                //Case home delivery
                if (Dealer.equals("Home")) {
                    del.ChooseHome();
                    logger.log(Status.INFO, "Home delivery has been choosen");
                }

                //Case home delivery
                if (Dealer.equals("Dealer")) {
                    del.ChooseDealer();
                    logger.log(Status.INFO, "Dealer delivery has been choosen");
                }

                //Case home delivery
                if (Dealer.equals("FreeDealer")) {
                    logger.log(Status.INFO, "Free Dealer delivery has been choosen");
                    del.ChooseFreeDealer();
                }

                //Validate delivery choice
                del.ValidateChoice();
                Thread.sleep(2000);

                //search for Dealer
                if (Dealer.equals("Dealer")) {
                    del.enterDealerAddress(DeliverySearch);
                    del.ValidateDealer();
                    Thread.sleep(1000);
                    del.ValidateDealerChoice();
                    Thread.sleep(1000);
                    logger.log(Status.INFO, "Dealer has been validated");
                }
            }

            if (ScenarioMode.equals("B2B")) {
                //chhose delivery on choice of my site

                del.ChooseHome();
                logger.log(Status.INFO, "Delivery on the site of my choice has been choosen");

                //Validate delivery choice
                del.ValidateChoice();
                Thread.sleep(2000);

            }


            //get Delivery Date
            DeliveryDate = del.getDeliveryDate();
            logger.log(Status.INFO, "delivery date is : " + DeliveryDate);

            //Validate delivery choice
            del.ValidateDelivery();
            Thread.sleep(1000);


        } catch (Exception e) {
            e.printStackTrace();
            FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);

        }

        return DeliveryDate;

    }


}
