package solo2c.ProjSpecFunctions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.PageObjectModel.RegistrationPage;
import solo2c.Utilities.UniversalMethods;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;


public class UserRegistration extends UniversalMethods {

    public static Object[] Registration(String resultDirectory,
                                        WebDriver driver,
                                        ExtentReports extent,
                                        ExtentTest logger,
                                        String Country,
                                        String ScenarioMode) {

        RegistrationPage RP = new RegistrationPage(driver);
        Object[] Adresses = new Object[5];

        try {
            RP.ClickOnAcoountCreationButton();
            logger.log(Status.INFO, "User registration has been choosen");
            Thread.sleep(500);
            Adresses = RP.FeelRegistrationForm(Country, ScenarioMode);
            logger.log(Status.INFO, "User registration form has been field");
            RP.ClickOnConfirmationButton();
            Thread.sleep(20000);
            logger.log(Status.INFO, "User registration has been validated");

            //Check the Cofirmation Message
            String Message = null;
            if (Country.equals("FR")) {
                Message = "ACTIVER MON COMPTE";
            } else if (Country.equals("IT")) {
                Message = "ATTIVA IL MIO ACCOUNT";
            }

            System.out.println(RP.GetConfirmationMessage());
            System.out.println(Country);
            System.out.println(Message);

            if (RP.GetConfirmationMessage().equals(Message) == true) {
                logger.log(Status.PASS, "The activation Message got correctly");
            } else {
                FailWithScreenshot("Didn't get the activation message", resultDirectory, driver, extent, logger);
                driver.quit();
            }
            Thread.sleep(3000);
            RP.GotoYopmailAndActivateTheAccount(Country);
            Thread.sleep(3000);
            logger.log(Status.INFO,"User account has been validated");

        } catch (Exception e) {
		/*e.printStackTrace();
		logger.log(Status.FAIL,
		MarkupHelper.createLabel("Failed test case", ExtentColor.RED));*/
            catchFailDetails(resultDirectory, logger, driver, "Error while doing User Registration", e);

        }

        return Adresses;

    }
}

