package solo2c.Runner;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;

import solo2c.ScenarioMainClass.ScenarioMain_IT;


public class Runner_IT {
	
	@DataProvider
	public static Object[][] dataMethod() throws IOException {
		
		     
		     //String ExcelPath = "\\src\\test\\java\\solo2c\\Datafiles\\Runner_IT.xlsx";
		     String ExcelPath = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Datafiles", "Runner_IT.xlsx").toString();
	         FileInputStream FIP=new FileInputStream(ExcelPath);
		     XSSFWorkbook wb = new XSSFWorkbook(FIP);
			 XSSFSheet sh1 = wb.getSheet("Exec");
			 XSSFSheet sh2 = wb.getSheet("TC table");
			 DataFormatter formatter = new DataFormatter();
			 
			 int row1 = sh1.getLastRowNum();
			 int col1 = sh1.getRow(0).getLastCellNum();
             int ExecIndex =0;
			 int TCIndex = 0; 
			 List<String> TCName = new ArrayList<String>();
			 for (int k = 0 ; k<col1 ;k++) {
					String celldata = sh1.getRow(0).getCell(k).getStringCellValue();
					if (celldata.equalsIgnoreCase("Exec"))
					 {
						ExecIndex = k;
					 }
					if (celldata.equalsIgnoreCase("TC"))
					 {
						TCIndex = k;
					 }
			 }
			 //System.out.println(row1);
			 for (int j = 1 ; j<=row1 ;j++) {
				    String celldata = sh1.getRow(j).getCell(ExecIndex).getStringCellValue();
				    System.out.println(j);
					if (celldata.equals("x")) 
					{
						String cellvalue = sh1.getRow(j).getCell(TCIndex).getStringCellValue();
				        System.out.println(cellvalue);
						TCName.add(cellvalue);
					}
				}
			 System.out.println(TCName);
			 
			 
			 int row2 = sh2.getLastRowNum();
			 System.out.println(row2);
			 int col2 = sh2.getRow(0).getLastCellNum();
			 System.out.println(row2);
			 int TCIndex2 = 0;
			 for (int k = 0 ; k<col2 ;k++) {
					String celldata = sh2.getRow(0).getCell(k).getStringCellValue();
					if (celldata.equalsIgnoreCase("TC"))
					 {
						TCIndex2 = k;
					 }
			 }
			 
			 
			 
			 int x = 0;
			 System.out.println(row2);
			 Object[][] TCParam = new String[TCName.size()][col2-1];
			 for (int j = 1 ; j<=row2 ;j++) {
				    String celldata = sh2.getRow(j).getCell(TCIndex2).getStringCellValue();
				    System.out.println(celldata);
				    System.out.println(j);
				    if (TCName.contains(celldata)) {
				    	
				    	for (int l = 1 ; l<col2 ;l++) {
				    		String cellvalue = formatter.formatCellValue(sh2.getRow(j).getCell(l));
				    		TCParam[x][l-1]= cellvalue;
				    		
				    	}
				    	x= x+1;						   
	
				    }
				    
				    
			}
			return TCParam;
    }
	
	
	    @Factory(dataProvider="dataMethod")	
		public Object[] createInstances(String Brand,
				                        String Country,
				                        String URL,
				                        String ScenarioName,
				                        String Dealer,
				                        String ScenarioMode,
				                        String Product,
				                        String Service,
		                                String DealerName,
		                                String DeliverySearch,
		                                String Email, 
		                                String Password,
		                                String ConnectMode,
		                                String Coordinates,
		                                String DeliveryAdress,
		                                String Immat,
		                                String OrderCoordinates,
		                                String ImatText,
		                                String PaymentMode,
		                                String CarNumber,
		                                String CarDate,
		                                String CVC
				                        ) {
		  return new Object[] {new ScenarioMain_IT(Brand,
				                                Country,
				                                URL, 
				                                ScenarioName,
				                                Dealer,
				                                ScenarioMode,
				                                Product,
				                                Service,
				                                DealerName,
				                                DeliverySearch,
				                                Email,
				                                Password,
				                                ConnectMode,
				                                Coordinates,
				                                DeliveryAdress,
				                                Immat,
				                                OrderCoordinates,
				                                ImatText,
				                                PaymentMode,
				                                CarNumber,
				                                CarDate,
				                                CVC)};
	}
	

}
