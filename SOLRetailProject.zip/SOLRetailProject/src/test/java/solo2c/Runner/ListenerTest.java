package solo2c.Runner;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solRetailIHM.ScenarioMainClass.ScenarioMain_UK;

public class ListenerTest implements ITestListener  {

	public void onTestStart(ITestResult result) {
		System.out.println("Name of the Started test case is "+result.getName());	
		
	}

	public void onTestSuccess(ITestResult result) {
		System.out.println("Name of the Passed test case is "+result.getName());	
		
		
	}

	public void onTestFailure(ITestResult result) {
		System.out.println("Name of the Failed test case is "+result.getName());
		ScenarioMain_UK.logger.log(Status.FAIL,"Failed Scenario");
		ScenarioMain_UK.driver.quit();
		//org.testng.Assert.fail();
	}

	public void onTestSkipped(ITestResult result) {
		System.out.println("Name of the Skipped test case is "+result.getName());	
		ScenarioMain_UK.logger.log(Status.WARNING,"Skipped scenario");
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		ScenarioMain_UK.logger.log(Status.WARNING,"Failed within success percentage scenario");
		
	}

	public void onStart(ITestContext context) {
		
		
	}

	public void onFinish(ITestContext context) {
		
		
	}

	
	
}
