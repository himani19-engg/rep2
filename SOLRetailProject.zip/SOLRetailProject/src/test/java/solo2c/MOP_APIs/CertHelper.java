package solo2c.MOP_APIs;

import java.io.FileInputStream;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;

import io.restassured.config.SSLConfig;

public class CertHelper {

  public static SSLConfig getSslConfig() {
    String password = "57fMa23wTy";
    KeyStore keyStore = null;
    try {
      //FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\KeyStore\\keystore.jks");
      FileInputStream fis = new FileInputStream(Paths.get(System.getProperty("user.dir"), "KeyStore", "keystore.jks").toString());
      keyStore = KeyStore.getInstance("JKS");
      keyStore.load(
          fis,
          password.toCharArray());

    } catch (Exception ex) {
      System.out.println("Error while loading keystore >>>>>>>>>");
      ex.printStackTrace();
    }
    if (keyStore != null) {
      org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
      try {
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);
      } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
      } catch (KeyManagementException e) {
        e.printStackTrace();
      } catch (KeyStoreException e) {
        e.printStackTrace();
      } catch (UnrecoverableKeyException e) {
        e.printStackTrace();
      }
      return new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
    }
    else return  null;
  }
}
