package solo2c.MOP_APIs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.codehaus.jettison.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import io.restassured.specification.RequestSpecification;

public class AccessTokenGeneration {
	
	 private static String requestBody = "{\n" +
			"  \"client_id\": \"summitdev\",\n" +
			"  \"client_secret\": \"NL47vYHE34t\",\n" +
			"  \"grant_type\": \"client_credentials\" \n}";
		

	    @BeforeClass
	    public void setup() {
	    	
	    	RestAssured.config = RestAssured.config().sslConfig(CertHelper.getSslConfig());
	        RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com/oauth"; 
	    
	      
	    	
	    }

	    @Test
	    public String postRequest() {
	        Response response = given()
	        		.header("Content-type", "application/json")
	                .and()
	                .body(requestBody)
	                .when()
	                .post("/v2/token")
	                .then()
	                .extract().response();
	        
	        System.out.println("Token generation status code is: "+response.getStatusCode());
	        
	        String Response = response.body().asString();
	        
	       String[] Response1 = Response.split(",");
	      // System.out.println(Response1[0]);
	       String[] Response2 =  Response1[0].split(":");
	      // System.out.println(Response2[1]);
	       
	       String AccessToken = Response2[1].substring(1, Response2[1].length()-1);
	       //System.out.println("Access Token is: "+AccessToken);
	       
	        //System.out.println("The response is: " +response.body().asString());
	        
	        //System.out.println("The request body is: " +requestBody);
	        
	        AssertJUnit.assertEquals(200, response.statusCode());
	        
	        return AccessToken;
			
	        	       
	    }
}
