package solo2c.MOP_APIs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jettison.json.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import io.restassured.specification.RequestSpecification;

import solo2c.MOP_APIs.AccessTokenGeneration;



public class MOPAPIs {
	
	    
	   	
	
	    @BeforeClass
	    public void setup() {
	    	
	    	RestAssured.config = RestAssured.config().sslConfig(CertHelper.getSslConfig());
	        RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
            }
	    
	    @Test
	    public static void postRequestAccept(String Country, String MOPID) throws IOException {
	    
	    	//Validate MOP	    	
	    	AccessTokenGeneration TokenObj = new AccessTokenGeneration();
	    	TokenObj.setup();
			String Token =  TokenObj.postRequest();
			System.out.println("Token Value is " + Token);
			RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
			
			String requestBody = "{\n" +
					"  \"sourceName\": \"SUMMIT\",\n" +
					"  \"mopId\": \""+ MOPID +"\",\n" +
					"  \"brand\": \"AC\",\n" +
					"  \"country\": \""+ Country +"\",\n" +
					"  \"financeFile\": {\n" +
					"   	\"status\": \"Acceptation Definitive\",\n" +
					"   	\"statusId\": \"4\",\n" +
					"   	\"preScore\": \"vert\"}\n}" ;
			
			Response response = given()
					.header("Content-type", "application/json")
					.header("Authorization", "Bearer "+Token+"")
			        .and()
			        .body(requestBody)
			        .when()
			        .post("/api/mop/update")
			        .then()
			        .extract().response();
			
			System.out.println("request "+requestBody);
			
			System.out.println("Mop validation status code is: "+response.getStatusCode());
			
			String Response = response.body().asString();
			System.out.println("Mop validation response is: "+Response);
	    	
	    }
	    
	    
	@Test    
public static void postRequestRefused(String Country, String MOPID) {
	    					
	    		
		        AccessTokenGeneration TokenObj = new AccessTokenGeneration();
		        TokenObj.setup();
				String Token =  TokenObj.postRequest();
				System.out.println("Token Value is " + Token);
				RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
				String requestBody = "{\n" +
						"  \"sourceName\": \"SUMMIT\",\n" +
						"  \"mopId\": \""+MOPID+"\",\n" +
						"  \"brand\": \"AC\",\n" +
						"  \"country\": \""+Country+"\",\n" +
						"  \"financeFile\": {\n" +
						"   	\"status\": \"Refus Definitif\",\n" +
						"   	\"statusId\": \"5\",\n" +
						"   	\"preScore\": \"vert\"}\n}" ;
				
				Response response = given()
		        		.header("Content-type", "application/json")
		        		.header("Authorization", "Bearer "+Token+"")
		                .and()
		                .body(requestBody)
		                .when()
		                .post("/api/mop/update")
		                .then()
		                .extract().response();
				
				System.out.println("request "+requestBody);
				
				System.out.println("Mop validation status code is: "+response.getStatusCode());
		        
		        String Response = response.body().asString();
		        System.out.println("Mop validation response is: "+Response);
						
			}  
	
	
	        @Test
	        public static void postRequestITA(String MOPID) throws IOException {
	    	
	        	AccessTokenGeneration TokenObj = new AccessTokenGeneration();			
				TokenObj.setup();
				String Token =  TokenObj.postRequest();
				System.out.println("Token Value is " + Token);
				RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
				
				String requestBody = "{\n" +
						"  \"sourceName\": \"SUMMIT\",\n" +
						"  \"payment\": {\n" +
						"   	\"psaPayId\": \"172124\",\n" +
						"   	\"amount\": \"500\",\n" +
						"   	\"pspReference\": \"800089109513\",\n" +
						"       \"status\": \"AUTHORISED\",\n" +
						"       \"type\": \"BANKDEPOSIT\"} \n}" ;
				
				
				Response response = given()
		        		.header("Content-type", "application/json")
		        		.header("Authorization", "Bearer "+Token+"")
		                .and()
		                .body(requestBody)
		                .when()
		                .post("/api/mop/AC/IT/"+MOPID+"/payments/add")
		                .then()
		                .extract().response();
				
				System.out.println("request "+requestBody);
				
				System.out.println("Mop validation status code is: "+response.getStatusCode());
		        
		        String Response = response.body().asString();
		        System.out.println("Mop validation response is: "+Response);
	        }
	    
	        @Test
	    	public static String getRequest(String Country, String MOPID) throws IOException {
	 	    	
	    		AccessTokenGeneration TokenObj = new AccessTokenGeneration();
	    	    String callBackURL = null; 
	    		TokenObj.setup();
				String Token =  TokenObj.postRequest();
				System.out.println("Token Value is " + Token);
				RestAssured.baseURI = "https://monprojet-api-citroen-staging.sol.awsmpsa.com";
				
				Response response = given()
						.header("Content-type", "application/json")
						.header("Authorization", "Bearer "+Token+"")
				        .get("/api/mop/AC/"+Country+"/mopId/"+MOPID+"")
				        .then()
				        .extract().response();
				
				 		        
				String Response = response.body().asString();
				System.out.println("Mop validation response is: "+Response);
				
		       String[] Response1 = Response.split("callBackUrl");
		      // System.out.println(Response1[0]);
		       String[] Response2 =  Response1[1].split(",");
		       System.out.println(Response2[0]);
		       
		       callBackURL = Response2[0].substring(3, Response2[0].length()-1).replaceAll("\\/", "");
		       System.out.println("Call Back URL is: "+callBackURL);
	 	    	
	 	    	return callBackURL; 
	    	}
	    	
}
