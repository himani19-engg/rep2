package solo2c.ScenarioMainClass;

import org.testng.annotations.Test;
import java.io.File;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import solo2c.Utilities.UniversalMethods;
import solo2c.Utilities.BaseClass;
import solo2c.ProjSpecFunctions.ChoosePaymentMode;
import solo2c.ProjSpecFunctions.LoginApplication;
import solo2c.ProjSpecFunctions.ChooseCarOptions;
import solo2c.ProjSpecFunctions.BasketValidation;
import solo2c.ProjSpecFunctions.ChooseDeliveryOptions;
import solo2c.ProjSpecFunctions.FinancialWidget;
import solo2c.ProjSpecFunctions.Imatriculation;
import solo2c.ProjSpecFunctions.UserLogin;
import solo2c.ProjSpecFunctions.UserRegistration;
import solo2c.ProjSpecFunctions.OrderValidation;
import solo2c.ProjSpecFunctions.PaymentCash;
import solo2c.ProjSpecFunctions.PaymentFinance;


public class ScenarioMain_IT extends UniversalMethods {
	
	    final String URL;
		final String Brand;
		final String Country;
		final String ScenarioName;
		final String Dealer;
		final String ScenarioMode;
		final String Product;
		final String Service;
		final String DealerName;
		final String DeliverySearch;
		final String Email;
		final String Password;
		final String ConnectMode;
		final String Coordinates;
		final String DeliveryAdress;
		final String Immat;
		final String OrderCoordinates;
		final String ImatText;
		final String PaymentMode;
		final String CarNumber;
		final String CarDate;
		final String CVC; 
	
		public static WebDriver driver=null;
		public static ExtentHtmlReporter htmlReporter;
		public static ExtentReports extent;
		public static ExtentTest logger;
		public static Object [] carPrices;
		public static Object [] Adresses;
		public static String DeliveryDate;
		public static String resultDirectory;
		public static String MOPID;
		public static String EmailR;
		public static String PasswordR;
		public static String CoordinatesR;
		public static String DeliveryAdressR;
		public static String CoordinatesOrderR;
		
		
		public ScenarioMain_IT(String Brand, 
				            String Country, 
				            String URL, 
				            String ScenarioName,
				            String Dealer,
	                        String ScenarioMode,
	                        String Product,
	                        String Service,
	                        String DealerName,
	                        String DeliverySearch,
	                        String Email,
	                        String Password,
	                        String ConnectMode,
	                        String Coordinates,
	                        String DeliveryAdress,
	                        String Immat,
	                        String OrderCoordinates,
	                        String ImatText,
	                        String PaymentMode,
	                        String CarNumber,
		                    String CarDate,
		                    String CVC) {
			super();
			this.Brand = Brand;
			this.Country = Country;
			this.URL = URL;
			this.ScenarioName = ScenarioName;
			this.Dealer = Dealer;
			this.ScenarioMode = ScenarioMode;
			this.Product = Product;
			this.Service = Service;
		    this.DealerName = DealerName;
		    this.DeliverySearch = DeliverySearch;
		    this.Email = Email;
			this.Password = Password;
			this.ConnectMode = ConnectMode;
			this.Coordinates = Coordinates;
			this.DeliveryAdress = DeliveryAdress; 
			this.Immat = Immat;
			this.OrderCoordinates = OrderCoordinates;
			this.ImatText = ImatText;
			this.PaymentMode = PaymentMode;
			this.CarNumber = CarNumber;
			this.CarDate = CarDate;
			this.CVC = CVC;
		}
		
		@BeforeTest
		public void SetUp() throws Exception
		{
		BaseClass bc = new BaseClass();
		bc.projectSetup();
		
		
		String dateName = new SimpleDateFormat("EEE dd MMM yyyy HH_mm_ss").format(new Date());
		System.out.println(dateName);
		resultDirectory = Paths.get(System.getProperty("user.dir"),"test-output", "Solo2c", "Results_"+ dateName+ "").toString();
		System.out.println(resultDirectory);
		
        File file = new File(resultDirectory);
       // true if the directory was created, false otherwise
        if (file.mkdirs()) {
            System.out.println("Directory is created!");
        } else {
            System.out.println("Failed to create directory!");
        }
		
		
		htmlReporter = new ExtentHtmlReporter(resultDirectory +"/NRTCampaignSolo2c_"+ dateName +".html");
		// Create an object of Extent Reports
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		
		htmlReporter.config().setReportName("NRT QA auto Sol o2c");
		htmlReporter.config().setCSS(".r-img { width: 100%; }");
		
		//String ExtentConfig = System.getProperty("user.dir") + "/src/test/javasolo2c/Utilities/extent-config.xml";
		
		htmlReporter.loadXMLConfig(new File(Paths.get(System.getProperty("user.dir"),"src", "test", "java", "solo2c", "Utilities","extent-config.xml").toString()), true);
				
		}
		

		@Test(priority = 1, description = "Scenario E2E", enabled = true)
		public void Sceanrio() throws Exception
		{
			Object [] carPrices;
			
			ChromeOptions options=new ChromeOptions();
			options.setExperimentalOption("excludeSwitches", new String[] {"enable-automation"});
			options.addArguments("--disable-web-security");
			options.addArguments("--no-proxy-server");
			options.addArguments("--no-sandbox");
			//options.addArguments("start-maximized");
			options.addArguments("force-device-scale-factor=0.75");
			options.addArguments("high-dpi-support=0.75");
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", prefs);
			driver=new ChromeDriver(options);
			driver.manage().window().setSize(new Dimension(1920, 1080));
			driver.manage().timeouts().implicitlyWait(320, TimeUnit.SECONDS);
						
			
			
			logger = extent.createTest(ScenarioName);
		  
		  System.out.println("ScenarioName : " + ScenarioName);
		  
		  //Login to Sol o2c
		  LoginApplication.login(resultDirectory, driver, extent, logger, Brand,Country, URL,Dealer, ScenarioMode);
		  
//		  //Choose payment mode
//		  ChoosePaymentMode.ChoosePayment(resultDirectory, driver, extent, logger, Country, ScenarioMode);
//		  
		// financialWidget
			 
			 if(ScenarioMode.equals("B2CF")) {
				 FinancialWidget.Finance(resultDirectory, driver, extent, logger, Country);
			 }
	 
		  
		  //Define car options
		  carPrices = ChooseCarOptions.ChooseOptions(resultDirectory, driver, extent, logger, Country, ScenarioMode);
		 
		  //Validate Basket
		  BasketValidation.Basket(resultDirectory, carPrices, driver, extent, logger, Brand, Country, ScenarioMode, Product, Service); 
		  
		  //Choose Delivery Options
		  DeliveryDate = ChooseDeliveryOptions.Delivery(resultDirectory, driver, extent, logger,Country, ScenarioMode, Dealer, DealerName, DeliverySearch);
		  
		  //Case Login 
		  if(ConnectMode.equals("Login")) {
		  UserLogin.Login(resultDirectory, driver, extent, logger,Country, ScenarioMode, Email, Password, ConnectMode, Coordinates, DeliveryAdress);
		  }
          //Case Registration
		  if(ConnectMode.equals("Registration")) {
			  Adresses = UserRegistration.Registration(resultDirectory, driver, extent, logger, Country, ScenarioMode);
			  EmailR = Adresses[0].toString();
			  PasswordR = Adresses[1].toString();
			  CoordinatesR = Adresses[2].toString();
		      DeliveryAdressR = Adresses[4].toString();  
			  UserLogin.Login(resultDirectory, driver, extent, logger,Country, ScenarioMode, EmailR, PasswordR, ConnectMode, CoordinatesR, DeliveryAdressR);
		   }
		  
		  //Imatriculation
		  Imatriculation.Imat(resultDirectory, driver, extent, logger, Country, ScenarioMode,Immat);
		  
		  //Order confirmation 
		  String ordercheck = "confirmation";
		  if(ConnectMode.equals("Login")) {
			  MOPID = OrderValidation.Order(resultDirectory, DeliveryDate, driver, extent, logger, Brand, Country, Dealer, ScenarioMode, Product, Service,  DealerName, DeliveryAdress, OrderCoordinates, ImatText, ordercheck );
		  }
		  if(ConnectMode.equals("Registration")) {
			  CoordinatesOrderR = Adresses[3].toString();
			  MOPID = OrderValidation.Order(resultDirectory, DeliveryDate, driver, extent, logger, Brand, Country, Dealer, ScenarioMode, Product, Service,  DealerName, DeliveryAdressR, CoordinatesOrderR, ImatText, ordercheck);
		  }
		  
		  //Payment
		  if ((Country.equals("FR")) && (ScenarioMode.equals("B2CC")))	{  
			  PaymentCash.Payment(resultDirectory, ScenarioName, driver, extent, logger, Country,ScenarioMode, PaymentMode, CarNumber, CarDate, CVC);
		  }
		  
		  if ((Country.equals("IT")) && ((ScenarioMode.equals("B2CC"))||(ScenarioMode.equals("B2B"))))	{  
			  PaymentCash.Payment(resultDirectory, ScenarioName, driver, extent, logger, Country, ScenarioMode, PaymentMode, CarNumber, CarDate, CVC);
		  }
		  if (ScenarioMode.equals("B2CF")) {
			  PaymentFinance.Payment(resultDirectory, ScenarioName, driver, extent, logger, Country, Brand, PaymentMode, MOPID);
		  }
		  
		//Order Validation
		ordercheck = "validation";
		if ((PaymentMode.equals("Valid")) || ((ScenarioMode.equals("B2B")) && (Country.equals("FR")))) {
			  if(ConnectMode.equals("Login") ) {
				 OrderValidation.Order(resultDirectory, DeliveryDate, driver, extent, logger, Brand, Country, Dealer, ScenarioMode, Product, Service,  DealerName, DeliveryAdress, OrderCoordinates, ImatText, ordercheck);
			  }
			  if(ConnectMode.equals("Registration")) {
				 
				 OrderValidation.Order(resultDirectory, DeliveryDate, driver, extent, logger, Brand, Country, Dealer, ScenarioMode, Product, Service,  DealerName, DeliveryAdressR, CoordinatesOrderR, ImatText, ordercheck);
			  }
		}
				  
			driver.quit();
			Thread.sleep(45000);
		  
		  
	    }
		
				
		@AfterTest
		public static void closeBrowser() {
			extent.flush();
			
			
			
			
		}
		   
			
}
