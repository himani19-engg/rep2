package solo2c.PageObjectModel;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;

public class BasketPage extends UniversalMethods {
    WebDriver driver = null;


    By BaskeTitleFR = By.xpath("(//*[contains(text(),'mon panier')])[2]");
    By BaskeTitleIT = By.xpath("(//*[contains(text(),'Il tuo carrello')])[2]");

    By BasketValidFR = By.xpath("//*[contains(text(),'mon panier')]");
    By BasketValidIT = By.xpath("//*[contains(text(),'Il tuo carrello')]");


    By CarName = By.xpath("//*[@data-id='deal-summary-item-name-description']");

    By CarProduct = By.xpath("//*[@data-id='deal-summary-item-name-accessory']");

    By CarService = By.xpath("//*[@data-id='deal-summary-item-name-service']");


    By TotalCashFR = By.xpath("//p[contains(text(),'total ttc')]/../../div[2]/p");
    By TotalCashIT = By.xpath("//p[contains(text(),'totale IVA inclusa')]/../../div[2]/p");

    By FinanceLoanFR = By.xpath("//p[contains(text(),'loyers')]/../p[2]");
    By FinanceLoanIT = By.xpath("//p[contains(text(),'Canone Totale')]/../p[2]");

    By FinanceFirstLoanFR = By.xpath("//p[contains(text(),'Premier loyer')]");
    By FinanceFirstLoanIT = By.xpath("//p[contains(text(),'Primo Canone totale')]/../p[2]");

    By ValidateBasket = By.xpath("//*[@data-id='delivery-confirmation-continue-button']");


    public void ScrollBasket(String Country, String ordercheck) throws InterruptedException {
        System.out.println("open Basket");
        if (ordercheck.equals("confirmation")) {
            if (Country.equals("FR")) {
                scroling(driver, BaskeTitleFR);
            }
            if (Country.equals("IT")) {
                scroling(driver, BaskeTitleIT);
            }
        }
        if (ordercheck.equals("validation")) {
            if (Country.equals("FR")) {
                scroling(driver, BasketValidFR);
            }
            if (Country.equals("IT")) {
                scroling(driver, BasketValidIT);
            }
        }
    }

    public String getCarPriceCashFR() {
        System.out.println("Getting Price cash");
        String text = getInnerHML(driver, TotalCashFR);
        text = text.replaceAll(",", "").replaceAll(" ", "").replaceAll("\\.", "").replaceAll("&nbsp;", "");
        return text;
    }

    public String getCarPriceCashIT() {
        System.out.println("Getting Price cash");
        String text = getInnerHML(driver, TotalCashIT);
        text = text.replaceAll(",", "").replaceAll(" ", "").replaceAll("\\.", "").replaceAll("&nbsp;", "");
        return text;
    }

    public String getCarLoanFR() {
        System.out.println("Getting Finance loan");
        String text = getInnerHML(driver, FinanceLoanFR);
        text = text.replaceAll(" ", "").replaceAll("&nbsp;", "").replaceAll("€", "").replaceAll("\\.", "").replaceAll(",", "");
        System.out.println("Finance loan # " + text);
        return text;
    }

    public String getCarLoanIT() {
        System.out.println("Getting Finance loan");
        String text = getInnerHML(driver, FinanceLoanIT);
        text = text.replaceAll(" ", "").replaceAll("&nbsp;", "").replaceAll("€", "").replaceAll("\\.", "");
        text = text.replaceAll(",", ".");
        double text2 = Double.parseDouble(text);
        text2 = Math.ceil(text2);
        int text3 = ((int) text2);
        text = String.valueOf(text3);
        text = text.replaceAll(",", "").replaceAll("\\.", "");
        System.out.println("Finance loan # " + text);
        return text;
    }

    public String getCarFirstLoanFR() {
        System.out.println("Getting Finance first loan");
        String text = getInnerHML(driver, FinanceFirstLoanFR);
        text = text.replaceAll(" ", "").replaceAll("&nbsp;", "").replaceAll("€", "").replaceAll("\\.", "").replaceAll(",", "").replaceAll("Premierloyer:", "");
        System.out.println("Finance first loan # " + text);
        return text;
    }

    public String getCarFirstLoanIT() {
        System.out.println("Getting Finance first loan");
        String text = getInnerHML(driver, FinanceFirstLoanIT);
        text = text.replaceAll(" ", "").replaceAll("&nbsp;", "").replaceAll("€", "").replaceAll("\\.", "");
        ;
        text = text.replaceAll(",", ".");
        double text2 = Double.parseDouble(text);
        text2 = Math.ceil(text2);
        int text3 = ((int) text2);
        text = String.valueOf(text3);
        text = text.replaceAll(",", "").replaceAll("\\.", "");
        System.out.println("Finance first loan # " + text);
        return text;
    }


    public String getCarName() {
        System.out.println("Getting CarName");
        return getInnerHML(driver, CarName);
    }

    public String getCarProduct() {
        System.out.println("Getting CarProduct");
        return getInnerHML(driver, CarProduct);
    }

    public String getCarService() {
        System.out.println("Getting CarService");
        return getInnerHML(driver, CarService);
    }


    public boolean checkBasketTitleFR() throws InterruptedException {
        System.out.println("Checking Basket Title");
        return isElementPresentWithoutWait(driver, BaskeTitleFR);
    }

    public boolean checkBasketTitleIT() throws InterruptedException {
        System.out.println("Checking Basket Title");
        return isElementPresentWithoutWait(driver, BaskeTitleIT);
    }

    public void Validate() throws InterruptedException {
        System.out.println("Validate");
        WebElement element = driver.findElement(ValidateBasket);
        element.sendKeys(Keys.ENTER);

    }

    public BasketPage(WebDriver driver) {
        this.driver = driver;
    }

    public void CheckBasketData(String resultDirectory, ExtentReports extent, ExtentTest logger, String Brand, String ScenarioMode, String Product, String Service) {

        try {
            //Check car Name
            if (getCarName().equalsIgnoreCase(Brand.replaceAll("-", " "))) {
                logger.log(Status.PASS, "" + Brand + " is present");
            } else {
                FailWithScreenshot("" + Brand + " is  not present", resultDirectory, driver, extent, logger);
                driver.quit();

            }

//			//Check car Product
//			System.out.println("Product : " +Product);
//			if (getCarProduct().equalsIgnoreCase(Product))
//			{
//				logger.log(Status.PASS,
//						MarkupHelper.createLabel("" + Product + " is present", ExtentColor.GREEN));
//			}		
//			else {
//				FailWithScreenshot("" + Product + " is  not present", resultDirectory, driver, extent, logger);
//				driver.quit();
//						
//			}

            //Check car Service
            if ((ScenarioMode.equals("B2B")) || (ScenarioMode.equals("B2CC"))) {
                if (getCarService().equalsIgnoreCase(Service)) {
                    logger.log(Status.PASS, "" + Service + " is present");
                } else {
                    FailWithScreenshot("" + Service + " is  not present", resultDirectory, driver, extent, logger);
                    driver.quit();

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);

        }

    }

    public void CheckBasketDataPrices(String resultDirectory, ExtentReports extent, Object[] prices, ExtentTest logger, String Country, String ScenarioMode) {

        try {
            //Check total amount cash
            if ((ScenarioMode.equals("B2B")) || (ScenarioMode.equals("B2CC"))) {
                if (Country.equals("FR")) {

                    if (getCarPriceCashFR().equals(prices[0])) {
                        logger.log(Status.PASS, "TOTAL Amount TTC is OK");
                    } else {
                        FailWithScreenshot("TOTAL Amount TTC is not OK", resultDirectory, driver, extent, logger);
                        driver.quit();

                    }
                }

                if (Country.equals("IT")) {

                    if (getCarPriceCashIT().equals(prices[0])) {
                        logger.log(Status.PASS, "TOTAL Amount TTC is OK");
                    } else {
                        FailWithScreenshot("TOTAL Amount TTC is not OK", resultDirectory, driver, extent, logger);
                        driver.quit();

                    }
                }
            }

            //Check Finance loans
            //Monthly Loan
            if (ScenarioMode.equals("B2CF")) {
                //Monthly Loan

                if (Country.equals("FR")) {

                    if (getCarLoanFR().contains(prices[0].toString())) {
                        logger.log(Status.PASS, "Finance Loan is OK");
                    } else {
                        FailWithScreenshot("Finance Loan is not OK", resultDirectory, driver, extent, logger);
                        driver.quit();

                    }
                }

                if (Country.equals("IT")) {

                    if (getCarLoanIT().contains(prices[0].toString())) {
                        logger.log(Status.PASS, "Finance Loan is OK");
                    } else {
                        FailWithScreenshot("Finance Loan is not OK", resultDirectory, driver, extent, logger);
                        driver.quit();

                    }
                }
                //First loan
                if (Country.equals("FR")) {

                    if (getCarFirstLoanFR().equals(prices[1])) {
                        logger.log(Status.PASS, "Finance First Loan is OK");
                    } else {
                        FailWithScreenshot("Finance First Loan is not OK", resultDirectory, driver, extent, logger);
                        driver.quit();

                    }
                }

                if (Country.equals("IT")) {

                    if (getCarFirstLoanIT().equals(prices[1])) {
                        logger.log(Status.PASS, "Finance First Loan is OK");
                    } else {
                        FailWithScreenshot("Finance First Loan is not OK", resultDirectory, driver, extent, logger);
                        driver.quit();

                    }
                }
            }

        } catch (Exception e) {
            /*e.printStackTrace();
            FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
			catchFailDetails(resultDirectory, logger,driver, "Unable to get Basket Data Prices",e);

        }

    }

}