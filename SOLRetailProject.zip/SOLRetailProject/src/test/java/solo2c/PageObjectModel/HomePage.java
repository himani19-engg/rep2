package solo2c.PageObjectModel;

import java.awt.Point;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import solo2c.Utilities.UniversalMethods;

public class HomePage extends UniversalMethods {
	WebDriver driver = null;
	
	By CarText = By.xpath("(//div[@id='__next']//p)[3]");
	
	By B2Blink_FR = By.xpath("(//p[contains(text(),'PRO')])[1]");
	By B2Blink_IT = By.xpath("(//p[contains(text(),'PROFESSIONISTA')])[1]");
	
	By B2Clink_FR = By.xpath("(//p[contains(text(),'particuliers')])[1]");
	By B2Clink_IT = By.xpath("(//p[contains(text(),'Privato')])[1]");
	
	By CashVerification = By.xpath("//*[@data-id='price-switcher-formatted-price']/../p[2]");
	By FinanceVerification = By.xpath("//*[@data-id='price-switcher-formatted-price']//../sup");
	
	By ITRemmiseLink = By.xpath("//*[contains(text(),'clicca qui')]");
	By ITRemiseValidation = By.xpath("//button[contains(text(),'si')]");
	
	By AdditionnalProduct = By.xpath("//*[@data-id='accessory-selected-count']/span");
	By AddAdditionnalProductFR = By.xpath("//*[@data-id='closed-package-kit mains-libres nomade pour smartphone']"); 
	By AddAdditionnalProductIT = By.xpath("//*[@data-id='closed-package-kit vivavoce portatile per smartphone']"); 
	
	By AdditionnalService = By.xpath("//*[@data-id='service-selected-count']/span");
	By AddAdditionnalServicetFR = By.xpath("//*[@data-id='closed-package-MY AMI CARE 3 ANS']"); 
	By AddAdditionnalServicetIT = By.xpath("//*[@data-id='closed-package-MY AMI CARE 3 ANNI']"); 
	
	By ValidateProduct = By.xpath("//button[@data-id='customize-add-package']");
	By Validate = By.xpath("//button[@data-id='customize-order-button']");
	
	By TotalPrice = By.xpath("//*[@data-id='price-switcher-formatted-price']");
	
	By FirstLoanPriceFR = By.xpath("//*[@data-id='price-switcher-deposit-text']");
	By FirstLoanPriceIT = By.xpath("//*[@data-id='price-switcher-price-container']/p[3]");
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getCarTotalPrice() {
		System.out.println("Getting First Brand's Price");
		String text = getAnyText(driver, TotalPrice);
		text = text.replaceAll(",", "").replaceAll(" ","").replaceAll("\\.","");
		return text;
	}
	
	public String getCarLoanPrice() {
		System.out.println("Getting First Loan Price");
		String text = getAnyText(driver, TotalPrice);
		text = text.replaceAll(".", "").replaceAll("nbsp;", "").replaceAll(",", "").replaceAll(" ", "").replaceAll("TTC/MOIS", "").replaceAll("€", "");
		return text;
	}
	
	public String getFirstLoanPriceFR() {
		System.out.println("Getting First Loan Price");
		String text = getAnyText(driver, FirstLoanPriceFR);
		text = text.replaceAll("nbsp;", "").replaceAll(",", "").replaceAll(" ", "").replaceAll("PREMIERLOYER:", "").replaceAll("€", "");
		return text;
	}	
	
	public String getFirstLoanPriceIT() {
		System.out.println("Getting First Loan Price");
		String text = getAnyText(driver, FirstLoanPriceIT);
		text = text.replaceAll("nbsp;", "").replaceAll(",", "").replaceAll(" ", "").replaceAll("CONUNPRIMOCANONEDI", "").replaceAll("\\.","").replaceAll("€", "");
		return text;
	}	
	
	
	
	public boolean checkCash() throws InterruptedException {
		System.out.println("Checking cash info");
		return isElementPresentWithoutWait(driver, CashVerification);
	}
	
	public boolean checkFinance() throws InterruptedException {
		System.out.println("Checking finance info");
		return isElementPresentWithoutWait(driver, FinanceVerification);
	}    
	
	public void clickB2BLinkFR() throws InterruptedException {
		System.out.println("Click B2B link");
		//clickElement(driver, ContSansAccepter);
		driver.findElement(B2Blink_FR).click();
	}
	
	public void clickB2BLinkIT() throws InterruptedException {
		System.out.println("Click B2B link");
		//clickElement(driver, ContSansAccepter);
		driver.findElement(B2Blink_IT).click();
	}
	
	public void clickB2CLinkFR() throws InterruptedException {
		System.out.println("Click B2C link");
		//clickElement(driver, ContSansAccepter);
		driver.findElement(B2Clink_FR).click();
	}
	
	public void clickB2CLinkIT() throws InterruptedException {
		System.out.println("Click B2C link");
		//clickElement(driver, ContSansAccepter);
		driver.findElement(B2Clink_IT).click();
	}
	
	public String getCarTitle() {
		System.out.println("Getting First Brand's Price");
		return getAnyText(driver, CarText);
	}
	
	public void ClickITRemmiseLink() throws InterruptedException
	{
		System.out.println("Click 10% reduction IT");
		clickElement(driver, ITRemmiseLink);
	}
	
	public void ClickITRemiseValidation() throws InterruptedException
	{
		System.out.println("Click 10% reduction IT");
		clickElement(driver, ITRemiseValidation);
	}
	
	public void SelectAdditionnalProduct() throws InterruptedException
	{
		System.out.println("Select Addtionnal Product");
		clickElement(driver, AdditionnalProduct);
	}
	
	public void SelectAdditionnalService() throws InterruptedException
	{
		System.out.println("Select Addtionnal Service");
		clickElement(driver, AdditionnalService);
	}
	
	public void AddAdditionnalProductFR() throws InterruptedException
	{
		System.out.println("Add Addtionnal Product");
		waitForElementTobeVisible(driver, AddAdditionnalProductFR);
		clickElement(driver, AddAdditionnalProductFR);
	}
	
	public void AddAdditionnalProductIT() throws InterruptedException
	{
		System.out.println("Add Addtionnal Product");
		waitForElementTobeVisible(driver, AddAdditionnalProductIT);
		clickElement(driver, AddAdditionnalProductIT);
	}
	
	public void AddAdditionnalServiceFR() throws InterruptedException
	{
		System.out.println("Add Addtionnal Service");
		waitForElementTobeVisible(driver, AddAdditionnalServicetFR);
		clickElement(driver, AddAdditionnalServicetFR);
	}
	
	public void AddAdditionnalServiceIT() throws InterruptedException
	{
		System.out.println("Add Addtionnal Service");
		waitForElementTobeVisible(driver, AddAdditionnalServicetIT);
		clickElement(driver, AddAdditionnalServicetIT);
	}
	
	public void ValidateProduct() throws InterruptedException
	{
		System.out.println("Validate Addtionnal Product");
	    
	    waitForElementTobeVisible(driver, ValidateProduct);
		WebElement element = driver.findElement(ValidateProduct);
		element.sendKeys(Keys.ENTER);
		
	}
	
	public void Validate() throws InterruptedException
	{
		System.out.println("Validate");
	    WebElement element = driver.findElement(Validate);
		element.sendKeys(Keys.ENTER);
		
	}
		
		
	

		
		
	
		

}