package solo2c.PageObjectModel;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;
import static solRetailIHM.Utilities.UniversalMethods.waitForPageToLoad;

public class DeliveryOptionsPage extends UniversalMethods {
	WebDriver driver = null;
	
	By FreeDealer = By.xpath("//*[@data-id='delivery-option-2-unchecked']/../..//div");
	By Dealer = By.xpath("//*[@data-id='delivery-option-1-unchecked']/../..//div");
	By Home = By.xpath("//*[@data-id='delivery-option-0-unchecked']/../..//div");
	
	By ValidateChoice = By.xpath("//*[@data-id='delivery-type-continue-button']"); 
	
	By DealerAdress = By.xpath("//*[@data-id='address-text-field']");
	By ValidateDealerAdress = By.xpath("//*[@data-id='delivery-address-selection-continue']");
	By ValidateDealer = By.xpath("(//*[@data-id='delivery-point-select-button'])[1]");
	
	By HomeDelivery = By.xpath("//*[@data-id='delivery-label-confirmation']"); 
	
    By Address = By.xpath("//address");

	By ValidateDeliveryChoice = By.xpath("//*[@data-id='delivery-confirmation-continue-button']");
	
	By DeliveryDate = By.xpath("//*[@data-id='delivery-confirmation-title']/../p[contains(text(),'/')]");
	
	By DeliveryTitleFR = By.xpath("//*[contains(text(),'MA LIVRAISON')]");
	By DeliveryTitleIT  = By.xpath("//*[contains(text(),'LA TUA CONSEGNA')]");
	
	 public void ScrollDelivery(String Country) throws InterruptedException
		{
			System.out.println("open delivery");
			if (Country.equals("FR")) {scroling(driver,DeliveryTitleFR);}
			if (Country.equals("IT")) {scroling(driver,DeliveryTitleIT);}
		}    
	
	
	public void enterDealerAddress(String Dealer) throws Exception {
		System.out.println("Enter Retailer");
		enterData(driver,  DealerAdress, Dealer);
		//Thread.sleep(2000);
		waitForPageToLoad(driver,5);
		Actions actionObject = new Actions(driver);
		actionObject = actionObject.sendKeys(Keys.ARROW_DOWN); 
		actionObject.perform();
		//Thread.sleep(2000);
		waitForPageToLoad(driver,5);
		actionObject = actionObject.sendKeys(Keys.ENTER); 
		actionObject.perform();
		//Thread.sleep(2000);
		waitForPageToLoad(driver,5);
	}	
	
	public String getAddress() throws InterruptedException {
		System.out.println("checked home delivery Text");
		String text = getAnyText(driver, Address);
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		return text;

	}
	
	public String getHomeDeliveryText() throws InterruptedException {
		System.out.println("checked home delivery Text");
		return getAnyText(driver, HomeDelivery);

	}
	
	public String getDeliveryDate() throws InterruptedException {
		System.out.println("checked delivery date");
		return getAnyText(driver, DeliveryDate);
	

	}
	
	
	
	public void ValidateDealer() throws InterruptedException
	{
		System.out.println("Validating Dealer");
		scroling(driver,ValidateDealerAdress);				
	}
	
	public void ChooseFreeDealer() throws InterruptedException
	{
		System.out.println("Choosing Free Dealer");
		scroling(driver,FreeDealer);				
	}
	
	public void ChooseHome() throws InterruptedException
	{
		System.out.println("Choosing Home");
		scroling(driver,Home);				
	}
	
	public void ChooseDealer() throws InterruptedException
	{
		System.out.println("Choosing Dealer");
		scroling(driver,Dealer);				
	}
	
	public void ValidateChoice() throws InterruptedException
	{
		System.out.println("Validate Choice");
	    WebElement element = driver.findElement(ValidateChoice);
		element.sendKeys(Keys.ENTER);
		
	}
	
	public void ValidateDealerChoice() throws InterruptedException
	{
		System.out.println("Validate Choice");
	    WebElement element = driver.findElement(ValidateDealer);
		element.sendKeys(Keys.ENTER);
		
	}
	
	public void ValidateDelivery() throws InterruptedException
	{
		System.out.println("Validate Delivery");
	    WebElement element = driver.findElement(ValidateDeliveryChoice);
		element.sendKeys(Keys.ENTER);
		
	}
		
	public DeliveryOptionsPage(WebDriver driver) {
		this.driver = driver;
	}
	
	
	public void CheckDeliveryData(String resultDirectory, ExtentReports extent, ExtentTest logger, String Dealer, String ScenarioMode, String DealerName) 
	{
		try {
	// check delivery information is as expected 
			if (!ScenarioMode.equals("B2B")) {
				if (Dealer.equals("Home"))
				{
					if (getHomeDeliveryText().equals(DealerName))
					{
						logger.log(Status.PASS,"Home delivery info is ok");
					}
					else {
						FailWithScreenshot("Home delivery info is not ok", resultDirectory, driver, extent, logger);
							driver.quit();
						
					}
					
				}
			
				
				
				if ((Dealer.equals("Dealer")) || (Dealer.equals("FreeDealer")))
				{   
					System.out.println("Address : " + getAddress());
					if ((getAddress().equals(DealerName))) 
					{
						logger.log(Status.PASS,"Delivery info is ok");
					}
					else {
						FailWithScreenshot("Delivery info is not ok", resultDirectory, driver, extent, logger);
								driver.quit();
						
					}
					
				}
			}
			
			if (ScenarioMode.equals("B2B")) {
				
					if (getHomeDeliveryText().equals(DealerName))
					{
						logger.log(Status.PASS,"Home delivery info is ok");
					}
					else {
						FailWithScreenshot("Home delivery info is not ok", resultDirectory, driver, extent, logger);
							driver.quit();
						
					}
			}
			
		} catch(Exception e) {
			/*e.printStackTrace();
			FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
			catchFailDetails(resultDirectory, logger,driver, "Test Failed while Checking Delivery Data",e);
			
		}
	}
	
}