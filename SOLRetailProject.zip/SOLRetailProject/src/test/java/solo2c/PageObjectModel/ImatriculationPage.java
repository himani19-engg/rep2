package solo2c.PageObjectModel;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import solo2c.Utilities.UniversalMethods;

public class ImatriculationPage extends UniversalMethods {
	WebDriver driver = null;
	
	By ImmatPSA = By.xpath("//*[@id='Citroen']/../div");
	By ImmmatClient = By.xpath("//*[@id='Myself']/../div");
	
	By ImmatValidation = By.xpath("//*[@data-id='basket-registration-vehicle-continue-button']");
	By ImmatConfirmation = By.xpath("//*[@data-id='basket-vehicleRegistration-confirmChoiceModal-confirm']");
	
	public void PSAImmat() throws InterruptedException
	{
		System.out.println("Choosing PSA immatriculation");
		scroling(driver, ImmatPSA);				
	}
	
	public void ClientImmat() throws InterruptedException
	{
		System.out.println("Choosing Client immatriculation");
		scroling(driver, ImmmatClient);				
	}
		
	public void ValidateImmat() throws InterruptedException
	{
		System.out.println("Validate Immat");
	    WebElement element = driver.findElement(ImmatValidation);
		element.sendKeys(Keys.ENTER);
		
	}
	
	public void ConfirmImmat() throws InterruptedException
	{
		System.out.println("confirm Immat");
	    clickElement(driver, ImmatConfirmation);
	}
	
	public ImatriculationPage(WebDriver driver) {
		this.driver = driver;
	}
	
}