package solo2c.PageObjectModel;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import solo2c.Utilities.UniversalMethods;

import static solRetailIHM.Utilities.UniversalMethods.waitForPageToLoad;


public class RegistrationPage extends UniversalMethods {
	WebDriver driver = null;
	public double FinanceMonthlyPrice;
	public double FinanceFirstLoanPrice;
	public String incrementemailAdresse; 
	
	By RegistrationButton = By.xpath("//*[@data-id='basket-redirect-registration-button']");
	By EmailAdressField = By.id("email");
	By PasswordField =  By.id("password");
	By PasswordConfirmField =  By.id("passwordConfirm");
	By SelectorField = By.className("select-holder");
	By FealSelectorField = By.xpath ("//*[@class ='select-items'] / li [1]");
	By LastNameField =  By.id("USR_LAST_NAME");
	By FirstNameField =  By.id("USR_FIRST_NAME");
	By PhoneNumberField =  By.id("USR_PHONE_NUMBER_HOME");
	By AdressField =  By.id("USR_BILLING_ADDRESS_STREET");
	By PostalCodeField =  By.id("USR_BILLING_ADDRESS_POSTAL_CODE");
	By DeliveryCityField =  By.id("USR_BILLING_ADDRESS_CITY");
	By DeliveryCountryField =  By.id("USR_BILLING_ADDRESS_COUNTRY");
	By ProvinceField = By.id("USR_BILLING_ADDRESS_PROVINCE");
	By RiasonSocialField = By.id("USR_BILLING_RAISON_SOCIAL");
	By SIRETField = By.id("USR_BILLING_SIRET");
	By AdressFieldFinance =  By.id("USR_DELIVERY_ADDRESS_STREET");
	By PostalCodeFieldFinance =  By.id("USR_DELIVERY_ADDRESS_POSTAL_CODE");
	By DeliveryCityFieldFinance =  By.id("USR_DELIVERY_ADDRESS_CITY");
	By DeliveryCountryFieldFinance =  By.id("USR_DELIVERY_ADDRESS_COUNTRY");
	By ProvinceFieldFinance = By.id("USR_DELIVERY_ADDRESS_PROVINCE");
	By ConfirmationButton =  By.id("submit");
	By ConfirmationMessage =  By.xpath("//* [@id = 'page_title ']");
	By FiscalCodeIT =  By.id("USR_VATIM");
	By YopmailCookiesAcception =  By.id("accept");
	By YopmailEmailField = By.className("ycptinput");
	By ConfirmYopmailEmailField = By.id("refreshbut");
	By YopmailRefresh = By.id("refresh");
	By YopmailIframe = By.name("ifmail");
    By YopmailEmailActivationFR = By.xpath("//span[contains(text(),'Activez votre compte My Citroën')]");
    By YopmailEmailActivationIT = By.xpath("//span[contains(text(),'Attiva il tuo Account My Citroën')]");    
	By AccoutConfirmationFR = By.xpath("//a[contains(text(),'CONTINUER')]");
	By AccoutConfirmationIT = By.xpath("//a[contains(text(),'CONTINUA')]");
	
	            
	
	public void ClickOnAcoountCreationButton() throws InterruptedException
	{
		System.out.println("Registration Button Clicked");
		WebElement webelement = driver.findElement(RegistrationButton);
		webelement.sendKeys(Keys.ENTER);		

		
	}
	
	
	public Object[] FeelRegistrationForm(String Country, String ScenarioMode) throws InterruptedException, IOException, AWTException
	{
		Object[] Adresses = new Object[5];
		double random = (Math.floor(Math.random() * (+1999999999 + 1 - +1)) + +1 );
		String Email = "TestO2c" + random + "@yopmail.com";
		//String Email = "TestO2c" + (Math.floor(Math.random() * (+10000000 + 1 - +1)) + +1 )+ "@yopmail.com";
		String Password = "Test+1234";
		Adresses[0] = Email;
		Adresses[1] = Password;
		
		String ChoiceFR = "Mlle";
		String ChoiceIT = "Sig.na";
		String FirstName = "TestLN";
		String LastName = "TestFN";
		String PhoneNumber = "66666666";
		                      
		
		String BillingAdress = null;
		if(Country.equals("IT")) {BillingAdress = ChoiceIT + LastName + FirstName + "+396" + PhoneNumber + "12345abcde678fgh" + Email;}
		if(Country.equals("FR")) {BillingAdress = ChoiceFR + LastName + FirstName + "+336" + PhoneNumber + Email;}
		String BillingAdressOrder = null;
		if(Country.equals("IT")) {BillingAdressOrder = LastName + FirstName + Email + "+396" + PhoneNumber + "12345abcde678fgh";}
		if(Country.equals("FR")) {BillingAdressOrder = LastName + FirstName + Email + "+336" + PhoneNumber;}
			
		Adresses[2] = BillingAdress;
		Adresses[3] = BillingAdressOrder;	
		
		String Adress = "17 rue des fleurs";
		String PostalCode = "92001";
		String City = "Paris";
		String Land = "France"; 
		
		String PersonnalAdress = Adress + PostalCode + City + Land; 
		PersonnalAdress = PersonnalAdress.replaceAll(" ", "");
		Adresses[4] = PersonnalAdress;
				
		System.out.println("Registration Button field");
		incrementemailAdresse =  Email ;
		//driver.findElement(EmailAdressField).sendKeys(incrementemailAdresse);
		enterData(driver,EmailAdressField,incrementemailAdresse);
		//Thread.sleep(1000);
		//driver.findElement(PasswordField).sendKeys(Password);
		enterData(driver,PasswordField,Password);
		//Thread.sleep(1000);
		//driver.findElement(PasswordConfirmField).sendKeys(Password);
		enterData(driver,PasswordField,Password);
		//Thread.sleep(1000);
		//driver.findElement(SelectorField).click();
		clickElement(driver,SelectorField);
		//Thread.sleep(1000);
		//driver.findElement(FealSelectorField).click();
		clickElement(driver,FealSelectorField);
		//Thread.sleep(1000);
		//driver.findElement(LastNameField).sendKeys(FirstName);
		enterData(driver,LastNameField,FirstName);
		//Thread.sleep(1000);
		//driver.findElement(FirstNameField).sendKeys(LastName);
		enterData(driver,LastNameField,LastName);
		//Thread.sleep(1000);
		//driver.findElement(PhoneNumberField).click();
		clickElement(driver,PhoneNumberField);
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
		//String PhoneEXEPath = "\\src\\test\\java\\solo2c\\Utilities\\Solo2cRegistrationPhone.exe";
//		String PhoneEXEPath = Paths.get(System.getProperty("user.dir"),"src","test", "java", "solo2c","Utilities", "Solo2cRegistrationPhone.exe").toString();
//    	Runtime.getRuntime().exec(PhoneEXEPath);
		
		String Solo2cRegistrationPhone = "666666666";
		StringSelection stringSelection = new StringSelection(Solo2cRegistrationPhone);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		waitForPageToLoad(driver,5);
		//Thread.sleep(1000);
         if((ScenarioMode.equals("B2CF")) ||(ScenarioMode.equals("B2B"))) {
			//driver.findElement(AdressFieldFinance).sendKeys(Adress);
			//Thread.sleep(1000);
			enterData(driver,AdressFieldFinance,Adress);
			//driver.findElement(PostalCodeFieldFinance).sendKeys(PostalCode);
			 enterData(driver,PostalCodeFieldFinance,PostalCode);
			//Thread.sleep(1000);
			//driver.findElement(DeliveryCityFieldFinance).sendKeys(City);
			 enterData(driver,DeliveryCityFieldFinance,City);
			//Thread.sleep(1000);
			//driver.findElement(DeliveryCountryFieldFinance).sendKeys(Land);
			 enterData(driver,DeliveryCountryFieldFinance,Land);
			//Thread.sleep(1000);
			if (Country.equals("IT")) {
				//driver.findElement(ProvinceFieldFinance).sendKeys("Paris");
				enterData(driver,ProvinceFieldFinance,"Paris");
			}
			waitForPageToLoad(driver,5);
		}
		else {
			//driver.findElement(AdressField).sendKeys(Adress);
			//Thread.sleep(1000);
			enterData(driver,AdressField,Adress);
			//driver.findElement(PostalCodeField).sendKeys(PostalCode);
			//Thread.sleep(1000);
			 enterData(driver,PostalCodeField,PostalCode);
			//driver.findElement(DeliveryCityField).sendKeys(City);
			//Thread.sleep(1000);
			 enterData(driver,DeliveryCityField,City);
			//driver.findElement(DeliveryCountryField).sendKeys(Land);
			//Thread.sleep(1000);
			 enterData(driver,DeliveryCountryField,Land);
			if (Country.equals("IT")) {
				//driver.findElement(ProvinceField).sendKeys("Paris");
				enterData(driver,ProvinceField,"Paris");
			}
			waitForPageToLoad(driver,5);
		}
		if (ScenarioMode.equals("B2B")) {
			//driver.findElement(RiasonSocialField).sendKeys("Test");
			//Thread.sleep(1000);
			enterData(driver,RiasonSocialField,"Test");
			if (Country.equals("IT")) {
				//driver.findElement(SIRETField).sendKeys("07643520567");
				enterData(driver,SIRETField,"07643520567");
			}
			//Thread.sleep(1000);
			if (Country.equals("FR")) {
				//driver.findElement(SIRETField).sendKeys("36252187900034");
				enterData(driver,SIRETField,"36252187900034");
			}
			waitForPageToLoad(driver,5);
		}
		
		if ((Country.equals("IT")) && (!ScenarioMode.equals("B2B"))) {
		driver.findElement(FiscalCodeIT).sendKeys("12345abcde678fgh");
		enterData(driver,FiscalCodeIT,"12345abcde678fgh");
		}
		waitForPageToLoad(driver,5);
	    
        return Adresses; 		
	}
	
	
	public void ClickOnConfirmationButton() throws InterruptedException
	{
		System.out.println("Confirmation Button Clicked");
		WebElement webelement = driver.findElement(ConfirmationButton);
		webelement.sendKeys(Keys.ENTER);

		
	}
	
	public String GetConfirmationMessage() throws InterruptedException
	{
		//Thread.sleep(500);
		waitForPageToLoad(driver,5);
		System.out.println("Confirmation Message got");
		WebElement webelement = driver.findElement(ConfirmationMessage);
		return webelement.getText();

		
	}
	
	public void GotoYopmailAndActivateTheAccount(String Country) throws InterruptedException
	
	
	{   
		
		//Thread.sleep(3000);
		waitForPageToLoad(driver,5);
		((JavascriptExecutor)driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1)); //switches to new tab
		driver.get("http://www.yopmail.com/en/");
		UniversalMethods.waitForUrlContains("yopmail", driver, 20000);
		//driver.findElement(YopmailCookiesAcception).click();
		clickElement(driver,YopmailCookiesAcception);
		//driver.findElement(YopmailEmailField).sendKeys(incrementemailAdresse);
		enterData(driver,YopmailEmailField,incrementemailAdresse);
		//driver.findElement(ConfirmYopmailEmailField).click();
		clickElement(driver,ConfirmYopmailEmailField);
		UniversalMethods.waitForUrlContains("https://yopmail.com/en/wm", driver, 20000);
		boolean present = false;
		
		for (int k = 0; k <= 50; k++) {
			//driver.findElement(YopmailRefresh).click();
			clickElement(driver,YopmailRefresh);
			Thread.sleep(500);
			WebElement IFram = driver.findElement(YopmailIframe);
			driver.switchTo().frame(IFram);
			
			if(Country.equals("FR")) {present= isElementPresentWithoutWait(driver, YopmailEmailActivationFR);}
		    if(Country.equals("IT")) {present= isElementPresentWithoutWait(driver,YopmailEmailActivationIT);}
		    if (present) {
		    	
		    	if(Country.equals("FR")) {clickUsingJS(driver, YopmailEmailActivationFR);}
				if(Country.equals("IT")) {clickUsingJS(driver, YopmailEmailActivationIT);}
			    break; 
		    }
		    driver.switchTo().defaultContent(); 
		}
		
		//Thread.sleep(1000);
		waitForPageToLoad(driver,5);
			
		driver.switchTo().window(tabs.get(0));
		
		//Thread.sleep(3000);
		waitForPageToLoad(driver,5);
		UniversalMethods.waitForUrlContains("https://id-dcr-pre.citroen.com/", driver, 20000);
		if(Country.equals("FR")) {
			//driver.findElement(AccoutConfirmationFR).click();
			clickElement(driver,AccoutConfirmationFR);
		}
		if(Country.equals("IT")) {
			//driver.findElement(AccoutConfirmationIT).click();
			clickElement(driver,AccoutConfirmationIT);
		}
		UniversalMethods.waitForUrlContains("preprod.summit-automotive.solutions", driver, 20000);
		
	
	}
		
	public RegistrationPage(WebDriver driver) {
		this.driver = driver;
	}
	
}