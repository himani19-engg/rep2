package solo2c.PageObjectModel;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;

public class OrderPage extends UniversalMethods {
	WebDriver driver = null;
	
	By UserCoordinatesFR = By.xpath("//p[contains(text(),'mon adresse de facturation en France')]/../div[1]");
	By UserCoordinatesFR_B2B =  By.xpath("//p[contains(text(),'mon adresse de facturation en France')]/../div[2]");
	By UserCoordinatesIT = By.xpath("//p[contains(text(),'indirizzo di fatturazione in Italia')]/../div[1]");
	By UserCoordinatesIT_B2B =  By.xpath("//p[contains(text(),'di immatricolazione e fatturazione')]/../div[2]");
	
	By UserDeliveryAdressFR= By.xpath("//p[contains(text(),'mon adresse de facturation en France')]/../div[2]");
	By UserDeliveryAdressFR_B2B = By.xpath("//p[contains(text(),'mon adresse de facturation en France')]/../div[3]");
	By UserDeliveryAdressIT= By.xpath("//p[contains(text(),'indirizzo di fatturazione in Italia')]/../div[2]");
	By UserDeliveryAdressIT_B2B =  By.xpath("//p[contains(text(),'di immatricolazione e fatturazione')]/../div[3]");
	
	By ImatTitle = By.xpath("//div[contains(text(),'immatriculation')]");
	By Imattext = By.xpath("//div[contains(text(),'immatriculation')]/../../div[2]");
	
	
	By ConditionConsent = By.xpath("//*[@data-id='order-summary-cash-condition-checkbox']/../div");
	By ServiceConsent = By.xpath("//*[@data-id='order-summary-cash-service-checkbox']/../div");
	
	By FinanceGuarantee = By.xpath("//*[@data-id='order-summary-payment-finance-guarantee-checkbox']/../div");
	
	By PaymentConsent = By.xpath("//*[@data-id='order-summary-payment-consent-checkbox']/../div");
	
	By OrderConfirmTitleB2B = By.xpath("//h2[contains(text(),'commande confirmé')]"); 
	
	
	By MOP = By.id("__NEXT_DATA__");
	
	
	By ValidateOrderforPayment = By.xpath("//*[@data-id='my-order-summary-to-pay-link']");
	
	
	public String getMOP() throws InterruptedException
	{
		//get MOP ID value corresponding to order from source code
		WebElement MOPID = driver.findElement(MOP);
		String MOPIDValue = MOPID.getAttribute("innerText");
		String [] MOPIDValue1 = MOPIDValue.split("externalId\":\"");
		
		String [] MOPIDValue2 = MOPIDValue1[1] .split("\"");
		return MOPIDValue2[0];
	}

	public void ValidateOrderforPayment() throws InterruptedException
	{
		System.out.println("Validate Order for Payment");
	    scroling(driver,ValidateOrderforPayment);
		
		
	}
	
	public void clickFinanceGuarantee() throws InterruptedException
	{
		System.out.println("checking FinanceGuarantee");
		scroling(driver,FinanceGuarantee);
	}
	
	public void clickConditionConsent() throws InterruptedException
	{
		System.out.println("checking ConditionConsent");
		scroling(driver,ConditionConsent);
	}
	
	public void clickServiceConsent() throws InterruptedException
	{
		System.out.println("checking ServiceConsent");
		scroling(driver,ServiceConsent);
	}
	
	public void clickPaymentConsent() throws InterruptedException
	{
		System.out.println("checking PaymentConsent");
		scroling(driver,PaymentConsent);
	}
	
	public void clickImatTitle() throws InterruptedException
	{
		System.out.println("checking Imat");
		scroling(driver,ImatTitle);
	}
	
	public String getImat() {
		System.out.println("Getting Imat");
		return getAnyText(driver, Imattext);
	}
	
	public boolean getOrderConfirmTitleB2B()  throws InterruptedException {
		System.out.println("Getting B2B confirm");
		return isElementPresentWithoutWait(driver, OrderConfirmTitleB2B);
	}	
	
	public String getCoordinates(String Country, String ScenarioMode) throws InterruptedException {
		System.out.println("check coordinates");
		String text = null; 
		if (Country.equals("FR"))
		{
		   if (ScenarioMode.equals("B2B")) {text = getAnyText(driver, UserCoordinatesFR_B2B);}
		   else {text = getAnyText(driver, UserCoordinatesFR);}
		}
		if (Country.equals("IT"))
		{
			 if (ScenarioMode.equals("B2B")) {text = getAnyText(driver, UserCoordinatesIT_B2B);}
			 else {text = getAnyText(driver, UserCoordinatesIT);}
		}
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		return text; 
		

	}
	
	public String getDeliveryAdress(String Country, String ScenarioMode) throws InterruptedException {
		System.out.println("check delivery address");
		String text = null; 
		if (Country.equals("FR"))
		{
		    if (ScenarioMode.equals("B2B")) {text = getAnyText(driver, UserDeliveryAdressFR_B2B);}
		    else {text = getAnyText(driver, UserDeliveryAdressFR);}
		}
		if (Country.equals("IT"))
		{
			if (ScenarioMode.equals("B2B")) {text = getAnyText(driver, UserDeliveryAdressIT_B2B);}
		    else {text = getAnyText(driver, UserDeliveryAdressIT);}
		
		}
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		return text; 
		

	}
	
	
	
		
	public OrderPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void CheckAdressData(String resultDirectory, ExtentReports extent, ExtentTest logger, String Country, String ScenarioMode, String	DeliveryAdress, String OrderCoordinates) 
	{
		try {
			
			System.out.println("coord : " + getCoordinates(Country, ScenarioMode));
			System.out.println("OrderCoordinates : " + OrderCoordinates);
			//check coordinates are ok
			if (getCoordinates(Country,ScenarioMode).equalsIgnoreCase(OrderCoordinates))
			{
				logger.log(Status.PASS,"User coordinates are OK");
			}
			else {
				FailWithScreenshot("User coordinates are not OK", resultDirectory, driver, extent, logger);
				driver.quit();
				
			}
			
			System.out.println("delivery ad : " + getDeliveryAdress(Country, ScenarioMode));
			//check delivery address is OK
			if (getDeliveryAdress(Country, ScenarioMode).equalsIgnoreCase(DeliveryAdress))
			{
				logger.log(Status.PASS,"User delivery address is OK");
			}
			else {
				FailWithScreenshot("User delivery addres is not OK", resultDirectory, driver, extent, logger);
				
				driver.quit();
						
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);
			
		}
	}
	
}