package solo2c.PageObjectModel;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import solRetailIHM.Utilities.UniversalMethods;


public class FinancialWidgetPage extends UniversalMethods {
	WebDriver driver = null;
	public double FinanceMonthlyPrice;
	public double FinanceFirstLoanPrice;
	
	By FinanceWidgetButton = By.xpath("//*[@data-id='finance-icon-container']");
	By FinanceCheckBox = By.xpath("//*[@id='package-desktop'] [2]  //*[@class='custom-radio-border']");
	By FinanceMonthlyPriceBox = By.xpath("//*[@id='package-desktop'] [2]  //*[@class='price-container'] /span [1]");
	By FinanceFirstLoanPriceBox = By.xpath("(//* [@class ='package-container package-container--selected  '] //* [@class='package-data-value__number'] [1] / span) [1]");
	By FinanceDuration = By.xpath("//*[@class='repaymentPeriod-container-body '] //*[@class='repaymentPeriod-month '] [1]");
	By FinanceTableFirstLoanPriceFR = By.xpath("(//* [@class = 'financing-line-container']  /span [2]) [1]");
	By FinanceTableFirstLoanPriceIT = By.xpath("(//* [@class = 'financing-line-container']  /span [2]) [11]");
	By FinanceTableMounthlyPriceIT = By.xpath("(//* [@class = 'financing-line-container']  /span [2]) [7]");
	By FinanceTableMounthlyPriceFR = By.xpath("(//* [@class = 'financing-line-container']  /span [2]) [4]");
	By FinanceTableDurationIT = By.xpath("(//* [@class = 'financing-line-container']  /span [2]) [5]");
	By FinanceTableDurationFR = By.xpath("(//* [@class = 'financing-line-container']  /span [2]) [11]");
	By ConfirmButton = By.xpath("//*[@class='Fipsa-button fipsa-active-btn']");
	
	public void ClickFinanceWidgetButton() throws InterruptedException
	{
		System.out.println("Open Financial Widget");
		driver.findElement(FinanceWidgetButton).click();

		
	}
	
	public void ClickOnLLAAndAmiCare() throws InterruptedException
	{
		System.out.println("Changer LLA");
		driver.findElement(FinanceCheckBox).click();

		
	}
	
	public String GetMounthlyPrice() throws InterruptedException
	{
		System.out.println("GetMounthlyPrice");
	    WebElement element = driver.findElement(FinanceMonthlyPriceBox);
		element.getText();
		String text = element.getText();
		text = text.replaceAll(",", "").replaceAll(" ","").replaceAll("\\.","").replaceAll("&nbsp;", "").replaceAll("€", "");
		System.out.println(text);
		return text;
		
	}
	
	public String GetFirstLoanPrice() throws InterruptedException
	{
		
		System.out.println("GetFirstLoanPrice1");
	    WebElement element = driver.findElement(FinanceFirstLoanPriceBox);
		String text = element.getText();
		text = text.replaceAll("\\D", "");
		System.out.println(text);
	
		
		return text;
		
	}
	
	public void Choose24mounths() throws InterruptedException
	{
		System.out.println("Choose 24 mounts");
		driver.findElement(FinanceDuration).click();

		
	}
	
	public String GetTableMounthlyPrice(String Country) throws InterruptedException
	{
		System.out.println("GetTableMounthlyPrice");
		WebElement element = null;
		
		if(Country.equals("FR")) {
	    element = driver.findElement(FinanceTableMounthlyPriceFR);}
		else if (Country.equals("IT")) {
	    element = driver.findElement(FinanceTableMounthlyPriceIT);
		}
		
		String text = element.getText();
		text = text.replaceAll(",", "").replaceAll(" ","").replaceAll("\\.","").replaceAll("&nbsp;", "").replaceAll("€", "");
		System.out.println(text);
		return text;
		
	}
	
	public String GetTableDuration(String Country) throws InterruptedException
	{
		System.out.println("Get Durration");
		WebElement element = null;
		
		if(Country.equals("FR")) {
	    element = driver.findElement(FinanceTableDurationFR);}
		else if (Country.equals("IT")) {
	    element = driver.findElement(FinanceTableDurationIT);
		}
		
		String text = element.getText();
		text = text.replaceAll(",", "").replaceAll(" ","").replaceAll("\\.","").replaceAll("&nbsp;", "");
		System.out.println(text);
		return text;
		
	}
	
	public String GetTableFirstLoanPrice(String Country) throws InterruptedException
	{
		System.out.println("GetTableFirstLoanPrice");
		
		WebElement element = null;
		
		if(Country.equals("FR")) {
	     element = driver.findElement(FinanceTableFirstLoanPriceFR);
		}
		else if (Country.equals("IT")) {
	     element = driver.findElement(FinanceTableFirstLoanPriceIT);
		}
		String text = element.getText();
		
		text = text.replaceAll("\\D", "");
		System.out.println(text);
		return text;
		
		
		
	}
	
	public void Confirm() throws InterruptedException
	{
		System.out.println("Confirm OK");
		driver.findElement(ConfirmButton).click();

		
	}
		
	public FinancialWidgetPage(WebDriver driver) {
		this.driver = driver;
	}
	
}