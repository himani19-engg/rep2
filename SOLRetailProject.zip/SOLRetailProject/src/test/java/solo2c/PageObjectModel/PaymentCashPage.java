package solo2c.PageObjectModel;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;

public class PaymentCashPage extends UniversalMethods {
	WebDriver driver = null;
	
	By CardNumber = By.name("cardnumber");
		
	By ExpiryDate = By.xpath("//*[@id='root']/div/div/input");
		
	By CVC = By.name("cvc"); 
		
	By Validate = By.xpath("//*[@id='submit-button']"); 
	By Confirm = By.xpath("//*[@id='Submit']"); 
	
	By OrderValidTitleFR = By.xpath("//h2[contains(text(),'paiement acompte effectué')]");
	By OrderValidTitleIT= By.xpath("//h2[contains(text(),'acconto effettuato')]");
	
	By OrderValidTitleFRFinance = By.xpath("//h2[contains(text(),'votre commande est terminée')]");
	By OrderValidTitleITFinance = By.xpath("//h2[contains(text(),'Il tuo ordine è stato completato.')]");
	By OrderValidTitleITB2B = By.xpath("//p[contains(text(),'Il tuo ordine è stato confermato')]");
	
	By OrderRefuseFR = By.xpath("//p[contains(text(),'échec du paiement de votre acompte')]");
	By OrderRefuseIT= By.xpath("//p[contains(text(),'Mancato pagamento')]");
	
	public boolean getOrderValidTitle(String Country, String ScenarioMode)  throws InterruptedException {
		System.out.println("Getting order validation");
		boolean pr = false;
		if (Country.equals("FR"))
		{
		   pr = isElementPresent(driver, OrderValidTitleFR);
		}
		if ((Country.equals("IT")) && (!ScenarioMode.equals("B2B")))
		{
		   pr = isElementPresent(driver, OrderValidTitleIT);
		}
		if ((Country.equals("IT")) && (ScenarioMode.equals("B2B")))
		{
		   pr = isElementPresent(driver, OrderValidTitleITB2B);
		}
		return pr;
		
	}
	
	public boolean getOrderValidTitleFinance(String Country)  throws InterruptedException {
		System.out.println("Getting order validation");
		boolean pr = false;
		if (Country.equals("FR"))
		{
		   pr = isElementPresent(driver, OrderValidTitleFRFinance);
		}
		if (Country.equals("IT"))
		{
		   pr = isElementPresent(driver, OrderValidTitleITFinance);
		}
		return pr;
		
	}
	
	public boolean getOrderRefuseTitle(String Country)  throws InterruptedException {
		System.out.println("Getting order refusal");
		boolean pr = false;
		if (Country.equals("FR"))
		{
		   pr = isElementPresent(driver, OrderRefuseFR);
		}
		if (Country.equals("IT"))
		{
		   pr = isElementPresent(driver, OrderRefuseIT);
		}
		return pr;
		
	}						
   
    public void EnterCardNumber(String NumCard) throws InterruptedException 
	{
		System.out.println("enter card number");
		driver.switchTo().frame(0);
		enterData(driver, CardNumber, NumCard );
	}  
    
    public void EnterExpiryDate(String Date) throws InterruptedException 
	{
		System.out.println("enter Expiry Date");
		driver.switchTo().defaultContent();
		driver.switchTo().frame(2);
		enterData(driver, ExpiryDate, Date );
	}
    
    public void EnterCVC(String CardCVC) throws InterruptedException 
	{
		System.out.println("enter CVC");
		driver.switchTo().defaultContent();
		driver.switchTo().frame(3);
		enterData(driver, ExpiryDate, CardCVC );
	}
    
    public void Validate() throws InterruptedException 
	{
		System.out.println("validate");
		driver.switchTo().defaultContent();
		clickElement(driver, Validate );
	}
    
    public void Confirm() throws InterruptedException 
	{
		System.out.println("confirm");
		clickElement(driver, Confirm);
	}
    
    
		
	public PaymentCashPage(WebDriver driver) {
		this.driver = driver;
	}
	
	
		
	
	
}