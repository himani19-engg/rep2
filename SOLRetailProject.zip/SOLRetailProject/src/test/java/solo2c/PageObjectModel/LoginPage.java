package solo2c.PageObjectModel;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import solo2c.Utilities.UniversalMethods;

import static solRetailIHM.Utilities.UniversalMethods.catchFailDetails;
import static solRetailIHM.Utilities.UniversalMethods.waitForPageToLoad;

public class LoginPage extends UniversalMethods {
	WebDriver driver = null;
	
	By LoginPageAcesss = By.xpath("//*[@data-id='basket-redirect-login-button']");
	By email = By.id("email"); 
	By password = By.id("password"); 
	By LoginValidate = By.id("submit"); 
	 
	
	By UserCoordinatesFR = By.xpath("(//p[contains(text(),'mes coordonnées')])[2]/../div/div");
	By UserCoordinatesIT = By.xpath("//p[contains(text(),'di immatricolazione e fatturazione.')]/../div/div");
	
	By UserDeliveryAdressFR= By.xpath("//p[contains(text(),'mon adresse')]/../div/div");
	By UserDeliveryAdressIT= By.xpath("//p[contains(text(),'in Italia')]/../div/div");
	
	By PersonnalInfoValidate = By.xpath("//*[@data-id='my-details-confirm']");
	
	By RaisonSociale = By.xpath("//label[contains(text(),'raison sociale')]/div"); 
	By SIRET = By.xpath("//label[contains(text(),'SIRET')]/div");
	By ItalyTVA =By.xpath("//label[contains(text(),'PARTITA IVA')]/div");
	By ItalyCodeFiscale = By.name("tin");
	By PhoneNumber = By.xpath("//*[@name='phone']");
	By Validate_SIRET_TVA = By.xpath("//*[@type='submit']");
	By ValidateB2BInfo = By.xpath("//button[@type='submit']");
	By ConfirmB2B = By.xpath("//*[@data-id='basket-vehicleRegistration-confirmChoiceModal-confirm']");
	
	
	By AdressTitleFR = By.xpath("(//*[contains(text(),'mes coordonnées')])[2]");
	By AdressValidFR = By.xpath("//*[contains(text(),'mes coordonnées')]");
	By AdressTitleIT  = By.xpath("//*[contains(text(),'I dati del principale intestatario di Citroën AMI:')]");
	
	public void ScrollItaly(String Country) throws Exception
	{
		System.out.println("Italy TVA / code fiscale / phone number");
		String bodyText = driver.findElement(By.xpath("//*[@id='__next']")).getText();
		System.out.println("entrée 1");
	     //if ((driver.findElements(ItalyTVA).size() != 0) ||(driver.findElements(ItalyCodeFiscale).size() != 0) || (driver.findElements(PhoneNumber).size() != 0))  {
			
	    	 //if (driver.findElements(ItalyTVA).size() != 0) {
		if (bodyText.contains("PARTITA IVA")) {
			System.out.println("entrée 2");
	    	scroling(driver,ItalyTVA);
			Robot robot = new Robot();
	    	robot.keyPress(KeyEvent.VK_CONTROL);
	    	robot.keyPress(KeyEvent.VK_A); 
	    	robot.keyRelease(KeyEvent.VK_CONTROL);
	    	robot.keyPress(KeyEvent.VK_DELETE);	    	
	    	//String loginEXEPath = "\\src\\test\\java\\solo2c\\Utilities\\Solo2cB2BItalyTVA.exe";
	    	//String loginEXEPath = Paths.get(System.getProperty("user.dir"),"src", "test", "java", "solo2c","Utilities", "Solo2cB2BItalyTVA.exe").toString();
	    	//Runtime.getRuntime().exec(loginEXEPath);
	    	//Thread.sleep(500);
			waitForPageToLoad(driver,5);
	    	String Solo2cB2BItalyTVA = "07643520567";
			StringSelection stringSelection = new StringSelection(Solo2cB2BItalyTVA);
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(stringSelection, stringSelection);

			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			waitForPageToLoad(driver,5);
	    	//Thread.sleep(500);
	    	
	      }
	    	 
	    	 //if (driver.findElements(ItalyCodeFiscale).size() != 0) {
		if (bodyText.contains("Fiscale")) {
			System.out.println("entrée 3");

	    		 scroling(driver,ItalyCodeFiscale);
	 			Robot robot = new Robot();
	 	    	robot.keyPress(KeyEvent.VK_CONTROL);
	 	    	robot.keyPress(KeyEvent.VK_A); 
	 	    	robot.keyRelease(KeyEvent.VK_CONTROL);
	 	    	robot.keyPress(KeyEvent.VK_DELETE);	    	
	 	    	//String loginEXEPath = "\\src\\test\\java\\solo2c\\Utilities\\Solo2cB2BCodeFiscale.exe";
	 	    	//String loginEXEPath = Paths.get(System.getProperty("user.dir"),"src","test", "java", "solo2c","Utilities", "Solo2cB2BCodeFiscale.exe").toString();
	 	    	//Runtime.getRuntime().exec(loginEXEPath);
	 	    	//Thread.sleep(500);
				waitForPageToLoad(driver,5);
	 	    	String Solo2cB2BCodeFiscale = "12345abcde678fgh";
				StringSelection stringSelection = new StringSelection(Solo2cB2BCodeFiscale);
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(stringSelection, stringSelection);

				
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_V);
				robot.keyRelease(KeyEvent.VK_V);
				robot.keyRelease(KeyEvent.VK_CONTROL);
	 	    	//Thread.sleep(500);
			    waitForPageToLoad(driver,5);
	    		 
	    	 }
		
		if (bodyText.contains("Telefono")) {
	       
	    	 ScrollPhoneNumber(Country);
	    	 System.out.println("entrée 4");
	    	 
	    	 scroling(driver,Validate_SIRET_TVA);}
		
		     System.out.println("entrée 5");
		     waitForPageToLoad(driver,5);
			 //Thread.sleep(500);
	    	 
	     } 	 
  
	
		
	public void ScrollFrance(String Country) throws Exception
	{
		 System.out.println("SIRET FR // phone number");
		 System.out.println(driver);
		 String bodyText = driver.findElement(By.xpath("//*[@id='__next']")).getText();
		 
		
	     //if ((driver.findElements(SIRET).size() != 0) || (driver.findElements(PhoneNumber).size() != 0)){
			
	    	 //if (driver.findElements(SIRET).size() != 0) {
		 if (bodyText.contains("SIRET")) {
			 
	    	scroling(driver,SIRET);
			Robot robot = new Robot();
	    	robot.keyPress(KeyEvent.VK_CONTROL);
	    	robot.keyPress(KeyEvent.VK_A); 
	    	robot.keyRelease(KeyEvent.VK_CONTROL);
	    	robot.keyPress(KeyEvent.VK_DELETE);	    	
	    	//String loginEXEPath = "\\src\\test\\java\\solo2c\\Utilities\\Solo2cB2BSIRET.exe";
	    	//String loginEXEPath = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities", "Solo2cB2BSIRET.exe").toString();
	    	//Runtime.getRuntime().exec(loginEXEPath);
	    	/*Thread.sleep(1000);
	    	
	    	Thread.sleep(500);*/
			 waitForPageToLoad(driver,5);
 	    	String Solo2cB2BSIRET = "36252187900034";
			StringSelection stringSelection = new StringSelection(Solo2cB2BSIRET);
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(stringSelection, stringSelection);

			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
 	    	//Thread.sleep(500);
			 waitForPageToLoad(driver,5);
	    	scroling(driver,Validate_SIRET_TVA);
			//Thread.sleep(1000);
			 waitForPageToLoad(driver,5);
			
	    	 }
		 
		 if (bodyText.contains("téléphone")) {
			 
	    	 ScrollPhoneNumber(Country);
	    	 scroling(driver,Validate_SIRET_TVA);}
			waitForPageToLoad(driver,5);
	    	 //Thread.sleep(1000);
	     
	}  
	
	public void ScrollPhoneNumber(String Country) throws Exception
	{
		System.out.println("Phone number");
	     //if (driver.findElements(PhoneNumber).size() != 0) {
			scroling(driver,PhoneNumber);
//			Robot robot = new Robot();
//	    	robot.keyPress(KeyEvent.VK_CONTROL);
//	    	robot.keyPress(KeyEvent.VK_A); 
//	    	robot.keyRelease(KeyEvent.VK_CONTROL);
//    	    robot.keyPress(KeyEvent.VK_DELETE);
			
			driver.findElement(PhoneNumber).clear();
	    	//String PhoneEXEPath = "\\src\\test\\java\\solo2c\\Utilities\\Solo2cPersonalPhoneNumber.exe";
	    	//String PhoneEXEPath = Paths.get(System.getProperty("user.dir"),"src", "test","java", "solo2c","Utilities", "Solo2cPersonalPhoneNumber.exe").toString();
	    	//Runtime.getRuntime().exec(PhoneEXEPath);
	    	
	    	//Thread.sleep(500);
			waitForPageToLoad(driver,5);
	    	String Solo2cPersonalPhoneNumber = "";
	    	
	        if (Country.equals("FR")) { Solo2cPersonalPhoneNumber = "+33666666666";}
	        if (Country.equals("IT")) { Solo2cPersonalPhoneNumber = "+39666666666";}
	        
	        scroling(driver,PhoneNumber);
	        
			StringSelection stringSelection = new StringSelection(Solo2cPersonalPhoneNumber);
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			clipboard.setContents(stringSelection, stringSelection);

			Robot robot2 = new Robot();
			robot2.keyPress(KeyEvent.VK_CONTROL);
			robot2.keyPress(KeyEvent.VK_V);
			robot2.keyRelease(KeyEvent.VK_V);
			robot2.keyRelease(KeyEvent.VK_CONTROL);
		    waitForPageToLoad(driver,5);
 	    	/*Thread.sleep(500);
	    	Thread.sleep(500);*/
	    	
	     }
	
	public void ScrollAdress(String Country, String ordercheck) throws InterruptedException
	{
		System.out.println("open Adress");
		if (Country.equals("FR")) {
			if (ordercheck.equals("confirmation")) {scroling(driver,AdressTitleFR);}
			if (ordercheck.equals("validation")) {scroling(driver,AdressValidFR);}
		}
		if (Country.equals("IT")) {scroling(driver,AdressTitleIT);}
	}  
	
	public void clickRaisonSociale() throws Exception {
		System.out.println("Entered Raison sociale");
		 JavascriptExecutor js = (JavascriptExecutor) driver;
         js.executeScript("window.scrollBy(0,50)");
         //Thread.sleep(500);
		waitForPageToLoad(driver,5);
         clickElement(driver, RaisonSociale);
	}	
	
	public void clickSiret() throws Exception {
		System.out.println("Entered Siret");
		 JavascriptExecutor js = (JavascriptExecutor) driver;
         js.executeScript("window.scrollBy(0,50)");
         //Thread.sleep(500);
		waitForPageToLoad(driver,5);
         js.executeScript("window.scrollBy(0,50)");
         //Thread.sleep(500);
		waitForPageToLoad(driver,5);
         clickElement(driver, SIRET);
	}	
	
	public void ValidateB2BIndfo() throws InterruptedException
	{
		System.out.println("Validate B2B Info");
	    WebElement element = driver.findElement(ValidateB2BInfo);
		element.sendKeys(Keys.ENTER);
		
	}
	
	public void ConfirmB2B() throws InterruptedException
	{
		System.out.println("Confirm B2B Info");
		clickElement(driver, ConfirmB2B);
	}
	public void GoToLoginPage() throws InterruptedException
	{
		System.out.println("Go to login Page");
	    WebElement element = driver.findElement(LoginPageAcesss);
		element.sendKeys(Keys.ENTER);
		
	}
	
	public void PersonnalInfoValidate() throws InterruptedException
	{
		System.out.println("Validating personnal Info");
	    WebElement element = driver.findElement(PersonnalInfoValidate);
		element.sendKeys(Keys.ENTER);
		
	}
	
	public String getCoordinates(String Country) throws InterruptedException {
		System.out.println("check coordinates");
		String text = null; 
		if (Country.equals("FR"))
		{
		text = getAnyText(driver, UserCoordinatesFR);
		}
		if (Country.equals("IT"))
		{
		text = getAnyText(driver, UserCoordinatesIT);
		}
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		return text; 
		

	}
	
	public String getDeliveryAdress(String Country) throws InterruptedException {
		System.out.println("check delivery address");
		String text = null; 
		if (Country.equals("FR"))
		{
		text = getAnyText(driver, UserDeliveryAdressFR);
		}
		if (Country.equals("IT"))
		{
		text = getAnyText(driver, UserDeliveryAdressIT);
		}
		text = text.replaceAll("\\n", "");
		text = text.replaceAll("\\r", "");
		text = text.replaceAll(" ", "");
		return text; 
		

	}
	
	public void enterEmail(String Email) throws Exception {
		System.out.println("Entered Email");
		enterData(driver, email, Email);
		driver.findElement(By.xpath("//html")).click();
	}
	
	public void enterPassword(String Password) throws Exception {
		System.out.println("Entered Password");
		enterData(driver, password, Password);
		driver.findElement(By.xpath("//html")).click();
	}
	
	public void validateLogin() throws Exception {
		System.out.println("Validate Login ");
		clickUsingJS(driver, LoginValidate); 
	}
	
	
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void CheckAdressData(String resultDirectory, ExtentReports extent, ExtentTest logger, String Country, String Coordinates, String	DeliveryAdress
) 
	{
		try {
			
			System.out.println("coord : " + getCoordinates(Country));	
			System.out.println("coord1 : " + Coordinates);	
			//check coordinates are ok
			if (getCoordinates(Country).equalsIgnoreCase(Coordinates))
			{
				logger.log(Status.PASS,"User coordinates are OK");
			}
			else {
				FailWithScreenshot("User coordinates are not OK", resultDirectory, driver, extent, logger);
				driver.quit();
				
			}
			
			System.out.println("delivery ad : " + getDeliveryAdress(Country));
			System.out.println("delivery ad : " + DeliveryAdress);
			//check delivery address is OK
			if (getDeliveryAdress(Country).equalsIgnoreCase(DeliveryAdress))
			{
				logger.log(Status.PASS,"User delivery address is OK");
			}
			else {
				FailWithScreenshot("User delivery addres is not OK", resultDirectory, driver, extent, logger);
				
				driver.quit();
						
			}
			
		} catch(Exception e) {
			/*e.printStackTrace();
			FailWithScreenshot("Failed test case", resultDirectory, driver, extent, logger);*/
			catchFailDetails(resultDirectory, logger,driver, "Test Failed while Checking Address Data",e);
			
		}
	}
}