package solo2c.PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import solRetailIHM.Utilities.UniversalMethods;

public class CookieAccepter extends UniversalMethods{
	WebDriver driver=null;	
	By ContAccepter=By.className("psac_noselect");
	
	By CookiesAccept = By.id("_psaihm_button_param_accept");
	
	//By ContAccepter=By.id("_psaihm_continue_without_accepting");
	
	public CookieAccepter(WebDriver driver) {
		this.driver=driver;
	}
	
	public void clickContAccepter() throws InterruptedException {
		System.out.println("Clicked Accepter Btn");
		//clickElement(driver, ContSansAccepter);
		
		driver.findElement(ContAccepter).click();
	}

	public void clickCookiesAccept() throws InterruptedException {
		System.out.println("Clicked Accept Cookies");
		//clickElement(driver, ContSansAccepter);
		if (driver.findElements(CookiesAccept).size() != 0) {
		      driver.findElement(CookiesAccept).click();
		}
	}

}
