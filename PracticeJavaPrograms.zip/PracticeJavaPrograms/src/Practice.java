
public class Practice {

	public static void main(String[] args) {
		System.out.println(100+50+"world");
		System.out.println("hello"+100+50);
		
	}
	public int add(int x,int y) {
		return x+y;
	}
	public long add(long x,long y) {
		return x+y;
	}

}
