import java.util.HashMap;
import java.util.Map;

public class OccurenceOfChar {

	public static void occurence(String str) {
		Map<Character, Integer> charMap=new HashMap<Character, Integer>();
		char[] charArray=str.toCharArray();
		for(char c: charArray) {
			if(!String.valueOf(c).isBlank()) {
				if(charMap.containsKey(c)){
					charMap.put(c, charMap.get(c)+1);
				} else {
					charMap.put(c, 1);
				}
			}		
		}
		for(char c:charMap.keySet()) {
			System.out.println(charMap.get(c));
		}
		System.out.println(str+": "+charMap);
		
	}
	public static void main(String[] args) {
		String str="My name is Himani";
		occurence(str);
		occurence("ttt");
		occurence("test");
	}

}
