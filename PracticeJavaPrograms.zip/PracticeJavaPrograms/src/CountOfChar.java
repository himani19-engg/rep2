
public class CountOfChar {
	public static int count(String s, char c) {
		char[] array=s.toCharArray();
		int n=0;
		for(int i=0;i<array.length;i++) {
			if(array[i]==c) {
				n=n+1;
			}
		}
		return n;
	}
	public static void main(String[] args) {
		String str="My name is Himani";
		char c='i';
		System.out.println(count(str,c));

	}

}
