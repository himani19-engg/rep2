
public class NoOfWords {

	public static void main(String[] args) {
		String s="I am Himani Chawla";
		String[] s1=s.split(" ");
		System.out.println("Number of words in "+s+" is "+s1.length);

	}

}
