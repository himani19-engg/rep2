
public class Example {
	private int x;
	public static void main(String[] args) {
		Example obj =new Example(5);
		obj.Example(6);
		String s= new String("hello");
		String s1= new String("hello");
		if(s==s1) {
			System.out.println(true);
		} else {
			System.out.println(false);
		}
	}
	public Example(int x) {
		System.out.println("x= "+x);
	}
	public void Example(int x) {
		System.out.println(x);
	}

}
