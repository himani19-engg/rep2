
public class ReverseStringPreservingSpaces {

	public static String revStr(String inputString) {
		char[] inputArray=inputString.toCharArray();
		char[] outputArray=new char[inputArray.length];
		for(int i=0; i<inputArray.length;i++) {
			if(inputArray[i]==' ') {
				outputArray[i]=' ';
			}
		}
		int j=inputArray.length-1;
		for(int i=0;i<inputArray.length;i++) {
				if(!(inputArray[i]==' ')) {
					while(outputArray[j]==' ') {
						j--;
					}
					outputArray[j]=inputArray[i];
					j--;
				}
		}
		return String.valueOf(outputArray);
	}
	public static void main(String[] args) {
		String str="This is for practice purpose";
		System.out.print(revStr(str));
		
	}

}
