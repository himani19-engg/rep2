import java.util.Arrays;

public class Anagrams {
	public static boolean checkAnagram(char[] first,char[] second) {
		int n1=first.length;
		int n2=second.length;
		if(n1!=n2) {
			return false;
		}
		Arrays.sort(first);
		Arrays.sort(second);
		for(int i=0;i<n1;i++) {
			if(first[i]!=second[i]) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {

		String s1="listen";
		String s2="silent";
		char[] firstArray=s1.toCharArray();
		char[] secondArray=s2.toCharArray();
		Boolean b=checkAnagram(firstArray,secondArray);
		if(b) {
			System.out.print("Given strings are anagrams");
		} else {
			System.out.print("Given strings are not anagrams");
		}

	}

}
