
public class FirstNonRepeatedChar {
	public static char firstNonRep(String input) {
		char c=' ';
		char[] arr=input.toCharArray();
		for(int i=0;i<input.length();i++) {
			if(input.indexOf(arr[i])==input.lastIndexOf(arr[i])) {
				c=arr[i];
				return c;
			}
		}
		return c;
	}

	public static void main(String[] args) {
		String s="geeksforgeeks";
		
		System.out.println(firstNonRep(s));

	}

}
