
public interface Interf {

}
