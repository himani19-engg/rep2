
public class BinaryGap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinaryGap b=new BinaryGap();
		System.out.println(Integer.toHexString(b.hashCode()));
		System.out.println(b.toString());
		String s="himani";
		s="chawla";
		String s1=new String("himani");
		s1="chawla";
		System.out.println(s);
		System.out.println(s1);

	}

}
