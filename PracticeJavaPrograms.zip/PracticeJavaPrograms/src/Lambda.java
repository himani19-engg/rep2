interface Cab{
	public void test(); 
}

public class Lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cab cab=()->System.out.println("Cab is booked");
		cab.test();
	}

}
