
public class CompareChar {

	public static void main(String[] args) {
		char d='a';
		char b='A';
		int x=Character.compare(d, b);
		System.out.println(Integer.toString(x));
		String s="AvFC";
		String s2="";
		
		System.out.println(s.toLowerCase());
		char y='a';
		System.out.println((int)'Z');
		for(int i=0;i<s.length();i++) {
			int c=(int)s.charAt(i);
			if(c>=65 & c<=90) {
				c=c+32;
			}
			s2=s2+(char)c;
			
		}
		System.out.println(s2);
	}

}
