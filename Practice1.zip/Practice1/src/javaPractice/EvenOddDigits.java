package javaPractice;

import java.util.Scanner;

public class EvenOddDigits {
	public static void evenOdd(int n) {
		int e=0,o=0, num=0;
		while(n!=0) {
			num=n%10;
			if(num%2==0) {
				e+=1;
			} else {
				o+=1;
			}
			n=n/10;
		}
		System.out.println("Even digits count is "+e);
		System.out.println("Odd digits count is "+o);
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		evenOdd(num);
	}

}
