package javaPractice;

public class Demo1 {
	public String name;
	public int id;
	public void hello() {
		System.out.println("Hello");
	}
	public static void main(String[] args) {
		Demo1 a= new Demo1();
		a.name="Ankit";
		a.id=1;
		System.out.println(a.name);
		System.out.println(a.id);
		a.hello();
		
		Demo1 b=new Demo1();
		b.name="Rekha";
		b.id=2;
		System.out.println(b.name);
		System.out.println(b.id);
		b.hello();
	}

}
