import java.util.ArrayList;
import java.util.List;

public class IndexOfSubstring {

	public static void main(String[] args) {
		/*
		 * String s="India for India"; String sub="India"; List<Integer> indexes=new
		 * ArrayList<Integer>(); int index=0; while(index!=-1) {
		 * index=s.indexOf(sub,index); if(index!=-1) { indexes.add(index); index++; } }
		 * System.out.print(indexes);
		 */
		
		String s="India for India";
	    String sub="India";
	    List<Integer> indexes=new ArrayList<Integer>();
	    int index=0;
	    while(index!=-1) {
	    	index=s.indexOf(sub,index);
	    	if(index!=-1) {
	    		indexes.add(index);
	    		index++;
	    	}
	    }
	    System.out.print(indexes+" "+indexes.size());
	}

}
