
public class Division {

	public static void main(String[] args) {
		
		float f1=6.4f;
		float f2=2.1f;
		float f3=f1/f2;
		System.out.println(f3);
		
	}

}
