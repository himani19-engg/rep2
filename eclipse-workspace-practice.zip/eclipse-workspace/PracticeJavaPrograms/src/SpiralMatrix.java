import java.util.Scanner;

public class SpiralMatrix {

	public static void main(String[] args) {
		/*
		 * int[][] sm= { {1 ,2, 3, 4, 5}, {6, 7, 8, 9,10}, {11,12,13,14,15},
		 * {16,17,18,19,20}, {21,22,23,24,25}, {26,27,28,29,30} };
		 */
		int[][] sm=new int[6][5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<sm.length;i++) {
			for(int j=0; j<sm[0].length;j++) {
				sm[i][j]=sc.nextInt();
			}
		}
		int rowBegin=0, colBegin=0;
		int rowEnd=sm.length-1, colEnd=sm[0].length-1;
		System.out.println(rowEnd+" "+colEnd);
		while(rowBegin<=rowEnd&&colBegin<=colEnd) {
			for(int j=colBegin;j<=colEnd;j++) {
				System.out.println(sm[rowBegin][j]);
			}
			rowBegin++;
			for(int j=rowBegin;j<=rowEnd;j++) {
				System.out.println(sm[j][colEnd]);
			}
			colEnd--;
			if(rowBegin<=rowEnd) {
				for(int j=colEnd;j>=colBegin;j--) {
					System.out.println(sm[rowEnd][j]);
				}
			}
			rowEnd--;
			if(colBegin<=colEnd) {
				for(int j=rowEnd;j>=rowBegin;j--) {
					System.out.println(sm[j][colBegin]);
				}
			}
			colBegin++;
		}
		
	}

}
