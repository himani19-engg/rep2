
public class OccurrenceWithoutLoops {

	public static void main(String[] args) {
		
		String names = "xxhixx123x";

	      int result = number(names);
	      System.out.println("number of x: " + result);
	}
	public static int number (String name)
	   {

	      int index = 0, result = 0;

	      if(name.charAt(index) == 'x')
	      {
	         result++;
	      }
	         index++;

	      if (name.trim().length() != 0& (name.length()>index))
	  
	      {
	        result+=number(name.substring(index));
	      }
	      return result;
	   }
	

}
