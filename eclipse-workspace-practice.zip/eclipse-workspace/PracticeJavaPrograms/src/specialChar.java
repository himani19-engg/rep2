import java.util.ArrayList;
import java.util.List;

public class specialChar {

	public static void main(String[] args) {
		String s="abc@3$5^87Fg%";
		char[] inputArray=s.toCharArray();
		List<Integer> indexes=new ArrayList<Integer>();
		for(int i=0;i<inputArray.length;i++) {
			char c=inputArray[i];
			if(!Character.isDigit(c)&&!Character.isLetter(c)) {
				indexes.add(i);
			}
		}
		for(int j=0;j<indexes.size();j++) {
			System.out.print(indexes.get(j)+" ");
		}
		s.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(s.replaceAll("[^a-zA-Z0-9]", ""));
		System.out.println(Character.isTitleCase('\u01f2'));
		System.out.println((char)('\u01f2'));
		System.out.println(Integer.reverse(123));
	}

}
