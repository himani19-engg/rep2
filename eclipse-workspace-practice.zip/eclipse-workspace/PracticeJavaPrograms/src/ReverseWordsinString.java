import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReverseWordsinString {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String s= br.readLine();
		//String s="My name is Himani";
		String[] s1=s.split(" ");
		String[] s2=new String[s1.length];
		int i=0;
		for(int j=s1.length-1;j>=0;j--) {
			s2[j]=s1[i];
			i++;
		}
		for(String k:s2) {
			System.out.print(k+" ");
		}
	}

}
