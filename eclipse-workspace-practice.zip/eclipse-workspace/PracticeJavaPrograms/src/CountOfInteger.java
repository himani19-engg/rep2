import java.util.Map;
import java.util.HashMap;
public class CountOfInteger {
	public static void intCount(int[] arr) {
		Map<Integer, Integer> intMap= new HashMap<Integer, Integer>();
		for(int i:arr) {
			if(intMap.containsKey(i)) {
				intMap.put(i, intMap.get(i)+1);
			} else {
				intMap.put(i, 1);
			}
		}
		System.out.println(intMap);
	}
	public static void main(String[] args) {
		int[] array= {1,2,3,2,4,1,2,7,5};
		intCount(array);

	}

}
