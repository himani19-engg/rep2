
public class CompareChar {

	public static void main(String[] args) {
		char c='a';
		char b='A';
		int x=Character.compare(c, b);
		System.out.println(Integer.toString(x));
		String s="AvFC";
		
		System.out.println(s.toLowerCase());
	}

}
