import java.util.HashMap;
import java.util.List;

public class FindMissingNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {1,2,3,4,5,7};
		String s="my name is this and this is my name";
		for(int i:arr) {
			System.out.println(i);
		}
		String[] sl=s.split(" ");
		
		HashMap<String,Integer> h=new HashMap<String,Integer>();
		for(String i:sl) {
			if(h.containsKey(i)) {
				h.put(i, h.get(i)+1);
			} else {
				h.put(i, 1);
			}
		}
		for(String s1:h.keySet()) {
			if(h.get(s1)>1) {
				System.out.println(s1+" " +h.get(s1));
			}
		}
	}

}
