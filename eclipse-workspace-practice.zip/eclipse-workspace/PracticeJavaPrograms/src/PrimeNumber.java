
public class PrimeNumber {
	public static boolean prime(int num) {
		if(num==2 || num==3) {
			return true;
		}
		for(int i=2;i<=Math.sqrt(num);i++) {
			if(num%i==0) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		int n=49;
		if(prime(n)) {
			System.out.println(n+" is a prime number");
		} else {
			System.out.println(n+" is not a prime number");
		}
		for(int i=2;i<=n;i++) {
			if(prime(i)) {
				System.out.println(i);
			}
		}
	}

}
