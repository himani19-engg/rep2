package patterns;

public class Pattern8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=4;i++) {
			for(int j=1;j<i;j++) {
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++) {
				if(i==k)
				System.out.print("*");
			}
			for(int l=4;l>=(i*2)-4;l--) {
				System.out.print(" ");
			}
			for(int m=1;m<=i;m++) {
				if(m==i) {
					System.out.print(" *");
				}
			}
			System.out.println();
		}
	}

}
