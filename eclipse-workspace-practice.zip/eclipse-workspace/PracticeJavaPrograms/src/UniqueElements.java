import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class UniqueElements {

	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5,6,2,3,1,3,4,7};
		Set<Integer> set=new HashSet<Integer>();
		for(int i=0;i<arr.length;i++) {
			set.add(arr[i]);
		}
		Integer[] out=set.toArray(new Integer[set.size()]);
		System.out.println(Arrays.toString(out));
		System.out.println(Arrays.toString(arr));
	}
	

}
