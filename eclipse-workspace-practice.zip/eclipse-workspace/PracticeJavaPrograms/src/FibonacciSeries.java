import java.util.Scanner;

public class FibonacciSeries {
	public static void fb(int N) {
		int num1=0,num2=1,num3;
		for(int i=0;i<N;i++) {
			System.out.print(num1+" ");
			num3=num1+num2;
			num1=num2;
			num2=num3;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter number of terms");
		Scanner sc=new Scanner(System.in);
		int N=sc.nextInt();
		fb(N);
		
	}

}
