
public class RemoveWhiteSpaces {

	public static void main(String[] args) {
		String s="  I am Himani Chawla   ";
		System.out.print(s.replaceAll(" ", ""));
	}

}
