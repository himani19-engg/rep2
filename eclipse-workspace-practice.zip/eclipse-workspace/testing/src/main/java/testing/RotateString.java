package testing;

public class RotateString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="HimaniChawla";
		System.out.println(str.substring(3)+str.substring(0,3));
		System.out.println(str.substring(str.length()-3)+str.substring(0,str.length()-3));
	}

}
