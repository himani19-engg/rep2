package testing;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoQA {

	public static void main(String[] args) {
		//setup the system for selenium webdriver
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		//maximize the window
		driver.manage().window().maximize();
		//navigate to demoqa website
		driver.get("https://demoqa.com/");
		//navigate to elements on site
		WebElement ele=driver.findElement(By.xpath("//*[text()='Elements']"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", ele);
		//select text box
		WebElement textBox=driver.findElement(By.xpath("//*[text()='Text Box']"));
		textBox.click();
		//enter name in full name field
		WebElement fullName=driver.findElement(By.id("userName"));
		fullName.sendKeys("Philip Jones");
		//enter email in user name field
		WebElement userName=driver.findElement(By.id("userEmail"));
		userName.sendKeys("Philip.Jones@gmail.com");
		//enter current address in current address field
		WebElement currentAddress=driver.findElement(By.id("currentAddress"));
		currentAddress.sendKeys("Madrid, Spain");
		//enter permanent address in current address field
		WebElement permanentAddress=driver.findElement(By.id("permanentAddress"));
		permanentAddress.sendKeys("New York, USA");
		//click submit button
		WebElement submit=driver.findElement(By.id("submit"));
		submit.click();
		
		//select check box
		WebElement checkBox=driver.findElement(By.xpath("//*[text()='Check Box']"));
		checkBox.click();
		WebElement chBox=driver.findElement(By.className("rct-checkbox"));
		chBox.click();
		
		//select radio button
		WebElement radioButton=driver.findElement(By.xpath("//*[text()='Radio Button']"));
		//radioButton.click();
		JavascriptExecutor executor1 = (JavascriptExecutor) driver;
		executor1.executeScript("arguments[0].click();", radioButton);
		WebElement impressive=driver.findElement(By.id("impressiveRadio"));
		//impressive.click();
		executor1.executeScript("arguments[0].click();", impressive);

		
	}

}
