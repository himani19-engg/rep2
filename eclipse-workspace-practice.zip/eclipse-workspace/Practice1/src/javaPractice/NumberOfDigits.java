package javaPractice;

import java.util.Scanner;

public class NumberOfDigits {
	public static int noOfDig(int num) {
		int n=0;
		while(num!=0) {
			n+=1;
			num=num/10;
		}
		return n;
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int i=s.nextInt();
		System.out.println(noOfDig(i));

	}

}
