package javaPractice;

import java.util.Scanner;

public class ReverseANumber {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int i=s.nextInt();
		int j=i;
		int rev=0;
		while(i!=0) {
			rev=rev*10+i%10;
			i=i/10;
		}
		System.out.println(rev);
		if(rev==j) {
			System.out.println("This number is palindrome");
		} else {
			System.out.println("This number is not palindrome");
		}
	}

}
