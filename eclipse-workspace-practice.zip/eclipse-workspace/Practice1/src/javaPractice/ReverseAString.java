package javaPractice;

import java.util.Scanner;

public class ReverseAString {
	public static String revString(String str) {
		String rev="";
		for(int i=str.length()-1;i>=0;i--) {
			rev=rev+str.charAt(i);
		}
		return rev;
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String name=s.next();
		System.out.println(ReverseAString.revString(name));
		
		StringBuilder sb=new StringBuilder(name);
		sb.reverse();
		System.out.println(sb.toString());
		System.out.println(String.valueOf(sb));
		
	}

}
